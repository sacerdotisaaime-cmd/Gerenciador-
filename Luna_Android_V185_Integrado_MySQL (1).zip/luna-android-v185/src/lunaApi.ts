import { Capacitor, CapacitorHttp } from '@capacitor/core';

const STORAGE_KEY = 'luna_api_base_url';
const DEFAULT_BASE_URL = import.meta.env.VITE_LUNA_API_BASE_URL ||
  'http://192.168.1.19/gestao-aime-comercial/sistema_teste/public/api/v1';

export type LunaUser = { id: string; name: string; email: string; organization?: { id: string; name: string; role: string } };
export type LunaSession = { access_token: string; token_type: 'Bearer'; expires_at: number; user: LunaUser };
export type LunaLoginResult = {
  access_token: string; token_type: 'Bearer' | string; expires_in: number;
  user: { id: string; name: string; email: string };
  organization: { id: string; name: string; role: string };
};
export type LunaSnapshotResult = { payload: Record<string, unknown>; updated_at: string; organization_id?: string };

export function getLunaApiBaseUrl(): string {
  const saved = localStorage.getItem(STORAGE_KEY);
  return (saved || DEFAULT_BASE_URL).replace(/\/+$/, '');
}

export function setLunaApiBaseUrl(value: string): string {
  const normalized = value.trim().replace(/\/+$/, '');
  if (!/^https?:\/\//i.test(normalized)) throw new Error('Informe um endereço começando com http:// ou https://.');
  const host = normalized.match(/^https?:\/\/([^/:]+)/i)?.[1] || '';
  if (/^\d+\.\d+\.\d+\.\d+$/.test(host)) {
    const octets = host.split('.').map(Number);
    if (octets.some((n) => n < 0 || n > 255)) throw new Error('IP inválido. Confira os quatro números do endereço.');
  }
  if (!/\/api\/v1$/i.test(normalized)) throw new Error('O endereço precisa terminar em /api/v1.');
  localStorage.setItem(STORAGE_KEY, normalized);
  return normalized;
}

async function request<T>(path: string, options: {
  method?: 'GET' | 'POST' | 'PUT' | 'DELETE'; token?: string; body?: unknown; idempotencyKey?: string;
} = {}): Promise<T> {
  const url = `${getLunaApiBaseUrl()}/${path.replace(/^\/+/, '')}`;
  const headers: Record<string, string> = { Accept: 'application/json', 'Content-Type': 'application/json' };
  if (options.token) headers.Authorization = `Bearer ${options.token}`;
  if (options.idempotencyKey) headers['Idempotency-Key'] = options.idempotencyKey;
  const method = options.method || 'GET';
  let status = 0;
  let payload: any;
  if (Capacitor.isNativePlatform()) {
    const response = await CapacitorHttp.request({
      url, method, headers, data: options.body,
      connectTimeout: 20000, readTimeout: 60000,
    });
    status = response.status;
    payload = response.data;
  } else {
    const response = await fetch(url, {
      method, headers,
      body: options.body === undefined ? undefined : JSON.stringify(options.body),
      cache: 'no-store',
    });
    status = response.status;
    payload = await response.json().catch(() => ({}));
  }
  if (typeof payload === 'string') {
    try { payload = JSON.parse(payload); } catch { /* mensagem tratada abaixo */ }
  }
  if (status < 200 || status >= 300) {
    const message = payload?.error?.message || `A API Luna respondeu HTTP ${status}.`;
    const error = new Error(message) as Error & { status?: number; code?: string };
    error.status = status;
    error.code = payload?.error?.code;
    throw error;
  }
  if (!payload || typeof payload !== 'object' || !('data' in payload)) throw new Error('Resposta inesperada da API Luna.');
  return payload.data as T;
}

export const lunaApi = {
  health: () => request<{ service: string; version: string; status: string; database: string; scope: string }>('health'),
  login: (email: string, password: string, deviceName = 'Luna Android V185') => request<LunaLoginResult>('auth/login', {
    method: 'POST', body: { email, password, device_name: deviceName },
  }),
  me: (token: string) => request<{ user: LunaLoginResult['user']; organization: LunaLoginResult['organization'] }>('auth/me', { token }),
  logout: (token: string) => request<{ logged_out: boolean }>('auth/logout', { method: 'POST', token }),
  getSnapshot: (token: string) => request<LunaSnapshotResult>('snapshot', { token }),
  saveSnapshot: (token: string, payload: Record<string, unknown>) => request<{ saved: boolean; collections_received: number; updated_at: string }>(
    'snapshot', { method: 'POST', token, body: { payload } },
  ),
};
