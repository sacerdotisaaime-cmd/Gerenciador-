# V140 — Alerta em tela + diagnóstico de notificações

- Alerta em tela quando o aplicativo está aberto e um compromisso chega ao horário.
- Painel 🐞 Avisos com permissões, alarmes, avisos pendentes, próximo agendamento e último resultado da programação nativa.
- Teste de notificação nativa em 10 segundos.
- Registro de erros de programação/fallback.
- Preserva reagendamento e demais funções da V139.

Observação: o alerta em tela depende do aplicativo estar visível. Para aplicativo fechado, a entrega depende das notificações/alarmes nativos e das permissões do Android.
