# Luna Android V185 + Luna Web/MySQL

## Objetivo e arquitetura

Esta versão usa o código-fonte do V185 como aplicativo principal (o `src/main.tsx` monta o `src/App.tsx` completo). Mantém o layout, os menus e os módulos existentes, substituindo a autenticação e a ponte do snapshot Supabase por uma compatibilidade com a Luna API.

- Android: login Luna, armazenamento local persistente do V185 e sincronização periódica.
- Web: mantém o sistema comercial e sua interface existente.
- Backend: a API lê/grava o mesmo `tenant_records` e `tenant_settings` usado pelo Web.
- Isolamento: a organização é obtida exclusivamente do token Bearer; o cliente não escolhe `organization_id`.
- Aplicativo: `com.sacerdotisaaime.luna`, separado do aplicativo individual antigo.

## Endereço de API local

`http://192.168.1.19/gestao-aime-comercial/sistema_teste/public/api/v1`

A tela de login contém **Configurações de conexão**, onde o endereço pode ser alterado e testado. O IP `192.168.1.19` é o IP local informado para desenvolvimento; pode mudar se o roteador renovar o endereço do PC.

HTTP é permitido somente para o teste na rede local. Para publicar na internet, configure HTTPS e altere a URL da API.

## Coleções

O V185 usa 39 coleções de dados. A API comercial aceita essas 39 e mais quatro coleções que já pertenciam ao Web (`gestao_client_credits`, `gestao_credit_cards`, `gestao_financial_categories`, `gestao_financial_setup`). O adaptador grava cada registro como JSON versionado por organização nas tabelas comuns `tenant_records` e `tenant_settings`; não são 43 tabelas SQL de domínio.

A ponte de sincronização:
- mescla registros identificados por `id` e horário de atualização;
- tenta novamente quando há conflito HTTP 409 entre dispositivos;
- propaga tombstones (exclusões lógicas) para evitar ressuscitar registros apagados;
- preserva a lixeira do V185 e marca restaurações/remoções da própria lixeira;
- mantém coleções exclusivas do Web que o V185 não envia.

## Instalação no Web/XAMPP

1. Faça backup da pasta Web e exporte o banco MySQL.
2. Extraia o pacote `Luna_Web_MySQL_Integrado_PATCH.zip` na pasta `C:\xampp\htdocs\gestao-aime-comercial` (ou pasta equivalente). O ZIP contém apenas arquivos alterados dentro de `sistema_teste/`.
3. **Não substitua** `sistema_teste/app/config.php` nem `sistema_teste/legacy_original/app/config.php`. Esses dois arquivos contêm a configuração privada da instalação e foram omitidos do pacote.
4. Mantenha ambos os sistemas apontando para o mesmo banco `gestao_aime_plataforma`.
5. Não execute `database/schema.sql` novamente em uma base existente. Antes, confirme que ela já possui `tenant_records`, `tenant_settings`, `api_tokens`, `sync_changes`, `organizations`, `organization_members` e `subscriptions`.
6. Confirme no navegador do celular, usando a mesma rede Wi-Fi, que `/public/api/v1/health` responde `status=online` e `database=connected`.

## Compilação Android no GitHub Actions

1. Coloque `Luna_Android_V185_Integrado_MySQL.zip` na raiz do repositório GitHub. O workflow falha se encontrar mais de um ZIP dentro dos dois primeiros níveis; deixe somente esse ZIP nesse local.
2. Substitua o conteúdo de `.github/workflows/build-android-release.yml` pelo arquivo `build-android-release-LUNA-V185-INTEGRADO.yml` fornecido.
3. Preserve os GitHub Secrets de assinatura: `ANDROID_KEYSTORE_BASE64`, `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS` e `ANDROID_KEY_PASSWORD`.
4. Execute o workflow manualmente. Ele seleciona explicitamente `app/luna-android-v185`, gera o projeto Android com Capacitor, ativa HTTP local no Manifest, recria as integrações nativas do V185 e compila o APK assinado.
5. Instale o APK Luna. O novo `applicationId` permite manter o aplicativo individual antigo instalado em paralelo.

## Teste de homologação recomendado

Antes de inserir dados reais, use registros fictícios:
1. Entre no Android com a mesma conta comercial utilizada no Web.
2. Cadastre um consulente no Android e confirme no Web.
3. Edite esse consulente no Web e confirme no Android.
4. Teste consulta/atendimento, financeiro, agenda, estoque e trabalho nos dois lados.
5. Teste exclusão e restauração pela lixeira em ambos os lados.
6. Desconecte o Wi-Fi, faça uma alteração local, reconecte e aguarde a sincronização.
7. Crie duas contas/organizações de teste e confirme que uma não consegue ler os dados da outra.

## Limites que ainda exigem homologação

- O pacote contém integração de código-fonte. Não foi possível gerar o APK neste ambiente: a instalação local de dependências npm excedeu o tempo disponível. O workflow GitHub é quem fará a compilação real.
- PHP passou por validação sintática, e os arquivos TypeScript modificados passaram por transpilação/sintaxe; isso não substitui um `npm run build`, uma execução no XAMPP com PDO MySQL nem testes com duas sessões reais.
- O snapshot tem limite de 64 MB por requisição. Fotos e áudios embutidos nos registros continuam no formato V185, mas bibliotecas grandes podem atingir esse limite. Para volumes grandes, o próximo passo é implementar upload/download de mídias separado em `media_files`.
- A sincronização usa snapshots JSON versionados por registro. É uma ponte de compatibilidade para reaproveitar o V185 sem redesenhar os módulos; a evolução para APIs de domínio e tabelas normalizadas pode ser feita depois da homologação.
- Dados locais/Supabase da instalação individual antiga não são importados automaticamente. O novo app inicia separado e usa a organização da conta Luna.


**Compatibilidade Android:** `@capacitor/barcode-scanner` está fixado em `2.2.1`, versão da linha 2 compatível com Capacitor 7. Não atualizar para 3.x sem migrar primeiro todo o projeto para Capacitor 8.
