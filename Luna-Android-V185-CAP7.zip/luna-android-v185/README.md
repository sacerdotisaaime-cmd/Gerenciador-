# Gestão Sacerdotisa Aime — V8

Projeto Vite + React + Capacitor para gestão de atendimentos, clientes, financeiro, agenda, compras, estoque e registros das atividades.

A V8 é baseada na V7 e contém correções específicas no fluxo nativo de permissões de **Contatos** e **Microfone** para Android.

Consulte `README_V8.md` para o histórico das correções e o procedimento de teste.


## V12
Primeira integração com Supabase: autenticação e sincronização inicial de clientes, consultas e perguntas.


## V45
See README_V45.md for the Organization/rotinas/saúde implementation.


**Compatibilidade Android:** `@capacitor/barcode-scanner` está fixado em `2.2.1`, versão da linha 2 compatível com Capacitor 7. Não atualizar para 3.x sem migrar primeiro todo o projeto para Capacitor 8.
