# Debug de sincronização SQL — V185

Foi adicionado o painel **Diagnóstico de sincronização** na tela de entrada, dentro das configurações de conexão.

O diagnóstico executa somente leituras:
- GET /health: estado da API e do banco;
- GET /auth/me: validação do token já armazenado;
- GET /snapshot: download e contagem de coleções/registros;
- identifica ausência de sessão local;
- permite copiar relatório técnico.

Nenhuma operação POST/PUT/DELETE é executada pelo painel. Nenhum dado é criado, sobrescrito ou apagado.

Para acessar: tela Entrar → Diagnóstico de sincronização → Executar diagnóstico.
