# V149.2 — NFC-e SP: parser corrigido + diagnóstico detalhado

Correções desta versão:

- O parser da NFC-e de São Paulo aceita tanto `Qtde.` quanto `Qtd.`.
- O parser aceita espaço antes do `)` em `(Código: 52801 )`.
- O parser reconhece `Valor a pagar R$: 273,99` e variações equivalentes.
- Mantida a aceitação de QR Code, URL completa `ConsultaQRCode.aspx?p=...|3|1` e chave de 44 dígitos.
- Em caso de falha, o aplicativo abre automaticamente uma janela **Diagnóstico da importação NF-e**.
- O diagnóstico mostra URL consultada, transporte usado, HTTP, URL final, content-type, tamanho da resposta, marcadores encontrados, formato detectado, quantidade de itens retornados pelo parser e erro específico.
- Há opção de copiar o diagnóstico para facilitar a próxima correção.

Importante: a janela de diagnóstico só aparece quando a importação não consegue concluir. Ela não interfere no funcionamento normal.
