# V147 — Standby + NF-e/NFC-e corrigidos

## Standby / lixeira
- Mantém um único registro por atendimento e o mesmo ID durante o ciclo ativo → standby → retomada.
- Remove o rascunho auxiliar quando o atendimento já foi salvo oficialmente em Standby.
- Deduplica registros de Standby acidentalmente repetidos com o mesmo consulente, título e momento de criação.
- A lixeira passa a guardar o atendimento completo em `gestao_trash_consultations` e apenas metadados no índice da lixeira.
- A restauração usa a versão completa mais recente, preservando texto, perguntas, fotos e áudios.
- O novo armazenamento da lixeira também participa da sincronização/reset do Supabase.

## NF-e / NFC-e
- Leitura do QR continua funcionando pela câmera e agora inicia a consulta automaticamente.
- Extração da chave de 44 dígitos foi ampliada para URLs/parametros de QR Code.
- No Android, a consulta do link usa `CapacitorHttp` para evitar a limitação de CORS do WebView quando a SEFAZ permitir acesso.
- O app tenta interpretar XML oficial da NF-e/NFC-e e importar estabelecimento, data, itens, quantidade, unidade, preço unitário e valor final da nota.
- Também foi incluída importação direta de arquivo XML como fallback.
- Quando a SEFAZ exige captcha ou não fornece dados estruturados à consulta automática, o link e a chave continuam salvos para conferência manual.

## Validação
- TypeScript: aprovado com `tsc -p tsconfig.json --noEmit`.
- O build completo não foi executado neste ambiente porque a instalação dos pacotes externos excedeu o tempo disponível; o workflow GitHub continua responsável por instalar as dependências e gerar o APK.
