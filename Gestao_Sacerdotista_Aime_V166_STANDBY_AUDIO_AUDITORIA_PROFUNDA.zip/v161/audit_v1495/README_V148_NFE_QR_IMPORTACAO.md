# V148 — QR NFC-e e importação de itens

- Leitura QR com fallback de campos do resultado do scanner.
- Solicitação explícita de câmera quando disponível.
- Chave de 44 dígitos de SP pode gerar automaticamente a URL pública da NFC-e.
- Parser reforçado para itens renderizados em DIV/SPAN, além de tabelas.
- Abertura da nota usa a URL pública de SP quando só a chave estiver disponível.
- XML continua como fallback para importação 100% estruturada.

Observação: a consulta pública da SEFAZ pode exigir captcha/bloquear automação; nesse caso a nota continua podendo ser aberta e o XML pode ser importado.
