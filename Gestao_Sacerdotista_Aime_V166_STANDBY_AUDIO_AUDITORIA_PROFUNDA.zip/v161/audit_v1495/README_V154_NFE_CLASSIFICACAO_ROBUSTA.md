# V154 — NFC-e classificação robusta dos produtos

Esta versão mantém a consulta/importação da NFC-e da V153 e corrige especificamente o parser do texto renderizado da SEFAZ.

## Problema corrigido

A V153 já conseguia consultar a NFC-e e encontrar o conteúdo da nota, mas o parser analisava janelas de várias linhas com uma expressão regular aberta. Isso podia fazer a captura começar no meio de um item ou em textos da nota que não eram produtos, gerando registros como `Qtde...`, `CNPJ...` ou trechos do cabeçalho.

## Correção

O parser agora:

- reconhece o início de um produto somente quando encontra uma linha com `Nome do produto (Código: XXXXX)`;
- coleta quantidade, unidade, preço unitário e valor total apenas nas linhas imediatamente seguintes daquele produto;
- exige quantidade e valor total válidos para aceitar o registro;
- ignora cabeçalho, CNPJ, endereço, protocolos, forma de pagamento e demais seções;
- evita duplicação de itens;
- mantém a importação por XML como fonte estruturada e prioritária.

### Exemplo da NFC-e testada

A estrutura mostrada nas capturas é interpretada como 4 produtos:

1. CONTRA FILE BOV GRILL kg — 3,454 KG — R$ 67,90 — R$ 234,53
2. CR DT TANDY 50G MELANCIA — 1 UN — R$ 8,99 — R$ 8,99
3. ESC DENT ORAL-B INF STAGES 1 4-24 MESES — 1 UN — R$ 25,98 — R$ 25,98
4. SAB DAVENE 90G AVEIA CLASSICO — 1 UN — R$ 4,49 — R$ 4,49

O total desses quatro itens é R$ 273,99, igual ao valor mostrado na NFC-e das capturas.
