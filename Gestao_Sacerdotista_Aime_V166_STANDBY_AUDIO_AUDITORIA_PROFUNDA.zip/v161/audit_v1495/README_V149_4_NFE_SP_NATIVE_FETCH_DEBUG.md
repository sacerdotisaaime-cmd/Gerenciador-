# V149.4 — NFC-e SP: consulta nativa + diagnóstico

Correção principal: implementa de fato `PermissionBridge.fetchNfePage()` no Android. A versão anterior declarava a chamada no TypeScript, mas o plugin nativo não possuía o método, causando `fetchNfePage() is not implemented on android`.

O bridge usa `HttpURLConnection`, preserva cookies básicos, segue redirecionamentos, envia User-Agent/Accept semelhantes a navegador, retorna status, URL final, content-type, bytes e corpo para o parser.

Também mantém a janela de diagnóstico detalhado para identificar HTTP, transporte e etapa do parser.

Aceita QR completo, URL `ConsultaQRCode.aspx?p=CHAVE|3|1` e chave de 44 dígitos.
