# V149.3 — Edição completa de tiragens/atendimentos

## Alteração principal
Na aba **Serviços → Tiragens**, cada tiragem concluída/registrada agora possui o botão **✏️ Editar**.

Ao editar uma tiragem, o aplicativo abre o atendimento completo e permite continuar trabalhando no mesmo registro, sem criar uma nova consulta.

### Dados gerais editáveis
- consulente
- título da tiragem/atendimento
- valor total
- moeda
- prioridade 1–5
- agendamento (data e horário)
- vínculo com trabalho
- leitura pré-trabalho
- observações/contexto
- status de pagamento e data de pagamento

### Conteúdo da tiragem
Na própria tela do atendimento continuam disponíveis as ações existentes para:
- editar o texto das perguntas;
- editar observações;
- adicionar pergunta extra;
- excluir perguntas mantendo a numeração;
- adicionar/remover fotos;
- adicionar/remover áudios;
- mover mídias entre locais;
- editar resposta da consulente;
- adicionar/remover fotos e áudios da resposta;
- editar informações recebidas e suas mídias.

As alterações são feitas no registro original pelo `updateConsultation`, preservando o ID e o histórico, sem duplicar o atendimento.

## Navegação
Também foi incluído **✏️ Editar atendimento completo** no histórico expandido das tiragens.
