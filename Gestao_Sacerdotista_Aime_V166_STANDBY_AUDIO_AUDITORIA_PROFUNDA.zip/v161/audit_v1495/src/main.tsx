import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.tsx'
import AppErrorBoundary from './AppErrorBoundary'
import { Capacitor } from '@capacitor/core'
import { StatusBar, Style } from '@capacitor/status-bar'
import { persistentStorageReady } from './persistentStorage'

if (Capacitor.isNativePlatform()) {
  void StatusBar.setBackgroundColor({ color: '#C52E7E' })
  void StatusBar.setStyle({ style: Style.Light })
}

const mountApp = async () => {
  try { await persistentStorageReady; } catch (error) { console.warn('Persistência inicial', error); }
  createRoot(document.getElementById('root')!).render(
    <StrictMode>
      <AppErrorBoundary><App /></AppErrorBoundary>
    </StrictMode>,
  )
}
void mountApp()
