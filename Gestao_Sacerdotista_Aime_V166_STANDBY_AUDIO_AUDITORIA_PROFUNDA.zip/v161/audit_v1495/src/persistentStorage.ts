const DB_NAME = "gestao-aime-persistent-v2";
const STORE_NAME = "kv";
const MARKER = "__GESTAO_IDB_VALUE__:v2";
const MEDIA_RE = /data:[^;,]+(?:;[^,]*)?;base64,/i;
const LARGE_THRESHOLD = 320 * 1024;

type KVRow = { key: string; value: string; updatedAt: number };

const cache = new Map<string, string>();
const writeQueues = new Map<string, Promise<void>>();
let initialized = false;
let dbPromise: Promise<IDBDatabase> | null = null;

const canUseIndexedDb = () => typeof indexedDB !== "undefined";

const openDb = (): Promise<IDBDatabase> => {
  if (!canUseIndexedDb()) return Promise.reject(new Error("INDEXEDDB_UNAVAILABLE"));
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) db.createObjectStore(STORE_NAME, { keyPath: "key" });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error("PERSISTENT_STORAGE_OPEN_FAILED"));
  });
  return dbPromise;
};

const idbGetAll = async (): Promise<KVRow[]> => {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const request = db.transaction(STORE_NAME, "readonly").objectStore(STORE_NAME).getAll();
    request.onsuccess = () => resolve(Array.isArray(request.result) ? request.result as KVRow[] : []);
    request.onerror = () => reject(request.error || new Error("PERSISTENT_STORAGE_READ_FAILED"));
  });
};

const idbPut = async (row: KVRow) => {
  const db = await openDb();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readwrite");
    tx.objectStore(STORE_NAME).put(row);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error || new Error("PERSISTENT_STORAGE_WRITE_FAILED"));
  });
};

const idbDelete = async (key: string) => {
  const db = await openDb();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readwrite");
    tx.objectStore(STORE_NAME).delete(key);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error || new Error("PERSISTENT_STORAGE_DELETE_FAILED"));
  });
};

const shouldVault = (raw: string) => raw.length >= LARGE_THRESHOLD || MEDIA_RE.test(raw);
const hasMarker = (raw: string | null) => raw === MARKER;

/**
 * Carrega primeiro os valores persistidos no IndexedDB e depois migra,
 * sem apagar nada, os valores grandes/mídias que ainda estejam no localStorage.
 * Isso precisa acontecer antes do React montar a árvore para que readStorage()
 * continue síncrono para o restante do aplicativo.
 */
export const initializePersistentStorage = async () => {
  if (initialized) return;
  if (!canUseIndexedDb()) {
    initialized = true;
    return;
  }

  try {
    const rows = await idbGetAll();
    for (const row of rows) {
      if (row?.key && typeof row.value === "string") cache.set(row.key, row.value);
    }
  } catch (error) {
    console.warn("Persistência IndexedDB indisponível; usando localStorage", error);
  }

  try {
    const migrate: Array<{ key: string; raw: string }> = [];
    for (let i = 0; i < localStorage.length; i += 1) {
      const key = localStorage.key(i);
      if (!key) continue;
      const raw = localStorage.getItem(key);
      if (raw == null || hasMarker(raw) || !shouldVault(raw)) continue;
      // Se já existe uma versão no IDB, ela é a fonte mais recente.
      if (cache.has(key)) continue;
      migrate.push({ key, raw });
    }
    for (const item of migrate) {
      cache.set(item.key, item.raw);
      try {
        await idbPut({ key: item.key, value: item.raw, updatedAt: Date.now() });
        localStorage.setItem(item.key, MARKER);
      } catch (error) {
        // Mantém a cópia original no localStorage se a migração falhar.
        console.warn(`Não foi possível migrar ${item.key} para IndexedDB`, error);
      }
    }
  } catch (error) {
    console.warn("Falha na migração inicial de persistência", error);
  }

  initialized = true;
};

/** Retorna o JSON persistido completo, inclusive valores guardados no IndexedDB. */
export const getPersistentRaw = (key: string): string | null => {
  try {
    const raw = localStorage.getItem(key);
    if (hasMarker(raw)) return cache.get(key) || null;
    if (raw !== null) return raw;
    return cache.get(key) || null;
  } catch {
    return cache.get(key) || null;
  }
};

export const getPersistentKeys = (): string[] => {
  const keys = new Set<string>();
  try {
    for (let i = 0; i < localStorage.length; i += 1) {
      const key = localStorage.key(i);
      if (key) keys.add(key);
    }
  } catch {}
  for (const key of cache.keys()) keys.add(key);
  return [...keys];
};

/**
 * Persiste uma string JSON. Mídias e registros grandes vão para IndexedDB;
 * localStorage recebe somente um marcador pequeno, evitando o limite do WebView.
 */
export const setPersistentRaw = (key: string, raw: string): Promise<void> => {
  const previous = writeQueues.get(key) || Promise.resolve();
  const next = previous.catch(() => undefined).then(async () => {
    cache.set(key, raw);
    if (shouldVault(raw) && canUseIndexedDb()) {
      await idbPut({ key, value: raw, updatedAt: Date.now() });
      try { localStorage.setItem(key, MARKER); } catch {}
      return;
    }
    try {
      localStorage.setItem(key, raw);
    } catch (error) {
      // Última defesa: se o localStorage estiver cheio, o valor ainda fica salvo no IDB.
      if (canUseIndexedDb()) {
        await idbPut({ key, value: raw, updatedAt: Date.now() });
        try { localStorage.setItem(key, MARKER); } catch {}
      } else {
        throw error;
      }
    }
  });
  writeQueues.set(key, next);
  return next;
};

export const removePersistentKey = (key: string): Promise<void> => {
  const previous = writeQueues.get(key) || Promise.resolve();
  const next = previous.catch(() => undefined).then(async () => {
    cache.delete(key);
    try { localStorage.removeItem(key); } catch {}
    if (canUseIndexedDb()) {
      try { await idbDelete(key); } catch {}
    }
  });
  writeQueues.set(key, next);
  return next;
};

export const persistentStorageMarker = MARKER;

export const persistentStorageReady = initializePersistentStorage();
