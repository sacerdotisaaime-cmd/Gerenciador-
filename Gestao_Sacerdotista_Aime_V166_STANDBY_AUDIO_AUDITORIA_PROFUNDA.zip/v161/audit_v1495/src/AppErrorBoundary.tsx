import React from "react";

type Props = { children: React.ReactNode };
type State = { error: Error | null; componentStack: string };

export default class AppErrorBoundary extends React.Component<Props, State> {
  state: State = { error: null, componentStack: "" };
  static getDerivedStateFromError(error: Error): Partial<State> { return { error }; }
  componentDidCatch(error: Error, info: React.ErrorInfo) {
    console.error("Erro fatal de renderização do aplicativo", error, info);
    this.setState({ componentStack: info.componentStack || "(componentStack indisponível)" });
    try {
      localStorage.setItem("gestao_aime_last_render_error", JSON.stringify({
        message: error.message,
        stack: error.stack || "",
        componentStack: info.componentStack || "",
        at: new Date().toISOString(),
      }));
    } catch {}
  }
  render() {
    if (!this.state.error) return this.props.children;
    return <div style={{ minHeight: "100vh", boxSizing: "border-box", padding: 24, display: "grid", placeItems: "center", background: "#fff7fb", fontFamily: "system-ui,sans-serif", color: "#3b2033" }}>
      <div style={{ maxWidth: 420, background: "white", borderRadius: 22, padding: 24, boxShadow: "0 14px 40px rgba(80,30,60,.12)" }}>
        <div style={{ fontSize: 28 }}>⚠️</div>
        <h2 style={{ margin: "8px 0" }}>O aplicativo encontrou um erro</h2>
        <p style={{ opacity: .75, lineHeight: 1.5 }}>O login foi concluído, mas uma tela do aplicativo encontrou um problema. Seus dados locais não foram apagados.</p>
        <details><summary>Detalhes técnicos</summary><pre style={{ whiteSpace: "pre-wrap", fontSize: 12, marginTop: 10 }}>{this.state.error.message}</pre>{this.state.componentStack && <><div style={{ marginTop: 10, fontWeight: 800 }}>Componente:</div><pre style={{ whiteSpace: "pre-wrap", fontSize: 11, marginTop: 6 }}>{this.state.componentStack}</pre></>}</details>
        <button onClick={() => window.location.reload()} style={{ marginTop: 16, width: "100%", padding: 13, border: 0, borderRadius: 12, background: "#b94c83", color: "white", fontWeight: 800 }}>Reabrir aplicativo</button>
      </div>
    </div>;
  }
}
