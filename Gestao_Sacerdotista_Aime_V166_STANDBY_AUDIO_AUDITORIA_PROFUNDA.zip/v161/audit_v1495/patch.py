from pathlib import Path
import re, zipfile
root=Path('/mnt/data/v145')
app=root/'src/App.tsx'
s=app.read_text()
# Channel bump
s=s.replace('const AGENDA_NOTIFICATION_CHANNEL_ID = "gestao-agenda-v144";', 'const AGENDA_NOTIFICATION_CHANNEL_ID = "gestao-agenda-v145";')
# Replace foreground listener block with robust native foreground notification + modal mapping
old='''useEffect(() => {\n  if (!Capacitor.isNativePlatform()) return;\n  let handle:any;\n  void LocalNotifications.addListener("localNotificationReceived", (notification:any) => {\n    try {\n      const extra=notification?.extra || {};\n      const agendaId=extra?.agendaId ? String(extra.agendaId) : "";\n      const target=agendaId ? agendaItems.find(a=>a.id===agendaId) : undefined;\n      if (target && target.notify && !target.completed && !target.deletedAt) setAgendaDueAlert(target);\n    } catch {}\n  }).then(x=>{handle=x;});\n  return ()=>{try{handle?.remove?.();}catch{}};\n}, [agendaItems]);'''
new='''useEffect(() => {\n  if (!Capacitor.isNativePlatform()) return;\n  let handle:any;\n  void LocalNotifications.addListener("localNotificationReceived", async (notification:any) => {\n    try {\n      const extra=notification?.extra || {};\n      const agendaId=extra?.agendaId ? String(extra.agendaId) : "";\n      const notificationId=Number(notification?.id);\n      const target=agendaId\n        ? agendaItems.find(a=>a.id===agendaId)\n        : agendaItems.find(a=>agendaNotificationId(a)===notificationId);\n      if (target && target.notify && !target.completed && !target.deletedAt) {\n        const content=agendaNotificationContent(target);\n        // Em primeiro plano o Android pode entregar o evento ao WebView sem exibir\n        // a notificação na barra. O bridge nativo recria o aviso imediatamente,\n        // preservando som, vibração e detalhes.\n        try {\n          await PermissionBridge.showForegroundAgendaNotification?.({\n            title:content.title, body:content.body, notificationId:notificationId || agendaNotificationId(target),\n          });\n        } catch {}\n        setAgendaDueAlert(target);\n      }\n    } catch {}\n  }).then(x=>{handle=x;});\n  return ()=>{try{handle?.remove?.();}catch{}};\n}, [agendaItems, clients, consultations]);'''
if old not in s: raise SystemExit('listener block not found')
s=s.replace(old,new)
# Remove visibility gate and use robust local parser in due checker
s=s.replace('''    if (typeof document !== "undefined" && document.visibilityState !== "visible") return;\n    const now = Date.now();''','''    const now = Date.now();''')
s=s.replace('''      .map(a => ({a, at: new Date(`${a.date}T${String(a.time).slice(0,5)}:00`).getTime()}))''','''      .map(a => ({a, at: agendaLocalDateTime(a.date, a.time).getTime()}))''')
# Enrich modal
old_modal='''{agendaDueAlert && <Modal title="🔔 Aviso de agenda" onClose={()=>setAgendaDueAlert(null)} priority={12000}>\n<div style={{display:"grid",gap:12}}>\n<div style={{padding:18,borderRadius:18,background:"#f8e8f1",textAlign:"center"}}><div style={{fontSize:28}}>⏰</div><strong style={{fontSize:21}}>Ei! Você tem um compromisso agora.</strong><div style={{marginTop:8,fontSize:17}}>{agendaDueAlert.title}</div><div style={{marginTop:6,fontWeight:800,color:"#b84d83"}}>{agendaDueAlert.date} · {String(agendaDueAlert.time).slice(0,5)}</div></div>\n<button type="button" style={styles.primaryButtonLarge} onClick={()=>setAgendaDueAlert(null)}>✓ Entendi</button>\n<button type="button" style={styles.secondaryButtonLarge} onClick={()=>{setAgendaDueAlert(null);setAgendaDebugOpen(true);}}>🐞 Ver diagnóstico</button>\n</div></Modal>}'''
new_modal='''{agendaDueAlert && <Modal title="🔔 Aviso de agenda" onClose={()=>setAgendaDueAlert(null)} priority={12000}>\n{(()=>{const content=agendaNotificationContent(agendaDueAlert); return <div style={{display:"grid",gap:12}}>\n<div style={{padding:18,borderRadius:18,background:"#f8e8f1",textAlign:"center"}}><div style={{fontSize:28}}>⏰</div><strong style={{fontSize:21}}>Ei! Você tem um compromisso agora.</strong><div style={{marginTop:8,fontSize:17}}>{agendaDueAlert.title}</div><div style={{marginTop:6,fontWeight:800,color:"#b84d83"}}>{agendaDueAlert.date} · {String(agendaDueAlert.time).slice(0,5)}</div></div>\n{content.clientName&&<div style={styles.card}><strong>👤 Consulente</strong><div style={{marginTop:4}}>{content.clientName}</div></div>}\n<div style={styles.card}><strong>⭐ Prioridade</strong><div style={{marginTop:4}}>{content.priority}/5</div></div>\n{content.description&&<div style={styles.card}><strong>📝 Descrição</strong><div style={{marginTop:4,whiteSpace:"pre-wrap"}}>{content.description}</div></div>}\n<button type="button" style={styles.primaryButtonLarge} onClick={()=>setAgendaDueAlert(null)}>✓ Entendi</button>\n</div>})()}\n</Modal>}'''
if old_modal not in s: raise SystemExit('modal block not found')
s=s.replace(old_modal,new_modal)
# Remove 10-second test button only
s=re.sub(r'\n<button type="button" style=\{styles\.primaryButtonLarge\} onClick=\{async\(\)=>\{try\{if\(!Capacitor\.isNativePlatform\(\)\).*?Testar notificação em 10 segundos</button>', '', s, count=1)
# label audio permission
s=s.replace('{key:"microphone",label:"🎙️ Microfone"}', '{key:"microphone",label:"🎙️ Áudio / Microfone"}')
# onboarding wording
s=s.replace('''try { const m=await PermissionBridge.requestMicrophone(); microphone=m.granted; } catch {}''','''try { const m=await PermissionBridge.requestMicrophone(); microphone=m.granted; } catch {}''')
app.write_text(s)

# Patch workflow Java template
wf=root/'.github/workflows/build-android-release.yml'
w=wf.read_text()
w=w.replace('name: Build Android APK - V144 - ALERTA + ALARME + SOM CORRIGIDOS','name: Build Android APK - V145 - ALERTA + ALARME + SOM + FOREGROUND')
w=w.replace('Google Drive native bridge V144 validado:', 'Google Drive native bridge V145 validado:')
w=w.replace('versionName "1.44.0"','versionName "1.45.0"').replace('versionCode 144','versionCode 145')
w=w.replace('id = "gestao-agenda-v144"', 'id = "gestao-agenda-v145"')
# Add imports for foreground notification
needle='''          import android.app.AlarmManager;\n          import android.provider.OpenableColumns;'''
repl='''          import android.app.AlarmManager;\n          import android.app.Notification;\n          import android.app.NotificationChannel;\n          import android.app.NotificationManager;\n          import android.media.AudioAttributes;\n          import android.provider.OpenableColumns;'''
if needle not in w: raise SystemExit('java import needle not found')
w=w.replace(needle,repl,1)
# Add plugin method before getPermissionStates
needle='''            @PluginMethod public void getPermissionStates(PluginCall call) { JSObject r=new JSObject();r.put("contacts",getPermissionState("contacts").toString());r.put("microphone",getPermissionState("microphone").toString());call.resolve(r); }'''
method='''            @PluginMethod public void showForegroundAgendaNotification(PluginCall call) {\n              try {\n                String title=call.getString("title", "Gestão Sacerdotista Aimê");\n                String body=call.getString("body", "Compromisso agendado.");\n                int id=call.getInt("notificationId", (int)(System.currentTimeMillis()%2000000000));\n                NotificationManager manager=(NotificationManager)getContext().getSystemService(Context.NOTIFICATION_SERVICE);\n                if(manager==null){ call.reject("NOTIFICATION_MANAGER_UNAVAILABLE"); return; }\n                final String channelId="gestao-agenda-v145";\n                Uri soundUri=Uri.parse("android.resource://"+getContext().getPackageName()+"/raw/aime_alert");\n                if(Build.VERSION.SDK_INT>=26){\n                  NotificationChannel channel=manager.getNotificationChannel(channelId);\n                  if(channel==null){\n                    channel=new NotificationChannel(channelId,"Agenda e atendimentos",NotificationManager.IMPORTANCE_HIGH);\n                    channel.setDescription("Avisos de atendimentos, trabalhos, vendas e compromissos agendados");\n                    channel.enableVibration(true);\n                    AudioAttributes attrs=new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).build();\n                    channel.setSound(soundUri,attrs);\n                    manager.createNotificationChannel(channel);\n                  }\n                }\n                Notification.Builder builder=Build.VERSION.SDK_INT>=26 ? new Notification.Builder(getContext(),channelId) : new Notification.Builder(getContext());\n                builder.setSmallIcon(getContext().getApplicationInfo().icon)\n                  .setContentTitle(title)\n                  .setContentText(body)\n                  .setStyle(new Notification.BigTextStyle().bigText(body))\n                  .setAutoCancel(true)\n                  .setPriority(Notification.PRIORITY_HIGH)\n                  .setVibrate(new long[]{0,300,200,500})\n                  .setSound(soundUri);\n                manager.notify(id,builder.build());\n                JSObject result=new JSObject(); result.put("ok",true); result.put("id",id); call.resolve(result);\n              } catch(Exception ex) { call.reject("FOREGROUND_NOTIFICATION_FAILED", ex.getMessage()==null?"Falha ao exibir notificação em primeiro plano":ex.getMessage()); }\n            }\n\n            @PluginMethod public void getPermissionStates(PluginCall call) { JSObject r=new JSObject();r.put("contacts",getPermissionState("contacts").toString());r.put("microphone",getPermissionState("microphone").toString());call.resolve(r); }'''
if needle not in w: raise SystemExit('plugin method needle not found')
w=w.replace(needle,method,1)
# Ensure Context import
w=w.replace('import android.content.Intent;','import android.content.Intent;\n          import android.content.Context;',1)
wf.write_text(w)

# Verify trigger untouched and no test button
assert 'on:\n  workflow_dispatch:' in w
assert 'Testar notificação em 10 segundos' not in s
assert 'showForegroundAgendaNotification' in w and 'PermissionBridge.showForegroundAgendaNotification' in s
print('patched')
