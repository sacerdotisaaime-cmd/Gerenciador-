# V155 — NFC-e classificação robusta (código quebrado em múltiplas linhas)

Esta versão parte da V154 e corrige o caso observado na NFC-e da SEFAZ-SP em que o nome do produto e o `(Código: ...)` podem ser quebrados em linhas diferentes.

## Correções

- Reconhece `(Código: XXXXX)` mesmo quando o código aparece na linha seguinte.
- Não usa a linha seguinte antecipadamente para decidir onde termina o item; isso evita perder o `Vl. Total` quando o próximo produto começa logo depois.
- Exige nome de produto + código + quantidade + valor total válidos.
- Rejeita cabeçalhos, CNPJ, endereço, `Qtde`, `Vl. Unit`, `Vl. Total`, protocolos e demais seções da NFC-e.
- Mantém a importação por XML como fonte estruturada prioritária.
- Mantém scanner QR, consulta SEFAZ, Google Drive, backup e demais funções da base V154.

## NFC-e das capturas

O parser deve produzir exatamente estes 4 itens:

1. CONTRA FILE BOV GRILL kg — 3,454 KG — R$ 67,90 — R$ 234,53
2. CR DT TANDY 50G MELANCIA — 1 UN — R$ 8,99 — R$ 8,99
3. ESC DENT ORAL-B INF STAGES 1 4-24 MESES — 1 UN — R$ 25,98 — R$ 25,98
4. SAB DAVENE 90G AVEIA CLASSICO — 1 UN — R$ 4,49 — R$ 4,49

Soma dos itens: R$ 273,99.
