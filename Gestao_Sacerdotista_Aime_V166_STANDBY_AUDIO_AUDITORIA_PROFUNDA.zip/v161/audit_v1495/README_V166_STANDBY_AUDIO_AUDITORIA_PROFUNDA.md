# V166 — Standby / Áudio — Auditoria profunda

Correção estrutural do erro `Cannot read properties of null (reading 'duration')`.

## Alterações
- sanitização central das listas de áudio antes da renderização;
- `AudioList` e `PhotoStrip` passam a trabalhar somente com dados válidos;
- telas de atendimento, histórico, entrada e mídia de foto usam `safeAudioItems`;
- `AudioPlayer` não executa mais `return` antes dos Hooks;
- `AudioPlayer` recebe `AudioItem | null | undefined` com defesa interna;
- restauração do atendimento após fechar/reabrir aplica `normalizeConsultationMedia` integralmente;
- Error Boundary passa a mostrar `componentStack` e guardar diagnóstico local;
- preservada a persistência/backup/Supabase da V165.

## Objetivo do teste
Criar vários atendimentos com fotos e áudios, colocar cada um em Standby, fechar/reabrir o app e retomar cada Standby em sequência. Nenhum deve cair com `duration`.
