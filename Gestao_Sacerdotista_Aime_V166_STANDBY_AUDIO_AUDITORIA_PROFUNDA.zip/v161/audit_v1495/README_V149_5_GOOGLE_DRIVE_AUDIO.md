# V149.5 — Google Drive e player de áudio

## Correções
- Implementado no PermissionBridge Android o método `listGoogleDriveBackups`.
- Implementado no PermissionBridge Android o método `downloadGoogleDriveBackup`.
- A importação do Google Drive agora garante autorização antes de listar os backups.
- Download do ZIP é feito diretamente para o cache do Android e depois lido pelo Capacitor Filesystem.
- Player de áudio do histórico passou a materializar Data URLs como Blob URLs, evitando manter uma URL base64 gigante como `src` do `<audio>`.
- Player usa `preload="auto"`, monitora `waiting`/`stalled`, tenta recuperação limitada e não trata buffering como pausa manual.
- Ao iniciar outro áudio, o player anterior é encerrado corretamente.
- O botão de reprodução só é marcado como ativo depois que `play()` realmente inicia.

## Compatibilidade preservada
A versão parte da V149.4 e mantém as correções anteriores de NFC-e/QR Code, diagnóstico da SEFAZ e edição completa de tiragens.
