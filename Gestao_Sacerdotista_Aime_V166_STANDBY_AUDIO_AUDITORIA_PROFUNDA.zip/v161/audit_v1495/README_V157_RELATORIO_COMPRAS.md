# V157 — Relatório de Compras + Comparador de Estabelecimentos

## Objetivo
Adicionar uma aba **Compras** em Relatórios sem alterar a importação NFC-e.

## Recursos
- filtros por período já existentes nos relatórios;
- filtro por Casa/Trabalho;
- filtro por estabelecimento;
- filtro por categoria;
- busca por produto;
- total gasto, quantidade e número de compras;
- detalhamento por item com data, estabelecimento, categoria, quantidade, unidade, preço unitário e total;
- resumo de gasto por estabelecimento;
- comparação entre dois estabelecimentos;
- comparação de preço unitário, quantidade, total gasto e número de compras quando um produto específico é selecionado;
- preservação dos dados existentes e compatibilidade com compras manuais e NFC-e.

## Observação
A comparação usa os itens já persistidos em `Purchase.items`; não altera XML/NFC-e nem cria uma segunda base de compras.
