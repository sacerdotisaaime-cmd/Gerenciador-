# V165 — Standby múltiplo + áudio blindado

## Correção principal
Corrige a falha ao fechar/reabrir o aplicativo e retomar um segundo atendimento em Standby quando existem fotos/áudios.

Erro observado:
`Cannot read properties of null (reading 'duration')`

## O que foi corrigido
- Sanitização central de todas as mídias persistidas de um atendimento.
- Áudios `null`, incompletos ou sem `data` são descartados com segurança antes da renderização.
- `responseAudios`, mídias de perguntas, fotos com áudio, mídias de trabalho/venda e comprovantes de termos também são normalizados.
- A deduplicação por ID continua preservando atendimentos diferentes em Standby.
- Retomar Standby sempre sanitiza novamente o atendimento antes de abrir a tela.
- Salvar em Standby agora grava explicitamente a lista de atendimentos no armazenamento persistente antes de remover o rascunho.
- Quando houver sessão Supabase e conexão, o Standby é enviado imediatamente ao snapshot remoto, com timeout de 8 segundos. Se a sincronização falhar, o Standby continua salvo localmente.
- Nenhuma função de backup, Caixa de Mídias, NFC-e, Financeiro ou demais áreas foi removida.

## Objetivo do teste
1. Abrir um atendimento A.
2. Adicionar foto e/ou áudio.
3. Salvar em Standby.
4. Abrir outro atendimento B.
5. Adicionar foto e/ou áudio.
6. Salvar B em Standby.
7. Fechar completamente o aplicativo.
8. Abrir novamente.
9. Retomar A e depois B.
10. Confirmar que ambos abrem sem o erro de `duration` e mantêm suas mídias.

## Observação
A validação TypeScript completa não pôde ser executada neste ambiente porque o pacote distribuído não contém as definições locais completas de `vite/client` e `@types/node`. A alteração foi revisada estruturalmente e o ZIP foi gerado a partir da V164.
