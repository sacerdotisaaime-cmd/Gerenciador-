# V160 — Orçamento vinculado ao atendimento

Correção pontual no fluxo de orçamento aberto de dentro de um atendimento.

- O botão `💼 Orçamento` dentro do atendimento agora informa o `sourceConsultationId`.
- O orçamento salvo recebe esse vínculo.
- O atendimento recebe `budgetId`.
- Após salvar, o aplicativo permanece/retorna ao atendimento em vez de navegar para a tela geral de Orçamentos.
- O orçamento continua disponível na área geral de Orçamentos.
- Nenhuma função foi removida e o fluxo de orçamento iniciado fora de um atendimento continua indo para a tela geral de Orçamentos.
