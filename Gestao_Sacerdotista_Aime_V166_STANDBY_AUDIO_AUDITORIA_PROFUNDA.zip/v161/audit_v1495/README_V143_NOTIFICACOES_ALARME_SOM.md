# V143 — notificações, alarmes e som

Correções incluídas:
- corrige a compilação Java do PermissionBridge (assinaturas de startsWith e diagnosticResult estático);
- abre a tela especial de Alarmes e lembretes com fallback para Configurações do aplicativo;
- interpreta os formatos de retorno de exact alarm (`value` e `exact_alarm`);
- cria um WAV real em `android/app/src/main/res/raw/aime_alert.wav`;
- usa um canal Android novo `gestao-agenda-v143`, evitando um canal antigo sem som;
- mantém fallback para notificações inexatas quando o acesso exato não estiver concedido;
- versão Android 1.43.0 / versionCode 143.
