# V164 — Standby + recuperação segura de mídias

Correção baseada na V163.

## Correções
- Sanitização de áudios restaurados do armazenamento local/Supabase.
- Áudios nulos, incompletos ou sem duração não derrubam mais a tela de atendimento.
- Player de áudio agora possui defesa adicional contra item nulo.
- Duração inválida/nula é tratada como `00:00`.
- Retomada de standby normaliza novamente fotos e áudios antes de abrir o atendimento.
- Atendimentos em standby com IDs diferentes não são mais deduplicados por nome/data/título.
- Removida a migração que podia transformar automaticamente um standby em agendado apenas porque possuía `scheduledAt` e timestamps iguais.

## Preservação
A V164 é baseada na V163 e mantém as alterações de layout do painel principal. Não remove funcionalidades de atendimento, mídia, áudio, histórico ou standby.
