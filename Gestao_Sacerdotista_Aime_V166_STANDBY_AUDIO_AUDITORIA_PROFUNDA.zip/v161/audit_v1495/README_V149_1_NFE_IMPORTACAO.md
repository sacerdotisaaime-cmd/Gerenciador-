# V149.1 — NFC-e SP: URL completa + importação de itens

- O campo QR Code/chave aceita QR Code, URL completa da NFC-e e chave de 44 dígitos.
- URLs da SEFAZ-SP no formato `ConsultaQRCode.aspx?p=CHAVE|3|1` são normalizadas para `%7C` antes da consulta nativa.
- No Android, a consulta usa um bridge nativo com `HttpURLConnection`, com cabeçalhos de navegador, evitando CORS do WebView.
- A consulta tenta primeiro a URL informada, depois a rota QR Code de SP e, por fim, a consulta pública pela chave.
- O parser existente é usado para importar nome, quantidade, unidade, preço unitário, total, fornecedor e total da nota.
- O botão flutuante `🐞 Avisos` usado apenas para diagnóstico/teste de alarmes foi removido. Os alarmes/notificações continuam funcionando.
- Barcode Scanner atualizado para 2.2.1.
