# V161 — Caixa de Mídias por Atendimento

## Objetivo
A Caixa de Mídias passa a funcionar explicitamente como uma área temporária vinculada ao atendimento em andamento.

## Regras
- Mídias recebidas enquanto existe atendimento ativo são vinculadas automaticamente ao `linkedConsultationId` desse atendimento.
- Importações manuais durante atendimento também recebem o vínculo.
- Importações para a ficha da consulente continuam preservando o vínculo temporário com o atendimento que originou a mídia.
- Em atendimento ativo, a Caixa de Mídias mostra somente as mídias daquele atendimento.
- Em Standby, as mídias permanecem preservadas.
- Ao encerrar/finalizar o atendimento, a rotina existente `cleanupConsultationMediaInbox()` remove as mídias temporárias ligadas ao atendimento, inclusive do armazenamento nativo quando disponível.
- As cópias já anexadas ao atendimento, histórico, ficha ou demais registros permanentes não são removidas.
- Sem atendimento ativo, a Caixa de Mídias continua permitindo visualizar mídias sem vínculo e mídias de atendimentos em Standby, mas não permite excluir acidentalmente as mídias vinculadas a um Standby.

## O que não foi alterado
Nenhuma nova função de negócio foi criada. O objetivo desta versão é organizar o ciclo de vida da Caixa de Mídias e impedir que ela acumule indefinidamente mídias já pertencentes a atendimentos encerrados.
