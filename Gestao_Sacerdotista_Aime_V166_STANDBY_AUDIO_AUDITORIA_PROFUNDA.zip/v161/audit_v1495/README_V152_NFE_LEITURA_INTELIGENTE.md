# V152 — NFC-e / NF-e: Leitura Inteligente e fallback de texto

## Objetivo
Corrigir a importação de notas sem alterar o Backup Mestre, persistência de mídia, Financeiro, Agenda ou demais módulos.

## Fluxo da importação
1. QR Code / link informado.
2. Consulta nativa via `HttpURLConnection`.
3. Parser estruturado de XML/HTML.
4. Se a resposta não trouxer itens, fallback de **leitura renderizada** usando WebView nativa: JavaScript, redirects e DOM são executados e o texto visível da página é devolvido ao React.
5. Parser local interpreta o texto da NFC-e e extrai estabelecimento, CNPJ, data, chave, itens, quantidade, unidade, preço unitário, total e total da nota.
6. Fallback manual: o usuário pode colar o texto copiado do navegador/modo leitura e pedir para interpretar.

## Importante
A versão não envia notas ou dados fiscais para um serviço externo de IA. A interpretação é local e determinística, reduzindo dependências externas e preservando privacidade. A IA pode ser adicionada posteriormente como último fallback, preferencialmente via backend seguro, sem chave de API dentro do APK.

## Limitação fiscal
A consulta pública da SEFAZ-SP pode exigir mecanismos de proteção/captcha em algumas rotas. Quando isso ocorrer, a chave/link continua disponível para abertura manual e o fallback de texto permite concluir a importação se o conteúdo da nota puder ser copiado. O acesso ao XML pelos serviços de apoio à escrituração da SEFAZ-SP é um fluxo separado e exige certificado digital do próprio contribuinte.
