# V162 — Orçamento aberto e vinculado corretamente ao atendimento

Base: V161 — Caixa de Mídias por Atendimento.

## Correção

Corrigido o fluxo do botão **💼 Orçamento** dentro de um atendimento.

Agora, ao tocar em Orçamento dentro da tiragem/atendimento:

- o contexto do atendimento de origem é preservado explicitamente;
- o orçamento abre como janela sobre o atendimento, sem transformar o atendimento em Standby;
- o orçamento recebe `sourceConsultationId` do atendimento de origem;
- o estado de origem do orçamento também é preservado no snapshot de navegação do Android/WebView;
- ao salvar o orçamento, ele fica vinculado ao atendimento e o aplicativo retorna para esse atendimento;
- o botão foi marcado explicitamente como `type="button"` e impede propagação do clique;
- a janela do orçamento recebeu prioridade visual alta para permanecer acima da tela do atendimento.

## Funções preservadas

Não foram removidas funções do orçamento, checkout, atendimento ou Caixa de Mídias. A alteração é direcionada ao fluxo de abertura/vínculo do orçamento.
