# V150 — Backup Mestre, mídia persistente e agendamento

## Correções principais

- Fotos e áudios que fazem parte de consultas, perguntas, respostas, trabalhos, vendas, termos e outros registros deixam de depender exclusivamente do limite do `localStorage`.
- `persistentStorage.ts` usa IndexedDB como cofre para valores grandes ou que contenham Data URLs; o `localStorage` guarda apenas um marcador pequeno.
- A inicialização carrega o cofre antes do React, evitando que o histórico abra com registros sem mídia.
- O Backup Mestre lê tanto localStorage quanto o cofre persistente, extrai as mídias para arquivos separados e grava SHA-256 por arquivo.
- A restauração usa o MIME registrado no manifesto, inclusive AAC, em vez de inferir somente pela extensão. Isso corrige o caso em que o áudio existia no ZIP, mas voltava como `application/octet-stream`.
- O manifesto é validado por SHA-256 antes de associar a mídia ao registro. Uma mídia ausente ou corrompida interrompe a restauração em vez de criar um histórico incompleto.
- A janela de backup mostra progresso, fase, quantidade de dados e mídias.
- O seletor de backup local mostra data, tamanho, módulos e quantidade de mídias antes de importar.
- O seletor do Google Drive deixa de usar `window.prompt`; mostra uma lista organizada por data/hora/tamanho e, nos backups novos, o resumo de conteúdo salvo na descrição do arquivo.
- Backups enviados ao Google Drive carregam um resumo técnico no metadata `description`.
- Backup automático diário com horário configurável. No Android, o agendamento é nativo e é reconstruído após reinicialização, troca de horário e atualização do pacote.
- O backup automático cria primeiro o ZIP local; se o Google Drive estiver conectado e a opção estiver ativa, faz o upload em seguida.

## Limitação importante

O mecanismo relacional `questions` do Supabase continua guardando texto/metadados, não os binários. A proteção principal dos binários nesta versão é o cofre persistente local + Backup Mestre/Google Drive. O snapshot do Supabase passa a enxergar os valores persistentes do cofre, mas não deve ser tratado como substituto do ZIP Mestre para arquivos grandes.

## Build

A compilação Android desta base continua sendo feita pelo workflow `.github/workflows/build-android-release.yml`. A validação estática desta preparação foi executada; uma compilação Gradle completa não foi executada neste ambiente porque a instalação das dependências npm excedeu o tempo disponível.
