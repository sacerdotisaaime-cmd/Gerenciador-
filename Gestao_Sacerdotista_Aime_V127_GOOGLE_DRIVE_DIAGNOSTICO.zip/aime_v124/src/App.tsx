name: Build Android APK - V127 - RELEASE - GOOGLE DRIVE DIAGNOSTICO

on:
  workflow_dispatch:

jobs:
  build-apk:
    runs-on: ubuntu-latest
    permissions:
      contents: read

    steps:
      - name: Baixar projeto
        uses: actions/checkout@v4

      - name: Configurar Node.js
        uses: actions/setup-node@v4
        with:
          node-version: 22

      - name: Configurar Java
        uses: actions/setup-java@v5
        with:
          distribution: temurin
          java-version: 21

      - name: Validar secrets de assinatura
        shell: bash
        env:
          ANDROID_KEYSTORE_BASE64: ${{ secrets.ANDROID_KEYSTORE_BASE64 }}
          ANDROID_KEYSTORE_PASSWORD: ${{ secrets.ANDROID_KEYSTORE_PASSWORD }}
          ANDROID_KEY_ALIAS: ${{ secrets.ANDROID_KEY_ALIAS }}
          ANDROID_KEY_PASSWORD: ${{ secrets.ANDROID_KEY_PASSWORD }}
        run: |
          set -e
          test -n "$ANDROID_KEYSTORE_BASE64" || { echo "ERRO: ANDROID_KEYSTORE_BASE64 vazio"; exit 1; }
          test -n "$ANDROID_KEYSTORE_PASSWORD" || { echo "ERRO: ANDROID_KEYSTORE_PASSWORD vazio"; exit 1; }
          test -n "$ANDROID_KEY_ALIAS" || { echo "ERRO: ANDROID_KEY_ALIAS vazio"; exit 1; }
          test -n "$ANDROID_KEY_PASSWORD" || { echo "ERRO: ANDROID_KEY_PASSWORD vazio"; exit 1; }
          echo "Secrets de assinatura reconhecidas."

      - name: Encontrar ZIP do projeto
        shell: bash
        run: |
          set -e
          mapfile -t ZIPS < <(find . -maxdepth 2 -type f -iname "*.zip" ! -path "./.git/*" | sort)
          COUNT="${#ZIPS[@]}"
          if [ "$COUNT" -eq 0 ]; then
            echo "ERRO: nenhum ZIP foi encontrado."
            exit 1
          fi
          if [ "$COUNT" -gt 1 ]; then
            echo "ERRO: foram encontrados vários ZIPs. Deixe somente o ZIP da versão que será compilada."
            printf '%s\n' "${ZIPS[@]}"
            exit 1
          fi
          ZIP_FILE="${ZIPS[0]}"
          echo "ZIP selecionado: $ZIP_FILE"
          ls -lh "$ZIP_FILE"
          echo "ZIP_FILE=$ZIP_FILE" >> "$GITHUB_ENV"

      - name: Descompactar projeto
        shell: bash
        run: |
          set -e
          rm -rf app
          mkdir -p app
          unzip -q "$ZIP_FILE" -d app

      - name: Localizar projeto
        shell: bash
        run: |
          set -e
          PROJECT_PACKAGE=$(find app -name package.json -not -path "*/node_modules/*" -print | head -n 1)
          if [ -z "$PROJECT_PACKAGE" ]; then
            echo "ERRO: package.json não encontrado."
            exit 1
          fi
          PROJECT_DIR=$(dirname "$PROJECT_PACKAGE")
          echo "Projeto: $PROJECT_DIR"
          echo "PROJECT_DIR=$PROJECT_DIR" >> "$GITHUB_ENV"

      - name: Ajustar dependências
        shell: bash
        run: |
          set -e
          cd "$PROJECT_DIR"
          node <<'NODE'
          const fs = require('fs');
          const file = 'package.json';
          const pkg = JSON.parse(fs.readFileSync(file, 'utf8'));
          const deps = pkg.dependencies || (pkg.dependencies = {});
          deps['@capacitor/core'] = '^7.4.3';
          deps['@capacitor/android'] = '^7.4.3';
          deps['@capacitor/camera'] = '^7.0.5';
          deps['@capacitor/share'] = '^7.0.2';
          deps['@capacitor/filesystem'] = '^7.0.2';
          deps['@capacitor-community/contacts'] = '7.2.0';
          deps['capacitor-voice-recorder'] = '7.0.6';
          deps['@capacitor/barcode-scanner'] = '2.0.4';
          fs.writeFileSync(file, JSON.stringify(pkg, null, 2) + '\n');
          NODE
          rm -rf node_modules
          rm -f package-lock.json

      - name: Instalar dependências
        shell: bash
        run: |
          set -e
          cd "$PROJECT_DIR"
          npm install
          npm install -D @capacitor/cli@7.4.3

      - name: Compilar aplicação web
        shell: bash
        run: |
          set -e
          cd "$PROJECT_DIR"
          npx vite build

      - name: Adicionar Android
        shell: bash
        run: |
          set -e
          cd "$PROJECT_DIR"
          npx cap add android

      - name: Ajustar SDK Android
        shell: bash
        run: |
          set -e
          VARIABLES="$PROJECT_DIR/android/variables.gradle"
          if [ -f "$VARIABLES" ]; then
            sed -i 's/minSdkVersion = [0-9]*/minSdkVersion = 26/' "$VARIABLES"
          fi

      - name: Sincronizar Capacitor
        shell: bash
        run: |
          set -e
          cd "$PROJECT_DIR"
          npx cap sync android

      - name: Criar PermissionBridge
        shell: bash
        run: |
          set -e
          ANDROID_SRC="$PROJECT_DIR/android/app/src/main/java/com/sacerdotisaaime/gestao"
          mkdir -p "$ANDROID_SRC"
          cat > "$ANDROID_SRC/PermissionBridgePlugin.java" <<'JAVA'
          package com.sacerdotisaaime.gestao;

          import android.Manifest;
          import android.app.PendingIntent;
          import android.content.Intent;
          import android.content.SharedPreferences;
          import android.net.Uri;
          import android.provider.OpenableColumns;
          import android.provider.Settings;
          import android.util.Base64;
          import java.io.ByteArrayOutputStream;
          import java.io.File;
          import java.io.FileInputStream;
          import java.io.FileOutputStream;
          import java.io.InputStream;
          import java.io.OutputStream;
          import java.net.HttpURLConnection;
          import java.net.URL;
          import java.net.URLEncoder;
          import java.nio.charset.StandardCharsets;
          import java.util.ArrayList;
          import java.util.Arrays;
          import java.util.Collections;
          import java.util.List;
          import java.util.concurrent.ExecutorService;
          import java.util.concurrent.Executors;
          import org.json.JSONArray;
          import org.json.JSONObject;
          import com.getcapacitor.JSObject;
          import com.getcapacitor.JSArray;
          import com.getcapacitor.PermissionState;
          import com.getcapacitor.Plugin;
          import com.getcapacitor.PluginCall;
          import com.getcapacitor.PluginMethod;
          import com.getcapacitor.annotation.CapacitorPlugin;
          import com.getcapacitor.annotation.Permission;
          import com.getcapacitor.annotation.PermissionCallback;
          import com.google.android.gms.auth.api.identity.AuthorizationClient;
          import com.google.android.gms.auth.api.identity.AuthorizationRequest;
          import com.google.android.gms.auth.api.identity.AuthorizationResult;
          import com.google.android.gms.auth.api.identity.Identity;
          import com.google.android.gms.common.api.ApiException;
          import com.google.android.gms.common.api.Scope;

          @CapacitorPlugin(
            name = "PermissionBridge",
            permissions = {
              @Permission(alias = "contacts", strings = {
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.WRITE_CONTACTS
              }),
              @Permission(alias = "microphone", strings = {
                Manifest.permission.RECORD_AUDIO
              })
            }
          )
          public class PermissionBridgePlugin extends Plugin {
            private static PermissionBridgePlugin instance;
            private static Intent pendingSharedIntent;
            private static boolean initialSyncClaimed = false;
            private static boolean sharedLaunch = false;
            private static final String INBOX_DIR = "shared-media-inbox";
            private static final long MAX_AUDIO_BYTES = 50L * 1024L * 1024L;
            private static final long MAX_PHOTO_BYTES = 20L * 1024L * 1024L;
            private static final String DRIVE_SCOPE = "https://www.googleapis.com/auth/drive.file";
            private static final int GOOGLE_AUTH_REQUEST_CODE = 9417;
            private PluginCall pendingGoogleAuthCall;
            private String googleAccessToken;
            private String googleAccountEmail;
            private final ExecutorService driveExecutor = Executors.newSingleThreadExecutor();

            @Override public void load() {
              super.load();
              instance = this;
              Intent pending = pendingSharedIntent;
              pendingSharedIntent = null;
              if (pending != null) handleSharedIntent(pending);
            }

            private File inboxDir() {
              File dir = new File(getContext().getFilesDir(), INBOX_DIR);
              if (!dir.exists()) dir.mkdirs();
              return dir;
            }

            private String typeFor(Uri uri) {
              try { return getContext().getContentResolver().getType(uri); } catch (Exception ignored) { return null; }
            }

            private String displayName(Uri uri) {
              try {
                android.database.Cursor cursor = getContext().getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null);
                if (cursor != null) {
                  try { if (cursor.moveToFirst()) return cursor.getString(0); } finally { cursor.close(); }
                }
              } catch (Exception ignored) {}
              return null;
            }

            private String b64(String value) {
              return Base64.encodeToString((value == null ? "" : value).getBytes(StandardCharsets.UTF_8), Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING);
            }
            private String unb64(String value) {
              try { return new String(Base64.decode(value, Base64.URL_SAFE), StandardCharsets.UTF_8); } catch (Exception ignored) { return ""; }
            }
            private String[] parse(File file) { return file.getName().split("__", -1); }

            private JSObject metadata(File file) {
              String[] p = parse(file);
              JSObject o = new JSObject();
              if (p.length < 5) return o;
              o.put("id", p[0]);
              o.put("kind", p[3]);
              o.put("mimeType", unb64(p[1]));
              o.put("name", unb64(p[2]));
              o.put("size", file.length());
              o.put("receivedAt", new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", java.util.Locale.US).format(new java.util.Date(file.lastModified())));
              return o;
            }

            private File findById(String id) {
              if (id == null || id.trim().isEmpty()) return null;
              File[] files = inboxDir().listFiles();
              if (files == null) return null;
              for (File file : files) if (file.getName().startsWith(id + "__")) return file;
              return null;
            }

            private boolean startsWith(byte[] data, int len, byte... signature) {
              if (len < signature.length) return false;
              for (int i = 0; i < signature.length; i++) if (data[i] != signature[i]) return false;
              return true;
            }

            private String sniffKindAndMime(File file) throws Exception {
              byte[] h = new byte[64];
              int len = 0;
              try (InputStream input = new FileInputStream(file)) {
                while (len < h.length) {
                  int n = input.read(h, len, h.length - len);
                  if (n < 0) break;
                  if (n == 0) continue;
                  len += n;
                }
              }
              if (len >= 3 && (h[0] & 0xff) == 0xff && (h[1] & 0xff) == 0xd8 && (h[2] & 0xff) == 0xff) return "photo|image/jpeg";
              if (startsWith(h, len, (byte)0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a)) return "photo|image/png";
              if (len >= 12 && startsWith(h, len, 0x52,0x49,0x46,0x46) && h[8]=='W' && h[9]=='E' && h[10]=='B' && h[11]=='P') return "photo|image/webp";
              if (startsWith(h, len, 0x4f,0x67,0x67,0x53)) return "audio|audio/ogg";
              if (len >= 12 && h[0]=='R' && h[1]=='I' && h[2]=='F' && h[3]=='F' && h[8]=='W' && h[9]=='A' && h[10]=='V' && h[11]=='E') return "audio|audio/wav";
              if (len >= 4 && h[0]=='I' && h[1]=='D' && h[2]=='3') return "audio|audio/mpeg";
              return null;
            }

            private void storeUri(Uri uri) {
              try {
                String mime = typeFor(uri);
                String name = displayName(uri);
                if (mime == null || mime.isEmpty()) mime = "application/octet-stream";
                if (name == null || name.trim().isEmpty()) name = "shared-media";
                boolean audio = mime.startsWith("audio/") || mime.equals("application/ogg") || mime.equals("application/octet-stream");
                boolean photo = mime.startsWith("image/");
                if (!audio && !photo) {
                  File temp = File.createTempFile("shared-", ".bin", inboxDir());
                  long total = 0;
                  try (InputStream input = getContext().getContentResolver().openInputStream(uri); OutputStream output = new java.io.FileOutputStream(temp)) {
                    if (input == null) throw new IllegalStateException("STREAM_NULL");
                    byte[] buffer = new byte[8192]; int n;
                    while ((n=input.read(buffer))!=-1) { total += n; if (total > MAX_AUDIO_BYTES) throw new IllegalStateException("MEDIA_TOO_LARGE"); output.write(buffer,0,n); }
                  }
                  String sniff = sniffKindAndMime(temp);
                  if (sniff == null) { temp.delete(); notifyReceiveError(uri, "UNSUPPORTED_MEDIA"); return; }
                  String[] parts = sniff.split("\\|",2); audio = "audio".equals(parts[0]); photo = "photo".equals(parts[0]); mime = parts[1];
                  name = name.replaceAll("[^a-zA-Z0-9._-]", "_");
                  String id = "media-" + System.currentTimeMillis() + "-" + Math.abs((uri.toString() + total).hashCode());
                  File out = new File(inboxDir(), id + "__" + b64(mime) + "__" + b64(name) + "__" + (audio ? "audio" : "photo") + "__1.bin");
                  if (!temp.renameTo(out)) { try (FileInputStream in = new FileInputStream(temp); FileOutputStream os = new FileOutputStream(out)) { byte[] buffer = new byte[8192]; int n; while ((n=in.read(buffer))!=-1) os.write(buffer,0,n); } temp.delete(); }
                  if (instance != null) instance.notifyListeners("sharedMedia", metadata(out));
                  return;
                }
                long limit = audio ? MAX_AUDIO_BYTES : MAX_PHOTO_BYTES;
                File temp = File.createTempFile("shared-", ".bin", inboxDir());
                long total = 0;
                try (InputStream input = getContext().getContentResolver().openInputStream(uri); OutputStream output = new java.io.FileOutputStream(temp)) {
                  if (input == null) throw new IllegalStateException("STREAM_NULL");
                  byte[] buffer = new byte[8192]; int n;
                  while ((n=input.read(buffer))!=-1) { total += n; if (total > limit) throw new IllegalStateException("MEDIA_TOO_LARGE"); output.write(buffer,0,n); }
                }
                name = name.replaceAll("[^a-zA-Z0-9._-]", "_");
                String id = "media-" + System.currentTimeMillis() + "-" + Math.abs((uri.toString() + total).hashCode());
                File out = new File(inboxDir(), id + "__" + b64(mime) + "__" + b64(name) + "__" + (audio ? "audio" : "photo") + "__1.bin");
                if (!temp.renameTo(out)) { try (FileInputStream in = new FileInputStream(temp); FileOutputStream os = new java.io.FileOutputStream(out)) { byte[] buffer = new byte[8192]; int n; while ((n=in.read(buffer))!=-1) os.write(buffer,0,n); } temp.delete(); }
                if (instance != null) instance.notifyListeners("sharedMedia", metadata(out));
              } catch (Exception ex) { notifyReceiveError(uri, ex.getMessage() == null ? "INTENT_READ_FAILED" : ex.getMessage()); }
            }

            private void notifyReceiveError(Uri uri, String code) {
              JSObject event = new JSObject(); event.put("ok", false); event.put("code", code); event.put("uri", uri == null ? "" : uri.toString());
              if (instance != null) instance.notifyListeners("sharedMediaError", event);
            }

            public static void handleSharedIntent(Intent intent) {
              if (intent == null) return;
              if (instance == null) { pendingSharedIntent = new Intent(intent); return; }
              String action = intent.getAction();
              if (!Intent.ACTION_SEND.equals(action) && !Intent.ACTION_SEND_MULTIPLE.equals(action)) return;
              sharedLaunch = true;
              try {
                ArrayList<Uri> urisToStore = new ArrayList<>();
                if (intent.getClipData() != null) { android.content.ClipData clip = intent.getClipData(); for (int i=0;i<clip.getItemCount();i++){ Uri uri=clip.getItemAt(i).getUri(); if(uri!=null&&!urisToStore.contains(uri))urisToStore.add(uri);} }
                if (Intent.ACTION_SEND_MULTIPLE.equals(action)) { ArrayList<Uri> extraUris = intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM); if(extraUris!=null) for(Uri uri:extraUris) if(uri!=null&&!urisToStore.contains(uri)) urisToStore.add(uri); }
                else { Uri uri=null; try{uri=intent.getParcelableExtra(Intent.EXTRA_STREAM);}catch(Exception ignored){} if(uri!=null&&!urisToStore.contains(uri))urisToStore.add(uri); }
                for (Uri uri : urisToStore) instance.storeUri(uri);
              } catch (Exception ex) { if(instance!=null)instance.notifyReceiveError(null,ex.getMessage()==null?"INTENT_READ_FAILED":ex.getMessage()); }
            }

            @PluginMethod public void claimInitialSync(PluginCall call) { boolean first=!initialSyncClaimed; initialSyncClaimed=true; JSObject result=new JSObject(); result.put("firstProcess",first); result.put("sharedLaunch",sharedLaunch); sharedLaunch=false; call.resolve(result); }
            @PluginMethod public void getSharedMedia(PluginCall call) { File[] files=inboxDir().listFiles(); JSArray arr=new JSArray(); if(files!=null)for(File file:files)if(file.isFile())arr.put(metadata(file)); JSObject result=new JSObject();result.put("pending",arr.length()>0);result.put("items",arr);call.resolve(result); }
            @PluginMethod public void listSharedMedia(PluginCall call) { File[] files=inboxDir().listFiles(); JSArray arr=new JSArray(); if(files!=null)for(File file:files)if(file.isFile())arr.put(metadata(file)); JSObject result=new JSObject();result.put("items",arr);call.resolve(result); }
            @PluginMethod public void readSharedMedia(PluginCall call) { String id=call.getString("id",""); File file=findById(id); if(file==null||!file.exists()){JSObject r=new JSObject();r.put("ok",false);call.resolve(r);return;} try{ByteArrayOutputStream output=new ByteArrayOutputStream();try(InputStream input=new FileInputStream(file)){byte[] buffer=new byte[8192];int read;while((read=input.read(buffer))!=-1)output.write(buffer,0,read);} JSObject r=metadata(file);r.put("ok",true);String mime=r.getString("mimeType","application/octet-stream");r.put("data","data:"+mime+";base64,"+Base64.encodeToString(output.toByteArray(),Base64.NO_WRAP));call.resolve(r);}catch(Exception ex){call.reject("SHARED_MEDIA_READ_ERROR",ex.getMessage()==null?"READ_FAILED":ex.getMessage());} }
            @PluginMethod public void deleteSharedMedia(PluginCall call) { String id=call.getString("id","");File file=findById(id);JSObject r=new JSObject();r.put("ok",file==null||file.delete());call.resolve(r); }

            @PluginMethod public void requestContacts(PluginCall call) { if(getPermissionState("contacts")==PermissionState.GRANTED){JSObject r=new JSObject();r.put("granted",true);r.put("state","granted");call.resolve(r);return;}requestPermissionForAlias("contacts",call,"contactsPermissionResult"); }
            @PermissionCallback private void contactsPermissionResult(PluginCall call) { boolean granted=getPermissionState("contacts")==PermissionState.GRANTED;JSObject r=new JSObject();r.put("granted",granted);r.put("state",granted?"granted":"denied");call.resolve(r); }
            @PluginMethod public void requestMicrophone(PluginCall call) { if(getPermissionState("microphone")==PermissionState.GRANTED){JSObject r=new JSObject();r.put("granted",true);r.put("state","granted");call.resolve(r);return;}requestPermissionForAlias("microphone",call,"microphonePermissionResult"); }
            @PermissionCallback private void microphonePermissionResult(PluginCall call) { boolean granted=getPermissionState("microphone")==PermissionState.GRANTED;JSObject r=new JSObject();r.put("granted",granted);r.put("state",granted?"granted":"denied");call.resolve(r); }
            @PluginMethod public void getPermissionStates(PluginCall call) { JSObject r=new JSObject();r.put("contacts",getPermissionState("contacts").toString());r.put("microphone",getPermissionState("microphone").toString());call.resolve(r); }
            @PluginMethod public void openSettings(PluginCall call) { try{Intent intent=new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);intent.setData(Uri.parse("package:"+getContext().getPackageName()));getActivity().startActivity(intent);call.resolve();}catch(Exception ex){call.reject("SETTINGS_ERROR",ex.getMessage());} }

            @PluginMethod public void getGoogleDriveStatus(PluginCall call) { JSObject r=new JSObject();r.put("connected",googleAccessToken!=null&&!googleAccessToken.isEmpty());if(googleAccountEmail!=null)r.put("email",googleAccountEmail);call.resolve(r); }

            private AuthorizationRequest driveAuthorizationRequest() {
              return AuthorizationRequest.builder()
                .setRequestedScopes(Collections.singletonList(new Scope(DRIVE_SCOPE)))
                .setPrompt(AuthorizationRequest.Prompt.SELECT_ACCOUNT)
                .build();
            }

            @PluginMethod public void connectGoogleDrive(PluginCall call) {
              try {
                Identity.getAuthorizationClient(getActivity()).authorize(driveAuthorizationRequest())
                  .addOnSuccessListener(result -> handleAuthorizationResult(result, call, true))
                  .addOnFailureListener(error -> {
                    String detail = googleErrorDetail(error);
                    android.util.Log.e("PermissionBridge", "Google Drive authorization failed: " + detail, error);
                    call.reject("GOOGLE_AUTH_FAILED", detail);
                  });
              } catch (Exception error) {
                String detail = googleErrorDetail(error);
                android.util.Log.e("PermissionBridge", "Google Drive authorization exception: " + detail, error);
                call.reject("GOOGLE_AUTH_EXCEPTION", detail);
              }
            }

            private String googleErrorDetail(Exception error) {
              if (error == null) return "Erro desconhecido na autorização do Google.";
              String message = error.getMessage();
              if (error instanceof ApiException) {
                ApiException api = (ApiException) error;
                String status = api.getStatus() == null ? "" : String.valueOf(api.getStatus());
                return "Código Google=" + api.getStatusCode() + " · " + status + (message == null ? "" : " · " + message);
              }
              return error.getClass().getSimpleName() + (message == null ? "" : " · " + message);
            }

            private void handleAuthorizationResult(AuthorizationResult result, PluginCall call, boolean allowResolution) {
              if(result.hasResolution()) {
                if(!allowResolution){ JSObject r=new JSObject();r.put("authorized",false);r.put("needsUserAction",true);r.put("message","A autorização do Google precisa ser concluída pelo usuário.");call.resolve(r);return; }
                pendingGoogleAuthCall=call;
                try { PendingIntent pending=result.getPendingIntent(); getActivity().startIntentSenderForResult(pending.getIntentSender(),GOOGLE_AUTH_REQUEST_CODE,null,0,0,0); }
                catch(Exception ex){pendingGoogleAuthCall=null;call.reject("GOOGLE_AUTH_UI_FAILED",ex.getMessage()==null?"Não foi possível abrir a autorização do Google":ex.getMessage());}
                return;
              }
              String token=result.getAccessToken();
              if(token==null||token.isEmpty()){call.reject("GOOGLE_TOKEN_EMPTY","O Google não retornou um token de acesso.");return;}
              googleAccessToken=token;
              googleAccountEmail=null;
              JSObject r=new JSObject();r.put("authorized",true);call.resolve(r);
            }

            public static boolean handleGoogleAuthorizationResult(int requestCode, int resultCode, Intent data) {
              if(instance==null || requestCode!=GOOGLE_AUTH_REQUEST_CODE) return false;
              PluginCall call=instance.pendingGoogleAuthCall; instance.pendingGoogleAuthCall=null;
              if(call==null) return true;
              if(resultCode!=android.app.Activity.RESULT_OK || data==null){call.reject("GOOGLE_AUTH_CANCELLED","Autorização do Google cancelada.");return true;}
              try {
                AuthorizationResult result=Identity.getAuthorizationClient(instance.getActivity()).getAuthorizationResultFromIntent(data);
                String token=result.getAccessToken();
                if(token==null||token.isEmpty()) throw new IllegalStateException("O Google não retornou um token de acesso.");
                instance.googleAccessToken=token;
                JSObject r=new JSObject();r.put("authorized",true);call.resolve(r);
              } catch(Exception ex){call.reject("GOOGLE_AUTH_RESULT_FAILED",ex.getMessage()==null?"Falha ao concluir a autorização do Google":ex.getMessage());}
              return true;
            }

            private String jsonEscape(String value){try{return JSONObject.quote(value==null?"":value);}catch(Exception e){return "\\\"\\\"";}}
            private String urlEncode(String value) throws Exception{return URLEncoder.encode(value,"UTF-8");}

            private InputStream openUriInputStream(Uri uri) throws Exception {
              if (uri == null) throw new IllegalArgumentException("URI nula");
              if ("file".equalsIgnoreCase(uri.getScheme())) return new FileInputStream(new File(uri.getPath()));
              InputStream input = getContext().getContentResolver().openInputStream(uri);
              if (input == null) throw new IllegalStateException("Não foi possível abrir o arquivo do backup.");
              return input;
            }

            private long uriLength(Uri uri) throws Exception {
              if (uri != null && "file".equalsIgnoreCase(uri.getScheme())) return new File(uri.getPath()).length();
              android.content.res.AssetFileDescriptor afd = getContext().getContentResolver().openAssetFileDescriptor(uri,"r");
              if (afd != null) { try { long len = afd.getLength(); if (len >= 0) return len; } finally { afd.close(); } }
              long total=0; byte[] buf=new byte[8192]; try(InputStream input=openUriInputStream(uri)){int n;while((n=input.read(buf))!=-1)total+=n;} return total;
            }

            private String http(String method,String urlString,String token,String contentType,byte[] body) throws Exception {
              HttpURLConnection c=(HttpURLConnection)new URL(urlString).openConnection();c.setRequestMethod(method);c.setConnectTimeout(30000);c.setReadTimeout(120000);c.setRequestProperty("Authorization","Bearer "+token);c.setRequestProperty("Accept","application/json");if(contentType!=null)c.setRequestProperty("Content-Type",contentType);if(body!=null){c.setDoOutput(true);c.setFixedLengthStreamingMode(body.length);try(OutputStream out=c.getOutputStream()){out.write(body);}}int code=c.getResponseCode();InputStream in=code>=200&&code<400?c.getInputStream():c.getErrorStream();ByteArrayOutputStream out=new ByteArrayOutputStream();if(in!=null){byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);in.close();}String response=out.toString(StandardCharsets.UTF_8.name());if(code<200||code>=300)throw new IllegalStateException("Google Drive HTTP "+code+": "+response);return response; }

            private String findOrCreateFolder(String token,String name,String parentId) throws Exception {
              String q="name='"+name.replace("'","\\'")+"' and mimeType='application/vnd.google-apps.folder' and trashed=false"+(parentId==null?" and 'root' in parents":" and '"+parentId+"' in parents");
              String url="https://www.googleapis.com/drive/v3/files?q="+urlEncode(q)+"&pageSize=10&fields=files(id,name,mimeType,parents,trashed)";
              JSONObject listed=new JSONObject(http("GET",url,token,null,null));JSONArray files=listed.optJSONArray("files");if(files!=null&&files.length()>0)return files.getJSONObject(0).getString("id");
              JSONObject meta=new JSONObject();meta.put("name",name);meta.put("mimeType","application/vnd.google-apps.folder");JSONArray parents=new JSONArray();if(parentId!=null)parents.put(parentId);meta.put("parents",parents);
              JSONObject created=new JSONObject(http("POST","https://www.googleapis.com/drive/v3/files?fields=id,name,mimeType,parents",token,"application/json; charset=UTF-8",meta.toString().getBytes(StandardCharsets.UTF_8)));return created.getString("id");
            }

            private JSONObject uploadResumable(String token,Uri uri,String fileName,String parentId) throws Exception {
              long length=uriLength(uri);
              String initUrl="https://www.googleapis.com/upload/drive/v3/files?uploadType=resumable&fields=id,name,size,md5Checksum,createdTime,parents";
              JSONObject meta=new JSONObject();meta.put("name",fileName);meta.put("mimeType","application/zip");JSONArray parents=new JSONArray();parents.put(parentId);meta.put("parents",parents);
              HttpURLConnection init=(HttpURLConnection)new URL(initUrl).openConnection();init.setRequestMethod("POST");init.setDoOutput(true);init.setConnectTimeout(30000);init.setReadTimeout(120000);init.setRequestProperty("Authorization","Bearer "+token);init.setRequestProperty("Content-Type","application/json; charset=UTF-8");init.setRequestProperty("X-Upload-Content-Type","application/zip");init.setRequestProperty("X-Upload-Content-Length",String.valueOf(length));byte[] metaBytes=meta.toString().getBytes(StandardCharsets.UTF_8);init.setFixedLengthStreamingMode(metaBytes.length);try(OutputStream out=init.getOutputStream()){out.write(metaBytes);}int initCode=init.getResponseCode();String session=init.getHeaderField("Location");if(initCode<200||initCode>=300||session==null)throw new IllegalStateException("Não foi possível iniciar o upload retomável do Drive (HTTP "+initCode+").");
              final int chunkSize=4*1024*1024;long offset=0;try(InputStream input=openUriInputStream(uri)){byte[] buffer=new byte[chunkSize];int read;while((read=readChunk(input,buffer))>0){long end=offset+read-1;HttpURLConnection put=(HttpURLConnection)new URL(session).openConnection();put.setRequestMethod("PUT");put.setDoOutput(true);put.setConnectTimeout(30000);put.setReadTimeout(180000);put.setRequestProperty("Content-Length",String.valueOf(read));put.setRequestProperty("Content-Range","bytes "+offset+"-"+end+"/"+length);put.setFixedLengthStreamingMode(read);try(OutputStream out=put.getOutputStream()){out.write(buffer,0,read);}int code=put.getResponseCode();if(code==308){String range=put.getHeaderField("Range");if(range!=null&&range.contains("-")){String tail=range.substring(range.lastIndexOf('-')+1);offset=Long.parseLong(tail)+1;}else offset=end+1;}else if(code==200||code==201){InputStream done=put.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream();if(done!=null){byte[] b=new byte[8192];int n;while((n=done.read(b))!=-1)out.write(b,0,n);done.close();}return new JSONObject(out.toString(StandardCharsets.UTF_8.name()));}else{InputStream err=put.getErrorStream();ByteArrayOutputStream out=new ByteArrayOutputStream();if(err!=null){byte[] b=new byte[8192];int n;while((n=err.read(b))!=-1)out.write(b,0,n);}throw new IllegalStateException("Falha no upload do Drive (HTTP "+code+"): "+out.toString(StandardCharsets.UTF_8.name()));}}}throw new IllegalStateException("Upload do Drive terminou sem confirmação.");
            }

            private int readChunk(InputStream input,byte[] buffer) throws Exception{int total=0;while(total<buffer.length){int n=input.read(buffer,total,buffer.length-total);if(n<0)break;if(n==0)continue;total+=n;}return total;}

            private JSONObject getDriveFile(String token,String id) throws Exception {return new JSONObject(http("GET","https://www.googleapis.com/drive/v3/files/"+urlEncode(id)+"?fields=id,name,size,md5Checksum,parents,trashed",token,null,null));}

            private int rotateDriveBackups(String token,String folderId,String keepId) throws Exception {
              String q="'"+folderId+"' in parents and trashed=false and mimeType!='application/vnd.google-apps.folder'";
              String url="https://www.googleapis.com/drive/v3/files?q="+urlEncode(q)+"&pageSize=100&orderBy=createdTime&fields=files(id,name,size,createdTime,trashed)";
              JSONObject listed=new JSONObject(http("GET",url,token,null,null));JSONArray files=listed.optJSONArray("files");if(files==null)return 0;int deleted=0;while(files.length()>5){JSONObject oldest=files.getJSONObject(0);if(oldest.getString("id").equals(keepId)){oldest=files.getJSONObject(1);}String id=oldest.getString("id");http("DELETE","https://www.googleapis.com/drive/v3/files/"+urlEncode(id),token,null,null);deleted++;JSONArray next=new JSONArray();for(int i=0;i<files.length();i++)if(!files.getJSONObject(i).getString("id").equals(id))next.put(files.getJSONObject(i));files=next;}return deleted;
            }

            @PluginMethod public void uploadBackupToGoogleDrive(PluginCall call) {
              String uriString=call.getString("uri","");String fileName=call.getString("fileName","gestao-sacerdotista-aime-backup.zip");if(uriString.isEmpty()){call.reject("DRIVE_URI_MISSING","Arquivo de backup não informado.");return;}
              if(googleAccessToken==null||googleAccessToken.isEmpty()){
                Identity.getAuthorizationClient(getActivity()).authorize(driveAuthorizationRequest()).addOnSuccessListener(result->{ if(result.hasResolution()){JSObject r=new JSObject();r.put("ok",false);r.put("needsAuthorization",true);r.put("message","Conecte o Google Drive antes de enviar o backup.");call.resolve(r);return;} googleAccessToken=result.getAccessToken(); if(googleAccessToken==null||googleAccessToken.isEmpty()){call.reject("DRIVE_TOKEN_EMPTY","Token do Google Drive vazio.");return;} performDriveUpload(call,Uri.parse(uriString),fileName,googleAccessToken); }).addOnFailureListener(e->call.reject("DRIVE_AUTH_FAILED",e.getMessage()==null?"Falha ao autorizar o Drive":e.getMessage()));
                return;
              }
              performDriveUpload(call,Uri.parse(uriString),fileName,googleAccessToken);
            }

            private void performDriveUpload(PluginCall call,Uri uri,String fileName,String token){driveExecutor.execute(()->{try{String root=findOrCreateFolder(token,"Gestão Sacerdotista Aimê",null);String backups=findOrCreateFolder(token,"Backups",root);JSONObject uploaded=uploadResumable(token,uri,fileName,backups);String id=uploaded.getString("id");JSONObject verified=getDriveFile(token,id);long localSize=uriLength(uri);long remoteSize=Long.parseLong(verified.optString("size","-1"));if(remoteSize!=localSize)throw new IllegalStateException("Validação do Drive falhou: tamanho local e remoto diferentes.");int deleted=rotateDriveBackups(token,backups,id);JSObject result=new JSObject();result.put("ok",true);result.put("fileId",id);result.put("folderId",backups);result.put("fileName",verified.optString("name",fileName));result.put("size",remoteSize);result.put("deleted",deleted);call.resolve(result);}catch(Exception ex){call.reject("DRIVE_UPLOAD_FAILED",ex.getMessage()==null?"Falha ao enviar o backup para o Google Drive":ex.getMessage());}});}
          }
          JAVA

      - name: Registrar PermissionBridge
        shell: bash
        run: |
          set -e
          MAIN="$PROJECT_DIR/android/app/src/main/java/com/sacerdotisaaime/gestao/MainActivity.java"
          cat > "$MAIN" <<'JAVA'
          package com.sacerdotisaaime.gestao;

          import android.content.Intent;
          import android.os.Bundle;
          import com.getcapacitor.BridgeActivity;

          public class MainActivity extends BridgeActivity {
            @Override
            public void onCreate(Bundle savedInstanceState) {
              registerPlugin(PermissionBridgePlugin.class);
              super.onCreate(savedInstanceState);
              PermissionBridgePlugin.handleSharedIntent(getIntent());
            }

            @Override
            protected void onNewIntent(Intent intent) {
              super.onNewIntent(intent);
              setIntent(intent);
              PermissionBridgePlugin.handleSharedIntent(intent);
            }

            @Override
            protected void onActivityResult(int requestCode, int resultCode, Intent data) {
              if (!PermissionBridgePlugin.handleGoogleAuthorizationResult(requestCode, resultCode, data)) {
                super.onActivityResult(requestCode, resultCode, data);
              }
            }
          }
          JAVA

      - name: Declarar permissões Android
        shell: bash
        run: |
          set -e
          MANIFEST="$PROJECT_DIR/android/app/src/main/AndroidManifest.xml"
          python3 - "$MANIFEST" <<'PY'
          from pathlib import Path
          import sys

          manifest = Path(sys.argv[1])
          text = manifest.read_text()
          permissions = [
              "android.permission.INTERNET",
              "android.permission.READ_CONTACTS",
              "android.permission.WRITE_CONTACTS",
              "android.permission.RECORD_AUDIO",
              "android.permission.CAMERA",
          ]
          marker = "<application"
          if marker not in text:
              raise SystemExit("ERRO: <application> não encontrado.")
          additions = []
          for permission in permissions:
              if f'android:name="{permission}"' not in text:
                  additions.append(f'    <uses-permission android:name="{permission}" />\n')
          if additions:
              text = text.replace(marker, "".join(additions) + marker, 1)

          import re
          activity_marker = 'android:name=".MainActivity"'
          if activity_marker in text:
              activity_start = text.rfind("<activity", 0, text.find(activity_marker) + len(activity_marker))
              activity_end = text.find("</activity>", activity_start)
              if activity_start >= 0 and activity_end >= 0:
                  activity_block = text[activity_start:activity_end]
                  # O Android precisa encontrar a Activity como destino de compartilhamento.
                  # Declaramos explicitamente exported/grantUriPermissions e aceitamos tanto
                  # audio/* quanto */*. O segundo filtro cobre casos em que WhatsApp/Samsung
                  # entrega o áudio como application/octet-stream ou outro MIME genérico; o
                  # plugin valida o conteúdo antes de importar.
                  activity_block = re.sub(r'\s+android:exported="[^"]*"', '', activity_block)
                  activity_block = re.sub(r'\s+android:grantUriPermissions="[^"]*"', '', activity_block)
                  activity_block = re.sub(r'\s+android:launchMode="[^"]*"', '', activity_block)
                  activity_block = activity_block.replace(
                      '<activity',
                      '<activity android:exported="true" android:grantUriPermissions="true" android:launchMode="singleTask"',
                      1,
                  )
                  # Remove filtros de compartilhamento que possam ter sido adicionados em
                  # uma geração anterior e recria os dois filtros de forma determinística.
                  activity_block = re.sub(
                      r'\s*<intent-filter>\s*<action android:name="android.intent.action.SEND" />.*?</intent-filter>',
                      '', activity_block, flags=re.S,
                  )
                  activity_block = re.sub(
                      r'\s*<intent-filter>\s*<action android:name="android.intent.action.SEND_MULTIPLE" />.*?</intent-filter>',
                      '', activity_block, flags=re.S,
                  )
                  intent_filter = """
                  <intent-filter>
                    <action android:name="android.intent.action.SEND" />
                    <category android:name="android.intent.category.DEFAULT" />
                    <data android:mimeType="audio/*" />
                  </intent-filter>
                  <intent-filter>
                    <action android:name="android.intent.action.SEND_MULTIPLE" />
                    <category android:name="android.intent.category.DEFAULT" />
                    <data android:mimeType="audio/*" />
                  </intent-filter>
                  <intent-filter>
                    <action android:name="android.intent.action.SEND" />
                    <category android:name="android.intent.category.DEFAULT" />
                    <data android:mimeType="image/*" />
                  </intent-filter>
                  <intent-filter>
                    <action android:name="android.intent.action.SEND_MULTIPLE" />
                    <category android:name="android.intent.category.DEFAULT" />
                    <data android:mimeType="image/*" />
                  </intent-filter>
                  <intent-filter>
                    <action android:name="android.intent.action.SEND" />
                    <category android:name="android.intent.category.DEFAULT" />
                    <data android:mimeType="*/*" />
                  </intent-filter>
                  <intent-filter>
                    <action android:name="android.intent.action.SEND_MULTIPLE" />
                    <category android:name="android.intent.category.DEFAULT" />
                    <data android:mimeType="*/*" />
                  </intent-filter>"""
                  activity_block = activity_block + intent_filter
                  text = text[:activity_start] + activity_block + text[activity_end:]
          manifest.write_text(text)
          PY

      - name: Preparar keystore
        shell: bash
        env:
          ANDROID_KEYSTORE_BASE64: ${{ secrets.ANDROID_KEYSTORE_BASE64 }}
        run: |
          set -e
          KEYSTORE="$PROJECT_DIR/android/app/release-key.jks"
          printf '%s' "$ANDROID_KEYSTORE_BASE64" | base64 --decode > "$KEYSTORE"
          test -s "$KEYSTORE"
          chmod 600 "$KEYSTORE"
          echo "Keystore preparada."

      - name: Configurar versão e assinatura
        shell: bash
        env:
          ANDROID_KEYSTORE_PASSWORD: ${{ secrets.ANDROID_KEYSTORE_PASSWORD }}
          ANDROID_KEY_ALIAS: ${{ secrets.ANDROID_KEY_ALIAS }}
          ANDROID_KEY_PASSWORD: ${{ secrets.ANDROID_KEY_PASSWORD }}
        run: |
          set -e
          APP_GRADLE="$PROJECT_DIR/android/app/build.gradle"
          test -f "$APP_GRADLE" || { echo "ERRO: build.gradle não encontrado."; exit 1; }

          python3 - "$APP_GRADLE" <<'PY'
          from pathlib import Path
          import re
          import sys

          path = Path(sys.argv[1])
          text = path.read_text()

          if "com.google.android.gms:play-services-auth:21.4.0" not in text:
              if "dependencies {" in text:
                  text = text.replace("dependencies {", "dependencies {\n    implementation 'com.google.android.gms:play-services-auth:21.4.0'", 1)
              else:
                  text += "\ndependencies { implementation 'com.google.android.gms:play-services-auth:21.4.0' }\n"

          text = re.sub(r'versionName\s+"[^"]+"', 'versionName "1.27.0"', text, count=1)
          text = re.sub(r'versionCode\s+\d+', 'versionCode 127', text, count=1)

          if 'signingConfigs {' not in text:
              signing = '''
              signingConfigs {
                  release {
                      storeFile file("release-key.jks")
                      storePassword System.getenv("ANDROID_KEYSTORE_PASSWORD")
                      keyAlias System.getenv("ANDROID_KEY_ALIAS")
                      keyPassword System.getenv("ANDROID_KEY_PASSWORD")
                  }
              }
              '''
              text = text.replace('android {', 'android {' + signing, 1)
          elif 'signingConfigs.release' not in text:
              text = text.replace('signingConfigs {', '''signingConfigs {
                  release {
                      storeFile file("release-key.jks")
                      storePassword System.getenv("ANDROID_KEYSTORE_PASSWORD")
                      keyAlias System.getenv("ANDROID_KEY_ALIAS")
                      keyPassword System.getenv("ANDROID_KEY_PASSWORD")
                  }
              ''', 1)

          build_types = re.search(r'buildTypes\s*\{', text)
          if not build_types:
              text += '''
              \nbuildTypes {
                  release {
                      signingConfig signingConfigs.release
                      minifyEnabled false
                  }
              }
              '''
          else:
              tail = text[build_types.end():]
              release = re.search(r'release\s*\{', tail)
              if not release:
                  pos = build_types.end()
                  text = text[:pos] + '''
                  release {
                      signingConfig signingConfigs.release
                      minifyEnabled false
                  }
                  ''' + text[pos:]
              elif 'signingConfig signingConfigs.release' not in tail[release.end():release.end()+2500]:
                  pos = build_types.end() + release.end()
                  text = text[:pos] + '''
                      signingConfig signingConfigs.release
                      minifyEnabled false
                  ''' + text[pos:]

          path.write_text(text)
          PY

          keytool -list \
            -keystore "$PROJECT_DIR/android/app/release-key.jks" \
            -storepass "$ANDROID_KEYSTORE_PASSWORD" \
            -alias "$ANDROID_KEY_ALIAS" >/dev/null

          echo "Keystore e alias validados."

      - name: Validar Manifest
        shell: bash
        run: |
          set -e
          MANIFEST="$PROJECT_DIR/android/app/src/main/AndroidManifest.xml"
          for PERM in INTERNET READ_CONTACTS WRITE_CONTACTS RECORD_AUDIO CAMERA; do
            FULL="android.permission.$PERM"
            grep -q "$FULL" "$MANIFEST" || { echo "ERRO: $FULL não está no Manifest."; exit 1; }
            echo "OK: $FULL"
          done
          grep -q 'android:launchMode="singleTask"' "$MANIFEST" || { echo "ERRO: MainActivity sem launchMode=singleTask."; exit 1; }
          echo "OK: MainActivity launchMode=singleTask"
          grep -q 'android.intent.action.SEND' "$MANIFEST" || { echo "ERRO: filtro ACTION_SEND ausente."; exit 1; }
          grep -q 'android.intent.action.SEND_MULTIPLE' "$MANIFEST" || { echo "ERRO: filtro ACTION_SEND_MULTIPLE ausente."; exit 1; }
          echo "OK: filtros de compartilhamento presentes."

      - name: Gerar APK RELEASE
        shell: bash
        env:
          ANDROID_KEYSTORE_PASSWORD: ${{ secrets.ANDROID_KEYSTORE_PASSWORD }}
          ANDROID_KEY_ALIAS: ${{ secrets.ANDROID_KEY_ALIAS }}
          ANDROID_KEY_PASSWORD: ${{ secrets.ANDROID_KEY_PASSWORD }}
        run: |
          set -e

          # As variáveis precisam estar disponíveis NESTA etapa,
          # porque é aqui que o Gradle lê System.getenv(...).
          test -n "$ANDROID_KEYSTORE_PASSWORD" || {
            echo "ERRO: ANDROID_KEYSTORE_PASSWORD não chegou ao Gradle."
            exit 1
          }

          test -n "$ANDROID_KEY_ALIAS" || {
            echo "ERRO: ANDROID_KEY_ALIAS não chegou ao Gradle."
            exit 1
          }

          test -n "$ANDROID_KEY_PASSWORD" || {
            echo "ERRO: ANDROID_KEY_PASSWORD não chegou ao Gradle."
            exit 1
          }

          cd "$PROJECT_DIR/android"
          chmod +x gradlew

          ./gradlew assembleRelease --no-daemon

      - name: Localizar APK final
        shell: bash
        run: |
          set -e
          APK="$PROJECT_DIR/android/app/build/outputs/apk/release/app-release.apk"
          if [ ! -f "$APK" ]; then
            echo "ERRO: APK release não encontrado."
            find "$PROJECT_DIR/android" -type f -name "*.apk" -print
            exit 1
          fi
          ls -lh "$APK"
          echo "APK_PATH=$APK" >> "$GITHUB_ENV"

      - name: Validar permissões do APK
        shell: bash
        run: |
          set -e
          APK="$APK_PATH"
          AAPT=$(find "$ANDROID_HOME/build-tools" -type f -name aapt | sort -V | tail -n 1)
          test -n "$AAPT" || { echo "ERRO: aapt não encontrado."; exit 1; }
          "$AAPT" dump permissions "$APK" | tee /tmp/apk-permissions.txt
          for PERM in READ_CONTACTS WRITE_CONTACTS RECORD_AUDIO CAMERA; do
            FULL="android.permission.$PERM"
            grep -q "$FULL" /tmp/apk-permissions.txt || { echo "ERRO: $FULL não está no APK."; exit 1; }
            echo "OK NO APK: $FULL"
          done
          "$AAPT" dump xmltree "$APK" AndroidManifest.xml | grep -q 'launchMode.*singleTask' || { echo "ERRO: launchMode=singleTask não encontrado no APK."; exit 1; }
          echo "OK NO APK: launchMode=singleTask"

      - name: Validar assinatura do APK
        shell: bash
        run: |
          set -e
          APK="$APK_PATH"
          APKSIGNER=$(find "$ANDROID_HOME/build-tools" -type f -name apksigner | sort -V | tail -n 1)
          test -n "$APKSIGNER" || { echo "ERRO: apksigner não encontrado."; exit 1; }
          "$APKSIGNER" verify --verbose "$APK"

      - name: Disponibilizar APK
        uses: actions/upload-artifact@v4
        with:
          name: gestao-sacerdotista-aime-v119-audio-photo-share
          path: ${{ env.APK_PATH }}
          if-no-files-found: error
          retention-days: 1

      - name: Limpar arquivo temporário de assinatura
        if: always()
        shell: bash
        run: |
          rm -f "$PROJECT_DIR/android/app/release-key.jks" 2>/dev/null || true
