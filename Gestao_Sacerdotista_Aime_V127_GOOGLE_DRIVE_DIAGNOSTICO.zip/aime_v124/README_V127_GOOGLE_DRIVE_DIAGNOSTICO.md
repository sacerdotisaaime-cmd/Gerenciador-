# V127 — Google Drive diagnóstico

Baseada integralmente na V126.

Correções desta versão:
- força o seletor de conta do Google na autorização;
- exibe no aplicativo o código/status retornado pelo Google quando a autorização falha;
- registra o erro nativo no Logcat;
- mantém `drive.file`, upload resumível, validação e rotação de backups.

Objetivo: descobrir se o bloqueio restante é certificado/pacote, Google Play Services, OAuth ou autorização da conta, sem esconder o erro real.
