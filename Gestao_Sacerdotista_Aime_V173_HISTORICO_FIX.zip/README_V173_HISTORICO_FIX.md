# V173 — HISTÓRICO DOS CONSULENTES — FIX ISOLADO

Correção exclusivamente no pipeline do Histórico dos Consulentes.

## Alterações
- `src/supabaseSync.ts`: consultas com o mesmo ID agora são mescladas de forma conservadora durante a sincronização local/Supabase; uma versão mais nova porém parcial não apaga perguntas, fotos, áudios, parcelas/cobranças e demais dados históricos existentes.
- `src/App.tsx`: a deduplicação de consultas deixou de substituir cegamente um registro completo por outro apenas por `updatedAt` e passou a mesclar os campos históricos.
- Mantida a lógica atual de seleção do histórico por `clientId` com fallback por nome.
- Nenhuma alteração deliberada em QR/NFC-e, áudio, agenda, Standby, financeiro ou demais módulos.

## Objetivo
Evitar a regressão em que o consulente aparece no CRM, mas o histórico abre com registros incompletos ou sem os detalhes anteriormente gravados.
