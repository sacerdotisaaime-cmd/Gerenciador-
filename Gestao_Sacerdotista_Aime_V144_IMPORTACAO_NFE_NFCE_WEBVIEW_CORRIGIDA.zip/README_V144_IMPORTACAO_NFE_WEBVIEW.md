# V144 — Importação NFC-e/NF-e via WebView

## Correção principal
A V143 fazia a consulta da URL do QR Code da SEFAZ por `HttpURLConnection`. Isso não equivale ao navegador do celular: páginas da SEFAZ podem depender de JavaScript, cookies, redirecionamentos e conteúdo dinâmico.

A V144 muda o transporte nativo para um `WebView` Android invisível, com JavaScript e DOM Storage habilitados. A URL do QR Code é carregada como navegador, aguarda o conteúdo e então o HTML final é devolvido ao React para o parser de NFC-e/NF-e.

## Mantido
- Leitura do QR Code com ZXing/Capacitor Barcode Scanner.
- Colagem manual da URL do QR Code.
- Extração da chave de acesso.
- Importação de fornecedor, data, itens, quantidade, unidade, preço unitário, total e valor final.
- Registro da compra após conferência.
- Google Drive e demais funções existentes da base V143.

## Correções adicionais
- URLs NFC-e de SP com `|` cru no parâmetro `p` são normalizadas para `%7C`.
- O resultado registra o transporte `android-webview` para diagnóstico.
- Há tentativas de extração após 1,8 s, 4,5 s e 8 s, além de limite final de 15 s.
- Mantido fallback HTTP para situações em que não seja possível criar o WebView.

## Limitação
Se a SEFAZ apresentar CAPTCHA/desafio humano, o app não deve tentar burlar o desafio. Nesse caso a URL pode ser aberta no navegador do celular e a consulta manual pode ser usada.
