# Gestão Sacerdotista Aimê — V100

## Correções desta versão

### 1. Persistência de Agenda após reinstalação
- A Agenda continua sendo armazenada localmente em `gestao_agenda`.
- O snapshot do Supabase agora também inclui `gestao_inventory`, que estava ausente nas versões anteriores.
- Agenda e Inventário fazem sincronização adicional com o snapshot na nuvem, com debounce curto após alterações.
- Isso reduz o risco de uma alteração recente ficar apenas no armazenamento local antes de uma desinstalação/reinstalação.
- A restauração continua usando a conta autenticada do aplicativo.

### 2. Prioridade da Agenda
- A escala usada na Agenda agora é de **1 a 5**.
- 1 = menor prioridade.
- 5 = máxima prioridade.
- A área `⭐ Prioridades` da tela inicial ordena primeiro pela prioridade e, em empate, por data/hora.
- A Agenda também ordena os trabalhos/agendamentos pela prioridade antes de usar data/hora como desempate.
- Atendimentos e trabalhos criados/agendados carregam a prioridade para o registro central da Agenda.
- Trabalhos criados a partir de orçamento também podem receber prioridade.
- Prioridades antigas acima de 5 são limitadas a 5 na leitura/atualização.

### 3. Inventário
- O cadastro do Inventário passa a fazer parte do snapshot sincronizado.
- A abertura do cadastro foi reforçada para ocorrer após a montagem da tela, evitando perda do clique em dispositivos Android mais lentos.
- A edição de item também força a tela de Inventário antes de abrir o modal.

## Validação
- A comparação de TypeScript foi feita contra a V99 para verificar regressões introduzidas por esta versão.
- Os erros estruturais restantes são problemas já existentes na base V99/ambiente de tipagem, e a alteração desta versão não introduziu erro duplicado de prioridade.
- A instalação completa das dependências não terminou dentro do ambiente de validação, portanto o build Vite/Android completo não foi declarado como validado.
