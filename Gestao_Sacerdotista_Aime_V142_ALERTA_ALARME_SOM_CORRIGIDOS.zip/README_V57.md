# Gestão Sacerdotista Aimê — V57

## Foco desta versão
Esta versão é exclusivamente uma correção do acesso ao módulo de reset/limpeza para testes.

### Correção principal
Na V56, o cartão **Limpeza / Testes** estava sendo renderizado dentro do `<section>` de **Financeiro** por falta de fechamento do bloco de Moedas e taxas. Como o bloco financeiro ficava `display:none` quando `settingsTab` era `maintenance`, o módulo de reset também ficava oculto.

Na V57, o bloco de Moedas e taxas é fechado antes do módulo de manutenção. Assim, ao tocar em **🧪 Limpar dados para teste** ou na aba **🧹 Limpeza / Testes**, o painel de reset passa a aparecer normalmente.

### O que permanece no reset
- Reset por módulo.
- Reset geral.
- Confirmação com contagem de 3 segundos.
- Escolha do destino: Supabase + armazenamento local, somente Supabase ou somente armazenamento local.
- Login/Supabase Auth preservado.
- Limpeza do snapshot Supabase e armazenamento local conforme o destino escolhido.

Nenhuma outra funcionalidade do aplicativo foi alterada propositalmente nesta versão.
