-- V13: backup/restauração completa do estado do aplicativo.
-- Execute este bloco no SQL Editor do Supabase.
create table if not exists public.app_snapshots (
  user_id uuid primary key references auth.users(id) on delete cascade,
  payload jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.app_snapshots enable row level security;

drop policy if exists "app_snapshots_select_own" on public.app_snapshots;
drop policy if exists "app_snapshots_insert_own" on public.app_snapshots;
drop policy if exists "app_snapshots_update_own" on public.app_snapshots;
drop policy if exists "app_snapshots_delete_own" on public.app_snapshots;

create policy "app_snapshots_select_own" on public.app_snapshots
for select to authenticated using (user_id = auth.uid());

create policy "app_snapshots_insert_own" on public.app_snapshots
for insert to authenticated with check (user_id = auth.uid());

create policy "app_snapshots_update_own" on public.app_snapshots
for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

create policy "app_snapshots_delete_own" on public.app_snapshots
for delete to authenticated using (user_id = auth.uid());

grant select, insert, update, delete on public.app_snapshots to authenticated;
