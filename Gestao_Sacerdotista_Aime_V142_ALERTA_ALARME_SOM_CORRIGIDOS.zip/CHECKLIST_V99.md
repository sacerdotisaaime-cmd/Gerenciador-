# CHECKLIST V99

## Layout / identidade
- [x] Acompanhamento de parcelas usa a foto real da consulente.
- [x] Nome da consulente não quebra letra por letra.
- [x] Nome usa reticências quando faltar espaço, mantendo leitura horizontal.
- [x] Standby não repete o nome da consulente.
- [x] Ações do standby podem ocupar uma segunda linha no celular sem espremer a identidade.
- [x] Títulos que repetem exatamente o nome da consulente são apresentados como tipo do serviço em pontos do Dashboard.

## Visão geral do mês
- [x] Somente Agendamentos, Atendimentos e Trabalhos.
- [x] Cards compactos.
- [x] Vendas, Contas e Parcelas removidos da visão geral.
- [x] Visão geral posicionada depois de “O que merece atenção primeiro”.
- [x] Navegação entre meses preservada.

## Preservação
- [x] Base V98 preservada.
- [x] Fluxo de áudio não foi alterado.
- [x] Nenhuma regra financeira das parcelas foi removida nesta versão.

## Validação
- [x] Verificação sintática via TypeScript global: não foram reportados erros de sintaxe; os erros restantes são de dependências/tipos ausentes porque `node_modules` não pôde ser instalado no ambiente.
- [ ] Build completo: não executado com sucesso por ausência das dependências locais; tentativas de `npm install` excederam o limite de tempo do ambiente.
