# Gestão Sacerdotista Aimê — V97

## Correção principal: recebimentos parciais e operações financeiras das parcelas

A V97 parte da V96 e preserva o módulo de áudio corrigido. Esta versão corrige o fluxo financeiro das parcelas para que operações feitas pelo dashboard/agenda financeira sejam tratadas como operações de registro, sem reabrir o atendimento ou o checkout.

### O que foi corrigido

- Recebimento parcial grava cada pagamento em `installment.payments[]` e atualiza `receivedAmount`/status.
- O recebimento parcial não chama mais o atualizador que abre `activeConsultation` e grava `DRAFT_KEY`.
- "Pagou" depois de um parcial registra somente o saldo restante como um novo pagamento, em vez de recriar o valor integral da parcela.
- Cada pagamento real gera seu próprio espelho financeiro, mantendo o histórico dos valores efetivamente recebidos.
- O histórico financeiro passa a derivar recebimentos de `payments[]`, com compatibilidade para parcelas antigas sem essa lista.
- O dashboard/agenda mostra o valor em aberto, o valor já recebido e o valor original quando houver pagamento parcial.
- O detalhe das parcelas identifica "Pago parcialmente" e mostra recebido/restante.
- "Não pagar" após pagamento parcial calcula o desfalque apenas sobre o saldo restante.
- "Prorrogar" usa atualização somente de registro e não abre o atendimento.
- A restauração do aplicativo não força a tela de consulta apenas porque existe um `activeConsultationId` antigo quando a última tela salva era o dashboard/financeiro.
- O fluxo também foi aplicado às parcelas vinculadas a perguntas.

### Regra esperada

Exemplo de uma parcela de R$ 500,00:

1. Receber R$ 150,00 → recebido R$ 150,00, restante R$ 350,00, parcela continua pendente/parcial.
2. Receber o restante → registra outro pagamento de R$ 350,00, recebido total R$ 500,00, parcela quitada.
3. Se marcar como não paga depois dos R$ 150,00 → desfalque de R$ 350,00, preservando os R$ 150,00 recebidos.
4. Em nenhuma dessas operações o aplicativo deve abrir a consulta/checkout.

## Validação

A tentativa de `npm run build` foi feita, mas o ambiente desta execução não possuía as dependências completas do projeto (`vite/client` e tipos de Node não estavam instalados); por isso não foi possível concluir o build local. A checagem de parsing TypeScript do arquivo não apontou erros de sintaxe.
