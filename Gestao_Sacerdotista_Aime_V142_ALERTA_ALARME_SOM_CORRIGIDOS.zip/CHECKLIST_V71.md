# Checklist V71

- [x] Baseada integralmente na V70 completa.
- [x] Corrigido o cadastro rápido de trabalho: camada própria `quick-catalog-layer`.
- [x] Corrigido o cadastro rápido de venda pelo mesmo mecanismo.
- [x] Mantido o estado da janela pai.
- [x] Mantido `saveQuickCatalog` e seleção automática do item criado.
- [x] Mantidos login, Supabase, financeiro, agenda, clientes, serviços, relatórios, áudio, fotos e demais funções da V70.
- [x] Transpile TS/TSX validado.
- [ ] Teste físico no Android ainda precisa ser feito.
