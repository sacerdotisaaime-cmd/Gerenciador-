# Gestão Sacerdotista Aimê — V61

Correção da V60.

- Corrige o erro de inicialização causado pelo efeito de restauração da câmera capturar `consultations` antes da declaração do estado.
- A restauração do atendimento após retorno da câmera agora acontece durante a hidratação dos dados, usando o snapshot salvo antes da câmera.
- Mantém as correções da V60: cadastro rápido de consulente, organização da Agenda, ações rápidas, atrasados, deduplicação de tipos de tiragem e preservação do atendimento.
- Preserva o núcleo de autenticação/Supabase.
