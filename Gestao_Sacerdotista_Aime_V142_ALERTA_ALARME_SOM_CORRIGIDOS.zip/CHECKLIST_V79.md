# Checklist V79

- [x] Standby continua separado de concluído.
- [x] Standby não entra no Histórico do consulente.
- [x] Standby não entra em Feito hoje.
- [x] Standby não entra nos recebíveis financeiros.
- [x] Standby permanece visível na tela inicial.
- [x] Histórico mostra somente `completed`.
- [x] Data do cabeçalho inclui dia da semana.
- [x] Textos “Bom dia...” removidos da tela inicial.
- [x] Visão mensal adicionada.
- [x] Navegação mensal adicionada.
- [x] Prioridade 1–10 adicionada ao agendamento.
- [x] Área de prioridades adicionada à tela inicial.
- [x] Projeto versionado como 0.79.0.
- [x] 5 arquivos TS/TSX transpilados sem diagnósticos de sintaxe.
