# V139 — Agenda: notificações nativas confiáveis

- Solicita/valida a permissão nativa de notificações no momento do agendamento.
- Agenda imediatamente o aviso do compromisso recém-criado/alterado.
- Reagendamento cancela o aviso antigo e programa o novo horário.
- Canal Android próprio da Agenda (`gestao-agenda-v139`) com importância alta, som padrão e vibração.
- Reconciliação automática dos avisos ao abrir/retomar o aplicativo.
- Mantém notificações de atendimentos, trabalhos, vendas e compromissos manuais.
- Mantém fallback sem `allowWhileIdle` caso o Android rejeite o alarme exato.
