import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.sacerdotisaaime.gestao',
  appName: 'Gestão Sacerdotisa Aime',
  webDir: 'dist',
  bundledWebRuntime: false,
};

export default config;
