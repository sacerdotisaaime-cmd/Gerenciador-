# Gestão Sacerdotisa Aimê — V14

V14 integra consulentes, orçamentos, trabalhos, tiragens relacionadas, atividades gratuitas, desfalques, histórico, registro diário, financeiro e relatórios.

## Fluxo central
Consulente → orçamento → trabalho → tiragem/atividade → pagamento/desfalque → histórico → financeiro → relatórios.

## Novidades
- Tiragem/atividade pode ser vinculada a um trabalho.
- Trabalho pode ser marcado como realizado.
- Suporte grátis registra valor potencial e desfalque.
- Desfalques separados para descontos, brindes, serviços gratuitos e inadimplência.
- Histórico mostra orçamentos, trabalhos e atividades vinculadas.
- Registro diário permite histórico rápido e edição direta de entradas/saídas/orçamentos.
- Menu ganhou Relatórios com comparação de dois meses.
- Relatórios mostram entradas, saídas, lucro, desfalques, gastos por setor e visão de rentabilidade por trabalho.
- Novo orçamento acessível a partir do Novo atendimento.
- Dados novos continuam incluídos no snapshot V13/V14.

## Supabase
A restauração completa continua usando `app_snapshots`. O arquivo `SUPABASE_V14.sql` adiciona a tabela opcional `desfalques` para futura sincronização relacional.

## Atenção
Esta versão ainda não envia fotos/áudios Base64 para Storage automaticamente; o snapshot mantém o estado local para restauração. A migração definitiva de mídia para Storage pode ser feita em uma etapa específica depois de validar o fluxo.

## Build Android
O workflow inclui um fallback de repositório Maven para reduzir falhas 403/Forbidden durante a resolução das dependências do Gradle.
