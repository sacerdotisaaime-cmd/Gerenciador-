# Gestão Sacerdotista Aimê — V93

## Correção do botão Gravar áudio

Base: V92.

### Correções principais
- O botão **Gravar áudio** agora usa um handler isolado que impede que o toque seja capturado por cards, accordions ou formulários ancestrais.
- `openAudioRecorder()` não bloqueia mais a abertura por estados temporários antigos (`audioRecorderStarting`/prévia pendente).
- Ao abrir o gravador, estados temporários de uma tentativa anterior são limpos.
- Abrir o gravador **nunca inicia o microfone**; somente o botão interno `Iniciar gravação` inicia a gravação.
- Se uma gravação real estiver ativa, o sistema informa isso em vez de ignorar silenciosamente o toque.
- O modal continua sendo renderizado em portal, isolado do restante da tela.
- Finalização continua salvando automaticamente o áudio e vinculando-o à pergunta/atendimento e ao histórico da consulente.
- Os áudios salvos continuam com reprodução, compartilhamento individual e opção de gravar mais áudio.

### Verificação
Foi feita uma verificação de parsing/TypeScript do `src/App.tsx`. O ambiente desta execução não tinha as dependências npm instaladas; a tentativa de `npm install` expirou, então não foi possível executar o build completo aqui. Os erros restantes reportados pelo TypeScript são principalmente de módulos/tipagens ausentes por falta das dependências no ambiente.
