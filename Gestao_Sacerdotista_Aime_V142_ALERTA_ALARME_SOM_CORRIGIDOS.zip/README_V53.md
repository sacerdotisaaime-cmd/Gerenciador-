# Gestão Sacerdotista Aimê — V53

## Principais correções e mudanças

- Fluxo orçamento aprovado → janela de configuração do trabalho → criação do trabalho.
- Na criação do trabalho é possível confirmar valor, pagamento/parcelamento, observações e agendamento.
- Trabalho agendado é sincronizado com a Agenda e aparece nos próximos agendamentos.
- Próximos agendamentos de trabalho possuem ação **Executar**.
- Janela **Executar trabalho** reorganizada em seções expansíveis:
  - estoque e materiais;
  - financeiro, valor e parcelas;
  - agendamento;
  - observações da execução.
- Financeiro da execução permite revisar valor, forma de recebimento, vencimentos e status de parcelas.
- Recebimentos registrados na execução são vinculados ao financeiro; parcelas marcadas manualmente como não pagas podem gerar desfalque.
- Status de parcela não pago continua sendo uma decisão manual; atraso não vira automaticamente desfalque.
- Modais continuam em quase tela cheia no celular, com rolagem única do conteúdo para evitar bloqueio no rodapé.
- Permissões nativas preparadas na abertura do aplicativo: notificações, câmera, microfone, contatos e acessos especiais de sobreposição/alarmes.
- Workflow Android atualizado para declarar e verificar POST_NOTIFICATIONS, CAMERA, RECORD_AUDIO, contatos, SYSTEM_ALERT_WINDOW e SCHEDULE_EXACT_ALARM.

## Validação

A estrutura JSX/TypeScript foi verificada com o compilador TypeScript global disponível no ambiente; não foram encontrados erros de sintaxe após as alterações. A instalação completa das dependências (`npm ci`) excedeu o limite de tempo deste ambiente, então o build final deve ser executado pelo GitHub Actions.
