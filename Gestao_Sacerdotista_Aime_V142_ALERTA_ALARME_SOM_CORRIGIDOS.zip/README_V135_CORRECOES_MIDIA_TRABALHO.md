# V135 — Correções de mídia no Novo Trabalho

## Correções incluídas

1. **Mídia importada enquanto “Novo trabalho” está aberto**
   - Quando o novo trabalho está dentro de uma tiragem/atendimento, a janela de mídia não oferece mais as opções de pergunta, ficha da consulente ou informações recebidas.
   - Ela mostra somente os destinos próprios do trabalho:
     - Enviar para o trabalho
     - Cliente foi informado sobre os termos e condições
     - Cliente consentiu com os termos e condições
   - A opção de compartilhar as mídias juntas e deixar somente na Caixa de Mídias continua disponível.

2. **Suporte específico ao Novo trabalho dentro da tiragem**
   - O fluxo `relatedCharge` foi incluído para fotos e áudios.
   - A Caixa de Mídias do próprio trabalho pode importar mídia diretamente para o trabalho, para o registro de termos informados ou para o registro de consentimento.

3. **Reprodução de áudio da Caixa de Mídias / galeria**
   - O MIME original da mídia passou a ser preservado no `AudioItem`.
   - O player não força mais `audio/ogg` para arquivos que podem ser AAC, M4A, MP3, WAV etc.
   - Isso corrige casos em que o botão de play/pause aparecia, mas o áudio não reproduzia.

4. **Limpeza da Caixa de Mídias ao finalizar o atendimento**
   - Mídias temporárias ligadas ao atendimento são removidas da Caixa de Mídias quando o atendimento é finalizado.
   - As cópias que foram efetivamente anexadas ao histórico, pergunta, trabalho ou ficha continuam preservadas.

5. **Rastreamento de mídias do trabalho**
   - Quando uma mídia é importada para um trabalho durante um atendimento ativo, ela fica vinculada ao ID do atendimento para permitir a limpeza automática no encerramento.

## Observação de build

A compilação completa não foi executada neste ambiente por ausência das dependências completas do projeto. Foi feita uma verificação TypeScript com o compilador disponível; os erros restantes são preexistentes no código-base e/ou relacionados à configuração de tipos, e não aos novos fluxos principais desta versão.
