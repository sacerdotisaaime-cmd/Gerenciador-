# Gestão Sacerdotista Aimê — V54

## Alterações desta versão

- Nova consulta: opção **Tiragem relacionada a um trabalho**, filtrando automaticamente os trabalhos da consulente selecionada.
- Cada trabalho possui **1 única pergunta-benefício gratuita**. Ela não gera desfalque.
- Perguntas seguintes vinculadas ao mesmo trabalho ficam como **pagas**.
- Uma **cortesia extra** é separada do benefício do trabalho e também não gera desfalque.
- A consulta e o histórico passam a guardar o vínculo da pergunta com o trabalho, número da pergunta e tipo (benefício, paga ou cortesia).
- Histórico e Central de Serviços mostram a quantidade de perguntas do trabalho, separando benefício, pagas e cortesias, com datas.
- Tela **Executar trabalho** agora permite BRL/EUR/USD/GBP, conversão pela cotação disponível, PayPal/Wise/Outros e a taxa cadastrada em Configurações.
- A taxa do método fica registrada no plano financeiro do trabalho e a receita recebida mantém valor bruto/taxa.
- Ao entrar novamente no aplicativo, a tela de fundo volta para **Início**.
- A janela de permissões permanece dentro do aplicativo; Sobreposição e Alarmes só abrem as Configurações do Android quando o usuário toca em **Configurar**.
- Mantidos o login/Supabase, Central de Serviços, execução, estoque, agenda, notificações, histórico e financeiro existentes.

## Observação de build

A checagem local foi feita com TypeScript/JSX. O ambiente atual não possui todos os módulos em `node_modules`, então os erros restantes são de módulos/tipos ausentes; a validação final do APK continua sendo feita pelo GitHub Actions.
