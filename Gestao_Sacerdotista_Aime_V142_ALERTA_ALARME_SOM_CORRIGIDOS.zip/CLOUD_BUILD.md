# Build em nuvem — V69

1. Envie o conteúdo deste projeto para o repositório configurado.
2. Abra GitHub → Actions → Build Android APK.
3. Execute `Run workflow`.
4. O projeto usa `npm run build` e depois Capacitor/Gradle conforme o workflow.

A validação local desta entrega confirmou o transpile de todos os arquivos TS/TSX de `src/`. O build completo depende da instalação das dependências no runner do GitHub.
