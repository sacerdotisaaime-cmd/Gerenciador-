# Gestão Sacerdotista Aimê — V56

## Correções desta versão

- Card Avisos da tela inicial com layout responsivo corrigido para evitar quebra vertical de nomes e ações.
- Avisos agora exibem etiqueta de origem:
  - CONTA A PAGAR em vermelho.
  - PARCELA A RECEBER em verde.
- Status do aviso continua separado da origem: pendente, vence hoje, atrasada ou prorrogada.
- Central de Contas permanece minimizável.
- Reset de módulos ampliado, incluindo Consulentes, Atendimentos/Tiragens, Trabalhos, Vendas, Agenda, Orçamentos, Execuções, Financeiro, Estoque, Fornecedores, Compras futuras, Notas, Lixeira, Cadastros/Configurações e Organização.
- Reset de Trabalhos e Vendas é seletivo: remove os registros correspondentes sem apagar consultas comuns não relacionadas.
- Reset Financeiro também limpa os planos de pagamento/parcelamentos financeiros dentro dos atendimentos e perguntas, sem apagar os atendimentos em si.
- Todo reset passa por janela de confirmação com contagem regressiva de 3 segundos.
- O usuário escolhe aplicar a limpeza somente no Supabase, somente no armazenamento local ou nos dois.
- Reset geral limpa o snapshot inteiro no Supabase e o armazenamento local, preservando login/Supabase Auth.
- Reset do Supabase usa atualização do snapshot existente para preservar módulos que não foram selecionados.

## Validação

- O código foi checado com TypeScript global para parsing/JSX. O ambiente desta sessão não possui node_modules completos, portanto erros de módulos/tipos externos não representam falha de sintaxe do código.
- A compilação final do APK deve ser validada pelo GitHub Actions.
