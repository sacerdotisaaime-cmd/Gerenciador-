# Gestão Sacerdotisa Aimê — V20

## Fluxo integrado de consulta, trabalho, venda e orçamento

- Parcelamentos mostram número de parcelas e permitem registrar a primeira como entrada paga, deixando o restante pendente.
- O checkout final da tiragem reúne a própria consulta + trabalhos + vendas adicionados durante o atendimento.
- A nova tiragem pode ser marcada como relacionada a um trabalho existente do consulente.
- O histórico mostra a etiqueta de trabalho relacionado e discrimina trabalhos/vendas adicionados à tiragem.
- Nova consulta mantém o fluxo de perguntas; trabalho e venda continuam como fluxos independentes.
- Durante uma tiragem há botões para adicionar novo trabalho ou nova venda para o mesmo consulente.
- Trabalho pode ser relacionado a orçamento e pode ser agendado; trabalho agendado entra na Agenda.
- Venda/trabalho continuam com moeda, pagamento, parcelamento, fotos, áudios, observações e vínculo com orçamento quando aplicável.
- Configurações agora possuem cadastro de tipos de trabalho e itens para venda.
- Itens de venda podem ter categoria e preço padrão.
- Orçamento direto continua disponível no módulo de Orçamentos.

## Observação
Os registros adicionados durante a tiragem ficam aguardando o checkout final, evitando criar cobranças duplicadas antes do encerramento.
