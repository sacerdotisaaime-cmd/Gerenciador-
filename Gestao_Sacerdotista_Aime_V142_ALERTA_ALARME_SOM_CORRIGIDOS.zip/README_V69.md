# V69 — Correções dos bugs encontrados na V68

A V69 parte do projeto completo da V68/V65 e corrige os problemas encontrados durante o uso real:

- foto da consulente não aparecendo na lista;
- histórico do dia acessível pelo menu, com data, pesquisa e filtros;
- data duplicada no cabeçalho;
- modais secundários abrindo atrás do modal atual;
- pausa real de áudio com confirmação do estado nativo e contador pausado.

Também preserva as correções anteriores da V68.

Consulte `CHECKLIST_V69.md` para conferir os 18 itens.
