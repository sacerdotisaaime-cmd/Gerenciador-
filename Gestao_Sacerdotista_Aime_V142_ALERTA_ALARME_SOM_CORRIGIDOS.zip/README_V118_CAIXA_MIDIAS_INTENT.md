# Gestão Sacerdotista Aimê — V118

## Caixa de Mídias — recebimento Android robusto

Base: V117 — Caixa de Mídias com persistência.

### Correções desta versão

- `MainActivity` usa `launchMode="singleTask"` para que o compartilhamento reutilize a instância existente do aplicativo e entregue o novo Intent por `onNewIntent()`.
- Tratamento de `ACTION_SEND` e `ACTION_SEND_MULTIPLE`.
- Tratamento de `EXTRA_STREAM` individual, `ArrayList<Uri>` e `ClipData`.
- O Android copia a mídia imediatamente para o armazenamento privado da Caixa de Mídias antes do JavaScript tentar importá-la.
- Identificação de mídia por MIME, extensão e assinatura do arquivo quando o MIME entregue pelo WhatsApp/Samsung for genérico.
- Suporte de detecção para Ogg/Opus, MP3, WAV, AAC/frames, M4A/MP4, WebM, JPEG, PNG, WebP e HEIC/HEIF.
- Limites: 50 MB para áudio e 20 MB para foto.
- Erros de recebimento deixam de ser silenciosos e geram evento de diagnóstico para a interface.
- O recebimento da mídia é independente da restauração do Supabase.
- Se o aplicativo for iniciado pelo botão Compartilhar, ele entra imediatamente no modo local e não bloqueia a Caixa de Mídias esperando a restauração remota.
- A Caixa de Mídias mantém os arquivos nativos como fonte principal e não carrega Base64 de todos os áudios automaticamente ao atualizar a lista.
- Fotos e áudios são lidos do armazenamento nativo somente quando necessário para pré-visualização, reprodução ou importação.
- O vínculo com atendimento, pergunta e foto selecionada continua seguindo o fluxo existente da V117.
- O áudio/foto importado continua na Caixa de Mídias até o encerramento do atendimento; a cópia incorporada ao histórico permanece.

### Compatibilidade

- `applicationId`: `com.sacerdotisaaime.gestao`
- `versionName`: `1.18.0`
- `versionCode`: `118`
- mesma assinatura/keystore do aplicativo anterior
- atualização por cima das versões anteriores compatíveis

### O que não foi alterado

- gravação interna de áudio;
- mecanismo principal do Supabase;
- lógica financeira, consulentes, trabalhos, vendas e agenda;
- identidade visual da Caixa de Mídias.
