# Gestão Sacerdotisa Aimê — V25

Base: V24 funcional (derivada da V23).

Alterações desta versão:
- cobrança individual da pergunta posicionada após o registro visual/fotos;
- trabalhos e vendas aparecem junto aos números das perguntas, com ícone e exclusão;
- toque no ícone de trabalho/venda abre a janela para edição;
- botão de encerrar atendimento fica no final da página e abre o checkout;
- áudio das fotos com duração visível, indicador de gravação e visualização em ondas;
- checkout destaca o total em reais e mostra a moeda escolhida em menor destaque quando estrangeira;
- lógica existente de checkout, parcelamento, conversão e taxas preservada;
- login e inicialização mantidos da V23/V24.
