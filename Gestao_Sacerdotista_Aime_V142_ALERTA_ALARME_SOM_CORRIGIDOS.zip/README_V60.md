# Gestão Sacerdotista Aimê — V60

Correções solicitadas após a V59, preservando a base e o fluxo de autenticação/Supabase.

- Atalho para cadastrar nova consulente diretamente no agendamento/agenda.
- Agendamentos profissionais concentrados em Trabalho; Família permanece para compromissos familiares e Contas para financeiro.
- Consultas, trabalhos e vendas agendados continuam aparecendo na Agenda e na tela inicial.
- Ações rápidas na tela inicial para iniciar atendimento, executar trabalho, abrir venda e reagendar.
- Agendamentos passados permanecem visíveis como ATRASADO até serem resolvidos.
- Deduplicação dos tipos de tiragem/pergunta cadastrados, preservando preços válidos.
- Preservação/restauração do atendimento ao retornar da câmera, evitando abandono para o histórico.
- O núcleo de login/Supabase/inicialização não foi reescrito.
