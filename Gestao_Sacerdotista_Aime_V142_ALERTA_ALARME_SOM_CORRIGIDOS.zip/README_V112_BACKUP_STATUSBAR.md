# Gestão Sacerdotista Aimê — V112

## Alterações
- Versão 1.12.0 / Android versionCode 112 (workflow de build).
- Barra de status nativa do Android em rosa mais forte (#C52E7E), com ícones claros.
- Nova aba **Configurações → Backup**.
- Backup completo em `.zip`, independente do Supabase, com os dados persistidos no localStorage do aplicativo.
- Importação do `.zip` substitui os dados locais e, quando houver conexão e usuário autenticado, atualiza também o snapshot remoto para o estado restaurado.
- Credenciais/tokens do Supabase são excluídos do backup.

## Observação
Fotos e áudios que estiverem efetivamente armazenados dentro dos registros locais são preservados. Arquivos externos que não estejam referenciados/armazenados no localStorage não são copiados por este backup.
