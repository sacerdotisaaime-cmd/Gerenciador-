# V109 — Correção profunda do gravador de áudio

Base: V108 — Fluxo direto das vendas.

## Problemas tratados

1. Gravador na ficha da consulente não deve ser cancelado por exigir `screen === "history"`. O alvo do gravador agora é validado pelo `clientId` real existente em `clients`.
2. O primeiro clique em `Gravar áudio` não pode depender de `audioRecorderOpen` já ter sido atualizado pelo React. `beginRecording(target)` recebe o alvo diretamente e inicia o microfone sem depender do estado da renderização anterior.
3. Foi adicionado um lock por ref (`recordingStartRef`) para impedir duas inicializações simultâneas do microfone.
4. No Android, a pausa usa segmentos finalizados com `VoiceRecorder.stopRecording()` para permitir uma prévia imediatamente reproduzível. Depois de uma pausa por segmento, `Retomar` inicia explicitamente um novo segmento; não chama `resumeRecording()` sobre uma gravação que já foi encerrada.
5. Ao finalizar no Android, todos os segmentos são unidos na ordem original e salvos como um único áudio.
6. Limpeza dos refs de pausa/inicialização foi reforçada em abertura, cancelamento, finalização e saídas antecipadas.

## Compatibilidade

O pacote `capacitor-voice-recorder` é 7.0.6 no projeto. A documentação pública do plugin informa que `pauseRecording()`/`resumeRecording()` podem não ser suportados em determinadas versões do sistema; por isso o fluxo Android desta versão usa segmentos finalizados como fallback determinístico para preservar a prévia e a retomada. O plugin continua sendo usado para captura nativa.

## Verificação

- Inspeção profunda do fluxo de abertura, alvo, validação de contexto, início, pausa, retomada, finalização e cancelamento.
- Comparação com a referência V96, que já era a base funcional de áudio.
- `tsc` foi executado sem dependências instaladas apenas para análise estrutural; o ambiente reportou somente erros já existentes decorrentes de módulos/tipos ausentes, sem um diagnóstico novo de sintaxe na área alterada.
- `npm install` excedeu o tempo disponível no ambiente, portanto o build Vite completo não pôde ser executado neste ambiente.

## Arquivo principal alterado

`src/App.tsx`

Nenhuma outra área funcional foi deliberadamente alterada.
