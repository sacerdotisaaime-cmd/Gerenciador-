# Gestão Sacerdotista Aimê — V68

Base: V65 completo, preservando Capacitor, Supabase snapshot, login, módulos e funcionalidades anteriores.

## Checklist solicitado

| # | Bug / função | V68 |
|---|---|---|
| 1 | Duplicação financeira de recebimento (ex.: R$20 aparecendo como R$40) | ✅ Corrigido na origem do cálculo: o recebimento do checkout/atendimento não é somado novamente pelas perguntas internas quando já existe plano de pagamento do atendimento. |
| 2 | Importar áudio salvo/recebido do WhatsApp em Fotos das Cartas | ✅ Implementado com seletor de arquivos Android (`audio/*`), múltiplos áudios e vínculo direto à carta. |
| 3 | Foto de perfil do consulente | ✅ Implementado: câmera/galeria, avatar na lista, toque para ampliar e persistência no registro do consulente/Supabase snapshot. |
| 4 | Modal secundário só aparece depois de fechar o modal atual | ✅ Corrigido estruturalmente: `Modal` passou a usar portal no `document.body`, evitando clipping/empilhamento de modal dentro de modal. |
| 5 | Compromisso mostrando data errada na tela inicial | ✅ Corrigido: o bloco de próximos agendamentos usa a data real do item e mostra data + horário explicitamente. |
| 6 | Editar compromisso não funciona / data não muda | ✅ Corrigido: edição preserva o registro, atualiza data, hora, descrição, categoria e cliente; ao editar, o compositor da Agenda é aberto diretamente. |
| 7 | Modal de cobrança mostrando só uma parcela | ✅ Corrigido no detalhe do pagamento: quando há várias parcelas, todas são exibidas com número, vencimento, valor e status. |
| 8 | Restaurar “Tudo que foi feito no dia” | ✅ Tela diária já existente foi reexposta por ação direta “Feito hoje” no dashboard, mantendo os registros do dia centralizados. |
| 9 | Valor do trabalho não editável | ✅ Implementado botão específico “Editar valor do trabalho” no detalhe do trabalho. A atualização preserva recebimentos e redistribui somente o saldo pendente quando necessário, atualizando o registro financeiro relacionado. |
| 10 | Pausar gravação cria/encerra outra gravação | ✅ Corrigido usando `pauseRecording()` / `resumeRecording()` do plugin. O mesmo áudio é finalizado apenas ao tocar em “Finalizar”. Também existe controle global fixo para gravações em qualquer módulo. |
| 11 | “Compartilhar foto + áudio” compartilhava apenas texto | ✅ Corrigido para gerar arquivos reais (foto + todos os áudios) e enviá-los no compartilhamento nativo, com fallback para `navigator.share` quando disponível. |
| 12 | Leitura pré-trabalho | ✅ Implementado: checkbox “Leitura pré-trabalho”, seleção do trabalho cadastrado, vínculo no atendimento/histórico e ação “Vender trabalho” para criar orçamento vinculado à leitura. |
| 13 | Data/hora espremidas no topo da Home | ✅ Corrigido: data/hora removidas da linha de atalhos superiores; o cabeçalho principal mostra data + hora ao lado, deixando os atalhos livres. |

## Preservação da base

- Login/Auth e inicialização preservados.
- Capacitor preservado.
- Supabase snapshot preservado.
- Dados de consulentes, atendimentos, fotos, áudios, trabalhos, vendas, agenda, financeiro e configurações continuam dentro do mecanismo existente de sincronização.
- Não foi criado um segundo aplicativo nem alterada a arquitetura de autenticação.

## Verificação técnica realizada

- Verificação sintática do `src/App.tsx` com TypeScript 5.8.3: sem diagnósticos de sintaxe TS1005/TS1109/TS1128/TS1160/TS1434/TS1700/TS1382/TS1110/TS1010/TS1068/TS1125.
- A instalação completa das dependências (`npm ci`) não concluiu dentro do ambiente de execução, então não é correto afirmar que o APK foi compilado aqui. A validação final de `npm run build` deve ser feita no ambiente com as dependências instaladas/GitHub Actions.

## Observação importante

A V68 foi construída sobre o projeto V65 completo disponível no ambiente, e não sobre os pacotes V66 antigos/estripados que haviam apresentado regressões.
