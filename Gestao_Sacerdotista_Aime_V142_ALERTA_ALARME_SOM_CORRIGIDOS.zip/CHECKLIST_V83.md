# Checklist V83

## Agenda
- Agenda deriva diretamente dos atendimentos, trabalhos, vendas e envios agendados.
- Itens relacionados dentro de uma tiragem também aparecem.
- Agendamento de venda usa data/hora de envio quando aplicável.
- Próximos agendamentos da tela inicial usam a mesma fonte de verdade.
- Atendimento tem Iniciar atendimento + Reagendar + Cancelar.
- Trabalho tem Executar + Reagendar + Cancelar.
- Venda/envio tem Abrir venda + Reagendar + Cancelar.
- Itens manuais continuam separados.

## Checkout / desfalque
- Desfalque de pergunta é marcado explicitamente.
- Grátis de pergunta comum com valor potencial continua sendo contabilizado como desfalque automático.
- Benefício/cortesia de trabalho não gera desfalque automático.
- Desfalque aparece no resumo do checkout.
- Checkout com somente desfalque não acusa valor inválido.
- Desfalques são sincronizados pelo registro central da pergunta.

## Parcelas / recebimentos
- Recebimento parcial abre modal próprio.
- Valor recebido e restante são calculados automaticamente.
- Recebimentos sucessivos são permitidos até quitar.
- Editar parcelas não abre checkout.
- Botão Receber valor no editor fecha o editor e abre somente o recebimento parcial.
- Status Pago parcialmente permanece refletido nos Serviços.

## Objetos do trabalho
- Novo atendimento > trabalho possui os dois cartões de objetos.
- Novo trabalho criado a partir de orçamento possui os dois cartões.
- Trabalho criado dentro de uma tiragem possui os dois cartões.
- Objeto recebido pode registrar endereço/CEP/país.
- Objeto enviado não vira venda separada nem aumenta checkout.
- Objetos ficam no registro central e podem ser exibidos no histórico.

## Áudio
- Gravação usa MediaRecorder quando disponível, com fallback nativo.
- Pausa/retomada real.
- Gravação finalizada abre prévia antes de salvar.
- Prévia possui play/pause, progresso e velocidades do player.
- Descartar a prévia não salva o áudio.
- Fluxo é compartilhado entre áudio recebido, serviço, resposta e áudio de foto.

## Inventário / interface
- Inventário permanece separado do estoque.
- Abrir Inventário fecha Novo atendimento e o modal de inventário anterior.
- Novo atendimento fecha o modal de inventário anterior.
- Texto/nomes não podem quebrar uma letra por linha nos blocos principais.

## Fotos
- Miniaturas da galeria permanecem visíveis.
- Foto pode ser ampliada.
- Foto individual pode ser excluída do histórico.

## Inicialização
- Base V82 preservada.
- Nenhuma alteração foi feita no fluxo de login/inicialização.

## Validação
- TypeScript foi usado para validação sintática/semântica do arquivo com dependências ausentes filtradas; não foi possível executar build completo porque npm ci excedeu o tempo disponível e node_modules não ficou instalado.
