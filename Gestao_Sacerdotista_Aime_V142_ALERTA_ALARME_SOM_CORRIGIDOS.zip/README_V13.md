# Gestão Sacerdotisa Aimê — V13

## O que foi corrigido
V13 adiciona uma camada de sincronização/backup completo do estado local no Supabase.

- Após login, verifica o snapshot remoto.
- Se o celular foi reinstalado e o local está vazio, restaura todos os dados do Supabase.
- Se o Supabase ainda não tem snapshot, envia os dados existentes do aparelho.
- Se os dois lados possuem dados, faz merge por `id` usando `updatedAt/createdAt/deletedAt` quando disponíveis.
- Faz sincronização automática em segundo plano a cada 15 segundos enquanto o app está aberto e também quando a internet volta.
- Mantém os dados no localStorage para uso offline.

## IMPORTANTE — primeiro uso da V13
1. Execute `SUPABASE_V13_SNAPSHOT.sql` no SQL Editor do seu projeto Supabase.
2. Instale/atualize para V13 no aparelho que ainda contém seus dados.
3. Entre com o mesmo e-mail e senha.
4. Aguarde aparecer "Todos os dados foram salvos no Supabase." ou deixe o aplicativo aberto por alguns segundos.
5. Só então faça o teste de desinstalar/reinstalar.
6. Instale V13 novamente e faça login. Os dados devem ser reconstruídos automaticamente.

## Observação
A V13 usa um snapshot JSON completo como camada de segurança de restauração. As tabelas relacionais e o Storage já criados continuam preparados para a próxima etapa de sincronização detalhada de fotos e áudios.

## Correção da V13.1
A primeira V13 tinha um erro de integração: as funções do sincronizador foram criadas em `src/supabaseSync.ts`, mas não estavam importadas no `App.tsx`. A V13.1 corrige essa integração.
