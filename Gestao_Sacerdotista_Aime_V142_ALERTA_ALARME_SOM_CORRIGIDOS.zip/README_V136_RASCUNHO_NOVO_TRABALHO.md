# V136 — Rascunho persistente do Novo Trabalho

Correção do fluxo de **Novo trabalho dentro da tiragem/atendimento**.

## Comportamento

- Ao tocar em **✨ Trabalho**, abre o editor normalmente.
- Ao fechar o modal pelo **X** ou pelo botão de fechar/cancelar, o preenchimento **não é apagado**.
- O trabalho fica representado por uma pequena caixa **✨ Rasc.** ao lado das perguntas e dos trabalhos/vendas já salvos.
- Ao tocar nessa caixa, o mesmo rascunho é reaberto com todos os campos, fotos, áudios, termos, consentimento e objetos já preenchidos.
- O rascunho também é incluído no snapshot de navegação do aplicativo para não desaparecer ao sair temporariamente da tela.
- O rascunho só é apagado quando o usuário toca no **X vermelho da própria caixa do rascunho** e confirma a exclusão.
- Ao clicar em **Cadastrar/Adicionar ao checkout**, o rascunho deixa de ser rascunho e vira um trabalho salvo dentro do atendimento.
- Se houver um trabalho em rascunho e o usuário tentar abrir uma nova venda, o aplicativo pede para retomar ou excluir o rascunho primeiro, evitando perda acidental.
