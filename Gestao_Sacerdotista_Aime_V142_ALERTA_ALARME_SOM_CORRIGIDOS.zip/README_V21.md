# Gestão Sacerdotisa Aimê — V21

## Ajustes de usabilidade
- Novo orçamento removido da primeira tela de Novo atendimento e disponibilizado dentro do atendimento iniciado.
- Dashboard reorganizado: Novo atendimento ocupa o card principal; Entrada rápida e Saída rápida ficam abaixo.
- Movimentações mostram 3 registros inicialmente, com expansão/recolhimento.
- Resumo financeiro concentra atendimentos, entrada, saída, a receber, saldo e desfalques; visão detalhada fica expansível.
- Configurações reorganizadas em abas Casa, Trabalho & vendas e Financeiro.
- Aba Trabalho & vendas traz cadastro de tipos de trabalho e catálogo de produtos para venda.
- Mantidos os demais recursos das versões anteriores.
