# V116 — Áudio do WhatsApp corrigido

Base: V114.

## Correção

O compartilhamento do WhatsApp já fazia o aplicativo aparecer na lista, mas a importação ainda dependia do `content://` recebido do WhatsApp permanecer acessível quando o JavaScript chamasse o plugin.

Nesta versão, o Android copia imediatamente o áudio recebido para o cache privado do aplicativo assim que o `ACTION_SEND`/`ACTION_SEND_MULTIPLE` chega. Depois o JavaScript lê a cópia local e continua o mesmo fluxo de associação:

1. foto selecionada da consulta → áudio fica na foto;
2. sem foto, pergunta atual → áudio fica na pergunta;
3. sem consulta, consulente aberta → áudio fica na ficha da consulente.

O limite continua em 30 MB por áudio compartilhado.

## Compatibilidade

- `applicationId`: `com.sacerdotisaaime.gestao`
- `versionName`: `1.16.0`
- `versionCode`: `115`
- mesma assinatura do aplicativo anterior
- atualização por cima da V114

## Importante

Não houve alteração no mecanismo de gravação interna nem no Supabase. A alteração é focada no recebimento de áudio compartilhado pelo Android.
