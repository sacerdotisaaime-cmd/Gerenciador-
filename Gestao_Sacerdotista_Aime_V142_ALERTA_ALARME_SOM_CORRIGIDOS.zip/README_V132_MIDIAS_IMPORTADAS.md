# V132 — Mídias importadas com destino

- Mídias recebidas do WhatsApp continuam sendo armazenadas na Caixa de Mídias.
- Uma nova janela é aberta automaticamente após a importação.
- Áudio + foto recebidos juntos são agrupados na mesma janela.
- É possível enviar o lote para a pergunta atual, ficha da consulente ou informações recebidas do atendimento.
- Também é possível compartilhar todas as mídias juntas novamente pelo compartilhamento do Android/WhatsApp.
- A opção de deixar somente na Caixa de Mídias continua disponível.
- Fotos encaminhadas para a ficha ficam em uma galeria própria da ficha; áudios continuam nos áudios da ficha.
