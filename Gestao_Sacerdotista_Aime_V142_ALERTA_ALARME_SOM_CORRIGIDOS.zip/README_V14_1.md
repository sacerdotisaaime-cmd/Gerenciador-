# Gestão Sacerdotisa Aimê — V14.1

## Correções e melhorias desta versão

- Novo orçamento acessível diretamente no modal de Novo atendimento, já vinculado à consulente.
- Novo orçamento também pode ser iniciado durante uma tiragem/atendimento e fica salvo no histórico da consulente.
- Botão Vender feitiço durante a tiragem, abrindo a entrada/venda rápida já atribuída à consulente.
- Pagamento do atendimento agora possui a opção Consulta grátis. O valor informado permanece como valor potencial e é tratado como desfalque, não como entrada recebida.
- Cada pergunta pode ter cobrança própria: Pago, Pagar depois, Parcelado ou Pergunta grátis.
- Pergunta grátis permite informar o valor que seria cobrado e registra o desfalque.
- Perguntas com cobrança passam a participar dos cálculos de entradas e valores a receber.
- Fotos das cartas agora possuem ações rápidas ao lado da miniatura: Áudio e Nota, além das mesmas opções no modal ampliado.
- Atividades vinculadas a trabalhos continuam ligadas ao histórico do consulente.
- Corrigido suporte interno para corte de áudio.
- Corrigidos pequenos problemas de tipagem existentes no App.tsx.

## Supabase

Esta versão continua usando a sincronização/snapshot da V13. Não é necessário recriar as tabelas existentes para os recursos acima. O snapshot continua sendo a camada de segurança para restauração completa.
