from pathlib import Path
import re
p=Path('/mnt/data/v17work/src/App.tsx')
s=p.read_text()

# Safe localStorage writer to prevent native WebView quota exceptions from blanking the app.
anchor='''const readStorage = <T,>(key: string, fallback: T): T => {\ntry {\nconst saved = localStorage.getItem(key);\nreturn saved ? JSON.parse(saved) : fallback;\n} catch {\nreturn fallback;\n}\n};'''
replacement=anchor+'''\n\nconst safeSetStorage = (key: string, value: unknown) => {\n  try {\n    window.localStorage.setItem(key, JSON.stringify(value));\n    return true;\n  } catch {\n    // Large media (photo/audio) can exceed WebView localStorage. Keep the UI alive.\n    return false;\n  }\n};'''
assert anchor in s
s=s.replace(anchor,replacement,1)
# Replace simple JSON.stringify localStorage writes with safe writer, including notification marker.
s=re.sub(r'localStorage\.setItem\(\s*([A-Za-z0-9_"\'\-]+)\s*,\s*JSON\.stringify\((.*?)\)\s*\)', r'safeSetStorage(\1, \2)', s, flags=re.S)
# Fix any remaining direct setItem with multiline JSON.stringify that regex may miss; manual broad replacements.
s=s.replace('localStorage.setItem(notifiedKey, JSON.stringify([...notified, item.id]));','safeSetStorage(notifiedKey, [...notified, item.id]);')

# Native photo compression: camera DataUrl is resized again before entering React/localStorage.
marker='''const takeNativePhoto = async (target: "question" | "intake") => {\ntry {'''
insert='''const compressDataUrl = async (dataUrl: string, maxSize = 1280, quality = 0.62): Promise<string> => {\n  if (!dataUrl) throw new Error("Imagem vazia.");\n  const image = new Image();\n  image.src = dataUrl;\n  await new Promise<void>((resolve, reject) => { image.onload = () => resolve(); image.onerror = () => reject(new Error("Falha ao ler imagem.")); });\n  const scale = Math.min(1, maxSize / Math.max(image.naturalWidth || image.width, image.naturalHeight || image.height));\n  const width = Math.max(1, Math.round((image.naturalWidth || image.width) * scale));\n  const height = Math.max(1, Math.round((image.naturalHeight || image.height) * scale));\n  const canvas = document.createElement("canvas");\n  canvas.width = width; canvas.height = height;\n  const ctx = canvas.getContext("2d");\n  if (!ctx) throw new Error("Canvas indisponível.");\n  ctx.drawImage(image, 0, 0, width, height);\n  return canvas.toDataURL("image/jpeg", quality);\n};\n\nconst takeNativePhoto = async (target: "question" | "intake") => {\ntry {'''
assert marker in s
s=s.replace(marker,insert,1)
old='''const result = await Camera.getPhoto({ quality: 65, width: 1600, correctOrientation: true, source: CameraSource.Camera, resultType: CameraResultType.DataUrl, allowEditing: false });\nif (!result.dataUrl) throw new Error("A câmera não retornou a imagem.");\nconst photo: PhotoItem = { id: makeId(), name: `foto-${Date.now()}.jpg`, data: result.dataUrl, createdAt: nowISO(), updatedAt: nowISO(), note: "", audios: [] };'''
new='''const result = await Camera.getPhoto({ quality: 55, width: 1280, correctOrientation: true, source: CameraSource.Camera, resultType: CameraResultType.DataUrl, allowEditing: false });\nif (!result.dataUrl) throw new Error("A câmera não retornou a imagem.");\nconst compressed = await compressDataUrl(result.dataUrl, 1280, 0.60);\nconst photo: PhotoItem = { id: makeId(), name: `foto-${Date.now()}.jpg`, data: compressed, createdAt: nowISO(), updatedAt: nowISO(), note: "", audios: [] };'''
assert old in s
s=s.replace(old,new,1)
old='''const result = await Camera.getPhoto({ quality: 65, width: 1600, correctOrientation: true, source: CameraSource.Photos, resultType: CameraResultType.DataUrl, allowEditing: false });\nif (!result.dataUrl) throw new Error("Imagem não selecionada.");\nconst photo: PhotoItem = { id: makeId(), name: `foto-${Date.now()}.jpg`, data: result.dataUrl, createdAt: nowISO(), updatedAt: nowISO(), note: "", audios: [] };'''
new='''const result = await Camera.getPhoto({ quality: 55, width: 1280, correctOrientation: true, source: CameraSource.Photos, resultType: CameraResultType.DataUrl, allowEditing: false });\nif (!result.dataUrl) throw new Error("Imagem não selecionada.");\nconst compressed = await compressDataUrl(result.dataUrl, 1280, 0.60);\nconst photo: PhotoItem = { id: makeId(), name: `foto-${Date.now()}.jpg`, data: compressed, createdAt: nowISO(), updatedAt: nowISO(), note: "", audios: [] };'''
assert old in s
s=s.replace(old,new,1)

# Finance robustly calculates old/new purchase item shapes and falls back to supplier area.
old='''const purchasesHome =\npurchases.reduce(\n(total, purchase) =>\ntotal +\npurchase.items\n.filter(\n(item) =>\nitem.destination === "home"\n)\n.reduce(\n(sum, item) =>\nsum + item.total,\n0\n),\n0\n);\nconst purchasesWork =\npurchases.reduce(\n(total, purchase) =>\ntotal +\npurchase.items\n.filter(\n(item) =>\nitem.destination === "work"\n)\n.reduce(\n(sum, item) =>\nsum + item.total,\n0\n),\n0\n);'''
new='''const purchaseItemValue = (item: PurchaseItem) => {\n  const stored = Number(item.total);\n  if (Number.isFinite(stored) && stored > 0) return stored;\n  const quantity = Number(item.quantity) || 0;\n  const unitPrice = Number(item.unitPrice) || 0;\n  return quantity * unitPrice;\n};\nconst purchaseAreaValue = (purchase: Purchase, area: FinanceArea) => {\n  const supplier = suppliers.find(item => item.id === purchase.supplierId);\n  const items = Array.isArray(purchase.items) ? purchase.items : [];\n  return items.reduce((sum, item) => {\n    const destination = item.destination || supplier?.area || "home";\n    return sum + (destination === area ? purchaseItemValue(item) : 0);\n  }, 0);\n};\nconst purchasesHome = purchases.reduce((sum, purchase) => sum + purchaseAreaValue(purchase, "home"), 0);\nconst purchasesWork = purchases.reduce((sum, purchase) => sum + purchaseAreaValue(purchase, "work"), 0);\nconst recurringHome = accountTemplates.filter(item => item.active && item.area === "home").reduce((sum,item)=>sum+Number(item.amount||0),0);\nconst recurringWork = accountTemplates.filter(item => item.active && item.area === "work").reduce((sum,item)=>sum+Number(item.amount||0),0);\nconst recurringTotal = recurringHome + recurringWork;'''
assert old in s
s=s.replace(old,new,1)
# Include recurring in pending/projection without pretending they are paid actual payables.
s=s.replace('''<StatCard\ntitle="A pagar"\nvalue={formatMoney(\npayablePending\n)}\n/>''','''<StatCard\ntitle="A pagar"\nvalue={formatMoney(payablePending)}\n/>\n<StatCard title="Recorrentes" value={formatMoney(recurringTotal)} />''',1)
# Add recurring section after work finance card.
needle='''<div\nstyle={\nstyles.actionGrid\n}\n>'''
addition='''<section style={styles.card}>\n<div style={styles.cardHeader}><div><div style={styles.eyebrow}>CONTAS RECORRENTES</div><h2 style={styles.cardTitle}>Próximas contas recorrentes</h2></div></div>\n{accountTemplates.filter(item=>item.active).length===0 ? <div style={styles.emptyBox}>Nenhuma conta recorrente ativa.</div> : <div style={styles.list}>{accountTemplates.filter(item=>item.active).map(item => <div key={item.id} style={styles.listItem}><div><strong>{item.name}</strong><div style={styles.muted}>{item.area === "home" ? "Casa" : "Trabalho"} · Todo dia {item.dueDay}{item.description ? ` · ${item.description}` : ""}</div></div><strong>{formatMoney(Number(item.amount||0))}</strong></div>)}</div>}\n<div style={{...styles.infoBox, marginTop: 10}}>Projeção mensal das contas recorrentes ativas: <strong>{formatMoney(recurringTotal)}</strong>.</div>\n</section>\n<div\nstyle={\nstyles.actionGrid\n}\n>'''
assert needle in s
s=s.replace(needle,addition,1)

# Recent finance cards should calculate item values consistently.
s=s.replace('''sum + item.total,\n0\n);''','''sum + purchaseItemValue(item),\n0\n);''')
# This global replacement can hit only reducers with exact snippet; okay.
# Replace purchase display home's raw total too.
s=s.replace('''sum + item.total,\n0\n);\nconst work =''','''sum + purchaseItemValue(item),\n0\n);\nconst work =''')
s=s.replace('''sum + item.total,\n0\n);\nreturn (''','''sum + purchaseItemValue(item),\n0\n);\nreturn (''')

# Add a diagnostic/protection notice to camera catch and make it distinguish cancellation.
s=s.replace('''} catch {\nshowToast("Não foi possível usar a câmera. Verifique a permissão de câmera do aplicativo.");\n}\n};\n\nconst chooseNativePhoto''','''} catch (error) {\n  console.error("Camera V18:", error);\n  showToast("Não foi possível usar a câmera. Verifique a permissão e tente novamente.");\n}\n};\n\nconst chooseNativePhoto''',1)

p.write_text(s)
