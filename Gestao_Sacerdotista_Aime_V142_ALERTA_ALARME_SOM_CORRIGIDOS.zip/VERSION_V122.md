# Gestão Sacerdotista Aimê — V122

Correções incluídas nesta versão:

- Termos e consentimento separados também para trabalhos adicionados dentro de um atendimento já em andamento.
- Evidências dos termos vinculadas ao trabalho específico: câmera, galeria/print, áudio gravado, áudio importado e Caixa de Mídias.
- Edição de trabalhos existentes preserva e carrega os registros de termos e consentimento.
- Indicadores de "Informado" e "Consentido" aparecem no registro do trabalho relacionado.
- Caixa de Mídias pode ser aberta pelos novos destinos de termos/consentimento e usa uma abertura centralizada para evitar falhas de abertura.
- Reprodução de áudio da Caixa de Mídias ficou mais robusta para mídias recebidas do WhatsApp, normalizando dados base64 sem prefixo MIME e mantendo play/pause pelo mesmo player do aplicativo.

Validação local realizada: transpile de `src/App.tsx` com TypeScript sem erros de sintaxe.
A instalação completa de dependências não terminou dentro do limite de execução deste ambiente, portanto não foi declarado um build Android final aqui.
