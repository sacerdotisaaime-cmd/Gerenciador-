# V108 — Fluxo direto da venda

Base: V107_CORRECOES_CONSULENTE_AUDIO_CHECKOUT.

Correção: as mudanças de etapa de uma venda (iniciar confecção, concluir confecção, preparar envio, enviar, entregar ou cancelar) agora atualizam somente o registro da venda/RelatedCharge.

O lifecycle da venda não chama mais `updateConsultation`, não cria/reabre `activeConsultation` e não grava `DRAFT_KEY`. Isso impede que uma ação operacional da venda seja tratada como retorno ao atendimento ou checkout.

A progressão permanece:
- approved → awaiting_confection (quando aplicável)
- awaiting_confection → in_confection
- in_confection → awaiting_shipping
- awaiting_shipping → shipped
- shipped → delivered

Áudio, consulentes, inventário e demais módulos não foram alterados.
