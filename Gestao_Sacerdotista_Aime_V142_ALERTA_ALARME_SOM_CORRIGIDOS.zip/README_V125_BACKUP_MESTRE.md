# V125 — Backup Mestre (base local segura)

Esta versão prepara o aplicativo para o Backup Mestre.

## Incluído
- Manifesto de módulos do backup.
- Backup ZIP completo com os dados persistidos localmente.
- Estado do último backup na tela de Configurações > Backup.
- Backup de segurança antes de restauração.
- Backup de segurança antes de limpeza geral/selecionada.
- No Android, os backups locais gerenciados ficam em `Documentos/Gestao-Sacerdotista-Aime/Backups`.
- Rotação local de no máximo 5 arquivos ZIP.
- A rotação local não apaga arquivos do Google Drive.
- Restauração continua atualizando o Supabase quando há sessão e conexão.
- Credenciais/tokens do Supabase não entram no backup.

## Próxima etapa
A conexão OAuth com o Google Drive ainda depende das credenciais do projeto Google Cloud e da configuração do cliente Android/Web. Esta versão não finge que o Drive já está conectado: a tela informa isso explicitamente.
