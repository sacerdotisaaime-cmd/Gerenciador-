# V127 — Google Drive Diagnóstico

Base: V126 Backup Mestre + Google Drive.

## Correção desta entrega
- Restaura o `src/App.tsx` funcional da V126, incluindo a interface e as chamadas reais do Google Drive.
- Mantém o fluxo nativo de OAuth/Drive da V127.
- A V127 acrescenta diagnóstico do erro de autorização em vez de esconder o motivo atrás de uma mensagem genérica.

## Google OAuth
- Cliente OAuth Android: `com.sacerdotisaaime.gestao`.
- Usa `AuthorizationClient` do Google Identity.
- Escopo solicitado: `https://www.googleapis.com/auth/drive.file`.
- A conta de teste deve estar cadastrada em Google Auth Platform → Público-alvo → Usuários de teste.

## Teste
1. Gerar o APK release pelo workflow.
2. Instalar o APK assinado com o mesmo certificado usado no cliente OAuth Android.
3. Abrir Backup Mestre.
4. Tocar em `Conectar Google Drive`.
5. Se a autorização falhar, a V127 deve mostrar o código/mensagem real do erro.
6. Depois de conectar, usar `Criar e enviar backup`.

## Drive
O fluxo cria `Gestão Sacerdotista Aimê / Backups`, envia o ZIP do Backup Mestre por upload retomável e valida o arquivo remoto antes da rotação dos backups antigos.
