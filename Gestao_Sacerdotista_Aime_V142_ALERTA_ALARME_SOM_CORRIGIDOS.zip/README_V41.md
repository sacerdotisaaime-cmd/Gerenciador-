# Gestão Sacerdotisa Aimê — V41

## O que foi incluído
- Mantida a base de login/Supabase da V39, sem alterar o fluxo de autenticação.
- Navegação inferior com 5 posições: Início, Clientes, Nova, Serviços e Agenda.
- Área de navegação inferior respeitando a área segura do Android e maior espaço final para o conteúdo.
- Agendamento com consulente opcional vinculada ao compromisso.
- **Configurações → Limpeza / Testes**, em uma aba separada.
- Reset por módulo: consulentes, atendimentos, agenda, orçamentos, serviços realizados, financeiro, estoque, fornecedores, compras futuras, notas, lixeira e cadastros/configurações.
- **Reset geral** com dupla confirmação.
- O reset primeiro grava a limpeza no `app_snapshots` do Supabase e só depois remove os dados locais e recarrega o aplicativo.
- O usuário/login do Supabase não é apagado.
- `currency-settings` passou a fazer parte do snapshot completo.

## Segurança do reset
O reset não usa `window.localStorage.clear()`, portanto não apaga a sessão de autenticação do aplicativo. A limpeza é direcionada apenas às chaves de dados selecionadas. O reset geral exige a digitação de `RESETAR`.

## Observação
A exclusão remota é feita no snapshot `app_snapshots`, que é o mecanismo de sincronização/restauração usado por esta versão. Não são apagados o usuário de autenticação nem a conta do Supabase.


## V42 — Núcleo financeiro integrado (sem Open Finance)
- Central de contas com pendentes, atrasadas, pagar e adiar.
- Contas fixas/variáveis preparadas para recorrência.
- Empréstimos com cronograma de parcelas, pagamento, saldo devedor e juros/multas por atraso.
- Reservas/caixinhas com guardar e resgatar como transferência interna.
- Aplicações com percentual do CDI configurável e saldo separado do caixa.
- Painel inicial com atalhos e Central de Contas.
- Novos dados incluídos no snapshot do Supabase para sincronização.
- Open Finance não foi implementado.
