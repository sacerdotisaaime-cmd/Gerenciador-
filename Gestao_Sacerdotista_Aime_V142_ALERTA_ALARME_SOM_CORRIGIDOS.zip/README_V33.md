# Gestão Sacerdotisa Aimê — V33

Base: V32 funcional.

## V33
- Tema visual rosa e refinamento de espaçamento/overflow.
- Barra inferior elevada para respeitar a área segura do Android.
- Navegação com histórico para o botão Voltar do Android/navegador.
- Nova Central de Serviços no menu: Trabalhos, Vendas, Tiragens e Orçamentos.
- Estrutura inicial de execução de trabalhos.
- Materiais padrão podem ser cadastrados por tipo de trabalho nas Configurações.
- Na execução, o uso é decidido na hora: item novo reduz estoque e gera custo do trabalho; item reutilizado não reduz estoque nem gera novo gasto financeiro e entra como economia estimada.
- Base preparada para custo e lucro por trabalho sem duplicar a saída financeira da compra.
- Login/Supabase preservados.
