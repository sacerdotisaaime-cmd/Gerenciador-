# Gestão Sacerdotisa Aimê — V30

Base: V29 funcional.

## Correções e melhorias
- Acompanhamento de parcelas no início agora inclui parcelas do atendimento e parcelamentos vinculados a perguntas.
- Filtro de período continua disponível e inicia em "Tudo" para não ocultar parcelas futuras.
- Relatórios ganharam aba Geral, além de Casa e Trabalho.
- Relatório de Trabalho mostra consultas, trabalhos, orçamentos, vendas, perguntas, recebido, a receber, não pago, gastos e lucro.
- Comparação mês A x mês B com percentuais de variação de atividade, recebimento, gastos e resultado.
- Visão de recebimentos por BRL/EUR/USD/GBP.
- Resultado Geral considera recebido do trabalho menos gastos do trabalho e gastos da casa.
- Compras de estoque continuam sendo a saída financeira; consumo de estoque não é lançado novamente como saída.
- Não foi implementada nesta versão a execução de trabalhos com apropriação de custo por estoque; essa arquitetura fica para uma próxima etapa.
- Login/Supabase não foram alterados.
