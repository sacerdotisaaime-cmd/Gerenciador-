# V37

Correção do branco pós-login.

- Remove o window.location.reload() do fluxo de sincronização pós-login.
- Sincroniza e hidrata os estados React a partir do localStorage antes de liberar o dashboard.
- Mostra tela de carregamento enquanto os dados são restaurados.
- Se a sincronização falhar, abre em modo local em vez de deixar tela branca.
- Adiciona Error Boundary para transformar erros de renderização em uma tela de diagnóstico.
- Mantém o login/Supabase da V36 e o tratamento nativo do botão voltar.
- Workflow continua usando npm run build.
