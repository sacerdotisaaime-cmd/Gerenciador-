# V95 — Gravador de áudio corrigido

## Base
- A V94 continua sendo a versão oficial/base.
- A V69 foi usada somente como referência para o fluxo comprovadamente funcional do `capacitor-voice-recorder`.
- Nenhum recurso da V69 foi usado como base do aplicativo.

## Correções do V95
- O botão **Gravar áudio** abre o modal diretamente.
- O clique externo não inicia o microfone.
- Removida a dependência da navegação `screen` para abrir/manter o modal.
- Removido o handler intermediário com `preventDefault/stopPropagation` do botão de abertura.
- O microfone só é acionado dentro de **Iniciar gravação**.
- Fluxo nativo usa a sequência funcional da referência V69: verificar disponibilidade, solicitar permissão e chamar `VoiceRecorder.startRecording()`.
- A gravação continua no mesmo modal até finalizar/cancelar.
- Finalizar salva automaticamente.
- **Ficha da consulente:** há um gravador próprio, com áudios persistidos no cadastro da consulente, reprodução, compartilhamento e exclusão.
- Áudios gravados na ficha continuam disponíveis ao reabrir a ficha.
- Áudios de perguntas, respostas, fotos, informações recebidas e trabalhos/vendas continuam usando os recursos da versão oficial.

## Validação
- Estrutura e chamadas do fluxo foram revisadas no código.
- O ZIP foi validado com `unzip -t`.
- Não foi possível executar um build TypeScript completo neste ambiente porque as dependências npm do projeto não estão instaladas e a instalação excedeu o tempo disponível.
