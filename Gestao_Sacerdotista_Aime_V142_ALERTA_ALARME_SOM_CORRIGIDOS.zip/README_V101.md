# Gestão Sacerdotista Aimê — V101

Base: V100.

## Correções desta versão

### Inventário
- Corrigida a abertura do formulário de “Novo item do inventário”: o modal agora abre diretamente, sem depender de `setTimeout` após a troca de tela.
- Edição de item usa o mesmo fluxo direto.
- Estado do modal passa a participar do snapshot de navegação.

### Agenda e prioridade
- Prioridade 1–5 preservada e exibida como etiqueta `PRIORIDADE X`.
- Dashboard de prioridades agora usa a foto do consulente quando disponível; sem foto, usa inicial.
- A identificação deixa de usar o número da prioridade como elemento visual principal.
- Agenda ordena compromissos por prioridade e, em empate, por data/hora.
- Itens com o mesmo compromisso visual são deduplicados.
- Trabalhos/vendas que tenham o mesmo evento no registro-pai e em `relatedCharges` não geram duas linhas quando título e horário coincidem e a charge está ativa.
- Standby deixa de repetir o nome: foto fica separada e o nome/status ficam em uma única coluna horizontal.
- Linhas da agenda exibem etiqueta de prioridade.

### Persistência
- Agenda e inventário passam a ser gravados explicitamente no snapshot Supabase após alterações, com debounce de 350 ms.
- Também existe flush em `pagehide`/`beforeunload` quando há conexão.
- A restauração remota continua ocorrendo antes da hidratação final da interface.

## Validação
- Foi feita verificação estática do TypeScript com `tsc --noEmit --noResolve`; não foram encontrados erros de sintaxe/parsing nas alterações.
- O build completo não pôde ser executado neste ambiente porque as dependências npm não estavam disponíveis localmente e a instalação excedeu o tempo limite.

## Preservação
- Áudio, parcelas e demais módulos não relacionados foram mantidos a partir da V100.
