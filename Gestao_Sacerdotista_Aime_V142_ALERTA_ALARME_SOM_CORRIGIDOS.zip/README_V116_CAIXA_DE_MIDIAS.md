# V116 — Caixa de Mídias

## Objetivo
Receber áudios e fotos compartilhados pelo Android/WhatsApp em uma Caixa de Mídias persistente, sem tentar adivinhar imediatamente a consulente ou pergunta.

## Fluxo
1. WhatsApp/galeria → Gestão Aimê → Caixa de Mídias.
2. A mídia fica aguardando até ser importada ou excluída.
3. Dentro do atendimento, o botão **Caixa de Mídias** abre a caixa sem sair da tela.
4. Áudio: se houver foto selecionada, vincula o áudio à foto; caso contrário, à pergunta atual.
5. Foto: é adicionada à pergunta atual.
6. Depois de importada, a mídia continua na caixa com indicação de que já foi vinculada ao atendimento.
7. Ao encerrar o atendimento, as mídias temporárias vinculadas a ele são removidas da Caixa de Mídias. A cópia já salva no histórico permanece.
8. Se o atendimento for colocado em standby, a mídia temporária não é apagada.

## Armazenamento
- O conteúdo pesado da Caixa de Mídias usa IndexedDB no WebView, não localStorage.
- No Android, o PermissionBridge mantém a mídia recebida em armazenamento interno do aplicativo até ela ser lida/excluída.
- O backup geral não incorpora a Caixa de Mídias temporária; ela é deliberadamente transitória.

## Compatibilidade
- Mantido o mesmo applicationId e assinatura do projeto anterior.
- VersionName 1.16.0 / versionCode 116.
- Preservados os fluxos de gravação, compartilhamento, fotos, perguntas, histórico, pagamentos e demais módulos existentes.
