# V137 — Organização profissional, checklists e permissões

Principais mudanças:
- Organização com rotina diária focada em uma pessoa responsável.
- Rotinas recorrentes continuam separadas no módulo `OrganizationWorkspace.tsx`.
- Cada rotina pode ter checklist e abrir uma janela própria para execução.
- Uma rotina com checklist só pode ser concluída depois que todas as etapas forem marcadas.
- Indicador de progresso do checklist.
- Notificações nativas com canal próprio.
- Respeito ao campo “Avisar antes (min)” das rotinas, criando lembrete antecipado e lembrete no horário.
- Status de notificações, alarmes exatos e sobreposição exibidos na configuração de Organização.
- Abertura real das telas especiais do Android para sobreposição e alarmes.
- Manifesto declara POST_NOTIFICATIONS, SCHEDULE_EXACT_ALARM e SYSTEM_ALERT_WINDOW.
