# Checklist V76

- [x] Base preservada a partir da V75.
- [x] Filtro Anteriores.
- [x] Atrasados não perdem trabalhos antigos.
- [x] Trabalho sem data aparece em qualquer filtro.
- [x] Resolver de consulente por ID + nome normalizado.
- [x] Nome não quebra por caractere.
- [x] Modal global de foto do consulente.
- [x] Foto só abre modal quando tocada.
- [x] Próximos agendamentos usam identificação padronizada.
- [x] Avisos de parcelas/contas exibem vencimento.
