# V98 — Auditoria profunda do fluxo de parcelas

Base: V97 corrigida, preservando o fluxo de áudio existente.

## Objetivo

Fazer Dashboard, Histórico do consulente, Serviços/Trabalhos e Financeiro enxergarem o mesmo estado da parcela, usando `installmentId` e os recebimentos reais registrados em `payments[]`.

## Correções desta versão

- `payments[]` passa a ser a fonte de verdade dos valores efetivamente recebidos quando existe histórico de pagamentos.
- Criada uma leitura central do estado da parcela: pendente, parcialmente paga, paga, vencida ou não paga.
- Parcelas antigas já quitadas sem `payments[]` são normalizadas para manter compatibilidade histórica.
- Cada recebimento mantém valor, data e forma de pagamento.
- Adicionado `lastPaymentAt` para diferenciar último recebimento de quitação total (`receivedAt`).
- Histórico do consulente passa a mostrar status parcial, recebido, restante e os recebimentos individuais.
- Detalhe de Serviços/Trabalhos passa a buscar a consulta atual pelo ID, evitando exibir uma cópia antiga depois de um recebimento.
- Detalhe de parcelas do Dashboard consulta a parcela atual diretamente em `consultations`, evitando valores congelados.
- Relatórios passam a calcular recebido pelo valor realmente recebido e aberto pelo saldo da parcela.
- Movimentações de relatório passam a usar cada `InstallmentPayment`, em vez de considerar automaticamente o valor integral da parcela.
- Recebimentos parciais carregam taxa/valor bruto no espelho financeiro.
- Desfalques após recebimento parcial usam somente o saldo restante.
- Recebimento posterior reduz o desfalque existente.
- Voltar a parcela para pendente/vencida ou prorrogar resolve o valor de desfalque ativo para não duplicar saldo.
- Execução de trabalho preserva `payments[]` e registra somente novos recebimentos quando uma parcela já tinha pagamentos.
- Edição de parcelas preserva o histórico de `payments[]` em vez de substituir o recebido manualmente.

## Fluxo esperado

Exemplo: parcela de R$200 recebe R$20.

- Parcela: original R$200
- Recebido: R$20
- Restante: R$180
- Status: Pago parcialmente
- Histórico: R$20 + data + forma de pagamento
- Financeiro: entrada real de R$20
- Serviços: mesma parcela, mesmo saldo
- Dashboard: mesmo saldo

Ao receber os R$180 restantes:

- novo `InstallmentPayment` de R$180
- recebido total R$200
- restante R$0
- status Paga
- financeiro registra somente os R$180 adicionais
- histórico mantém os dois recebimentos

## Validação

Foi feita uma checagem de sintaxe TypeScript/TSX com o compilador TypeScript disponível no ambiente. Não foram encontrados erros de parsing no `App.tsx`. A validação completa do `npm run build` não pôde ser concluída porque as dependências do projeto não ficaram disponíveis no ambiente; `npm ci` excedeu o tempo limite.
