import { useEffect, useMemo, useState, type ChangeEvent } from "react";
import { createPortal } from "react-dom";
import { Camera, CameraResultType, CameraSource } from "@capacitor/camera";

export type InventoryCondition = "new" | "used" | "good" | "bad" | "broken" | "replace";

export type InventoryBreakage = {
  id: string;
  quantity: number;
  date: string;
  location: string;
  reason: string;
  notes: string;
  unitValue: number;
};

export type InventoryItem = {
  id: string;
  name: string;
  description: string;
  photo?: string;
  unitValue: number;
  quantity: number;
  purchaseDate?: string;
  condition: InventoryCondition;
  breakages: InventoryBreakage[];
  createdAt: string;
  updatedAt: string;
  deletedAt?: string;
};

type Props = {
  items: InventoryItem[];
  onItemsChange: (items: InventoryItem[]) => void;
  onDelete: (item: InventoryItem) => void;
  onBack: () => void;
  showToast: (message: string) => void;
  styles: any;
  compressImageFile: (file: File, maxSize: number, quality: number) => Promise<string>;
  compressDataUrl: (dataUrl: string, maxSize: number, quality: number) => Promise<string>;
  formatMoney: (value: number) => string;
};

const makeId = () => `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
const today = () => new Date().toISOString().slice(0, 10);
const numberValue = (value: string | number | undefined, fallback = 0) => {
  const parsed = Number(String(value ?? "").replace(",", "."));
  return Number.isFinite(parsed) ? parsed : fallback;
};

export const normalizeInventoryItem = (raw: Partial<InventoryItem>): InventoryItem => {
  const quantity = Math.max(1, Math.floor(numberValue(raw.quantity, 1)));
  const legacyReference = numberValue((raw as any).referenceValue);
  const unitValue = Math.max(0, raw.unitValue !== undefined ? numberValue(raw.unitValue) : (legacyReference > 0 ? legacyReference / quantity : 0));
  const legacyBreakages = Array.isArray(raw.breakages) ? raw.breakages : [];
  const breakages: InventoryBreakage[] = legacyBreakages
    .filter(Boolean)
    .map((record: any) => ({
      id: String(record.id || makeId()),
      quantity: Math.max(1, Math.floor(numberValue(record.quantity, 1))),
      date: String(record.date || today()),
      location: String(record.location || "Não informado"),
      reason: String(record.reason || "Avaria / quebra"),
      notes: String(record.notes || ""),
      unitValue: Math.max(0, numberValue(record.unitValue, unitValue)),
    }));
  const legacyBroken = Math.max(0, Math.floor(numberValue((raw as any).brokenQuantity)));
  const recordedBroken = breakages.reduce((sum, record) => sum + record.quantity, 0);
  if (legacyBroken > recordedBroken) {
    breakages.push({
      id: `legacy-${String(raw.id || makeId())}`,
      quantity: legacyBroken - recordedBroken,
      date: String(raw.purchaseDate || today()),
      location: "Registro anterior",
      reason: "Avaria registrada anteriormente",
      notes: "Registro migrado do inventário anterior.",
      unitValue,
    });
  }

  return {
    id: String(raw.id || makeId()),
    name: String(raw.name || "Item do inventário"),
    description: String(raw.description || ""),
    photo: raw.photo || undefined,
    unitValue,
    // IMPORTANTE: quantity é o total físico cadastrado/comprado.
    // O histórico de avarias nunca aumenta esse número.
    quantity,
    purchaseDate: raw.purchaseDate || undefined,
    condition: raw.condition || "new",
    breakages,
    createdAt: String(raw.createdAt || new Date().toISOString()),
    updatedAt: String(raw.updatedAt || raw.createdAt || new Date().toISOString()),
    deletedAt: raw.deletedAt,
  };
};

export const InventoryModule = ({
  items,
  onItemsChange,
  onDelete,
  onBack,
  showToast,
  styles,
  compressImageFile,
  compressDataUrl,
  formatMoney,
}: Props) => {
  const normalizedItems = useMemo(() => items.filter(Boolean).map(normalizeInventoryItem), [items]);
  const [dialog, setDialog] = useState<null | { mode: "new" } | { mode: "edit"; itemId: string }>(null);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [photo, setPhoto] = useState("");
  const [quantity, setQuantity] = useState("1");
  const [unitValue, setUnitValue] = useState("");
  const [purchaseDate, setPurchaseDate] = useState("");
  const [condition, setCondition] = useState<InventoryCondition>("new");
  const [breakageOpen, setBreakageOpen] = useState(false);
  const [breakageQuantity, setBreakageQuantity] = useState("1");
  const [breakageDate, setBreakageDate] = useState(today());
  const [breakageLocation, setBreakageLocation] = useState("");
  const [breakageReason, setBreakageReason] = useState("");
  const [breakageNotes, setBreakageNotes] = useState("");

  const currentItem = useMemo(() => {
    if (!dialog || dialog.mode !== "edit") return null;
    return normalizedItems.find(item => item.id === dialog.itemId) || null;
  }, [dialog, normalizedItems]);

  const brokenQuantity = (item: InventoryItem) =>
    item.breakages.reduce((sum, record) => sum + Math.max(0, Math.floor(record.quantity)), 0);

  const availableQuantity = (item: InventoryItem) =>
    Math.max(0, item.quantity - brokenQuantity(item));

  const lossValue = (item: InventoryItem) =>
    item.breakages.reduce((sum, record) => sum + record.quantity * record.unitValue, 0);

  const resetForm = () => {
    setName("");
    setDescription("");
    setPhoto("");
    setQuantity("1");
    setUnitValue("");
    setPurchaseDate("");
    setCondition("new");
    setBreakageOpen(false);
    setBreakageQuantity("1");
    setBreakageDate(today());
    setBreakageLocation("");
    setBreakageReason("");
    setBreakageNotes("");
  };

  const openNew = () => {
    resetForm();
    setDialog({ mode: "new" });
  };

  const openEdit = (item: InventoryItem) => {
    const normalized = normalizeInventoryItem(item);
    setName(normalized.name);
    setDescription(normalized.description);
    setPhoto(normalized.photo || "");
    setQuantity(String(normalized.quantity));
    setUnitValue(String(normalized.unitValue));
    setPurchaseDate(normalized.purchaseDate || "");
    setCondition(normalized.condition);
    setBreakageOpen(false);
    setBreakageQuantity("1");
    setBreakageDate(today());
    setBreakageLocation("");
    setBreakageReason("");
    setBreakageNotes("");
    setDialog({ mode: "edit", itemId: normalized.id });
  };

  const closeDialog = () => {
    setDialog(null);
    resetForm();
  };

  useEffect(() => {
    if (!dialog) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") closeDialog();
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [dialog]);

  const save = () => {
    if (!name.trim()) {
      showToast("Informe o nome do item.");
      return;
    }
    const total = Math.max(1, Math.floor(numberValue(quantity, 1)));
    const value = Math.max(0, numberValue(unitValue));
    const now = new Date().toISOString();
    const existing = currentItem;
    const existingBroken = existing ? brokenQuantity(existing) : 0;
    if (existing && total < existingBroken) {
      showToast(`Não é possível reduzir o total para ${total}: ${existingBroken} unidade(s) já estão registradas como avariadas.`);
      return;
    }
    const item: InventoryItem = {
      id: existing?.id || makeId(),
      name: name.trim(),
      description: description.trim(),
      photo: photo || undefined,
      unitValue: value,
      quantity: total,
      purchaseDate: purchaseDate || undefined,
      condition,
      breakages: existing?.breakages || [],
      createdAt: existing?.createdAt || now,
      updatedAt: now,
    };
    const next = existing
      ? normalizedItems.map(row => row.id === existing.id ? item : row)
      : [item, ...normalizedItems];
    onItemsChange(next);
    closeDialog();
    showToast(existing ? "Item do inventário atualizado." : "Item do inventário cadastrado.");
  };

  const registerBreakage = () => {
    if (!currentItem) return;
    const available = availableQuantity(currentItem);
    const qty = Math.max(0, Math.floor(numberValue(breakageQuantity)));
    if (qty < 1) {
      showToast("Informe quantas unidades foram avariadas.");
      return;
    }
    if (qty > available) {
      showToast(`Há apenas ${available} unidade(s) disponível(is) para registrar como avariada.`);
      return;
    }
    if (!breakageDate) {
      showToast("Informe a data da avaria.");
      return;
    }
    if (!breakageLocation.trim()) {
      showToast("Informe onde aconteceu a avaria.");
      return;
    }
    if (!breakageReason.trim()) {
      showToast("Informe o que aconteceu.");
      return;
    }
    const record: InventoryBreakage = {
      id: makeId(),
      quantity: qty,
      date: breakageDate,
      location: breakageLocation.trim(),
      reason: breakageReason.trim(),
      notes: breakageNotes.trim(),
      unitValue: currentItem.unitValue,
    };
    const next = normalizedItems.map(item => {
      if (item.id !== currentItem.id) return item;
      const breakages = [...item.breakages, record];
      const broken = breakages.reduce((sum, row) => sum + row.quantity, 0);
      return {
        ...item,
        breakages,
        condition: broken >= item.quantity ? "broken" : item.condition,
        updatedAt: new Date().toISOString(),
      };
    });
    onItemsChange(next);
    setBreakageOpen(false);
    setBreakageQuantity("1");
    setBreakageDate(today());
    setBreakageLocation("");
    setBreakageReason("");
    setBreakageNotes("");
    showToast(`${qty} unidade(s) marcada(s) como avariada(s).`);
  };

  const choosePhoto = async (event: ChangeEvent<HTMLInputElement>) => {
    try {
      const file = event.target.files?.[0];
      if (!file) return;
      setPhoto(await compressImageFile(file, 1000, 0.78));
      event.target.value = "";
    } catch {
      showToast("Não foi possível selecionar a foto.");
    }
  };

  const takePhoto = async () => {
    try {
      const result = await Camera.getPhoto({
        quality: 70,
        width: 1000,
        height: 1000,
        correctOrientation: true,
        source: CameraSource.Camera,
        resultType: CameraResultType.DataUrl,
        allowEditing: false,
      });
      if (!result.dataUrl) throw new Error("NO_PHOTO");
      setPhoto(await compressDataUrl(result.dataUrl, 1000, 0.78));
      showToast("Foto adicionada ao inventário.");
    } catch {
      showToast("Não foi possível capturar a foto.");
    }
  };

  const conditionLabel: Record<InventoryCondition, string> = {
    new: "Novo",
    used: "Usado",
    good: "Bom",
    bad: "Ruim",
    broken: "Quebrado",
    replace: "Tem que substituir",
  };

  const modal = dialog && typeof document !== "undefined" ? createPortal(
    <div className="inventory-modal-layer" role="dialog" aria-modal="true" aria-label={dialog.mode === "edit" ? "Editar item do inventário" : "Novo item do inventário"}>
      <div className="inventory-modal-sheet">
        <div className="inventory-modal-header">
          <div><h2>{dialog.mode === "edit" ? "Editar item do inventário" : "Novo item do inventário"}</h2><div style={{fontSize:12,color:"#81757f",marginTop:3}}>Estoque fixo · independente de financeiro e estoque de consumo</div></div>
          <button type="button" className="inventory-modal-close" onClick={closeDialog} aria-label="Fechar">×</button>
        </div>
        <div className="inventory-modal-body">
          <div style={styles.infoBox}>Cadastre objetos duráveis e reutilizáveis do altar e das ferramentas. Este inventário é independente: não gera compras, despesas, receitas, movimentos de estoque ou qualquer outro lançamento.</div>
          <label style={styles.label}>Nome / identificação</label>
          <input value={name} onChange={e=>setName(e.target.value)} style={styles.input} placeholder="Ex.: Castiçal dourado" autoFocus />
          <label style={styles.label}>Descrição</label>
          <textarea value={description} onChange={e=>setDescription(e.target.value)} style={styles.textarea} placeholder="Material, tamanho, detalhes..." />
          <label style={styles.label}>Foto do item</label>
          <div style={{display:"flex",gap:8,flexWrap:"wrap",alignItems:"center"}}>
            {photo ? <img src={photo} alt="Prévia do item" style={{width:96,height:96,objectFit:"cover",borderRadius:14,border:"1px solid #eadce5"}} /> : null}
            <button type="button" style={styles.smallButton} onClick={takePhoto}>📷 Câmera</button>
            <label style={{...styles.smallButton,cursor:"pointer"}}>🖼️ Galeria<input type="file" accept="image/*" hidden onChange={choosePhoto} /></label>
            {photo && <button type="button" style={styles.deleteButton} onClick={()=>setPhoto("")}>Remover foto</button>}
          </div>
          <div className="inventory-form-grid">
            <div><label style={styles.label}>Quantidade total</label><input type="number" min="1" step="1" value={quantity} onChange={e=>setQuantity(e.target.value)} style={styles.input} /></div>
            <div><label style={styles.label}>Valor unitário</label><input type="number" min="0" step="0.01" value={unitValue} onChange={e=>setUnitValue(e.target.value)} style={styles.input} placeholder="R$ 0,00" /></div>
          </div>
          <div className="inventory-form-grid">
            <div><label style={styles.label}>Data da compra</label><input type="date" value={purchaseDate} onChange={e=>setPurchaseDate(e.target.value)} style={styles.input} /></div>
            <div><label style={styles.label}>Estado atual</label><select value={condition} onChange={e=>setCondition(e.target.value as InventoryCondition)} style={styles.input}><option value="new">Novo</option><option value="used">Usado</option><option value="good">Bom</option><option value="bad">Ruim</option><option value="broken">Quebrado</option><option value="replace">Tem que substituir</option></select></div>
          </div>
          <div className="inventory-form-total">Valor total do inventário: <strong>{formatMoney(Math.max(0, numberValue(unitValue)) * Math.max(1, Math.floor(numberValue(quantity, 1))))}</strong></div>

          {currentItem && (() => {
            const broken = brokenQuantity(currentItem);
            const available = availableQuantity(currentItem);
            return <section className="inventory-status-panel">
              <div className="inventory-status-grid"><div><small>Total</small><strong>{currentItem.quantity}</strong></div><div><small>Disponíveis</small><strong>{available}</strong></div><div><small>Avariados</small><strong>{broken}</strong></div><div><small>Valor total</small><strong>{formatMoney(currentItem.unitValue * currentItem.quantity)}</strong></div></div>
              {broken > 0 && <div className="inventory-loss-note">⚠️ {broken} unidade(s) estão avariadas e precisam ser repostas. Prejuízo registrado apenas neste inventário.</div>}
              {available > 0 && <button type="button" className="inventory-breakage-button" onClick={()=>setBreakageOpen(v=>!v)}>{breakageOpen ? "Fechar registro de avaria" : "⚠️ Registrar avaria / quebra"}</button>}
              {breakageOpen && <div className="inventory-breakage-form">
                <div className="inventory-form-grid"><div><label style={styles.label}>Quantidade avariada</label><input type="number" min="1" max={available} step="1" value={breakageQuantity} onChange={e=>setBreakageQuantity(e.target.value)} style={styles.input} /></div><div><label style={styles.label}>Data da avaria</label><input type="date" value={breakageDate} onChange={e=>setBreakageDate(e.target.value)} style={styles.input} /></div></div>
                <label style={styles.label}>Onde aconteceu?</label><input value={breakageLocation} onChange={e=>setBreakageLocation(e.target.value)} style={styles.input} placeholder="Ex.: altar, depósito..." />
                <label style={styles.label}>O que aconteceu?</label><input value={breakageReason} onChange={e=>setBreakageReason(e.target.value)} style={styles.input} placeholder="Ex.: caiu e quebrou" />
                <label style={styles.label}>Observação</label><textarea value={breakageNotes} onChange={e=>setBreakageNotes(e.target.value)} style={styles.textarea} placeholder="Detalhes da ocorrência..." />
                <button type="button" style={styles.primaryButtonLarge} onClick={registerBreakage}>✓ Registrar avaria</button>
              </div>}
              {currentItem.breakages.length > 0 && <div className="inventory-history"><strong>Histórico de avarias</strong>{[...currentItem.breakages].reverse().map(record=><div key={record.id} className="inventory-history-row"><div><strong>{record.quantity} unidade(s) · {record.date}</strong><span>{record.location} · {record.reason}</span>{record.notes && <small>{record.notes}</small>}</div><b>{formatMoney(record.quantity * record.unitValue)}</b></div>)}</div>}
            </section>;
          })()}
          <button type="button" style={styles.primaryButtonLarge} onClick={save}>✓ Salvar item</button>
          <button type="button" style={styles.secondaryButtonLarge} onClick={closeDialog}>Cancelar</button>
        </div>
      </div>
    </div>, document.body
  ) : null;

  const totalValue = normalizedItems.reduce((sum, item) => sum + item.unitValue * item.quantity, 0);
  const totalBroken = normalizedItems.reduce((sum, item) => sum + brokenQuantity(item), 0);

  return <>
    <button style={styles.backButton} onClick={onBack}>← Início</button>
    <section style={styles.hero}>
      <div className="inventory-eyebrow">INVENTÁRIO FIXO</div>
      <h2 style={styles.pageTitle}>Itens duráveis e reutilizáveis</h2>
      <p style={styles.heroText}>Um estoque independente para objetos físicos que permanecem com você. Não conversa com financeiro, compras ou estoque de consumo.</p>
      <button type="button" className="inventory-new-button" style={{...styles.primaryButtonLarge,touchAction:"manipulation"}} onClick={openNew}>＋ Novo item do inventário</button>
    </section>
    <section style={styles.card}>
      <div style={styles.statsGrid}><div><strong>{normalizedItems.length}</strong><span>Itens cadastrados</span></div><div><strong>{formatMoney(totalValue)}</strong><span>Valor total</span></div><div><strong>{totalBroken}</strong><span>Unidades avariadas</span></div></div>
    </section>
    <section style={styles.card}>
      {normalizedItems.length === 0 ? <div style={styles.emptyBox}>Nenhum item fixo cadastrado.</div> : <div className="inventory-list">{normalizedItems.map(item=>{
        const broken = brokenQuantity(item); const available = availableQuantity(item);
        return <div key={item.id} className="inventory-card-v104">
          <div className="inventory-card-main">{item.photo ? <img src={item.photo} alt={item.name} className="inventory-card-photo" /> : <div className="inventory-card-photo inventory-card-placeholder">🗃️</div>}<div className="inventory-card-info"><strong>{item.name}</strong><div className="inventory-card-description">{item.description || "Sem descrição."}</div><div className="inventory-card-metrics"><span>📦 {available} disponível(is)</span><span>💰 {formatMoney(item.unitValue)}/un.</span><span>🧾 {formatMoney(item.unitValue * item.quantity)} total</span></div><div className="inventory-card-status"><span className="inventory-condition">{conditionLabel[item.condition]}</span>{broken>0&&<span className="inventory-broken-badge">⚠️ {broken} avariado(s) · repor</span>}</div></div></div>
          <div className="inventory-card-actions"><button type="button" style={styles.smallButton} onClick={()=>openEdit(item)}>Editar / ver detalhes</button><button type="button" style={styles.deleteButton} onClick={()=>onDelete(item)}>Excluir</button></div>
          {broken>0&&<div className="inventory-card-loss">Prejuízo registrado no inventário: {formatMoney(lossValue(item))} · {broken} unidade(s) quebrada(s).</div>}
        </div>;
      })}</div>}
    </section>
    {modal}
  </>;
};
