import { supabaseClient } from './supabase';

export const V13_STORAGE_KEYS = [
  'gestao_clients','gestao_consultations','gestao_purchases','gestao_suppliers',
  'gestao_stock_items','gestao_stock_movements','gestao_inventory','gestao_payables','gestao_loans',
  'gestao_overdrafts','gestao_household_sectors','gestao_household_categories',
  'gestao_quick_transactions','gestao_bank_accounts','gestao_reading_types',
  'gestao_future_purchases','gestao_notes','gestao_agenda','gestao_account_templates',
  'gestao_budgets','gestao_reserves','gestao_investments','gestao_work_executions','gestao_trash','gestao_family_members','gestao_routine_templates','gestao_routine_logs','gestao_routine_settings','gestao_health_entries','gestao_cycle_entries','gestao_medications','gestao_medication_logs','gestao_routine_items','gestao_desfalques','gestao_work_types','gestao_sale_items','gestao_routine_notification_ids','currency-settings'
] as const;

type Snapshot = Record<string, unknown>;

const parse = (value: string | null): unknown => {
  if (!value) return [];
  try { return JSON.parse(value); } catch { return []; }
};

export const buildLocalSnapshot = (): Snapshot => {
  const snapshot: Snapshot = {};
  for (const key of V13_STORAGE_KEYS) snapshot[key] = parse(localStorage.getItem(key));
  return snapshot;
};

const itemTime = (item: any) => {
  const t = item?.updatedAt || item?.createdAt || item?.deletedAt;
  const n = t ? Date.parse(t) : 0;
  return Number.isFinite(n) ? n : 0;
};

const mergeArray = (localValue: any, remoteValue: any): any[] => {
  const local = Array.isArray(localValue) ? localValue : [];
  const remote = Array.isArray(remoteValue) ? remoteValue : [];
  const byId = new Map<string, any>();
  const withoutId: any[] = [];
  for (const item of remote) {
    if (item && typeof item === 'object' && item.id) byId.set(String(item.id), item);
    else withoutId.push(item);
  }
  for (const item of local) {
    if (item && typeof item === 'object' && item.id) {
      const id = String(item.id);
      const old = byId.get(id);
      byId.set(id, !old || itemTime(item) >= itemTime(old) ? item : old);
    } else {
      withoutId.push(item);
    }
  }
  return [...byId.values(), ...withoutId];
};

const mergeSnapshots = (local: Snapshot, remote: Snapshot): Snapshot => {
  const merged: Snapshot = {};
  for (const key of V13_STORAGE_KEYS) merged[key] = mergeArray(local[key], remote[key]);
  return merged;
};

const hasRealLocalData = (snapshot: Snapshot) => {
  return V13_STORAGE_KEYS.some((key) => {
    const value = snapshot[key];
    return Array.isArray(value) && value.length > 0;
  });
};

export const writeSnapshotLocally = (snapshot: Snapshot) => {
  for (const key of V13_STORAGE_KEYS) {
    localStorage.setItem(key, JSON.stringify(snapshot[key] ?? []));
  }
};

export const syncFullSupabaseSnapshot = async (userId: string, preferRemote = false) => {
  const local = buildLocalSnapshot();
  const { data: remoteRow, error: readError } = await supabaseClient
    .from('app_snapshots')
    .select('user_id,payload,updated_at')
    .eq('user_id', userId)
    .maybeSingle();
  if (readError) throw readError;

  if (!remoteRow) {
    if (!hasRealLocalData(local)) return { restored: false, uploaded: false, changed: false, source: 'empty' as const };
    const payload = local;
    const { error } = await supabaseClient.from('app_snapshots').upsert({
      user_id: userId, payload, updated_at: new Date().toISOString()
    }, { onConflict: 'user_id' });
    if (error) throw error;
    return { restored: false, uploaded: true, changed: false, source: 'local' as const };
  }

  const remote = (remoteRow.payload || {}) as Snapshot;
  const merged = preferRemote || !hasRealLocalData(local)
    ? remote
    : mergeSnapshots(local, remote);

  writeSnapshotLocally(merged);

  const localChanged = JSON.stringify(local) !== JSON.stringify(merged);
  const remoteChanged = JSON.stringify(remote) !== JSON.stringify(merged);
  if (remoteChanged && hasRealLocalData(merged)) {
    const { error } = await supabaseClient.from('app_snapshots').upsert({
      user_id: userId, payload: merged, updated_at: new Date().toISOString()
    }, { onConflict: 'user_id' });
    if (error) throw error;
  }
  return { restored: localChanged, uploaded: remoteChanged, changed: localChanged || remoteChanged, source: 'remote' as const };
};


export const resetSupabaseSnapshotKeys = async (userId: string, keys: string[]) => {
  const { data: remoteRow, error: readError } = await supabaseClient
    .from('app_snapshots')
    .select('user_id,payload')
    .eq('user_id', userId)
    .maybeSingle();
  if (readError) throw readError;

  const payload: Snapshot = { ...(remoteRow?.payload || buildLocalSnapshot()) };
  for (const key of keys) payload[key] = key === 'currency-settings'
    ? { paypalFeePercent: 0, wiseFeePercent: 0, otherFeePercent: 0 }
    : [];

  const { error } = await supabaseClient.from('app_snapshots').upsert({
    user_id: userId,
    payload,
    updated_at: new Date().toISOString(),
  }, { onConflict: 'user_id' });
  if (error) throw error;
  return payload;
};

export const updateSupabaseSnapshot = async (userId: string, updater: (payload: Snapshot) => Snapshot) => {
  const { data: remoteRow, error: readError } = await supabaseClient
    .from('app_snapshots')
    .select('user_id,payload')
    .eq('user_id', userId)
    .maybeSingle();
  if (readError) throw readError;
  const base = (remoteRow?.payload || buildLocalSnapshot()) as Snapshot;
  const payload = updater({ ...base });
  const { error } = await supabaseClient.from('app_snapshots').upsert({
    user_id: userId,
    payload,
    updated_at: new Date().toISOString(),
  }, { onConflict: 'user_id' });
  if (error) throw error;
  return payload;
};

export const pushFullSupabaseSnapshot = async (userId: string) => {
  const payload = buildLocalSnapshot();
  const { error } = await supabaseClient.from('app_snapshots').upsert({
    user_id: userId, payload, updated_at: new Date().toISOString()
  }, { onConflict: 'user_id' });
  if (error) throw error;
};
