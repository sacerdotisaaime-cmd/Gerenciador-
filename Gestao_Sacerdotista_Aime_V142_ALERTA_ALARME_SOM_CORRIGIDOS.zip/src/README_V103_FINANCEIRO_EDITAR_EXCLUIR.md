# Gestão Sacerdotista Aimê — V103

## Correção do financeiro: editar/excluir recebimentos de parcelas

Esta versão parte da V102 e corrige a ligação entre a lista de **Movimentações financeiras** e os recebimentos individuais de parcelas do plano principal de uma consulta/trabalho.

### Correção principal
Os recebimentos armazenados em `InstallmentPayment[]` agora carregam na lista financeira:

- `sourceType: "installmentPayment"`
- `sourceId` = ID do recebimento
- `consultationId`
- `installmentId`

Com isso, os botões **Editar** e **Excluir** conseguem localizar o recebimento original e usar as rotinas financeiras específicas.

### Resultado esperado
- Editar um recebimento altera somente aquele pagamento e recalcula a parcela.
- Excluir um recebimento remove somente aquele pagamento e recalcula valor recebido, restante e status.
- O atendimento/consulta continua preservado.
- O financeiro e o histórico permanecem sincronizados.
- Recebimentos parciais continuam sendo tratados individualmente.

### Compatibilidade
Foi mantida a compatibilidade com parcelas antigas que não possuem `payments[]`. Esses registros continuam aparecendo como lançamentos históricos, sem serem transformados artificialmente em pagamentos editáveis.

### Áudio
O código de áudio da V102 foi preservado sem alterações.
