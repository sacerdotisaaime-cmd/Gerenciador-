const SUPABASE_URL = "https://obrslawqyrycioonlbua.supabase.co";

// A Publishable Key is safe to ship in the app when RLS is enabled.
// Never put a Supabase Secret/Service Role key here.
const SUPABASE_PUBLISHABLE_KEY = "sb_publishable_25HmQjvFiqftcHHAXlLOZg_EoEeoHaP";

type SupabaseGlobal = {
  createClient: (url: string, key: string, options?: Record<string, unknown>) => any;
};

const sdk = (globalThis as any).supabase as SupabaseGlobal | undefined;

if (!sdk?.createClient) {
  throw new Error("Supabase SDK não carregou. Verifique sua conexão com a internet e tente novamente.");
}

export const supabaseClient = sdk.createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: false,
  },
});
