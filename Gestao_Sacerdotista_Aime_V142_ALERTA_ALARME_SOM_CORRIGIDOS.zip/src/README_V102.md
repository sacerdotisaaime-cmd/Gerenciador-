# Gestão Sacerdotista Aimê — V102

Base: V101.

Correções desta versão:
- Tiragens: ao abrir a aba Tiragens, o filtro inicial é **Agendadas**.
- Tiragens: em "Todos", a ordenação coloca agendadas primeiro; entre agendadas, a data/hora mais próxima aparece primeiro; depois Standby, Em atendimento e Concluídas.
- Tiragens: "Aguardando" foi substituído por **Standby** e "Em andamento" por **Em atendimento**.
- Agenda: registros vinculados a atendimento/trabalho/venda não são mais tratados também como compromissos manuais, evitando duplicação visual na Agenda.
- Financeiro: cada movimentação exibida em Movimentações financeiras ganhou botões de editar e excluir.
- Recebimentos de parcelas podem ser corrigidos/excluídos pela movimentação, sincronizando parcela, pagamentos, histórico e espelho financeiro.
- Recebimentos de parcelas de perguntas também passam a aparecer no histórico financeiro.
- Inventário: preservada a abertura da janela por portal ao clicar em Novo item/editar item.

Preservado o sistema de áudio da base V101 e as correções anteriores de persistência, prioridade, agenda e parcelas.
