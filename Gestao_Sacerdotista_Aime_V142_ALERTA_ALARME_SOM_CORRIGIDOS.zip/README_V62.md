# Gestão Sacerdotista Aimê — V62

V62 reúne as correções solicitadas desde a V61, preservando o núcleo de autenticação/Supabase.

## Correções desta versão

- Configurações: exclusão de tipos de tiragem, tipos de trabalho, itens de venda, setores e categorias, com confirmação e preservação do histórico já registrado.
- Novo atendimento: parcelamento de trabalhos/vendas mostra todas as parcelas, cada uma com valor e vencimento editáveis. Valores podem ser diferentes entre si; acréscimos negociados são aceitos quando o total parcelado fica acima do valor original.
- Trabalho/venda: botão Galeria para anexar fotos já existentes no celular.
- Nova venda na tiragem: “Novo item para venda” reutiliza o cadastro de catálogo e retorna ao formulário original com o item disponível/selecionado.
- Atendimento: seção “Informações recebidas” possui edição durante a tiragem, incluindo complemento de texto, fotos e áudios.
- Câmera: retorno de foto preserva a tiragem, pergunta atual e rascunho; não deve navegar para a tela inicial.
- Standby: fechar uma tiragem em andamento sem concluir salva como standby e volta ao início; “Retomar” reabre a tiragem diretamente.
- Histórico: removidas ações operacionais como Retomar/Executar/Excluir da ficha histórica; ficam Ver ficha completa e edição de informações.
- Modais: camada acima da barra inferior e área rolável com espaço extra para que o último botão nunca fique escondido.
- Retorno do Android/segundo plano: snapshot de navegação e formulários principais é salvo ao sair/pausar e restaurado ao reabrir, sem forçar a tela inicial.

## Validação

- TSX analisado com o parser do TypeScript: 0 diagnósticos de sintaxe.
- Transpilação sintática do App.tsx: 0 erros.
- O ambiente de execução desta preparação não conseguiu instalar as dependências npm dentro do limite de tempo; portanto o build Android completo não foi declarado como executado.
