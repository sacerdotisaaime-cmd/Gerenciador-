declare module '*' {
  export const createPortal: any;
  export const Camera: any;
  export const CameraResultType: any;
  export const CameraSource: any;
  export const Share: any;
  export const Filesystem: any;
  export const Directory: any;
  export const Contacts: any;
  export const VoiceRecorder: any;
  export const LocalNotifications: any;
  export const CapacitorBarcodeScanner: any;
  export const CapacitorBarcodeScannerTypeHint: any;
  export const Capacitor: any;
  export const registerPlugin: any;
  export const StrictMode: any;
  export const createRoot: any;
  export const useState: <T=any>(initial:T|(()=>T))=>[T,(v:any)=>void];
  export const useEffect: (fn:any,deps?:any[])=>void;
  export const useMemo: <T=any>(fn:()=>T,deps?:any[])=>T;
  export const useCallback: <T=any>(fn:T,deps?:any[])=>T;
  export const useRef: <T=any>(initial:T)=>{current:T};
  export const createContext: any;
  export const useContext: any;
  export const Fragment: any;
  export const App: any;
  const x:any;
  export default x;
}
declare namespace React { type ReactNode = any; type ChangeEvent<T=any> = {target:T}; type MouseEvent<T=any> = any; type KeyboardEvent<T=any> = any; }
declare namespace JSX { interface IntrinsicElements { [elemName:string]: any } }
