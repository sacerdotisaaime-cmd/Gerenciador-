# Gestão Sacerdotisa Aimê — V24

Base: V23 original (login/Supabase preservados).

## Alterações desta versão
- Removido o card de áudio de observação geral da pergunta. Áudio de foto continua disponível.
- Áudio gravado em "Informações recebidas" passa a ser salvo corretamente como áudio recebido.
- Perguntas são salvas automaticamente conforme o atendimento é atualizado; removido o botão "Salvar pergunta".
- O encerramento do atendimento continua abrindo o checkout final.
- Perguntas extras recebem um botão × para exclusão e renumeração das perguntas restantes.
- Cada pergunta ganhou preço e moeda próprios, salvos no histórico e usados no checkout.
- O início de um novo atendimento permite selecionar o tipo de tiragem e a moeda (BRL, EUR, USD ou GBP); as perguntas e preços cadastrados são criados automaticamente.
- Configurações agora permitem cadastrar preços padrão de tiragens, trabalhos e produtos em BRL, EUR, USD e GBP.
- Trabalho e venda selecionados dentro do atendimento puxam o preço padrão da moeda escolhida.
- Checkout mantém a lógica existente de conversão, parcelamento, descontos e taxas.
- No checkout, perguntas, trabalhos e vendas possuem opção "Editar" para ajustar valor/moeda antes do fechamento.
- Adicionado botão explícito "Salvar taxas" em Financeiro.

## Preservação
- `index.html` e `src/supabase.ts` continuam os da V23.
- Nenhuma alteração foi feita na autenticação ou na inicialização do Supabase.
