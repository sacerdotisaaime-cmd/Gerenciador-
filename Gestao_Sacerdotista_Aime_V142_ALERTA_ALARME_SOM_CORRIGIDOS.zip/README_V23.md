# Gestão Sacerdotisa Aimê — V23

## Checkout profissional
- Checkout único para tiragem, trabalhos e vendas adicionados durante o atendimento.
- A moeda do atendimento é preservada e usada de forma consistente no checkout.
- Perguntas podem ter cobrança individual, moeda própria, desconto e status grátis/desfalque.
- Pergunta grátis exibe o valor normal riscado e o valor cobrado como R$0/€0/etc.
- Trabalhos e vendas preservam a moeda original e são convertidos corretamente para a moeda do checkout.
- Total do checkout é calculado uma única vez, evitando duplicação.
- O valor total do checkout aparece por último, depois dos detalhes de cobrança.
- PayPal/Wise/Outras taxas são exibidos apenas dentro da etapa de cobrança do checkout.
- Conversão para BRL usa a cotação armazenada no app; valores estrangeiros são convertidos por ponte BRL.
- Parcelamento mostra número da parcela, valor, vencimento e entrada paga quando selecionada.
- A validação do parcelamento compara os valores depois da conversão para BRL, mantendo o financeiro compatível.

## Preservação de dados
- O sync inicial do Supabase agora bloqueia o backup automático até a restauração inicial terminar.
- Isso evita que um snapshot local vazio/incompleto sobrescreva o snapshot remoto antes da restauração.
- Os dados existentes continuam sendo tratados pelo snapshot completo do Supabase.

## Compatibilidade
- Mantida a estrutura anterior da V22.
- `App.tsx` e `supabaseSync.ts` passaram por verificação de sintaxe TypeScript/TSX sem diagnósticos.
