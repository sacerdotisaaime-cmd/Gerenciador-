# Gestão Sacerdotista Aimê V114 — Compartilhar áudio corrigido

Base: V113.

Correções principais:
- Activity principal explicitamente exported=true e grantUriPermissions=true.
- Intent filters Android para ACTION_SEND e ACTION_SEND_MULTIPLE.
- Compatibilidade com audio/* e MIME genérico (*/*) usado por alguns fluxos de compartilhamento.
- Recebimento também aceita áudio identificado pelo nome/extensão (.ogg, .opus, .m4a, .aac, .mp3, .wav, .amr, .3gp).
- Mantém o vínculo na nova consulta: foto selecionada > pergunta atual > ficha da consulente.
- Mantém backup, barra de status rosa e demais funções existentes.
- Versão Android: 1.14.0 / versionCode 114.
