# Arquitetura de dados — V11

A V11 prepara o aplicativo para uma migração futura para Supabase sem depender do Supabase ainda.

## Regra principal

- PostgreSQL/Supabase: dados estruturados.
- Supabase Storage: fotos e áudios.
- Banco local: cache/offline e fila de sincronização.
- Não guardar Base64 de fotos/áudios no PostgreSQL.

## Tabelas planejadas

- `profiles`: usuário e configurações da conta.
- `clients`: consulentes.
- `consultations`: atendimentos.
- `questions`: perguntas dentro dos atendimentos.
- `photos`: fotos vinculadas a uma pergunta, com `note` para observação específica.
- `audios`: áudios; `photo_id` opcional diferencia áudio da foto de áudio geral da pergunta.
- `purchases`: compras realizadas.
- `purchase_items`: itens das compras.
- `suppliers`: fornecedores/estabelecimentos.
- `stock_items`: itens do estoque.
- `stock_movements`: movimentações do estoque.
- `payables`: contas a pagar.
- `loans`: empréstimos.
- `overdrafts`: cheque especial.
- `household_sectors`: setores da casa/trabalho.
- `household_categories`: categorias.
- `quick_transactions`: entradas/saídas/vendas rápidas.
- `bank_accounts`: contas bancárias.
- `reading_types`: tipos de tiragem.
- `future_purchases`: compras futuras.
- `notes`: bloco de notas.
- `agenda_items`: agenda.
- `account_templates`: modelos de contas recorrentes.
- `budgets`: orçamentos.
- `trash_items` (futuro): lixeira/soft delete no servidor.

## Campos de sincronização

Registros principais devem usar:

- `id` UUID estável.
- `created_at`.
- `updated_at`.
- `deleted_at` nullable para soft delete.
- `user_id`/`profile_id` para isolamento por usuário.

## Fotos

O aplicativo deve reduzir a imagem antes do upload. A V11 limita imagens a aproximadamente 1280 px e JPEG de qualidade 0,68 para reduzir espaço e tráfego. No futuro podemos avaliar WebP/AVIF quando a compatibilidade do fluxo nativo estiver consolidada.

Storage sugerido:

`users/{user_id}/consultations/{consultation_id}/questions/{question_id}/photos/{photo_id}.jpg`

No banco ficam apenas os metadados e o caminho do objeto.

## Áudios

A gravação atual continua em AAC pelo plugin nativo. No futuro, o arquivo deve ser enviado diretamente ao Storage e o banco deve guardar apenas metadados como duração, tamanho, MIME type e `storage_path`.

Storage sugerido:

`users/{user_id}/consultations/{consultation_id}/questions/{question_id}/audios/{audio_id}.aac`

Para áudio ligado a foto, preencher `photo_id`. Para áudio geral, deixar `photo_id` nulo.

## Sincronização futura

Fluxo recomendado:

1. Usuário cria/edita no aparelho.
2. Banco local grava imediatamente.
3. Operação entra numa fila de sincronização.
4. Quando houver internet, dados estruturados sobem para Supabase.
5. Fotos/áudios compactados sobem para Storage.
6. O servidor confirma a operação.
7. Fila marca o item como sincronizado.
8. Ao reinstalar o aplicativo, login + sincronização recompõe os dados no aparelho.

## Lixeira

A V11 já possui lixeira local. Na migração, a mesma ideia será transformada em soft delete no Supabase: `deleted_at` será preenchido, o item some das consultas normais e pode ser restaurado. A exclusão definitiva será uma ação separada.

## Importante sobre backups

Backup do PostgreSQL e backup dos objetos do Storage são coisas diferentes. O plano de backup deve contemplar ambos.
