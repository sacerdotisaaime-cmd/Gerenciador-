# Gestão Sacerdotista Aimê — V107

Base: V106_INVENTARIO_RECONSTRUIDO_CORRIGIDO.

Alterações desta versão:

1. Consulente
- Campo Data de nascimento no cadastro e edição.
- Data persistida no objeto do consulente.
- Data exibida na lista de consulentes e na ficha/histórico.

2. Áudio
- O botão externo "Gravar áudio" abre o gravador e inicia a gravação automaticamente.
- O indicador de gravação aparece no mesmo fluxo do primeiro modal.
- Pausa no navegador gera prévia reproduzível.
- No Android, a pausa encerra somente o segmento atual para gerar uma prévia; ao retomar, um novo segmento é iniciado e os segmentos são unidos ao finalizar.
- O áudio pausado pode ser ouvido antes de retomar.
- O fluxo de áudio existente foi preservado; não foram alteradas as integrações de gravação além desse comportamento.

3. Registro visual
- O cartão de cada foto agora também oferece "Foto + áudio" quando houver áudios associados àquela foto.
- O compartilhamento conjunto usa a lógica existente de compartilhamento de múltiplos arquivos.

4. Cobrança de pergunta
- O bloco "COBRANÇA DA PERGUNTA" foi removido da tela da pergunta.
- A tela da pergunta informa que pagamento/recebimento são definidos no checkout.
- A lógica de checkout das perguntas foi preservada.

5. Trabalhos no checkout
- Trabalhos relacionados agora possuem situação de pagamento própria: Pago, Não pago, Parcelado, Grátis/cortesia e Desfalque.
- A situação pode ser configurada ao adicionar/editar o trabalho e diretamente no checkout final.
- Trabalhos marcados como Pago, Grátis/cortesia ou Desfalque deixam de compor o total a cobrar; Desfalque é registrado no módulo de desfalques ao finalizar.
- Trabalhos marcados como Não pago ou Parcelado continuam compondo o total a cobrar; o parcelamento final usa o fluxo de parcelamento já existente do checkout.

6. Inventário / áudio / demais módulos
- O inventário isolado da V106 foi mantido.
- Nenhuma lógica de áudio foi removida.
- Nenhuma alteração foi feita propositalmente no restante do aplicativo além dos fluxos descritos acima.

Verificação local:
- Todos os arquivos TS/TSX da pasta src passaram por análise sintática TypeScript sem diagnósticos.
- O build Vite completo não pôde ser executado neste ambiente porque a instalação das dependências excedeu o tempo disponível.
