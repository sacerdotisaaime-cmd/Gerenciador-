# Checklist V82

## Agenda
- [x] Consulta agendada aparece na Agenda
- [x] Trabalho agendado aparece na Agenda
- [x] Venda/envio agendado aparece na Agenda
- [x] Related work/sale agendado aparece na Agenda
- [x] Venda com registro comercial concluído, mas envio agendado, permanece visível
- [x] Reagendamento preserva o registro correto
- [x] Todos os itens do dia podem aparecer; não há corte silencioso em 3
- [x] Espelho automático da Agenda é reconstruído a partir dos serviços
- [x] Iniciar atendimento abre o atendimento, não a Agenda

## Inicialização
- [x] Timeout/erro do getSession não deixa login em branco
- [x] Timeout da sincronização inicial não deixa app preso carregando
- [x] Fallback para dados locais
- [x] Normalização defensiva de dados locais
- [x] Login/base V81 preservados

## Serviços e financeiro
- [x] Exclusão de consulta
- [x] Exclusão de trabalho
- [x] Exclusão de venda
- [x] Exclusão de related charge fora do atendimento ativo
- [x] Remoção de efeitos financeiros/materiais/agenda
- [x] Desfalque automático pelo checkout
- [x] Benefício/cortesia não geram desfalque automático
- [x] Pagamento parcial de parcela
- [x] Restante calculado automaticamente
- [x] Receber valor sem retornar ao checkout
- [x] Status Pago parcialmente
- [x] Recebimentos parciais no financeiro sem duplicação

## Consulentes e logística
- [x] CPF/documento no cadastro
- [x] Endereço estruturado no cadastro
- [x] CEP/código postal internacional
- [x] Histórico mostra CPF/endereço
- [x] Endereço puxado para envio de venda
- [x] Endereço puxado para orçamento
- [x] Endereço puxado para objeto recebido
- [x] Caixas de objetos clicáveis e abertura da janela corrigida

## Inventário
- [x] Inventário no menu sanduíche
- [x] Nome/descrição/foto/valor de referência
- [x] Estado novo/usado/bom/ruim/quebrado/substituir
- [x] Editar/excluir/lixeira
- [x] Separado do estoque de consumo

## Áudio e interface
- [x] Player unificado
- [x] Play/pausa/progresso
- [x] Velocidade 1x/1,5x/2x/0,75x
- [x] Gravação com pausa/retomada
- [x] Proteção contra nomes verticais/letra por letra
- [x] Miniaturas da galeria preservadas

## Validação
- [x] Transpile/sintaxe TSX dos arquivos principais passou
- [ ] Build npm completo — dependências não puderam ser instaladas dentro do tempo disponível no ambiente
