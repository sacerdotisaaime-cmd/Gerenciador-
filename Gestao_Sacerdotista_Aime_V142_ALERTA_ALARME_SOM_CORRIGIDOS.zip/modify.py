from pathlib import Path
p=Path('/mnt/data/v17work/src/App.tsx')
s=p.read_text()

# 1. Correct currency rate semantics and safer defaults.
s=s.replace('const [currencyRates, setCurrencyRates] = useState<Record<string, number>>({ EUR: 1, USD: 1, GBP: 1 });',
            'const [currencyRates, setCurrencyRates] = useState<Record<string, number>>({});')
old='''const currencySymbol = (currency: CurrencyCode) => currency === "EUR" ? "€" : currency === "USD" ? "$" : currency === "GBP" ? "£" : "R$";\nconst convertToBRL = (amount: number, currency: CurrencyCode) => currency === "BRL" ? amount : amount * (currencyRates[currency] || 0);\nconst convertFromBRL = (amount: number, currency: CurrencyCode) => currency === "BRL" ? amount : (currencyRates[currency] ? amount / currencyRates[currency] : 0);'''
new='''const currencySymbol = (currency: CurrencyCode) => currency === "EUR" ? "€" : currency === "USD" ? "$" : currency === "GBP" ? "£" : "R$";\n// currencyRates guarda quantos BRL valem 1 unidade da moeda estrangeira.\n// A API consultada usa base=BRL e quote=EUR/USD/GBP, portanto o retorno precisa ser invertido.\nconst convertToBRL = (amount: number, currency: CurrencyCode) => currency === "BRL" ? amount : amount * (currencyRates[currency] || 0);\nconst convertFromBRL = (amount: number, currency: CurrencyCode) => currency === "BRL" ? amount : (currencyRates[currency] ? amount / currencyRates[currency] : 0);'''
assert old in s
s=s.replace(old,new)
old='''      const rows = await response.json();\n      const next: Record<string, number> = {};\n      (Array.isArray(rows) ? rows : []).forEach((row: any) => { if (row.quote && row.rate) next[row.quote] = Number(row.rate); });\n      if (next.EUR && next.USD && next.GBP) { setCurrencyRates(next); setCurrencyRateDate(new Date().toISOString().slice(0,10)); }'''
new='''      const rows = await response.json();\n      const next: Record<string, number> = {};\n      (Array.isArray(rows) ? rows : []).forEach((row: any) => {\n        const quote = String(row.quote || "").toUpperCase();\n        const rateBRLToForeign = Number(row.rate);\n        if (quote && rateBRLToForeign > 0) next[quote] = 1 / rateBRLToForeign;\n      });\n      if (next.EUR && next.USD && next.GBP) {\n        setCurrencyRates(next);\n        const latestDate = Array.isArray(rows) && rows.length ? rows.map((row:any) => row.date).filter(Boolean).sort().at(-1) : "";\n        setCurrencyRateDate(latestDate || new Date().toISOString().slice(0,10));\n      }'''
assert old in s
s=s.replace(old,new)

# 2. DDI detection: don't classify every 10/11 digit number as Brazil before checking country codes.
old='''const detectCountryFromPhone = (phone: string) => {\n  let digits = String(phone || "").replace(/\\D/g, "");\n  if (digits.startsWith("00")) digits = digits.slice(2);\n  if ((digits.length === 10 || digits.length === 11) && digits.startsWith("55")) return "Brasil";\n  if (digits.length === 10 || digits.length === 11) {\n    // Números brasileiros frequentemente são salvos sem +55.\n    return "Brasil";\n  }\n  const match = COUNTRY_DDI.sort((a,b) => b[0].length - a[0].length).find(([ddi]) => digits.startsWith(ddi));\n  return match?.[1] || "";\n};'''
new='''const detectCountryFromPhone = (phone: string) => {\n  let digits = String(phone || "").replace(/\\D/g, "");\n  if (digits.startsWith("00")) digits = digits.slice(2);\n  if (digits.startsWith("55") && digits.length >= 12) return "Brasil";\n  const match = COUNTRY_DDI.slice().sort((a,b) => b[0].length - a[0].length).find(([ddi]) => digits.startsWith(ddi));\n  if (match) return match[1];\n  // Números brasileiros frequentemente são salvos sem +55.\n  if (digits.length === 10 || digits.length === 11) return "Brasil";\n  return "";\n};'''
assert old in s
s=s.replace(old,new)

# 3. Make recording updates explicitly persist before snapshot sync.
old='''    if (target.kind === "photo") {\n      const photos = currentQuestion.photos.map((photo) =>\n        photo.id === target.photoId\n          ? { ...photo, audios: [...(photo.audios || []), audio] }\n          : photo\n      );\n      updateCurrentQuestion({ photos });\n      window.setTimeout(()=>{ if(authUser && navigator.onLine) pushFullSupabaseSnapshot(authUser.id).catch(()=>{}); }, 700);\n      showToast("Áudio vinculado à foto.");\n    } else {\n      updateCurrentQuestion({ audios: [...currentQuestion.audios, audio] });\n      window.setTimeout(()=>{ if(authUser && navigator.onLine) pushFullSupabaseSnapshot(authUser.id).catch(()=>{}); }, 700);\n      showToast("Áudio de observação salvo.");\n    }'''
new='''    if (target.kind === "photo") {\n      const photos = currentQuestion.photos.map((photo) =>\n        photo.id === target.photoId\n          ? { ...photo, audios: [...(photo.audios || []), audio], updatedAt: nowISO() }\n          : photo\n      );\n      const updatedConsultation: Consultation = { ...activeConsultation!, questions: activeConsultation!.questions.map(q => q.id === currentQuestion.id ? { ...q, photos, updatedAt: nowISO() } : q), updatedAt: nowISO() };\n      updateConsultation(updatedConsultation);\n      try { localStorage.setItem(CONSULTATIONS_KEY, JSON.stringify(consultations.some(c => c.id === updatedConsultation.id) ? consultations.map(c => c.id === updatedConsultation.id ? updatedConsultation : c) : [updatedConsultation, ...consultations])); } catch {}\n      window.setTimeout(()=>{ if(authUser && navigator.onLine) pushFullSupabaseSnapshot(authUser.id).catch(()=>{}); }, 1200);\n      showToast("Áudio vinculado à foto e salvo no histórico.");\n    } else {\n      const updatedConsultation: Consultation = { ...activeConsultation!, questions: activeConsultation!.questions.map(q => q.id === currentQuestion.id ? { ...q, audios: [...currentQuestion.audios, audio], updatedAt: nowISO() } : q), updatedAt: nowISO() };\n      updateConsultation(updatedConsultation);\n      try { localStorage.setItem(CONSULTATIONS_KEY, JSON.stringify(consultations.some(c => c.id === updatedConsultation.id) ? consultations.map(c => c.id === updatedConsultation.id ? updatedConsultation : c) : [updatedConsultation, ...consultations])); } catch {}\n      window.setTimeout(()=>{ if(authUser && navigator.onLine) pushFullSupabaseSnapshot(authUser.id).catch(()=>{}); }, 1200);\n      showToast("Áudio de observação salvo no histórico.");\n    }'''
assert old in s
s=s.replace(old,new)

# 4. Add search field to history.
old='''</section>\n{budgets.filter(item => item.clientId === historyClient.id).length > 0 && ('''
new='''</section>\n<section style={styles.card}>\n  <label style={styles.label}>Pesquisar no histórico</label>\n  <input value={historySearch} onChange={e => setHistorySearch(e.target.value)} placeholder="🔎 Atendimento, pergunta ou palavra..." style={styles.input} />\n</section>\n{budgets.filter(item => item.clientId === historyClient.id).length > 0 && ('''
# only first occurrence after history? This exact sequence may occur elsewhere; use a scoped occurrence count.
idx=s.find('{screen ===\n"history"')
assert idx!=-1
pos=s.find(old, idx)
assert pos!=-1
s=s[:pos]+s[pos:].replace(old,new,1)

# 5. Receivables carry currency metadata so finance can show original currency + BRL.
old='''amount: installment.amount,\ndueDate: installment.dueDate,'''
new='''amount: installment.amount,\ncurrency: consultation.currency || "BRL",\ncurrencyRate: consultation.currencyRate || 1,\ndueDate: installment.dueDate,'''
s=s.replace(old,new)
old='''amount: consultation.value,\ndueDate: consultation.paymentDate || "",'''
new='''amount: consultation.value,\ncurrency: consultation.currency || "BRL",\ncurrencyRate: consultation.currencyRate || 1,\ndueDate: consultation.paymentDate || "",'''
s=s.replace(old,new)
# question receivables: attach consultation currency too
s=s.replace('''amount:i.amount, dueDate:i.dueDate, overdue:i.status==="overdue"||i.dueDate<todayKey''', '''amount:i.amount, currency:consultation.currency || "BRL", currencyRate:consultation.currencyRate || 1, dueDate:i.dueDate, overdue:i.status==="overdue"||i.dueDate<todayKey''')
s=s.replace('''amount:Number(question.value||0), dueDate:question.paymentDate||"", overdue:Boolean(question.paymentDate && question.paymentDate<todayKey)''', '''amount:Number(question.value||0), currency:consultation.currency || "BRL", currencyRate:consultation.currencyRate || 1, dueDate:question.paymentDate||"", overdue:Boolean(question.paymentDate && question.paymentDate<todayKey)''')

# 6. Improve finance receivables display.
old='''<div><strong>{item.clientName}</strong><div style={styles.muted}>{item.title} · Vencimento: {item.dueDate ? formatDate(item.dueDate) : "sem data"}{item.overdue ? " · vencido" : ""}</div></div>\n<div style={styles.rightStack}><strong>{formatMoney(item.amount)}</strong>{item.installmentId && consultation ? <div style={{display:"flex", gap:6, flexWrap:"wrap", justifyContent:"flex-end"}}><button style={styles.smallButton} onClick={() => receiveConsultationInstallment(consultation.id, item.installmentId)}>Recebida</button><button style={styles.smallButton} onClick={() => setConsultationInstallmentStatus(consultation.id, item.installmentId, "defaulted")}>Não recebida</button></div> : null}</div>'''
new='''<div><strong>{item.clientName}</strong><div style={styles.muted}>{item.title} · Vencimento: {item.dueDate ? formatDate(item.dueDate) : "sem data"}{item.overdue ? " · vencido" : ""}</div>{item.currency && item.currency !== "BRL" ? <div style={styles.muted}>💱 Cobrança: {currencySymbol(item.currency)} {(item.amount / (item.currencyRate || 1)).toFixed(2)} · equivalente: {formatMoney(item.amount)}</div> : <div style={styles.muted}>💵 Valor: {formatMoney(item.amount)}</div>}</div>\n<div style={styles.rightStack}><strong>{formatMoney(item.amount)}</strong>{item.installmentId && consultation ? <div style={{display:"flex", gap:6, flexWrap:"wrap", justifyContent:"flex-end"}}><button style={styles.smallButton} onClick={() => receiveConsultationInstallment(consultation.id, item.installmentId)}>Recebida</button><button style={styles.smallButton} onClick={() => setConsultationInstallmentStatus(consultation.id, item.installmentId, "defaulted")}>Não recebida</button></div> : null}</div>'''
assert old in s
s=s.replace(old,new)

# 7. Move international settings card inside settings screen instead of rendering on every screen.
settings_card='''<section style={styles.card}><div style={styles.eyebrow}>RECEBIMENTOS INTERNACIONAIS</div><h2 style={styles.cardTitle}>Moedas e taxas</h2><div style={styles.muted}>Cotação diária via Frankfurter/BCB. Última atualização: {currencyRateDate || "não atualizada"}.</div><div style={styles.twoColumns}><div><label style={styles.label}>PayPal · taxa %</label><input type="number" min="0" step="0.01" value={currencySettings.paypalFeePercent} onChange={e=>setCurrencySettings({...currencySettings,paypalFeePercent:Number(e.target.value)||0})} style={styles.input}/></div><div><label style={styles.label}>Wise · taxa %</label><input type="number" min="0" step="0.01" value={currencySettings.wiseFeePercent} onChange={e=>setCurrencySettings({...currencySettings,wiseFeePercent:Number(e.target.value)||0})} style={styles.input}/></div></div><label style={styles.label}>Outras taxas · %</label><input type="number" min="0" step="0.01" value={currencySettings.otherFeePercent} onChange={e=>setCurrencySettings({...currencySettings,otherFeePercent:Number(e.target.value)||0})} style={styles.input}/><div style={styles.infoBox}>USD: {currencyRates.USD?.toFixed(4) || "—"} · EUR: {currencyRates.EUR?.toFixed(4) || "—"} · GBP: {currencyRates.GBP?.toFixed(4) || "—"} BRL por unidade.</div></section>'''
assert s.count(settings_card)==1
s=s.replace(settings_card,'')
# Insert before the closing fragment of the settings screen, immediately before the first closing `</>\n)}` after the settings block.
settings_start=s.find('"settings" && (')
assert settings_start!=-1
closing=s.find('</>\n)}\n\n</main>', settings_start)
assert closing!=-1
s=s[:closing]+settings_card+'\n'+s[closing:]

# 8. HistoryItem: clickable photos, photo modal, and playable audios.
old='''function HistoryItem({\nconsultation,\nonResume,\nonEdit,\nonDelete,\n}: {\nconsultation: Consultation;\nonResume: () => void;\nonEdit: () => void;\nonDelete: () => void;\n}) {\nconst [expanded, setExpanded] =\nuseState(false);\nreturn ('''
new='''function HistoryItem({\nconsultation,\nonResume,\nonEdit,\nonDelete,\n}: {\nconsultation: Consultation;\nonResume: () => void;\nonEdit: () => void;\nonDelete: () => void;\n}) {\nconst [expanded, setExpanded] = useState(false);\nconst [selectedPhoto, setSelectedPhoto] = useState<PhotoItem | null>(null);\nconst [playingAudioId, setPlayingAudioId] = useState<string | null>(null);\nconst audioRefs = useRef<Record<string, HTMLAudioElement | null>>({});\nconst playAudio = (audio: AudioItem) => {\n  const element = audioRefs.current[audio.id];\n  if (!element) return;\n  Object.entries(audioRefs.current).forEach(([id, item]) => { if (id !== audio.id && item) { item.pause(); item.currentTime = 0; } });\n  if (playingAudioId === audio.id) { element.pause(); setPlayingAudioId(null); }\n  else { element.play().then(() => setPlayingAudioId(audio.id)).catch(() => setPlayingAudioId(null)); }\n};\nreturn ('''
assert old in s
s=s.replace(old,new)
old='''{question.photos.map(\n(photo) => (\n<div key={photo.id} style={{ display: "grid", gap: 6, minWidth: 120 }}>\n<img src={photo.data} alt="Carta" style={styles.historyPhoto} /><div style={styles.muted}>🎙️ {(photo.audios||[]).length} áudio(s)</div>\n{photo.note ? <div style={styles.muted}>📝 {photo.note}</div> : null}\n</div>\n)\n)}'''
new='''{question.photos.map(\n(photo) => (\n<button key={photo.id} type="button" onClick={() => setSelectedPhoto(photo)} style={{ display: "grid", gap: 6, minWidth: 120, border: 0, background: "transparent", padding: 0, textAlign: "left", cursor: "pointer" }}>\n<img src={photo.data} alt="Carta" style={styles.historyPhoto} /><div style={styles.muted}>🔎 Abrir foto · 🎙️ {(photo.audios||[]).length} áudio(s)</div>\n{photo.note ? <div style={styles.muted}>📝 {photo.note}</div> : null}\n</button>\n)\n)}'''
assert old in s
s=s.replace(old,new)
old='''<div\nstyle={\nstyles.historyAudio\n}\n>\n🎙️{" "}\n{\nquestion.audios\n.length\n}{" "}\náudio(s)\n</div>'''
new='''<div style={styles.historyAudio}>\n  🎙️ {question.audios.length} áudio(s) de observação\n  {question.audios.length > 0 && <div style={{ display: "grid", gap: 6, marginTop: 8 }}>\n    {question.audios.map((audio) => <div key={audio.id} style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>\n      <audio ref={element => { audioRefs.current[audio.id] = element; }} src={audio.data} onEnded={() => setPlayingAudioId(null)} style={{ display: "none" }} />\n      <button type="button" style={styles.smallButton} onClick={() => playAudio(audio)}>{playingAudioId === audio.id ? "⏸ Pausar" : "▶ Ouvir"}</button>\n      <span style={styles.muted}>{audio.name} · {formatDuration(audio.duration)}</span>\n    </div>)}\n  </div>}\n</div>'''
assert old in s
s=s.replace(old,new)
old='''</section>\n);\n}\n/* =========================================================\nAUDIO WAV'''
new='''</section>\n{selectedPhoto && <Modal title={`Foto da pergunta ${selectedPhoto.id ? "" : ""}`} onClose={() => setSelectedPhoto(null)}>\n  <div style={styles.photoModalContent}>\n    <img src={selectedPhoto.data} alt={selectedPhoto.name || "Foto da pergunta"} style={styles.photoLarge} />\n    {selectedPhoto.note && <div style={styles.noteBox}>📝 {selectedPhoto.note}</div>}\n    <div style={styles.photoModalSectionTitle}>Áudios desta foto ({(selectedPhoto.audios || []).length})</div>\n    {(selectedPhoto.audios || []).length === 0 ? <div style={styles.muted}>Nenhum áudio foi salvo nesta foto.</div> : (selectedPhoto.audios || []).map(audio => <div key={audio.id} style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap", marginBottom: 8 }}>\n      <audio ref={element => { audioRefs.current[`photo-${audio.id}`] = element; }} src={audio.data} onEnded={() => setPlayingAudioId(null)} style={{ display: "none" }} />\n      <button type="button" style={styles.smallButton} onClick={() => { const element = audioRefs.current[`photo-${audio.id}`]; if (!element) return; Object.entries(audioRefs.current).forEach(([id,item]) => { if (id !== `photo-${audio.id}` && item) { item.pause(); item.currentTime = 0; } }); if (playingAudioId === audio.id) { element.pause(); setPlayingAudioId(null); } else { element.play().then(() => setPlayingAudioId(audio.id)).catch(() => setPlayingAudioId(null)); } }}>{playingAudioId === audio.id ? "⏸ Pausar" : "▶ Ouvir"}</button>\n      <span style={styles.muted}>{audio.name} · {formatDuration(audio.duration)}</span>\n    </div>)}\n  </div>\n</Modal>}\n);\n}\n/* =========================================================\nAUDIO WAV'''
assert old in s
s=s.replace(old,new)

# 9. History search includes notes, payment, and currency.
old='''return `${c.title} ${c.clientName} ${c.questions.map(x=>x.text).join(" ")}`.toLowerCase().includes(q);'''
new='''return `${c.title} ${c.clientName} ${c.currency || "BRL"} ${c.paymentMethod || ""} ${c.questions.map(x=>`${x.text} ${x.notes}`).join(" ")}`.toLowerCase().includes(q);'''
s=s.replace(old,new)

# 10. Daily search: make it explicitly include client/phone/country by enriching details.
old='''details: [`Status: ${item.status === "completed" ? "Concluído" : item.status === "standby" ? "Standby" : "Ativo"}`, `Pagamento: ${item.paid ? "Pago" : "Pendente"}`, `Moeda: ${item.currency || "BRL"}`, `${item.currency && item.currency !== "BRL" && item.currencyRate ? `Pago: ${currencySymbol(item.currency)} ${(item.value/item.currencyRate).toFixed(2)} · equivalente ${formatMoney(item.value)}` : ""}`, `${item.paymentPlan?.fee ? `Taxa: ${formatMoney(item.paymentPlan.fee)} · líquido ${formatMoney(Math.max(0,item.value-item.paymentPlan.fee))}` : ""}`, `${item.questions.filter(q=>q.text.trim() || q.completed).length} pergunta(s)`].filter(Boolean),'''
new='''details: [`Consulente: ${item.clientName}`, `Telefone: ${clients.find(c=>c.id===item.clientId)?.phone || "não informado"}`, `País: ${clients.find(c=>c.id===item.clientId) ? clientCountry(clients.find(c=>c.id===item.clientId)!) : "Não identificado"}`, `Status: ${item.status === "completed" ? "Concluído" : item.status === "standby" ? "Standby" : "Ativo"}`, `Pagamento: ${item.paid ? "Pago" : "Pendente"}`, `Moeda: ${item.currency || "BRL"}`, `${item.currency && item.currency !== "BRL" && item.currencyRate ? `Pago: ${currencySymbol(item.currency)} ${(item.value/item.currencyRate).toFixed(2)} · equivalente ${formatMoney(item.value)}` : ""}`, `${item.paymentPlan?.fee ? `Taxa: ${formatMoney(item.paymentPlan.fee)} · líquido ${formatMoney(Math.max(0,item.value-item.paymentPlan.fee))}` : ""}`, `${item.questions.filter(q=>q.text.trim() || q.completed).length} pergunta(s)`].filter(Boolean),'''
assert old in s
s=s.replace(old,new)

p.write_text(s)
