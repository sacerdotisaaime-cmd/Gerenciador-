# V64 · Correções operacionais

- Painel Trabalhos e Vendas na tela Inicial com filtros persistentes, ordenação e recolhimento persistente.
- Máximo de 3 itens visíveis com rolagem interna.
- Ações diretas na tela Inicial para atendimento, trabalho e etapas de venda.
- Modal de execução de trabalho renderizado fora da tela Serviços, permitindo abertura direta pela Inicial.
- Fluxo de venda com confirmações de etapa e sem retorno automático ao checkout.
- Estados de filtro/ordenação/recolhimento preservados ao sair e reabrir o aplicativo.
