# Gestão Sacerdotista Aimê V55

V55 é uma revisão da V54 com foco em integração do fluxo diário de trabalho, agenda e financeiro.

## Mudanças principais

1. **Permissões de primeiro acesso**
   - A preparação de permissões é exibida somente uma vez por instalação/dados do app.
   - O aplicativo sempre retorna para **Início** ao abrir.
   - Sobreposição e Alarmes não abrem sozinhos; só abrem quando o usuário toca em **Configurar**.

2. **Fluxo dos trabalhos**
   - Removido o status operacional "Em execução" da interface.
   - Orçamento aprovado → Aguardando execução.
   - Trabalho pode ser **Executado agora** ou **Agendado**.
   - Trabalho agendado aparece na Agenda/Próximos e recebe lembrete.
   - Ao executar um trabalho agendado, ele passa diretamente para **Executado**.
   - Cancelamento e prorrogação permanecem disponíveis antes da execução.
   - Registros legados "in_progress" são migrados para "approved".

3. **Executar trabalho**
   - Se um trabalho ainda não está agendado, a seção Agendamento permite escolher **Agendar em vez de executar agora**.
   - O botão muda para **Agendar trabalho** nesse modo.
   - Se o trabalho já está agendado, o botão permanece **Concluir trabalho**.

4. **Moedas e PayPal**
   - Valores em BRL/EUR/USD/GBP continuam disponíveis.
   - Taxas PayPal/Wise/Outra são normalizadas para evitar `toFixed` em valor indefinido.
   - A taxa configurada é gravada no plano financeiro do trabalho e considerada nas movimentações recebidas.

5. **Parcelas e sincronização**
   - Parcelas vencidas passam a ser reconhecidas como vencidas.
   - Recebimento de parcelas de consulta/pergunta gera movimentação financeira de entrada.
   - "Não vai pagar" gera desfalque para parcelas de consulentes.
   - Prorrogação registra a data anterior e o novo vencimento.
   - O mesmo registro é reutilizado no histórico do consulente, no trabalho e no financeiro.

6. **Tela inicial — Avisos**
   - Novo card entre **Próximos agendamentos** e **Organização**.
   - Filtros: 3 dias (padrão), hoje, 7 dias, 15 dias e atrasados.
   - Mostra contas e parcelas de consulentes que exigem atenção.
   - Exibe até três itens por área visual com rolagem para os demais.
   - Permite pagar/receber ou prorrogar; para parcelas de consulentes também permite **Não vai pagar**.

7. **Central de Contas**
   - Fica minimizada por padrão na tela inicial.
   - Pode ser expandida e continua com acesso à Central completa.
