# V117 — Caixa de Mídias + retorno rápido sem restauração repetida

## Correções

1. **Compartilhamento WhatsApp → Caixa de Mídias**
   - O `PermissionBridgePlugin` agora guarda o `Intent` compartilhado caso a Activity entregue o Intent antes de o plugin terminar de carregar.
   - Quando o plugin carrega, o Intent pendente é processado e o arquivo é copiado para a caixa nativa.
   - O JavaScript continua usando a Caixa de Mídias como fonte de importação.
   - O fluxo antigo de importação direta do áudio para a tela atual foi removido para não competir com a Caixa de Mídias.

2. **Restauração de dados apenas no início real do processo**
   - Foi adicionado um marcador nativo mantido apenas na memória do processo Android.
   - Primeiro início do processo: restauração completa do Supabase ocorre normalmente.
   - Retorno após minimizar/trocar de aplicativo ou recriação da Activity no mesmo processo: os dados locais são hidratados imediatamente e a tela não fica bloqueada em “Restaurando seus dados...”.
   - A sincronização de fundo existente continua funcionando depois que o aplicativo está pronto.

3. **Versão Android**
   - versionName 1.17.0
   - versionCode 117
   - applicationId e assinatura permanecem os mesmos para atualização sobre as versões anteriores.
