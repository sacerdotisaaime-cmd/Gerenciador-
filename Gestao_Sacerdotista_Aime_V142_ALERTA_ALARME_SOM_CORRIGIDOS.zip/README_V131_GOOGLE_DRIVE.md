# V131 — Google Drive / plugin bridge / build diagnostic

Baseada na V130.

Correções desta versão:
- registro explícito do PermissionBridge via MainActivity, sem alterar manualmente capacitor.plugins.json;
- validação do plugin ocorre depois da gravação do MainActivity;
- build usa `clean assembleRelease --stacktrace` para revelar falhas reais de empacotamento;
- diagnóstico de empacotamento em caso de falha;
- Google Drive OAuth e diagnóstico mantidos;
- versionCode 131 / versionName 1.31.0.
