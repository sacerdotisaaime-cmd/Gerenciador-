# V129 — Google Drive

Esta versão corrige o erro `PermissionBridge.connectGoogleDrive() is not implemented on android`.

## Build
Use **somente** `.github/workflows/build-android-release.yml`.
O workflow legado `build-apk.yml` foi removido porque não continha a integração Google Drive e poderia gerar um APK incorreto.

## Google OAuth
- Package: `com.sacerdotisaaime.gestao`
- SHA-1: `75:E9:22:49:A1:52:98:56:B7:77:7F:3E:32:BE:49:E4:9F:08:87:D0`
- Scope: `https://www.googleapis.com/auth/drive.file`
- Client ID: configurado no fluxo Android do Google Cloud.

## Diagnóstico
Se a autorização falhar, o app mostra código, etapa, mensagem e detalhes do erro.
