# Gestão Sacerdotista Aimê — V76

Correções focadas na V75, preservando a arquitetura e funcionalidades anteriores.

## Correções desta versão
- Filtro operacional **Anteriores** para trabalhos/agendamentos passados.
- Filtro **Atrasados** continua exibindo trabalhos efetivamente atrasados.
- Trabalhos sem data de execução permanecem disponíveis em todos os filtros.
- Identificação de consulente mais robusta por ID e nome normalizado, inclusive registros antigos sem correspondência direta de ID.
- Nome da consulente não quebra mais letra por letra nos cards operacionais.
- Foto da consulente fica clicável e abre o modal ampliado também fora do atendimento ativo.
- Modal global da foto com **Editar foto** e **Fechar**, sem abrir automaticamente por iniciar atendimento/execução.
- Foto + nome nos principais cards de identificação, incluindo próximos agendamentos e avisos de parcelas.
- Avisos financeiros mostram explicitamente a **data de vencimento** e, quando aplicável, desde quando está vencida.

## Validação
- ZIP deve ser testado com `unzip -t`.
- A compilação Android não é considerada validada sem build real do projeto.
