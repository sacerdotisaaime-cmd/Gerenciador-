# Gestão Sacerdotisa Aimê — V26

Base: V25 funcional.

## Alterações desta versão
- Checkout: resumo incorporado à seção de moeda/recebimento, com total principal em BRL e valor menor na moeda escolhida.
- Checkout: edição de perguntas passa a transformar um valor positivo em cobrança efetiva, corrigindo total que permanecia em zero quando a pergunta estava marcada como incluída.
- Checkout: edição de trabalho/venda com campos de valor e moeda mais usáveis e conversão ao trocar a moeda.
- Parcelamento: entrada é um registro separado, sempre hoje; parcelas numeradas #1, #2... começam no mês seguinte quando há entrada. Sem entrada, #1 começa na data inicial (hoje por padrão).
- Atendimento: ações de pergunta extra, trabalho, venda e orçamento ficaram compactas.
- Áudio de foto: indicador visual de áudio gravado com duração e mini forma de onda; gravação continua mostrando onda animada e tempo.
- Agenda: nova aba Consulentes com pendências, vencidas e arquivadas; permite marcar pago, não pago/calote e prorrogar vencimento. Pagamentos recebidos depois podem reverter o desfalque financeiro sem apagar o histórico.
- Login/Supabase: não alterados em relação à V25.
