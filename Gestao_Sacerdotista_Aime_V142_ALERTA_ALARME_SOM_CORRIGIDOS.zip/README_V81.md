# Gestão Sacerdotista Aimê — V81

Base: V80. Esta versão reúne as correções solicitadas depois da alteração da Agenda que foi cancelada/postergada. **O bug geral da Agenda não foi refeito nesta versão.**

## Implementado

1. **Fotos no Novo atendimento**
   - Miniaturas das fotos selecionadas pela Galeria aparecem imediatamente.
   - Toque na miniatura para ampliar.
   - Exclusão individual da foto antes de salvar.
   - Fotos feitas pela câmera continuam aparecendo no mesmo painel.

2. **Fotos na Ficha completa**
   - Cada foto pode ser aberta.
   - A foto aberta possui botão para excluir somente aquela foto.
   - A remoção atualiza o registro e o contador.

3. **Editar status e condições**
   - Novo botão na tela de detalhes de trabalho, venda e tiragem.
   - Permite corrigir status, valor, forma de pagamento, parcelas e data real de execução quando aplicável.
   - A alteração usa o mesmo registro central e passa a ser refletida pelas áreas que consultam esse registro.

4. **Data real da execução do trabalho**
   - O fluxo “Executar trabalho” agora pergunta a data em que o trabalho realmente aconteceu.
   - A data real é separada do momento em que a conclusão foi registrada.
   - A data fica armazenada em `executedDate`.

5. **Exclusão de trabalhos, vendas e consultas**
   - Central de Serviços ganhou exclusão para os registros.
   - A exclusão também limpa os efeitos financeiros/materiais vinculados quando existentes.
   - Trabalhos executados removidos devolvem ao estoque os itens consumidos como “novo” e removem seus movimentos financeiros/execução vinculados.
   - Registros excluídos continuam usando a Lixeira existente, com os efeitos vinculados preservados no pacote de restauração quando aplicável.

6. **Desfalque por pergunta no checkout**
   - Novo estado explícito `desfalque`.
   - Desfalque não entra no total cobrado do checkout.
   - Ao salvar/finalizar, o sistema cria ou atualiza automaticamente o desfalque correspondente.
   - Benefício do trabalho e cortesia extra continuam separados e não geram desfalque.

7. **Objetos recebidos/enviados em trabalhos**
   - Novo trabalho permite registrar que a cliente enviou um objeto/material.
   - Também permite registrar objeto/material enviado pela equipe.
   - Cada registro aceita descrição, valor de referência opcional e observação.
   - O objeto enviado não vira uma venda/cobrança separada; seu valor é apenas referência e fica dentro do trabalho.
   - Informações aparecem no histórico/ficha do trabalho.

8. **Pagamento parcial de parcelas**
   - Cada parcela passou a suportar `receivedAmount` e histórico de pagamentos parciais.
   - É possível registrar quanto entrou agora e quanto ainda falta.
   - A mesma parcela pode receber vários pagamentos até ser quitada.
   - Dashboard e detalhes de serviço oferecem “Receber valor”.
   - Totais recebidos, pendentes e status `Pago parcialmente` passam a considerar o valor efetivamente recebido.

## Revisão de segurança das alterações

- O fluxo geral da Agenda não foi refeito nesta versão; o bug de Agenda permanece explicitamente separado para uma versão futura.
- A base funcional utilizada foi a V80 disponível no projeto.
- Foi feita verificação sintática/semântica do `src/App.tsx` com o TypeScript global disponível no ambiente, descontando os erros de módulos externos porque as dependências do projeto não estavam instaladas.

## Limitação de validação

A execução completa de `npm run build` não pôde ser concluída neste ambiente porque a instalação das dependências (`npm install`) excedeu o tempo disponível. O código-fonte, porém, foi verificado com `tsc` e não apresentou erros adicionais além dos módulos externos ausentes.
