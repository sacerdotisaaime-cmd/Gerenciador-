# Gestão Sacerdotisa Aimê — V19

V19 separa estruturalmente os três fluxos do botão Nova:

- Consulta/Tiragem: mantém perguntas, fotos e áudios da tiragem e cobrança no encerramento.
- Trabalho: seleção de tipo de trabalho configurável em Administração, título, cobrança, moeda, pagamento, observações, foto, áudio, orçamento vinculado e custos de envio.
- Venda: seleção de item de venda configurável em Administração, cobrança, moeda, pagamento, observações, foto, áudio, orçamento vinculado e custos de envio.

Trabalhos e vendas são registrados no histórico do consulente como registros próprios, sem serem tratados como perguntas. Fotos abrem em modal e os áudios podem ser reproduzidos no histórico.

Novas listas são armazenadas localmente e incluídas no snapshot Supabase: `gestao_work_types` e `gestao_sale_items`.
