# V105 — Inventário corrigido

Base: V104 — Gestão Sacerdotista Aimê.

## Correções desta versão

- A janela de cadastro/edição do Inventário foi retirada do retorno específico do atendimento e passou a ser um overlay global.
- O modal do Inventário agora usa `createPortal(..., document.body)`, mantendo o mesmo padrão robusto usado pelos outros overlays do aplicativo.
- A abertura do modal passou a ser síncrona, sem `setTimeout`.
- Removido o `onPointerUp` com `stopPropagation` do botão “Novo item do inventário”.
- O estado transitório de janela aberta do Inventário não é mais restaurado automaticamente pelo snapshot de navegação após reinicialização.
- Quantidade de inventário passa a ter mínimo de 1 unidade.
- O sistema impede reduzir o total abaixo da quantidade já registrada como avariada.
- A normalização corrige inconsistências em `brokenQuantity` e preserva o histórico de avarias.
- O valor unitário e o valor total do inventário ficam normalizados de forma consistente.
- O histórico de avarias continua registrando quantidade, data, local, motivo, observação e valor unitário da ocorrência.

## Preservado

- Sistema de áudio do V104.
- Persistência local do inventário.
- Sincronização do `gestao_inventory` com o snapshot Supabase.
- Fotos por câmera e galeria.
- Lixeira/restauração.
- Cadastro, edição e exclusão de itens.
- Registro de avarias/quebras e cálculo de unidades disponíveis/prejuízo.
