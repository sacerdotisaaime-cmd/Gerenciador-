# Gestão Sacerdotisa Aimê — V38

Correção da V37: o erro exibido no aparelho era `pendingCount is not defined`, um ReferenceError em JavaScript/TypeScript. Os contadores do painel foram restaurados no escopo correto e o bloco de Relatórios foi restaurado para sua própria tela `reports`, com seus cálculos locais (`a`, `b`, `receivedByCurrency`, despesas etc.).

Também foi mantido o fluxo de login/Supabase da V37, sem alterar a inicialização de autenticação.
