# Gestão Sacerdotista Aimê — V70

## Correção principal

Corrigido o fluxo de **cadastros rápidos dentro de outras janelas**.

### Antes
- Ao tocar em `＋ Novo tipo de trabalho` ou `＋ Novo item para venda`, a janela filha podia ficar atrás da janela pai.
- Em alguns fluxos o cadastro só ficava visível depois de fechar a janela anterior.

### Agora
- O cadastro rápido recebe uma camada superior explícita (`priority=50000`).
- A janela pai permanece aberta e preserva o que já estava preenchido.
- `Novo trabalho na tiragem → Novo tipo de trabalho` abre imediatamente por cima.
- `Nova venda na tiragem → Novo item para venda` segue o mesmo comportamento.
- O fluxo de `Novo atendimento → Novo trabalho/venda → novo cadastro` usa o mesmo mecanismo.
- Ao salvar um novo tipo de trabalho, ele é associado tanto ao cadastro geral quanto ao campo do trabalho relacionado à tiragem e seus valores são preenchidos automaticamente conforme a moeda selecionada.
- No Android, o botão Voltar fecha primeiro o cadastro rápido, sem fechar a janela pai.
- O bloqueio de fundo também considera a janela de cadastro rápido.

## Preservação

V70 parte integralmente do projeto V69 e altera somente o mecanismo de modal/cadastro rápido descrito acima. As demais funções, módulos, Supabase, Capacitor e arquivos do projeto foram mantidos.

## Verificação

- Todos os arquivos `.ts`/`.tsx` foram submetidos a transpile TypeScript para verificar sintaxe.
- O ZIP foi validado com `unzip -t`.
- Não foi executado APK em dispositivo Android nesta etapa; o comportamento físico no aparelho deve ser confirmado pelo build do GitHub Actions.
