# V104 — Inventário completo e cadastro corrigido

## Correções
- Cadastro de novo item do inventário agora usa uma camada própria, fora da pilha genérica de modais, eliminando o problema de tocar em “Novo item do inventário” e nenhuma janela aparecer.
- Compatibilidade com itens antigos do inventário por normalização dos dados.
- Foto por câmera e galeria.
- Quantidade comprada.
- Valor unitário e valor total de referência.
- Data de compra.
- Estado/conservação.
- Quantidade disponível calculada a partir das unidades avariadas.
- Registro individual de avaria/quebra com quantidade, data, local, motivo e observação.
- Histórico de avarias dentro do próprio item.
- Cálculo do prejuízo das unidades quebradas e indicação de reposição.
- Persistência local e sincronização remota já existentes foram preservadas.
- Nenhuma alteração no módulo de áudio.
