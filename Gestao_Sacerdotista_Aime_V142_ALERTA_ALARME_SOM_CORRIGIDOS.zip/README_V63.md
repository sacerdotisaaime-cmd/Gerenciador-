# Gestão Sacerdotista Aimê — V63

V63 parte da V62 e aplica a nova rodada de correções estruturais solicitadas, preservando o núcleo de autenticação/Supabase e as correções já existentes.

## Correções desta versão

- **Iniciar atendimento pela tela Início:** o botão agora abre diretamente o atendimento/triagem agendado específico, recuperando consulente, perguntas e informações, marcando-o como em andamento e levando à tela da tiragem. Não passa pela Agenda.
- **Informações recebidas:** o botão **Editar** usa o registro mais recente do atendimento e abre novamente o editor completo, permitindo complementar texto, fotos e áudios e salvar sem abandonar a tiragem.
- **Pagamento parcial nos Serviços:** trabalhos e vendas agora distinguem **Pago**, **Pago parcialmente** e **Não pago**. Quando houver parcelamento, as parcelas e seus estados continuam visíveis para controle.
- **Fluxo das vendas:** as ações de ciclo (iniciar/concluir confecção, preparar envio, marcar enviado/entregue etc.) atualizam o mesmo registro e mantêm o usuário no fluxo operacional. Não redirecionam para o checkout de edição.
- **Tela Início:** o bloco **Organização · Hoje / Rotinas e tarefas** foi substituído por um painel operacional de **trabalhos, vendas e atendimentos aguardando ação**, incluindo agendados e atrasados. Cada item possui ação direta apropriada e, quando aplicável, reagendamento, sem exigir entrada em Serviços.
- **Histórico:** permanece sem botões operacionais de executar/retomar/registrar trabalho. Ficam as ações de **Ver ficha completa** e **Editar informações**; atividades vinculadas são exibidas apenas como informação.
- **Correções anteriores da V62 preservadas:** exclusões de cadastros com confirmação, parcelamento editável, galeria, edição de informações recebidas, continuidade após câmera, standby, modais/rolagem, persistência de estado ao trocar de aplicativo, atalho para novo contato, integração Agenda/Trabalho e demais correções já existentes.

## Validação

- `src/App.tsx` foi analisado por transpilação sintática do TypeScript/TSX: **0 diagnósticos**.
- O build completo do projeto não foi declarado como executado porque as dependências npm do pacote não estavam disponíveis localmente e a tentativa de instalação excedeu o limite de execução do ambiente.
