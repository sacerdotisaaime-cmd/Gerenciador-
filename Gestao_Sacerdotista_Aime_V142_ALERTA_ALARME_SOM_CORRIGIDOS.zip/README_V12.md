# Gestão Sacerdotisa Aimê — V12

## Supabase
V12 adds the first Supabase integration while keeping the existing localStorage data as the local layer.

- Supabase Project URL: configured in `src/supabase.ts`
- Publishable key: configured in `src/supabase.ts`
- Secret/service-role keys are not used.
- Login uses the single Supabase Auth account created for the app.
- On first authenticated load, clients, consultations and questions are merged with Supabase.
- Existing local records are preserved and uploaded; remote records are also brought down.
- Photos and audio remain local in V12; Storage upload is the next integration step.

Before testing V12, run `SUPABASE_GRANTS_V12.sql` once in the Supabase SQL Editor.

The Supabase JS SDK is loaded from the official jsDelivr CDN at runtime, so no secret key is bundled.
