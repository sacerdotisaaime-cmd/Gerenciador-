# Gestão Sacerdotista Aimê — V72

Correção do cadastro rápido dentro da tiragem ativa.

A causa raiz era que `quickCatalogKind` era alterado, mas o JSX do cadastro rápido só era alcançado pelo retorno principal do `App`; quando `activeConsultation` estava aberto, o App retornava antes desse JSX.

V72 monta a camada de cadastro rápido também no retorno da tiragem ativa, preservando o contexto pai.
