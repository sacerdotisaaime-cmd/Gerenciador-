# Gestão Sacerdotisa Aimê — V45

V45 parte da V44 e preserva a linha de login/Supabase. O foco desta versão é separar Trabalho & Financeiro de Organização e Ferramentas e criar uma primeira camada funcional de rotinas, execução, saúde/bem-estar, medicamentos e alarmes.

## O que foi implementado

- Cabeçalho simplificado: menu + Trabalho & Financeiro + Organização + Ferramentas.
- Removidos o texto “Gestão” e o avatar “A” do cabeçalho.
- Ações rápidas do Início agora ficam em um card recolhível para liberar espaço.
- Novo card de Organização na tela inicial, abaixo dos próximos agendamentos, com rotinas/tarefas do dia e execução por um toque.
- Rotinas recorrentes da Casa e do Trabalho: dias da semana, horário, responsável, participantes, prioridade, checklist e tipo tarefa/cronômetro.
- Pessoas da família: adultos e crianças; no Trabalho somente adultos aparecem como responsáveis.
- Registro real de execução: iniciado, concluído, horário de início/fim e duração para rotinas cronometradas.
- “O que foi feito hoje” dentro de Organização.
- Agenda separada de Organização para as rotinas recorrentes.
- Compras futuras aparecem dentro de Casa/Trabalho e continuam separadas de estoque e de saída financeira.
- Bem-estar & Saúde: humor/estado, passou mal, descanso, não conseguiu trabalhar e observações.
- Registro menstrual com início, fim, cólica e observações.
- Gestão de medicamentos: pessoa, quantidade, dose, tomadas/dia, horários, estoque mínimo, registro de tomada e cálculo aproximado de dias de estoque.
- Alertas de estoque baixo de medicamentos.
- Configuração de notificações e permissão de alarmes.
- Notificações nativas do Android via Capacitor Local Notifications: o app programa lembretes dos próximos 21 dias para rotinas e medicamentos quando a permissão está ativa.
- Relatórios de rotinas com contagem e duração das execuções; também foi adicionada a aba de Rotinas aos relatórios gerais.
- Novos dados entram no snapshot Supabase e no reset de Organização.
- Ferramentas passa a ser a área para utilidades, com Bloco de notas como primeira ferramenta.

## Observações

- O controle de medicamentos é de organização, registro, estoque e lembrete. Ele não define dose, tratamento ou orientação médica.
- Previsões de ciclo são deliberadamente simples: esta versão registra datas e sintomas, sem tentar fazer diagnóstico ou previsão médica.
- A compilação completa não foi executada neste ambiente porque a instalação de dependências excedeu o tempo disponível. O TypeScript foi verificado com `tsc -p tsconfig.json --noEmit` e terminou sem erros. O workflow do GitHub instala as dependências e também inclui `@capacitor/local-notifications`.

## Base preservada

A V45 foi construída diretamente a partir da V44. A correção de Hooks da V44 foi preservada: os Hooks continuam no nível superior do componente, antes dos retornos condicionais, conforme as regras oficiais do React.
