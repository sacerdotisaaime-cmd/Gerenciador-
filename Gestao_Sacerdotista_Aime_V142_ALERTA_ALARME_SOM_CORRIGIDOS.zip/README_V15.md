# Gestão Sacerdotisa Aimê — V15

V15 integra o fluxo de atendimento, trabalho, tiragens, orçamento, vendas, pagamentos, desfalques, histórico, diário, mídia e recebimentos internacionais.

## Principais mudanças
- Pesquisa rápida de consulente no Novo atendimento.
- Orçamento rápido vinculado à consulente.
- Orçamento expansível no histórico e conversão direta em trabalho.
- Frete no orçamento: Uber, Correios e opção Correios ainda não informado, além de dados de envio.
- Trabalho com atividades vinculadas: tiragem, trabalho realizado e suporte grátis.
- Pagamento definido no encerramento do atendimento, com pago, pendente, parcelado ou grátis.
- Perguntas extras continuam com cobrança independente.
- Desfalques para gratuidades e parcelas marcadas como calote.
- Histórico pesquisável e linha do tempo diária com acesso rápido ao histórico.
- Foto com áudio e nota diretamente na miniatura; modal mantém os mesmos recursos.
- Compartilhamento conjunto de foto + primeiro áudio da foto.
- Salvamento da foto no armazenamento de documentos do aparelho.
- Indicador de gravação com tempo decorrido.
- Moedas BRL/EUR/USD/GBP e cotação diária via Frankfurter usando referência BCB quando disponível.
- PayPal/Wise/outros como métodos de recebimento e configuração de taxas.
- Relatórios e rentabilidade mantidos e integrados aos novos registros.

## Observação sobre moedas
As taxas são de referência e podem não ser a taxa comercial efetivamente cobrada por banco, PayPal ou Wise. O aplicativo aplica a taxa percentual configurada para estimar o líquido.
