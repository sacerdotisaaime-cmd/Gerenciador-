# Gestão Sacerdotista Aimê — V94

## Correção do botão Gravar áudio

Correção aplicada sobre a V93:

- O botão externo de **Gravar áudio** apenas abre o modal; não inicia o microfone.
- Removida a validação de `currentQuestion`/`activeConsultation` da etapa de abertura, evitando que um estado transitório impeça a janela de aparecer.
- As validações do alvo são feitas somente quando o usuário toca em **Iniciar gravação**.
- Corrigido o efeito que fechava o gravador quando `activeConsultation` ficava temporariamente nulo. Agora a saída do atendimento é determinada pela tela atual (`screen !== "consultation"`).
- Mantidos os fluxos de foto, galeria e importação de áudio.
- Mantido o salvamento automático ao finalizar e o vínculo do áudio com a pergunta/histórico.

## Fluxo esperado

**Gravar áudio → modal abre imediatamente → Iniciar gravação → gravar → Finalizar → salvar automaticamente → áudio aparece na lista → compartilhar / gravar mais.**

## Observação de validação

O código-fonte foi revisado diretamente. O ambiente desta execução não possui as dependências instaladas, portanto o build completo não foi executado aqui.
