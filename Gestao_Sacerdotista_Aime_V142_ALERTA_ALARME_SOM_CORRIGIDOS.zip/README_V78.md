# Gestão Sacerdotista Aimê — V78

Correção estrutural do ciclo de vida dos atendimentos, partindo da V77.

## Regras implementadas
- `active`: atendimento realmente em andamento; pode ser colocado em standby.
- `standby`: somente atendimento ativo temporariamente pausado.
- `scheduled`: atendimento/trabalho criado com data e hora, aguardando início; não aparece como standby.
- `completed`: atendimento finalizado; permanece no histórico/financeiro e não pode voltar a standby.
- Editar um atendimento concluído preserva `completed`.
- A Central de Serviços não carrega atendimento concluído para o fluxo de encerramento/standby; abre o editor diretamente.
- A exclusão de atendimento concluído é permitida somente pelo Histórico do consulente.
- A exclusão pela área de Standby não pode apagar atendimento concluído.
- Registros antigos criados como `standby` com agendamento e `updatedAt === createdAt` são migrados para `scheduled` na hidratação, preservando pausas reais que já tiveram atualização posterior.
