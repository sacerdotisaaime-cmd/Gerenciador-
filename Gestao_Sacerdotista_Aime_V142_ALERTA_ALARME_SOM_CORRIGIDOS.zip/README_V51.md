# Gestão Sacerdotista Aimê — V51

V51 is based on V50 and focuses on the service workflow and mobile modal usability.

## Main changes

- Central de Serviços is now the operational control center for budgets, works, sales and readings.
- Client history is informational for budgets: no approve/reject/convert actions are offered there.
- Budgets waiting for approval have Approve and Reject actions in the Central de Serviços.
- Approving a budget automatically creates a linked work and puts it in the waiting-for-execution queue.
- Existing approved budgets without a linked work can be repaired from the Central de Serviços.
- Sale workflow now has an optional confection step:
  - Approved
  - Awaiting confection
  - In confection
  - Awaiting shipping
  - Shipped
  - Delivered
- Sale creation includes a "Precisa de confecção?" option.
- Sales in the Central of Services show operational status separately from payment status.
- Shipping remains connected to agenda data when a shipping date/time exists.
- Mobile modal windows were revised so standard modals occupy almost the full available screen, with an internal scroll area and safe-area padding instead of being squeezed into a short bottom sheet.
- The standalone dashboard payment detail sheet follows the same mobile sizing rule.

## Validation

- `npx tsc --noEmit --skipLibCheck` passes in the working environment.
- A full `npm run build` could not be completed in this environment because the dependency installation (`npm ci`) timed out; use GitHub Actions for the authoritative Android build.
