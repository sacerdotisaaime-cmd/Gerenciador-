# Gestão Sacerdotisa Aimê — V28

Base: V27 funcional.

## Correções desta versão
- Corrigido layout dos cards expandidos de Consulentes na Agenda: conteúdo passa a ocupar a largura disponível em bloco, sem ficar espremido lateralmente.
- Consulentes continuam agrupados por nome, com expansão por cliente e ações de pagar, não pagar e prorrogar.
- Adicionada pesquisa discreta na Agenda > Consulentes.
- Entradas e saídas recentes do início não exibem cobranças/parcelas pendentes; somente movimentações efetivamente recebidas/pagas e saídas.
- Adicionado campo de pesquisa e área de rolagem controlada para movimentações recentes.
- Adicionado novo card no início para acompanhamento de parcelas, com abas Pagas, Pendentes e Não pagas, pesquisa por consulente e rolagem interna.
- Clicar em uma movimentação/parcela abre uma janela inferior de detalhes com ações disponíveis quando aplicável.
- Removida a seção redundante de Visão geral financeira do início.
- Mantido o atalho do card Desfalques para Agenda > Consulentes > Arquivadas.
- Login/Supabase não foram alterados nesta versão.
