# Gestão Sacerdotista Aimê — V58

Base: V57. Alterações restritas aos pontos solicitados.

- Ações de Pagar/Prorrogar contas agora usam modal padrão, com confirmação e atualização real do estado.
- Agenda mantém os itens existentes e permite ações operacionais rápidas onde o trabalho já é exibido.
- Adicionados cadastros rápidos por modal para tipo de trabalho, item de estoque e categoria, sem sair do fluxo atual; a estrutura também suporta venda e tiragem.
- Toast reposicionado acima da barra inferior e com quebra de texto.
- Modal central preserva minimização, fechamento e rolagem interna.
- Login, Supabase e inicialização não foram alterados.
- Nenhuma alteração de modelo do Supabase foi introduzida.
