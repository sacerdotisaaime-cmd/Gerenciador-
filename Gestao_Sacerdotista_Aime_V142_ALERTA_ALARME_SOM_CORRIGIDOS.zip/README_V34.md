# V34 — fluxo integrado de serviços

Baseado na V33, com foco em fluxo real: serviço/orçamento → agenda → execução → conclusão.

Principais mudanças:
- barra inferior alinhada à área nativa do Android, sem cartão flutuante sobre o conteúdo;
- Abrir trabalho mostra detalhes do trabalho, não o checkout; checkout fica em Editar perguntas/preços;
- status de trabalho: aprovado, agendado, em execução, concluído, cancelado e adiado;
- reagendamento e integração do trabalho com a agenda;
- execução conclui o trabalho, marca a agenda e registra custo/economia;
- materiais fora do estoque + nota da execução;
- tiragens na Central de Serviços aparecem somente quando estão em standby e não deletadas;
- Novo orçamento independente de consulta e sem consulente obrigatório;
- orçamento com múltiplos itens (perguntas, tiragem, trabalho, pedra/material etc.);
- origem do contato + indicação de qual consulente;
- Relatórios → Contatos;
- notificações da agenda via Notification API quando permitidas.

Observação: a build completa depende de `npm install`; a versão preserva a estrutura de login/Supabase da V33.
