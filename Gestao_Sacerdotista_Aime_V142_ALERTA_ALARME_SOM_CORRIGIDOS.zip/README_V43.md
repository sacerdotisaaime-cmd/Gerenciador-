# Gestão Sacerdotisa Aimê — V43

V43 reorganiza o financeiro e inicia a separação entre Trabalho/Financeiro e Rotina & Vida.

## Correções principais
- Caixinhas: clicar no atalho abre a caixinha existente; permite selecionar uma caixinha, guardar, resgatar e criar outra.
- Empréstimos: clicar no atalho abre os empréstimos existentes; permite selecionar um empréstimo, visualizar parcelas, pagar e criar outro.
- Aplicações separadas foram retiradas da interface: o rendimento CDI passa a pertencer à própria caixinha.
- Caixinhas ficam fora da Central de Contas. Central de Contas trata somente obrigações a pagar, contas recorrentes e parcelas.
- Configurações continua acessível pelo menu sanduíche.
- Novo eixo superior: Trabalho & Financeiro / Rotina & Vida.
- Rotina & Vida ganhou uma primeira estrutura funcional de tarefas pessoais, casa, família e crianças, separada da agenda profissional/financeira.
- Mantido o núcleo de login/Supabase da V42; não foi adicionado Open Finance.

## Observação de build
Foi feita checagem estática de parsing/JSX com TypeScript global. As dependências do projeto não estão instaladas neste ambiente, então não foi afirmado build completo local.
