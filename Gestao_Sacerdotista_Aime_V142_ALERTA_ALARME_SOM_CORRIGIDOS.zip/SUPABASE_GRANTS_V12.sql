-- Execute once in Supabase SQL Editor before testing V12.
-- RLS remains responsible for limiting rows to the authenticated user.

grant usage on schema public to authenticated;
grant select, insert, update, delete on all tables in schema public to authenticated;

grant usage, select on all sequences in schema public to authenticated;
