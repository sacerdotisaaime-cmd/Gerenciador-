# Gestão Sacerdotisa Aimê — Correções Android v2

Este pacote parte do projeto que já foi instalado no Android e inclui correções para:

- câmera nativa para foto da tiragem e informações recebidas;
- compressão das fotos para reduzir travamentos e consumo de armazenamento;
- acesso nativo aos contatos;
- gravação nativa de áudio com permissão de microfone;
- compartilhamento nativo de fotos e áudios pelo menu de compartilhamento do Android;
- parcelamento com acréscimo sobre o valor original;
- parcelas individualmente recebidas ou marcadas como não recebidas/desfalque;
- indicador financeiro separado para valores não recebidos;
- primeira versão de Orçamentos no menu sanduíche;
- botão de NF-e/QR também em Saída rápida;
- leitor QR nativo para Android.

## Compilação em nuvem

O arquivo `.github/workflows/build-apk.yml` deste pacote contém o workflow atualizado. Se o projeto for colocado dentro de um repositório como arquivos, abra GitHub Actions e execute `Build Android APK` manualmente.

Se o repositório mantiver o ZIP como um único arquivo, use o workflow criado no repositório que descompacta `gestao-sacerdotisa-aime-cloud-apk.zip` antes de instalar as dependências.

O APK de teste será disponibilizado em `Artifacts` com o nome `gestao-sacerdotisa-aime-debug-apk`.
