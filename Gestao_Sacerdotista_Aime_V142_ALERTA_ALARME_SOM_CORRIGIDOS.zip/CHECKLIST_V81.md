# Checklist V81

- [x] Miniaturas da Galeria em Novo atendimento
- [x] Abrir/excluir foto no fluxo de novo atendimento
- [x] Excluir foto individual na Ficha completa
- [x] Editar status e condições
- [x] Data real da execução
- [x] Excluir trabalho/venda/tiragem pela Central de Serviços
- [x] Desfalque explícito por pergunta e sincronização no checkout
- [x] Benefício/cortesia não geram desfalque
- [x] Objetos recebidos/enviados no trabalho
- [x] Pagamento parcial de parcelas
- [x] Cálculo de recebido/em aberto considerando pagamentos parciais
- [x] Agenda geral mantida fora do escopo desta versão
- [x] Verificação TypeScript do arquivo principal sem erros adicionais após descontar módulos externos ausentes
- [ ] Build completo com dependências instaladas — não executado neste ambiente por timeout no npm install
