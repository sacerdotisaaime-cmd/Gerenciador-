# Gestão Sacerdotista Aimê — V82

## Base
V82 foi construída a partir da **V81**, preservando a base funcional e as correções já existentes. A Agenda, que havia sido deixada de lado anteriormente, foi revisada nesta versão porque a solicitação atual pediu explicitamente a correção dela.

## Correções implementadas nesta V82

1. **Agenda revisada de ponta a ponta**
   - Consultas agendadas passam a aparecer automaticamente.
   - Trabalhos agendados passam a aparecer automaticamente.
   - Vendas/envios agendados passam a aparecer automaticamente, inclusive quando o registro comercial já está concluído mas o envio ainda está pendente.
   - Trabalhos/vendas vinculados a uma tiragem (`relatedCharges`) também entram na Agenda.
   - Reagendamento mantém o vínculo com o registro correto.
   - A Agenda não fica limitada aos três primeiros itens do dia; exibe todos os agendamentos do dia selecionado.
   - Um espelho automático é reconstruído a partir dos próprios registros para recuperar a Agenda mesmo se o espelho antigo de armazenamento tiver sido perdido.
   - As notificações continuam usando esse espelho automático.
   - A ação de iniciar atendimento continua abrindo o atendimento diretamente, sem mandar a usuária para a Agenda.

2. **Tela branca / inicialização**
   - `getSession()` agora possui tratamento de erro e timeout de 8 segundos.
   - A sincronização inicial do Supabase possui timeout de 12 segundos.
   - Se o Supabase estiver indisponível, o aplicativo segue com os dados locais em vez de ficar preso na inicialização.
   - A inicialização local normaliza dados antigos/malformados de clientes, Agenda, estoque e inventário.
   - O login continua preservado.

3. **Exclusão de serviços**
   - Trabalhos, vendas e consultas podem ser excluídos pela Central de Serviços.
   - A exclusão de uma consulta remove seus efeitos financeiros, desfalques e agenda.
   - A exclusão de um trabalho executado devolve materiais novos ao estoque e remove movimentos/execução vinculados.
   - A exclusão de trabalho/venda vinculados a uma tiragem também remove o registro vinculado e seus efeitos específicos.
   - A tela de detalhes não exige abrir o checkout para excluir.

4. **Desfalque automático pelo checkout**
   - Perguntas marcadas no fechamento como `⚠ Grátis → desfalque` ou `⚠ Desfalque · não cobrado` geram o desfalque automaticamente.
   - O valor usado é o valor potencial da própria pergunta.
   - Benefício de trabalho e cortesia extra permanecem separados e não geram desfalque automaticamente.
   - O desfalque passa para histórico, serviços e relatórios através do registro central.
   - A opção de registrar desfalque manual continua disponível apenas como ferramenta administrativa, não como etapa normal do checkout.

5. **Parcelas com pagamento parcial**
   - Cada parcela possui valor total, recebido acumulado, restante e histórico de pagamentos.
   - `Receber valor` abre uma janela própria, sem retornar ao checkout.
   - É possível informar quanto entrou e a forma de recebimento.
   - A parcela fica como `Pago parcialmente` enquanto houver saldo.
   - Ao completar o valor, passa automaticamente para `Paga`.
   - Cada recebimento parcial entra no financeiro sem duplicar recebimentos anteriores.

6. **Objetos/material de trabalhos**
   - As caixas de “cliente enviou algo” e “eu enviei algo” são clicáveis de forma confiável.
   - O registro abre imediatamente sua janela própria.
   - Objeto recebido pode armazenar endereço, código postal e país.
   - Se houver endereço cadastrado no contato, ele é preenchido automaticamente.
   - O objeto enviado continua sendo apenas um registro ligado ao trabalho; não cria uma venda/cobrança separada.

7. **Consulentes: CPF e endereço**
   - Cadastro/edição agora possui CPF/documento.
   - Endereço estruturado: rua, número, complemento, bairro/região, cidade, estado/província, CEP/código postal e país.
   - Aceita códigos postais internacionais sem obrigar formato brasileiro.
   - O endereço aparece no histórico do consulente.
   - Trabalho/venda/orçamento usam o endereço cadastrado como preenchimento automático quando aplicável.

8. **Inventário no menu sanduíche**
   - Novo item `Inventário` no menu.
   - Separado do estoque de consumo.
   - Cadastro de nome, descrição, foto e valor de referência.
   - Estado: Novo, Usado, Bom, Ruim, Quebrado, Tem que substituir.
   - Edição, exclusão e lixeira.
   - Não altera automaticamente o estoque de consumo.

9. **Áudios**
   - Player visual unificado nos locais de áudio já existentes.
   - Play/pausa, barra de progresso e controle de velocidade (1x, 1,5x, 2x, 0,75x).
   - O áudio pode ser ouvido depois de salvo e continua sendo exibido no histórico/ficha.
   - Gravação continua com pausa/retomada e finalização separada.

10. **Nomes quebrando letra por letra**
    - Proteções globais de largura mínima e quebra de linha foram adicionadas aos cards, clientes, Agenda, histórico e listas.
    - `writing-mode`, `word-break` e `white-space` conflitantes foram neutralizados nos elementos de nome.
    - O objetivo é impedir definitivamente o comportamento visto na captura em que nomes apareciam uma letra por linha.

11. **Fotos**
    - As miniaturas da Galeria no novo atendimento permanecem implementadas.
    - Fotos da câmera e da galeria aparecem no mesmo painel.
    - Miniaturas podem ser abertas e removidas antes de salvar quando o fluxo permite.

## Validação realizada

- O `src/App.tsx`, `main.tsx`, `supabase.ts`, `supabaseSync.ts` e `AppErrorBoundary.tsx` foram submetidos ao compilador TypeScript em modo de transpile para verificar a sintaxe TS/TSX; todos passaram sem diagnóstico de erro de sintaxe.
- O build completo com Vite/TypeScript não pôde ser executado porque o ambiente de trabalho não conseguiu concluir a instalação das dependências npm dentro do tempo disponível. Portanto, esta entrega **não afirma que um APK foi compilado aqui**.
- A V82 contém uma proteção adicional para impedir que falhas/timeout de Supabase deixem a aplicação presa em branco.

## Observação importante

A V82 preserva o funcionamento da base V81 e aplica as correções solicitadas nesta rodada. Não foi feita uma migração para uma versão antiga como V69.
