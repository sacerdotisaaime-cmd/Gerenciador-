# Gestão Sacerdotisa Aime — V8

## Correção focada em Contatos e Microfone

A V8 mantém as funções da V7 e corrige a arquitetura de permissões Android:

- **Contatos:** não usa mais a ponte nativa personalizada para solicitar a permissão. O `@capacitor-community/contacts` faz a solicitação de `READ_CONTACTS` no próprio `pickContact()`, conforme a API do plugin.
- **Microfone:** usa diretamente `VoiceRecorder.requestAudioRecordingPermission()` antes de `startRecording()`, que é a API de permissão do `capacitor-voice-recorder`.
- A ponte nativa `PermissionBridge` foi reduzida a diagnóstico e abertura das configurações do aplicativo, evitando que um erro da ponte seja apresentado falsamente como "permissão negada".
- `MainActivity` agora registra a ponte nativa **antes** de `super.onCreate()`, corrigindo a ordem de inicialização do plugin.
- O AndroidManifest continua garantindo `READ_CONTACTS`, `WRITE_CONTACTS`, `CAMERA` e `RECORD_AUDIO`.
- O tratamento de contatos diferencia permissão negada de cancelamento da seleção.
- O tratamento do microfone diferencia falta de autorização de erro real de gravação.

## Como testar

1. Gere o APK pela GitHub Actions.
2. Para o primeiro teste da V8, prefira desinstalar a V7 antes de instalar a V8 **se você puder perder os dados locais**. O aplicativo ainda usa localStorage.
3. Abra a V8.
4. Entre em **Nova tiragem** e teste **Importar contato**. Em uma instalação limpa, o Android deve apresentar a solicitação de Contatos quando o picker for chamado.
5. Teste **Gravar áudio**. A V8 chama explicitamente a API nativa de solicitação de microfone antes de iniciar a gravação.
6. Se alguma permissão já estiver negada no Android, o aplicativo direciona para as configurações do próprio aplicativo em vez de afirmar que a ponte de permissão falhou.

## Observação

Esta versão foi corrigida e validada estaticamente no código-fonte e no workflow. O APK final precisa ser gerado no GitHub Actions e instalado em um aparelho Android para validar o diálogo nativo de permissão em tempo de execução.
