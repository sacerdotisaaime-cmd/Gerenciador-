# V9 — validação real de permissões Android

Esta versão corrige o fluxo de permissões de Contatos e Microfone em duas camadas:

1. O plugin nativo PermissionBridge declara READ_CONTACTS, WRITE_CONTACTS e RECORD_AUDIO com aliases do Capacitor 7 e solicita a permissão em runtime antes de abrir contatos ou iniciar gravação.
2. O GitHub Actions executa `cap sync` antes de alterar o AndroidManifest, valida o Manifest antes do Gradle e valida novamente o APK final com `aapt dump permissions`. Se alguma permissão estiver ausente do APK, o build falha em vez de entregar um APK inválido.

Permissões esperadas no APK final: READ_CONTACTS, WRITE_CONTACTS, RECORD_AUDIO e CAMERA.

O workflow também registra PermissionBridge antes de `super.onCreate()`.
