# V99 — layout e identificação da consulente

Base: V98.

## Correções
- Acompanhamento de parcelas agora usa a foto real da consulente via `ClientIdentity`, em vez do avatar fixo.
- Nome da consulente protegido contra quebra letra por letra; em espaços estreitos usa reticências, mantendo a leitura horizontal.
- Atendimentos em standby não repetem o nome da consulente: o nome fica na identificação e o bloco abaixo mostra apenas título/status.
- Ações de standby no celular passam para uma segunda linha quando necessário, evitando espremer o nome.
- Visão Geral do Mês foi reduzida aos três indicadores principais: Agendamentos, Atendimentos e Trabalhos.
- Vendas, Contas e Parcelas foram removidas dessa visão para evitar duplicação com os blocos próprios do Dashboard.
- A Visão Geral do Mês foi movida para depois de “O que merece atenção primeiro”.
- O áudio e o restante da base V98 foram preservados.
