# Gestão Sacerdotista Aimê — V73

Base: V72 funcional.

## Correções desta versão

- Menu sanduíche agora fica acima da barra inferior e possui área segura/rolagem até o fim.
- Itens finais do menu, incluindo Agenda e Configurações, não ficam escondidos pela navegação inferior.
- Limpeza e testes: cada módulo agora tem checkbox de seleção.
- Novo botão **Resetar selecionados** permite limpar vários módulos de uma vez.
- Mantidos os botões de reset individual e **Resetar tudo**.
- Reset múltiplo aplica somente os módulos marcados e preserva os demais dados.
- Em **Trabalhos e vendas**, atendimentos em standby não entram mais na fila operacional.
- Atendimentos mostrados nessa fila precisam estar realmente agendados.
- Ajuste da área de ações para evitar botões cortados/ocultos.
- Fotos das consulentes aparecem nos cards operacionais quando disponíveis.
- Foto pode ser tocada para abrir modal ampliado.
- Modal ampliado da foto oferece **Editar foto**, usando o cadastro existente da consulente para câmera/galeria.
- Standbys também exibem a foto quando disponível.
- Próximos agendamentos exibem foto/nome da consulente quando vinculados.
- Compromissos vinculados a consulentes exibem nome + foto + assunto.
- A categoria **Família** foi retirada da Agenda principal.
- Agendamentos pessoais/familiares ficam na Organização.
- Organização → Agenda ganhou abas **Rotinas** e **Agendamentos**.
- Organização → Agendamentos permite criar, listar e editar compromissos pessoais/familiares.
- Agendamentos antigos classificados como Família continuam preservados e passam a ser exibidos na Organização.
- Agenda principal permanece voltada a Trabalho/Atendimentos e Contas.

## Verificação

- Transpilação TypeScript/TSX com TypeScript 5.8.3: OK para App.tsx, main.tsx, supabase.ts e supabaseSync.ts.
- O projeto não possui node_modules localmente; `npm ci` foi iniciado, mas excedeu o limite de execução. Portanto, **não foi declarado build Vite/APK concluído**.
- A V72 original foi preservada separadamente antes das alterações.
