# V50 — Gestão Sacerdotisa Aimê

Base: V49. Esta versão implementa as correções solicitadas após os testes da V49.

## Reset / testes
- Reset por área com limpeza local e do snapshot `app_snapshots` do Supabase.
- Reset geral usa todas as chaves persistidas pelo aplicativo, preserva login/Auth e limpa notificações nativas agendadas.
- Limpeza financeira por Casa/Trabalho preserva a outra área e corrige o filtro de compras/contas/contas recorrentes.
- O reset escreve estados vazios no armazenamento local antes do reload para impedir que efeitos antigos repopulem os dados.

## Perguntas e pacotes
- Pacotes passam a ser distribuídos individualmente entre as perguntas. Ex.: pacote de 4 por €20 = €5 por pergunta.
- Cada pergunta do pacote tem seu próprio valor e participa individualmente do checkout.
- O preço individual pode continuar sendo alterado na ficha da pergunta e no checkout.
- Configurações mostram o valor total do pacote e o valor unitário calculado.
- Histórico e Central de Serviços exibem etiqueta de composição, como `Pacote 4 perguntas + 2 extras` ou `4 perguntas individuais`.
- Dados antigos com o modelo em que apenas a primeira pergunta carregava o valor do pacote são migrados para valores individuais na hidratação.

## Central de Serviços
- Trabalhos, vendas, tiragens e orçamentos ficam centralizados por tipo.
- Trabalhos começam filtrados por `Aguardando execução`.
- Busca por consulente/serviço.
- Filtros por status e pagamentos.
- Ordenação por mais recentes ou mais antigos.
- Trabalhos mostram consulente, descrição, agenda, valor e situação e abrem detalhe para executar, iniciar, prorrogar/reagendar e cancelar.
- Vendas, tiragens e orçamentos também podem ser abertos diretamente pela central.

## Validação
- `tsc --noEmit --skipLibCheck` passou sem diagnósticos.
- `npm ci` foi tentado neste ambiente, mas excedeu o limite de execução; o build Android completo deve ser validado pelo GitHub Actions.

## Persistência
Nenhuma tabela nova do Supabase foi criada. Os dados continuam no `app_snapshots` existente. As operações de reset respeitam a necessidade de apagar os dados do snapshot visíveis ao usuário autenticado; políticas RLS do Supabase continuam sendo aplicadas.
