# Gestão Sacerdotista Aimê — V70

V70 é uma correção incremental sobre V69, preservando o projeto completo.

Foco desta versão: corrigir a abertura de janelas de cadastro rápido (`Novo tipo de trabalho`, `Novo item para venda` e cadastros semelhantes) quando chamadas de dentro de outra janela.

A janela filha agora recebe uma camada superior explícita e o fluxo de retorno mantém a janela pai aberta.
