# V121 — Termos, consentimento e comprovantes no Trabalho

Implementação adicionada ao fluxo de Novo Trabalho:

- Cliente foi informado sobre os termos e condições.
- Cliente consentiu com os termos e condições.
- Cada confirmação possui seus próprios comprovantes.
- Fotos, prints e áudios podem ser adicionados da câmera, galeria/arquivo ou Caixa de Mídias.
- A Caixa de Mídias permite reutilizar mídias recebidas do WhatsApp sem precisar importar novamente do aparelho.
- Os registros e seus documentos ficam vinculados ao trabalho.
- O Histórico do consulente mostra as duas confirmações e permite expandir os comprovantes.
- A Central de Serviços → Trabalhos mostra badges de Informado e Consentido e o detalhe completo preserva os documentos.
- Os novos campos fazem parte do próprio registro da consulta/trabalho, portanto acompanham o snapshot existente de dados.

A versão preserva a infraestrutura V120 de compartilhamento/recepção de áudio e foto.
