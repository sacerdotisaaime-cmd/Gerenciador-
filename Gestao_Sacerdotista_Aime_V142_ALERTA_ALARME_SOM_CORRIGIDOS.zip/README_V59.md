# Gestão Sacerdotista Aimê — V59

## Correções V59
- Respeito à safe-area superior e inferior do Android para evitar que a barra de status/relógio fique sobre o conteúdo.
- Data e hora do aplicativo exibidas nas barras superiores e nos cabeçalhos das janelas principais.
- Rolagem centralizada dos modais: conteúdo rolável, cabeçalho fixo, espaço extra no final e `touch-action: pan-y`.
- Ajuste do limite de altura dos modais considerando a área segura superior.
- Nenhuma alteração deliberada em login, autenticação, Supabase ou regras de negócio.

Base: V58 corrigida.
