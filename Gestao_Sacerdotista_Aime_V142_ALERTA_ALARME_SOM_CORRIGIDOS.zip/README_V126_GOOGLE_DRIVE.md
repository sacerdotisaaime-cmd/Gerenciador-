# V126 — Backup Mestre + Google Drive

Esta versão adiciona a primeira integração real do Backup Mestre com o Google Drive.

## Google OAuth
- Cliente OAuth Android configurado para `com.sacerdotisaaime.gestao`.
- Usa o fluxo oficial Google Identity `AuthorizationClient`.
- Solicita somente `drive.file`, escopo não restrito e limitado aos arquivos criados pelo aplicativo.

## Drive
- Cria automaticamente a pasta `Gestão Sacerdotista Aimê` e a subpasta `Backups` no Meu Drive.
- Envia o ZIP do Backup Mestre por upload retomável (resumable).
- Valida o arquivo enviado consultando o tamanho e a pasta de destino antes de considerar o backup concluído.
- Mantém no máximo 5 backups do aplicativo na pasta do Drive; o novo arquivo é validado antes da rotação.
- O backup local continua sendo mantido independentemente do Drive.

## Teste
1. Instale o APK release assinado pelo mesmo keystore usado para o cliente OAuth.
2. Abra Configurações → Backup.
3. Toque em `Conectar Google Drive` e autorize a conta.
4. Toque em `Criar e enviar backup`.
5. Confirme no Google Drive a pasta `Gestão Sacerdotista Aimê/Backups`.

## Limitação desta etapa
A geração do ZIP ainda parte do estado local do WebView. A automação diária totalmente independente da abertura do aplicativo e a inclusão de arquivos binários externos que não estejam referenciados no estado local serão tratadas na próxima etapa da arquitetura. O envio ao Drive e a rotação de 5 arquivos já são reais nesta versão.
