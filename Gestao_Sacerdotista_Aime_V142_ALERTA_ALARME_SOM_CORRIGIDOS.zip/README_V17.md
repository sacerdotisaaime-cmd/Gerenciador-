# Gestão Sacerdotisa Aimê — V17

Correções desta versão:

- Corrige a conversão de moedas estrangeiras: a API usada com `base=BRL` retorna BRL→moeda, então a aplicação agora inverte a cotação para guardar e calcular corretamente quanto vale 1 EUR/USD/GBP em BRL.
- A tela de configuração de taxas PayPal/Wise/Outras fica exclusivamente dentro de Configurações; não é mais renderizada no final de todas as abas.
- Histórico dos consulentes ganhou busca visível.
- O histórico exibe fotos das perguntas como miniaturas clicáveis, abrindo foto em modal.
- Modal da foto no histórico permite reproduzir os áudios vinculados àquela foto.
- Áudios de observação das perguntas também podem ser reproduzidos no histórico.
- Ao salvar uma gravação, a consulta completa é persistida imediatamente no localStorage e sincronizada com o snapshot do Supabase após a atualização, reduzindo o risco de o áudio desaparecer ao encerrar ou recarregar o app.
- Financeiro > Valores a receber mostra, para cobranças estrangeiras, a moeda original e o equivalente em reais.
- Busca do registro do dia passa a considerar também consulente, telefone e país nos atendimentos.
- Detecção de país pelo DDI foi ajustada para priorizar códigos internacionais antes do fallback de números brasileiros sem +55.

## Conversão

`currencyRate` agora significa **BRL por 1 unidade da moeda estrangeira**. Exemplo: se 1 EUR = R$ 6,20, €20 = R$124,00.
