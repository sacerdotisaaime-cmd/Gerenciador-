# Gestão Sacerdotista Aimê — V119

## Caixa de Mídias — WhatsApp, fotos e áudios

Base: V118.

### Correções

- Compartilhamento Android usa `singleTask` e `onNewIntent()` para reutilizar a instância já aberta do aplicativo.
- `MainActivity` encaminha o Intent para `PermissionBridgePlugin.handleSharedIntent()`.
- Recebe `ACTION_SEND`, `ACTION_SEND_MULTIPLE`, `EXTRA_STREAM` e `ClipData`.
- Recebe áudio, imagem e MIME genérico `*/*`, validando o conteúdo antes de guardar.
- Ao receber uma mídia, o Android copia primeiro para a Caixa de Mídias nativa.
- Se o aplicativo foi aberto pelo Compartilhar, a Caixa de Mídias é aberta automaticamente.
- Se já havia um atendimento aberto, a mesma instância é reutilizada e a mídia aparece na Caixa.
- A mídia pode ser importada diretamente para o atendimento, sem exigir uma pergunta aberta.
- Quando existe pergunta atual, continuam disponíveis as opções de importar para a pergunta e, para áudio, vincular à foto selecionada.
- A mídia permanece na Caixa até o encerramento do atendimento; a cópia vinculada ao histórico não é apagada.
- O fluxo manual por arquivo continua disponível apenas como alternativa.
- Versionamento atualizado para `versionName 1.19.0` e `versionCode 119`.
- O workflow de release valida `singleTask`, filtros de compartilhamento e assinatura antes de publicar o APK.

### Fluxo esperado

`WhatsApp → Compartilhar → Gestão Sacerdotista Aimê → Caixa de Mídias → Importar para este atendimento`

Sem atendimento aberto, a mídia fica aguardando na Caixa.

### Atualização

A V119 usa a mesma keystore configurada nos Secrets do GitHub para permitir atualização sobre a versão instalada, desde que o repositório mantenha a mesma assinatura.
