# Gestão Sacerdotisa Aimê — V10

V10 mantém as correções de permissões da V9 e adiciona:

- áudio vinculado individualmente a cada foto de uma pergunta;
- botão de gravar áudio em cada foto;
- lista de áudios de cada foto com ouvir, cortar, compartilhar e excluir;
- áudios gerais da pergunta renomeados para Áudios de observação;
- migração automática de fotos antigas sem campo de áudios;
- importação de contatos compatível com o formato `name.display` e `phones[].number` usado pelo plugin de contatos 7.x;
- uso de `projection: { name: true, phones: true }` na seleção de contato;
- preenchimento automático de nome e telefone no formulário de Novo consulente antes de salvar.

O workflow também deve apontar explicitamente para este ZIP V10 e manter a validação das permissões no Manifest e no APK final.
