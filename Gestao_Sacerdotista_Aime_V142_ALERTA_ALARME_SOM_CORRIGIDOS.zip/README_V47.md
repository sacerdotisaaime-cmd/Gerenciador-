# Gestão Sacerdotisa Aimê — V47

## Correção desta versão

A V46 falhou no Vite durante a transformação de `src/App.tsx`, com erro de sintaxe JSX/TSX próximo ao bloco de configuração das rotinas recorrentes.

A V47 corrige esse ponto sem alterar a lógica de login/Supabase ou a arquitetura funcional da V46.

### Correção aplicada
- extraída a ação de ativar/desativar uma rotina recorrente para `toggleRoutineTemplate`;
- simplificado o `map()` JSX que renderiza as rotinas configuradas;
- removida a expressão JSX aninhada que estava causando o erro de transformação;
- TypeScript/transpilação TSX verificados sem diagnósticos.

## Observação
O build completo depende da instalação das dependências do projeto. No ambiente de preparação, `npm ci` excedeu o tempo disponível; portanto a versão não é apresentada como APK já compilado aqui.
