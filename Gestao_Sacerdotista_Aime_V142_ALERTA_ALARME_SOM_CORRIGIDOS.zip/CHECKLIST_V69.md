# Gestão Sacerdotista Aimê — V69

Base: V68 corrigida sobre o projeto completo V65. Esta versão incorpora os problemas encontrados ao testar a V68 e preserva a arquitetura Capacitor + Supabase snapshot.

## Checklist completo

| # | Item | V69 | Verificação no código |
|---|---|---|---|
| 1 | Recebimento duplicado (ex.: R$20 virar R$40) | ✅ | Cálculo financeiro evita somar novamente perguntas quando o checkout já possui plano de pagamento do atendimento. |
| 2 | Importar áudio do WhatsApp/aparelho para foto da carta | ✅ | Seletor `audio/*` com múltiplos arquivos e vínculo à foto. |
| 3 | Foto de perfil da consulente | ✅ | Câmera/galeria, armazenamento em `avatarPhoto`, avatar renderizado na lista e abertura ampliada. |
| 4 | Modal secundário ficar atrás do modal atual | ✅ V69 reforçado | Portal + pilha real de z-index por instância; cada modal novo fica acima do anterior. |
| 5 | Data errada nos próximos agendamentos | ✅ | Dashboard usa `agendaItems`/agendamentos reais e ordena por data + hora. |
| 6 | Editar compromisso | ✅ | Agenda mantém `agendaEditingId` e salva data, hora, título, descrição, categoria e cliente. |
| 7 | Cobrança mostrar apenas uma parcela | ✅ | Detalhe financeiro percorre todas as parcelas do plano. |
| 8 | Histórico “Tudo que foi feito no dia” | ✅ V69 reforçado | Tela `daily`, filtro por data, pesquisa e filtros por tipo; também foi adicionada ao menu lateral. |
| 9 | Valor do trabalho não editável | ✅ | “Editar valor do trabalho” abre edição do atendimento e recalcula o plano sem criar novo recebimento. |
| 10 | Pausar áudio | ✅ V69 reforçado | Timer para ao pausar; `pauseRecording()` é confirmado com `getCurrentStatus()` e só então a UI entra em pausado. |
| 11 | Compartilhar foto + áudio | ✅ | Compartilhamento nativo usa arquivos reais da foto e de todos os áudios vinculados. |
| 12 | Leitura pré-trabalho | ✅ | Checkbox, escolha do trabalho, vínculo no atendimento/histórico e abertura de orçamento vinculado. |
| 13 | Cabeçalho da Home espremido | ✅ | Data/hora ficam no cabeçalho principal e não nos atalhos superiores. |
| 14 | Foto salva da consulente não aparecia no card | ✅ V69 | O círculo da lista agora mostra `client.avatarPhoto`; sem foto, mostra a inicial. Toque abre a foto. |
| 15 | Histórico do dia não aparecia no menu + filtros | ✅ V69 | Novo item “Histórico do dia” no menu, seletor de data, pesquisa e filtros de atividade. |
| 16 | Data duplicada no cabeçalho | ✅ V69 | Removida a linha numérica duplicada; fica somente “19 DE SETEMBRO DE 2026 · 05:34”. |
| 17 | Modais aninhados não abrem imediatamente | ✅ V69 | Sistema de modais com portal + z-index por instância; vale para tipo de trabalho, produto/venda e outros cadastros secundários. |
| 18 | Pausar áudio visualmente, mas continuar gravando | ✅ V69 reforçado | A pausa só é confirmada quando o plugin reporta `PAUSED`; o contador também para durante a pausa. Retomar volta para `RECORDING` no mesmo áudio. |

## Histórico do dia — comportamento

- Navegação por qualquer data.
- Pesquisa por texto em título, consulente, descrição e detalhes.
- Filtros para atendimentos, trabalhos, vendas, orçamentos, entradas, saídas, compras, contas, estoque e agenda.
- Inclui trabalhos/vendas vinculados registrados em `relatedCharges`.
- Ordenação cronológica pela data/hora do registro.

## Verificação técnica

- Todos os arquivos `.ts`/`.tsx` de `src/` passaram por transpile TypeScript (`transpileModule`) sem diagnóstico de sintaxe.
- O `tsc -p tsconfig.app.json --noEmit` não pôde completar porque as dependências de `node_modules` não estão instaladas neste ambiente (`vite/client` ausente).
- Portanto, esta versão foi validada por transpile/sintaxe e inspeção estrutural, mas o build final do APK deve ser confirmado pelo GitHub Actions com `npm ci` + `npm run build`.

## Base preservada

- Login/Auth.
- Supabase snapshot sync.
- Capacitor.
- Dados e módulos existentes.
- Não foi criado um segundo aplicativo.
