# V74 — Correção focada em consulentes, filas operacionais e navegação

Esta versão é derivada diretamente da V73. O foco foi corrigir a identificação visual das consulentes e preservar os módulos existentes.

### Principais mudanças
- Componente centralizado `ClientIdentity` para foto redonda + nome.
- Fallback por nome quando o ID não está disponível no registro exibido.
- Modal de foto aberto exclusivamente pelo toque na foto.
- Editar foto continua levando ao cadastro da consulente para câmera/galeria.
- Standbys não entram nas filas de Trabalhos e Vendas nem nos próximos agendamentos.
- Botões operacionais com tamanho natural.
- Menu lateral em portal acima da barra inferior.
- Reset seletivo da V73 preservado.

Não foi feita afirmação de APK compilado nesta versão sem execução do build Android.
