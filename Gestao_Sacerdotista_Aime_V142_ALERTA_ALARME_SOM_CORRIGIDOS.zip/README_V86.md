# Gestão Sacerdotista Aimê — V86

Correções focadas exclusivamente em áudio e objetos/materiais de trabalhos.

- Gravação: usa `VoiceRecorder.requestAudioRecordingPermission()` para a permissão nativa e tenta `MediaRecorder` após a permissão, com fallback para `VoiceRecorder` nativo.
- Gravação: modal central com gravar/pausar/retomar/finalizar e prévia de áudio durante a pausa quando o navegador disponibiliza os dados parciais.
- Objetos: endereço da consulente pertence ao fluxo **Eu enviei alguma coisa para a cliente**; o fluxo **A cliente enviou algo para o trabalho** não preenche endereço.
- Aplicado aos contextos de trabalho criado na tiragem, novo trabalho e trabalho relacionado ao checkout/orçamento.
- Agenda não foi alterada nesta versão.
