# Gestão Sacerdotista Aimê — V92 · Áudio e Registro Visual

Correção focada no fluxo de fotos e áudios dentro de uma pergunta do atendimento.

## Alterações

- Registro Visual separado em funções independentes:
  - 📷 Tirar foto
  - 🎙️ Gravar áudio
  - 🖼️ Galeria
  - 🎵 Importar áudio
- O cartão inteiro não funciona como botão de áudio.
- O botão **Gravar áudio** apenas abre o modal; o microfone só inicia ao tocar em **Iniciar gravação**.
- O modal permanece aberto durante o ciclo da gravação.
- Ao finalizar a gravação, o áudio é **salvo automaticamente**, sem uma segunda etapa obrigatória de salvar.
- Após salvar, o modal mostra os áudios já salvos e permite **Gravar mais áudio**.
- Os áudios gravados/importados ficam vinculados à pergunta e, portanto, acompanham o atendimento no histórico da consulente.
- Cada áudio possui reprodução e **Compartilhar áudio** individual.
- Cada foto possui miniatura, abertura individual e **Compartilhar foto** individual.
- Ao fechar/encerrar o atendimento, um modal de áudio pendente não deve reaparecer depois.
- A importação de áudio também grava diretamente no registro da pergunta/histórico.
- O fluxo antigo de gravar/importar áudio diretamente dentro do cartão da foto foi removido da área principal; fotos e áudios passam a ser registros independentes.

## Verificação

Foi feita verificação TypeScript com o arquivo de configuração de sintaxe do projeto. O projeto já possuía erros de tipagem anteriores em outros pontos (por exemplo, Purchase/PayableAccount, CSSProperties/ErrorInfo e configuração de import do main.tsx); nenhum erro novo foi introduzido nas alterações de áudio/registro visual após a correção.

O build completo não foi executado neste ambiente porque a instalação das dependências (`npm ci`) não terminou dentro do limite de execução disponível.
