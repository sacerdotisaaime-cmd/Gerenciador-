# V48 — correções de consulta, vendas, agenda, notificações e usabilidade

Base: V47.

## Correções
- Preço configurado para uma tiragem com várias perguntas agora é tratado como preço total do pacote, não multiplicado por pergunta.
- Perguntas do pacote ficam marcadas como incluídas; o valor do pacote entra uma única vez no checkout.
- Venda ganhou fluxo de envio/entrega com tipo de envio, data/hora, endereço, telefone e frete.
- Uber: separado frete cobrado de Uber realmente gasto. O frete cobrado entra na venda; só o gasto efetivo entra como saída financeira.
- Envio agendado cria compromisso na Agenda.
- Trabalhos agendados entram corretamente no aviso de próximos agendamentos, inclusive quando o registro é um trabalho.
- Notificações nativas do Android passam a incluir Agenda, trabalhos e envios, além das rotinas e medicamentos já existentes.
- Modais receberam rolagem interna com proteção contra scroll da tela de fundo, suporte a toque no Android e espaço seguro para botões finais.
- Configurações ganhou atalho visível para Limpar dados para teste.
- Reset de Organização também limpa IDs locais de notificações.

## Persistência
Nenhuma tabela nova do Supabase foi criada. Os novos dados continuam usando o snapshot `app_snapshots` e as chaves existentes do aplicativo.

## Validação
- `src/App.tsx`: transpile JSX/TypeScript sem diagnósticos.
- Build completo com `npm install` não foi concluído no ambiente de desenvolvimento por timeout; o workflow do GitHub Actions continua responsável pelo build Android.
