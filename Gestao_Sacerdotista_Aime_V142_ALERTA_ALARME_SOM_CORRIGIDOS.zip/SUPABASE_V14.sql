-- V14: opcionalmente crie uma tabela relacional para desfalques.
create table if not exists public.desfalques (
  id uuid primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  client_id uuid,
  consultation_id uuid,
  work_id uuid,
  client_name text,
  type text not null,
  description text,
  potential_value numeric not null default 0,
  received_value numeric not null default 0,
  amount numeric not null default 0,
  date timestamptz not null default now(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);
alter table public.desfalques enable row level security;
drop policy if exists "desfalques_select_own" on public.desfalques;
drop policy if exists "desfalques_insert_own" on public.desfalques;
drop policy if exists "desfalques_update_own" on public.desfalques;
drop policy if exists "desfalques_delete_own" on public.desfalques;
create policy "desfalques_select_own" on public.desfalques for select to authenticated using (user_id = auth.uid());
create policy "desfalques_insert_own" on public.desfalques for insert to authenticated with check (user_id = auth.uid());
create policy "desfalques_update_own" on public.desfalques for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "desfalques_delete_own" on public.desfalques for delete to authenticated using (user_id = auth.uid());
grant select, insert, update, delete on public.desfalques to authenticated;
