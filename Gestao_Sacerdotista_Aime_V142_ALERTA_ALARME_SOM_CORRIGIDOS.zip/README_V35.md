# Gestão Sacerdotisa Aimê — V35

V35 é uma refatoração de interface e navegação baseada na V34.

## Interface
- Menu lateral com rolagem própria e área segura do Android.
- Barra inferior compacta e alinhada acima da área nativa do Android.
- Barra inferior: Clientes · Nova · Serviços · Agenda.
- Dashboard redesenhado para cards compactos e seções expansíveis.
- Agendamento rápido na tela inicial.
- Próximos agendamentos aparecem antes dos atendimentos em standby.
- Standby, parcelas, movimentações e estoque ficam compactos e expansíveis.

## Agenda
- Um único botão `＋ Agendar` abre o formulário somente quando necessário.
- O formulário pergunta o tipo de compromisso e só ocupa espaço quando aberto.
- Listas mostram no máximo 3 itens inicialmente.
- Um agendamento pode ser expandido para ver ações como editar/excluir.
- A agenda financeira de consulentes também usa grupos compactos expansíveis.

## Execução de trabalho
- Modal de execução possui rolagem própria.
- Botões Cancelar/Concluir ficam visíveis no rodapé do modal.
- Materiais do estoque podem ser novos ou reutilizados.
- Materiais externos podem ser registrados com quantidade, unidade, custo e nota.
- Nota da execução permanece vinculada ao trabalho.

## Navegação Android
- Usa o plugin `@capacitor/app` para interceptar o botão voltar nativo no APK.
- Dentro do aplicativo, voltar retorna à tela anterior.
- Janelas/formulários abertos pedem confirmação antes de serem fechados.
- Na tela inicial, o primeiro voltar mostra `Pressione voltar novamente para sair`; o segundo encerra o aplicativo.
- Mantém também a navegação por histórico no navegador.

## Preservação
- A estrutura de login/Supabase da linha de trabalho anterior foi preservada.
- O workflow do GitHub instala explicitamente `@capacitor/app` antes do build.

## Validação
- Sintaxe TypeScript/JSX verificada com `tsc` em modo de análise sintática sem resolução de dependências.
- Não foi possível executar `npm install` completo neste ambiente dentro do limite de execução; portanto o build Android completo deve ser validado no GitHub Actions.
