# Gestão Sacerdotista Aimê — V79

## Foco desta versão

### Standby isolado
- Standby é exclusivamente uma sessão iniciada e pausada temporariamente.
- Standby não entra no Histórico do consulente.
- Standby não entra em “Feito hoje / Tudo que foi feito”.
- Standby não alimenta recebimentos/contas a receber do financeiro.
- Standby não é considerado atendimento concluído em relatórios financeiros.
- A barra de Standby permanece visível na tela inicial mesmo quando não há itens.
- Atendimento concluído continua protegido contra conversão para Standby.

### Histórico e Feito hoje
- Histórico de consulente exibe somente atendimentos `completed`.
- Atividades de Standby não aparecem em “Feito hoje”.
- Trabalhos/charges ligados a Standby também não entram no histórico operacional do dia.

### Nova tela inicial
- Remove “Bom dia. Vamos organizar o dia?” e “Resumo rápido do que precisa da sua atenção”.
- Cabeçalho mostra dia da semana, data completa e hora atual.
- Novo card mensal “Visão geral do mês”, com navegação entre meses.
- Mostra contagens de agendamentos, atendimentos, trabalhos, vendas, contas e parcelas.
- Nova área “Prioridades”, ordenada de 1 a 10.
- Agendamentos manuais permitem definir prioridade de 1 a 10.
- A prioridade organiza a área de prioridades sem substituir os blocos operacionais por categoria.

### Persistência
- Prioridade dos agendamentos é armazenada junto ao registro e entra no snapshot existente.
- Versão do projeto: `0.79.0`.

## Verificação

A transpilação TypeScript/TSX dos 5 arquivos de `src` foi executada sem diagnósticos de sintaxe.

O build Android completo não foi executado localmente nesta entrega porque as dependências não estão instaladas no diretório. O workflow do GitHub Actions continua sendo o responsável pelo build Android.
