-- V16: país do consulente, usado para registrar o país informado/detectado pelo DDI.
alter table if exists public.clients
  add column if not exists country text;

-- Mantém RLS existente. Apenas garante que a coluna acompanha os registros do próprio usuário.
-- As políticas de clients da V12/V14 já controlam o acesso por user_id.
