# Gestão Sacerdotista Aimê — V72

## Correção principal
- Corrigido o cadastro rápido quando existe `activeConsultation`.
- O fluxo anterior tinha o botão `openQuickCatalog()` dentro do retorno da tiragem ativa, mas o JSX de `quickCatalogKind` só existia no retorno principal do App.
- Isso fazia o estado mudar sem que a janela fosse montada; ao sair da tiragem, o retorno principal passava a renderizar o cadastro, reproduzindo exatamente o defeito relatado.
- V72 renderiza o cadastro rápido também dentro do retorno da tiragem ativa, usando a camada própria já existente na V72.

## Fluxos cobertos
- Novo trabalho na tiragem → Novo tipo de trabalho.
- Nova venda na tiragem → Novo item para venda.
- Novo atendimento → Novo trabalho/venda → cadastro rápido.
- O cadastro permanece sobre a tela atual e, ao salvar, retorna ao contexto existente.

## Preservação
- Base: V72 completa.
- Não houve remoção dos módulos ou alterações no Supabase.
- Não foi usado código das versões antigas/stripadas.

## Validação
- Transpile de todos os TS/TSX será verificado.
- ZIP será testado com `unzip -t`.
- APK Android não é executado fisicamente neste ambiente.
