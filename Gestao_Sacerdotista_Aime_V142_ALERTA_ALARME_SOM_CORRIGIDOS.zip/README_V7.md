# Gestão Sacerdotisa Aime — V7

## Correções desta versão
- Tela **O que foi feito no dia** agora mostra **Editar** e **Excluir** nos registros editáveis.
- Atendimento: edição de título/o que foi feito, valor, observações e status/data de pagamento.
- Edição de atendimento preserva perguntas, fotos e áudios.
- Compra e compromisso da agenda podem ser editados diretamente a partir da atividade do dia.
- Exclusão de atendimento, compra, compromisso e orçamento pela atividade do dia, com confirmação quando aplicável.
- Mantida a ponte nativa Android para permissões de **Contatos** e **Microfone**.

## Importante sobre Contatos e Microfone
O Android controla as permissões. Se uma versão anterior do aplicativo já teve Contatos/Microfone negados várias vezes, o Android pode não mostrar novamente a janela de autorização. Nesse caso, o aplicativo abre as configurações do próprio aplicativo para permitir manualmente.

Para um teste totalmente limpo, desinstale a versão antiga antes de instalar o APK novo. Atenção: este aplicativo usa localStorage; desinstalar o aplicativo pode apagar os dados locais salvos nele.

Se quiser preservar os dados, primeiro tente:
Configurações do Android → Aplicativos → Gestão Sacerdotisa Aime → Permissões → permita Contatos e Microfone.
