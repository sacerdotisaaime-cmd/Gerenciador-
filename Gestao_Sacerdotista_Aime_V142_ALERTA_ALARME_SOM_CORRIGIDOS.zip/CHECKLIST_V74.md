# Gestão Sacerdotista Aimê — V74

## Base
- V74 parte integralmente da V73.
- Nenhum reset/reinstalação de Supabase foi necessário para a correção.

## Correções focais
1. Identificação visual padronizada da consulente com foto redonda + nome.
2. Busca da consulente por `clientId` e fallback seguro por nome normalizado, evitando cards sem foto quando o registro tem nome mas o ID não chegou naquele ponto.
3. Foto redonda é clicável; somente o toque na foto abre o modal ampliado.
4. Modal da foto mantém foto grande, Editar foto e Fechar.
5. A foto ampliada não é aberta por Iniciar atendimento/Executar trabalho ou outras ações.
6. Fotos/nome aplicados nos próximos agendamentos, trabalhos/vendas, standby, central de serviços, detalhes de serviço e execução.
7. Standby excluído das filas operacionais de Trabalhos e Vendas e dos próximos agendamentos.
8. Botões de ação dos cards operacionais deixam de crescer até ocupar o card inteiro.
9. Menu sanduíche é renderizado via portal no `document.body`, ficando acima da barra inferior e com rolagem independente.
10. Mantidos os recursos de reset seletivo/individual/geral existentes na V73.

## Verificação
- Verificação estática dos trechos alterados.
- Conferir transpile/build no ambiente com dependências instaladas e validar no Android/GitHub Actions antes de afirmar APK compilado.
