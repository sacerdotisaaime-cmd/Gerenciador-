# V133 — Mudar local de mídias

Esta versão parte da V132 e acrescenta a função **⇄ Mudar de lugar** diretamente nos cards de fotos e áudios.

## Comportamento
- Cada foto/áudio importado para a pergunta, ficha da consulente ou informações recebidas passa a ter um botão **Mudar de lugar**.
- Ao tocar, abre uma janela com os destinos disponíveis.
- A operação é de **transferência**, não duplicação: a mídia é removida do local anterior e salva no novo destino.
- A cópia da mídia continua na **Caixa de Mídias** como arquivo de segurança/histórico da importação.
- Destinos: pergunta atual, ficha da consulente e informações recebidas.
- O recurso funciona para fotos e áudios.
- O compartilhamento em conjunto da V132 permanece preservado.

## Observação de build
O código-fonte foi atualizado e o ZIP foi gerado. O ambiente desta sessão não tinha as dependências Node instaladas para executar uma compilação completa local do projeto. O APK deve ser gerado pelo fluxo de build já utilizado no projeto.
