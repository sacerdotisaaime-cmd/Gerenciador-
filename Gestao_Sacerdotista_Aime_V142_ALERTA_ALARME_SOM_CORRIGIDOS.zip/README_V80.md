# Gestão Sacerdotista Aimê — V80

V80 parte diretamente da V79 e concentra correções de ciclo de vida do atendimento, segurança financeira e melhorias no registro de respostas das consulentes.

## Principais correções
- Standby é temporário e isolado: não entra em Histórico, Feito hoje ou financeiro como concluído.
- Bloqueio de segunda execução de trabalho já concluído para evitar duplicação.
- Deduplicação dos lançamentos financeiros espelho de parcelas recebidas.
- Modal de edição de Informações Recebidas renderizado também dentro do atendimento ativo.
- Nova seção expansível de Resposta da consulente por pergunta, com texto, fotos e áudios.
- Correção de quebra de nomes em cards operacionais.
- Persistência da prioridade 1–10 dos agendamentos.

A V80 preserva as correções anteriores da V79 e o projeto completo de Capacitor/Vite/Supabase.
