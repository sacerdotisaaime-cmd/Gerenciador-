# Gestão Sacerdotista Aimê — V71

Correção V71: cadastro rápido (Novo tipo de trabalho / Novo item para venda) agora usa uma camada própria de interface, fora da pilha de Modal aninhados. O modal pai permanece preservado e o cadastro rápido deve aparecer imediatamente na frente.

Base: V70 completa. Nenhum módulo funcional foi removido.

Validação: todos os arquivos TS/TSX são transpilados com TypeScript sem erro sintático; APK Android não foi executado neste ambiente.
