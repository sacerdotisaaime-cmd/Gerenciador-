# Gestão Sacerdotista Aimê — V52

## Correções desta versão

- Corrige o erro `formatForeign is not defined` que podia aparecer ao abrir o histórico de alguns consulentes.
- Histórico do consulente passa a ter botão **🔎 Ver ficha completa**.
- Ficha completa reúne informações recebidas, fotos, áudios, perguntas, notas, cobrança por pergunta, parcelamento, trabalho, execução, venda, envio, status e registros vinculados.
- Fotos e áudios das informações recebidas passam a aparecer no histórico.
- Fotos e áudios de cada pergunta/tiragem ficam acessíveis no histórico e na ficha completa.
- Vendas mostram parcelamento, status operacional, confecção e envio quando existentes.
- Trabalhos mostram status, agendamento e dados da execução quando existentes.
- Janelas/modais receberam `className` correto para que as regras de quase tela cheia realmente sejam aplicadas no celular.
- Modais móveis ocupam praticamente toda a altura disponível e mantêm o conteúdo com rolagem interna, evitando botões cortados.

## Validação

`npx tsc --noEmit --skipLibCheck` passou.

O build completo depende da instalação das dependências; neste ambiente `npm ci` atingiu o limite de tempo, então a validação final do Android deve ser feita pelo GitHub Actions.
