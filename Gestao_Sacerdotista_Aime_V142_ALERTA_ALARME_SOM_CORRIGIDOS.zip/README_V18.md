# Gestão Sacerdotisa Aimê — V18

Correções desta versão:

- Corrige o crash/tela branca ao tirar foto: a imagem da câmera é redimensionada e comprimida antes de entrar no estado da aplicação/localStorage.
- Protege as gravações do localStorage contra exceções de quota, evitando que uma foto/áudio grande provoque tela branca.
- Mantém a foto vinculada à pergunta e disponível no histórico.
- Mantém áudio de observação e áudio da foto vinculados à pergunta/histórico.
- Financeiro passa a calcular compras de forma robusta mesmo quando registros antigos não possuem `total` no item: usa quantidade × preço unitário como fallback.
- Financeiro também usa a área do fornecedor como fallback quando uma compra antiga não possui destino no item.
- Contas recorrentes ativas agora aparecem dentro de Financeiro, com total mensal projetado e separação Casa/Trabalho.
- Mantidos os valores reais de compras, contas a pagar, recebimentos, desfalques e demais módulos.

## Foto
A câmera continua usando Capacitor Camera, mas a imagem capturada é comprimida no WebView para aproximadamente 1280px no maior lado antes de ser armazenada. Isso reduz drasticamente o tamanho do Base64 e evita estouro de armazenamento.

## Financeiro
`Compras Casa` e `Compras Trabalho` agora consideram:
1. `item.total`, quando válido e maior que zero;
2. caso contrário, `item.quantity * item.unitPrice`;
3. caso `destination` esteja ausente, usa a área do fornecedor.

Contas recorrentes não são marcadas como contas já pagas: são mostradas como projeção mensal separada.
