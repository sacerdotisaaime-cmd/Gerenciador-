# V128 — Google Drive + Diagnóstico OAuth

Base: V127 corrigida / Backup Mestre V125.

Objetivo desta versão: testar a autorização Google Drive e, se falhar, mostrar no próprio aplicativo código, etapa, mensagem e detalhes técnicos retornados pelo Google Play Services.

Configuração esperada:
- package: com.sacerdotisaaime.gestao
- scope: https://www.googleapis.com/auth/drive.file
- OAuth Android configurado no Google Cloud com o SHA-1 de release.

A versão não exige Client Secret no APK.
