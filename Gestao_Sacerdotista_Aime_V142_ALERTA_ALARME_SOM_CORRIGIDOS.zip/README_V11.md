# Gestão Sacerdotisa Aimê — V11

V11 mantém as funcionalidades da V10 e adiciona:

- Miniaturas de fotos das cartas.
- Clique na miniatura abre foto ampliada em modal.
- Áudio diretamente dentro do modal da foto.
- Vários áudios por foto.
- Observação escrita específica para cada foto.
- Áudios gerais continuam separados como "Áudios de observação".
- Lixeira no menu sanduíche.
- Exclusões de registros principais vão para a lixeira em vez de desaparecerem imediatamente.
- Restauração e exclusão definitiva na lixeira.
- Cliente + histórico e compra + movimentos de estoque são tratados como conjuntos para restauração.
- Fotos são compactadas para aproximadamente 1280 px / JPEG 68% antes do armazenamento local.
- Campos `updatedAt`, `deletedAt` e `note` preparados para a futura sincronização.
- Documento `SUPABASE_ARCHITECTURE_V11.md` com a estrutura completa planejada.
- Workflow genérico: usa o único ZIP do repositório e valida as permissões do APK final.

Ainda não há conexão com Supabase nesta versão. A próxima fase é criar o projeto Supabase, tabelas, Storage, Auth, RLS e a camada de sincronização offline/online.
