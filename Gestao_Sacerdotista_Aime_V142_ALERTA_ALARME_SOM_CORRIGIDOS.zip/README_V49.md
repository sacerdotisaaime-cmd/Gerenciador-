# V49 — Gestão Sacerdotisa Aimê

Base: V48. Esta versão reúne as correções solicitadas no PDF de 18 páginas e a limpeza por áreas para testes.

## Principais correções
- Orçamento com condições de pagamento: pago, pendente ou parcelado, com método, vencimento, entrada e número de parcelas.
- Conversão de orçamento em trabalho preservando condições de pagamento e parcelas. Um orçamento convertido recebe `linkedWorkId` e não pode ser convertido duas vezes.
- Histórico de parcelas pendentes permite alterar vencimento e forma de pagamento.
- Informações recebidas: miniaturas de fotos, abertura ampliada, salvar foto no aparelho/galeria quando permitido e reprodução/exclusão de áudios.
- Modal genérico com rolagem interna independente do fundo e botão de minimizar/reabrir, preservando o estado do formulário.
- Cadastro rápido de trabalhos permanece disponível a partir do atendimento.
- Desfalque passou para modal padrão com data editável.
- Reagendamento de trabalho passou para modal padrão com calendário/data/hora e atualização real da agenda.
- Estoque Casa/Trabalho com editar, excluir e consumo em modal padrão.
- Contas a pagar com histórico de contas pagas e cadastro de conta única, recorrente ou parcelada por quantidade de meses.
- Cadastro de empréstimo passou de prompts simples para formulário completo dentro do gerenciador.
- Reset ampliado: financeiro, atendimentos, agenda, orçamentos, serviços, estoque, fornecedores, compras futuras, notas, lixeira, cadastros e organização.
- Limpeza financeira separada por Casa ou Trabalho. Relatórios são recalculados a partir dos dados restantes.
- IDs de notificações locais entram no snapshot do Supabase e são limpos no reset.
- Fotos capturadas pela câmera são automaticamente salvas na galeria quando a ponte nativa e a permissão estiverem disponíveis.

## Persistência
Nenhuma tabela nova do Supabase foi criada. Os dados continuam usando o `app_snapshots` existente.

## Validação
- `tsc --noEmit --skipLibCheck` passou sem diagnósticos.
- `npm ci` foi tentado neste ambiente, mas ultrapassou o limite de execução; por isso o build Android completo deve ser validado pelo GitHub Actions.

## Observação
O login/Supabase não é apagado pelos resets. O reset geral exige confirmação digitando `RESETAR`.
