# Gestão Sacerdotista Aimê — V106 · Inventário Reconstruído

Base: V105_INVENTARIO_CORRIGIDO.

## Escopo desta versão

Esta versão altera somente a arquitetura do Inventário Fixo. O restante do aplicativo permanece como base.

O Inventário Fixo foi reconstruído como um módulo isolado em `src/InventoryModule.tsx`.

### O que o inventário é
- estoque físico de itens duráveis e reutilizáveis;
- objetos fixos do altar, ferramentas, castiçais, vasilhas, estátuas etc.;
- quantidade total cadastrada;
- quantidade disponível calculada pelo histórico de avarias;
- valor unitário e valor total;
- data de compra;
- estado atual;
- foto por câmera ou galeria;
- histórico de avarias/quebras com quantidade, data, local, motivo e observação;
- indicação de unidades que precisam ser repostas;
- exclusão pela lixeira do aplicativo.

### O que o inventário NÃO faz
- não gera compra;
- não movimenta estoque de consumo;
- não cria receita ou despesa;
- não cria lançamento financeiro;
- não altera trabalhos, vendas, tiragens ou atendimentos;
- não participa de cálculo financeiro.

A única persistência compartilhada mantida é a infraestrutura de armazenamento/sincronização da própria chave `gestao_inventory` e a lixeira geral do aplicativo.

## Regra principal de quantidade

`quantity` é sempre o total físico originalmente cadastrado/comprado. Registrar uma avaria reduz a disponibilidade, mas nunca aumenta o total.

`disponível = total - soma das unidades avariadas`

O histórico de avarias é a fonte de verdade para as unidades quebradas no novo módulo.

## Migração

Registros antigos com `unitValue`/`referenceValue` e `brokenQuantity` são lidos para o novo formato sem criar estoque artificial. A quantidade total antiga não é aumentada por causa do histórico de avarias.

## Áudio

Nenhuma lógica de áudio foi alterada nesta versão. A base continua sendo a versão V105, cuja origem é a base V96 com áudio corrigido.

## Verificação

A instalação das dependências não pôde ser concluída neste ambiente dentro do tempo disponível, portanto não foi declarado build aprovado. A alteração foi feita diretamente sobre os arquivos da V105 e o código antigo específico do formulário/portal do inventário foi removido do `App.tsx`.
