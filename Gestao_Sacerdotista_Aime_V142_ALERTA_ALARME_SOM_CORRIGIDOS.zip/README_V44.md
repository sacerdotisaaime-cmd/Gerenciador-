# Gestão Sacerdotisa Aimê V44

## Correção do erro React #310 da V43

A V43 colocou o `useEffect` de persistência de Rotina & Vida depois do bloco condicional `if (activeConsultation) return (...)`.
Quando o atendimento ativo era aberto/fechado, o componente App passava a executar uma quantidade diferente de Hooks, causando o erro de produção do React #310: `Rendered more hooks than during the previous render.`

### Correção
O `useEffect` de persistência de `ROUTINE_ITEMS_KEY` foi movido para junto dos demais efeitos de persistência, antes de qualquer retorno condicional da renderização.

Nenhuma regra do login/Supabase foi alterada nesta correção.
