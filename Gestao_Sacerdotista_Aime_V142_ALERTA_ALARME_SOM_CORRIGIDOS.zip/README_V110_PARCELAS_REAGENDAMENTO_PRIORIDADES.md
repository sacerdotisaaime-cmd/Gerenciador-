# Gestão Sacerdotista Aimê — V110

Base: V109 (ÁUDIO CORRIGIDO).

## Correções desta versão

### 1. Datas efetivas dos pagamentos das parcelas
- Cada parcela agora exibe a data do pagamento efetivamente realizado.
- Pagamento integral: mostra a data/hora da quitação integral.
- Pagamento parcial: mostra cada recebimento parcial com valor e data/hora.
- A data de vencimento continua separada da data efetiva do pagamento.
- Aplicado nas áreas relevantes de histórico do consulente, trabalhos, agenda financeira e detalhes financeiros/dashboard.
- Para registros antigos que possuem `receivedAt` mas não possuem `payments[]`, a data existente é usada como compatibilidade histórica.

### 2. Reagendamento
- O reagendamento agora mantém a data/hora e a prioridade do registro específico.
- Trabalho/venda relacionado a um atendimento é atualizado no próprio `relatedCharge` e no item correspondente da Agenda.
- A prioridade do item pode ser conferida/alterada durante o reagendamento.
- O registro-pai não é usado para sobrescrever a prioridade do trabalho/venda reagendado.

### 3. Prioridade individual por agendamento
- Trabalhos e vendas criados dentro de um atendimento passaram a ter prioridade própria.
- O trabalho/venda não herda automaticamente a prioridade do atendimento.
- O campo de prioridade foi incluído no cadastro/edição de trabalho e venda relacionados.
- Compromissos manuais e atendimentos já possuíam prioridade individual e continuam assim.
- O dashboard e a Agenda utilizam a prioridade do próprio agendamento.

## Base preservada
A versão foi criada diretamente a partir da V109 para preservar as correções de áudio já validadas.

## Verificação
- `unzip -t`: deve retornar integridade do ZIP sem erros.
- TypeScript foi executado com as dependências externas ausentes neste ambiente. Os diagnósticos restantes são de módulos/tipos não instalados e alguns diagnósticos preexistentes; não foram identificados erros novos nas regiões alteradas.
- Não foi declarado build Vite completo porque `node_modules` não está instalado neste ambiente.
