# Gestão Sacerdotisa Aimê — V16

V16 corrige e reorganiza o fluxo de atendimento e recebimentos:

- O valor **não aparece no início do atendimento** nem durante as perguntas.
- O valor/pagamento é definido no **encerramento**.
- A tela final mostra **quantas perguntas foram feitas** e lista as perguntas registradas.
- Para EUR/USD/GBP, o valor digitado é convertido para BRL pela cotação diária carregada pelo app.
- No encerramento, mostra **valor cobrado na moeda**, **equivalente em reais**, eventual taxa aplicada e **quanto será recebido em reais após a taxa**.
- Corrigido o campo de valor em BRL no encerramento para aceitar edição normalmente.
- Taxas percentuais configuráveis ficam somente em **Configurações**; outras formas de pagamento não recebem a taxa de PayPal/Wise indevidamente.
- O histórico financeiro identifica pagamentos internacionais com moeda original, equivalente em BRL e líquido quando houver taxa.
- Cadastro/importação de consulente ganhou **país**, com detecção automática pelo DDI quando possível e edição manual.
- Exemplo: um número brasileiro usado no WhatsApp por uma pessoa que mora na Europa pode ter o país corrigido manualmente.
- Histórico de consulentes ganhou pesquisa por nome, telefone ou país.
- Registro do dia mantém pesquisa por texto e filtros, com acesso direto ao histórico ao tocar em um atendimento.
- A estrutura anterior de fotos, áudios, lixeira, orçamento, trabalho vinculado, relatórios e sincronização Supabase foi preservada.

## Supabase

Execute `SUPABASE_V16.sql` no SQL Editor apenas se quiser que a tabela relacional `clients` também tenha a coluna `country`. O snapshot completo do app continua sendo a camada principal de restauração do V15/V16.
