# Gestão Sacerdotista Aimê V142 — Auditoria e correção de avisos

## O que foi corrigido

1. **Permissão de Alarmes e lembretes**
   - O botão agora usa primeiro a API oficial do `@capacitor/local-notifications` (`changeExactNotificationSetting`) para abrir a configuração de alarmes exatos.
   - Mantido o `PermissionBridge` como fallback.
   - O diagnóstico consulta também `checkExactNotificationSetting()` quando disponível.

2. **Teste de notificação em 10 segundos**
   - Não força mais `allowWhileIdle: true` quando alarmes exatos não estão autorizados.
   - Usa o modo exato quando permitido e o modo inexacto quando não permitido.
   - Usa um canal novo V142 com som próprio.

3. **Avisos da Agenda**
   - A programação individual usa o estado real de permissão de alarmes exatos.
   - A programação em lote de agenda, rotinas e medicamentos não força alarmes exatos quando eles estão bloqueados.
   - Foi eliminado o caminho que podia insistir em `allowWhileIdle: true` sem a permissão.

4. **Alerta dentro do aplicativo**
   - Mantida a verificação em primeiro plano.
   - Adicionado listener `localNotificationReceived` para abrir diretamente a janela de aviso quando uma notificação da Agenda for recebida com o `agendaId`.

5. **Som**
   - O workflow cria `res/raw/aime_alert.wav` durante o build.
   - O canal V142 usa esse arquivo, em vez de depender apenas do som `default` do aparelho.
   - O canal recebeu um novo ID (`gestao-agenda-v142`) para evitar herdar uma configuração silenciosa do canal anterior.

## Causa principal encontrada na auditoria

O diagnóstico do aparelho mostra `Notificações: granted`, mas `Alarmes exatos: Não permitido`. O código V141 ainda tinha caminhos que usavam `allowWhileIdle: true` no teste e na programação em lote, e o botão de permissão usava apenas o `PermissionBridge` próprio. A API oficial do plugin Capacitor possui uma função específica para encaminhar o usuário à configuração de alarmes exatos e uma função para consultar esse estado.

A documentação oficial do Capacitor confirma que alarmes programados podem não ser exatos sem `SCHEDULE_EXACT_ALARM`, que o usuário pode desativar essa permissão e que o plugin fornece `changeExactNotificationSetting()` / `checkExactNotificationSetting()`. O código V142 passa a usar essas APIs quando disponíveis e mantém fallback.

## Observação de teste

A compilação completa não foi executada localmente neste ambiente porque as dependências do projeto não estavam instaladas. O ZIP foi validado estruturalmente e o `package.json` foi validado. O build final deve ser feito pelo workflow do GitHub Actions.

## Teste recomendado no celular

1. Instalar a V142.
2. Abrir `🐞 Avisos`.
3. Tocar em `Ativar Alarmes e lembretes`.
4. Confirmar no Android a permissão de alarmes exatos.
5. Voltar ao app e tocar em `Atualizar diagnóstico`.
6. Confirmar `Alarmes exatos: Permitido`.
7. Testar `Teste de notificação em 10 segundos` e verificar **banner + som + vibração**.
8. Criar um atendimento na Agenda para alguns minutos à frente.
9. Com o app aberto, verificar a janela interna e a notificação.
10. Fechar/minimizar o app e repetir para verificar a notificação nativa em segundo plano.
