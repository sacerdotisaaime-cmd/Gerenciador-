# Gestão Sacerdotista Aimê — V96

## Correção definitiva do fluxo de áudio

Base preservada: V95. A V69 foi usada somente como referência do motor nativo de gravação.

### Correções principais
- O portal do gravador foi retirado do `return` tardio e passou a ser montado como portal global, inclusive durante atendimento ativo.
- O contexto `consultation` foi formalizado no tipo `Screen`.
- O fechamento automático do gravador não depende mais de uma tela artificial para atendimentos; usa `activeConsultation`, `historyClient` e `services` conforme o alvo.
- O botão externo `Gravar áudio` apenas abre a janela. O microfone só é solicitado ao tocar em `Iniciar gravação`.
- No Android/Capacitor, a permissão de microfone volta a usar `PermissionBridge.requestMicrophone()`, seguindo o caminho comprovado da V69.
- Pausa/retomada nativa usa `VoiceRecorder.pauseRecording()` / `resumeRecording()` quando disponíveis, mantendo fallback para ambientes sem esses métodos.
- `Client` passa a declarar `audios?: AudioItem[]`, permitindo persistência correta dos áudios da ficha da consulente.
- Mantidos os recursos existentes de áudio: gravação, pausa, retomada, finalização, reprodução, compartilhamento, descarte e gravação adicional.

## Validação feita
- Verificação estrutural do TSX com TypeScript sem erros de sintaxe/parsing.
- A instalação completa das dependências não foi concluída neste ambiente por timeout; portanto não foi declarado um build Vite completo como validado.
- O ZIP final foi validado com `unzip -t`.
