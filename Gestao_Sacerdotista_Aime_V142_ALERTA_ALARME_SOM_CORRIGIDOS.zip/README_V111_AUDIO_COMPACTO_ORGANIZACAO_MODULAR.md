# Gestão Sacerdotista Aimê — V111

## Base
V111 parte diretamente da V110, preservando as correções de parcelas, reagendamento, prioridades individuais e o fluxo de áudio corrigido da V109/V110.

## Áudio compacto
- Em Android/Capacitor, depois da permissão do microfone, o aplicativo tenta usar `MediaRecorder` do WebView com áudio mono e bitrate alvo de 32 kbps.
- A preferência de codec é Opus em WebM; OGG/Opus, MP4/AAC ou AAC são usados somente quando suportados pelo ambiente.
- O `VoiceRecorder` nativo permanece como fallback para ambientes em que `MediaRecorder` não esteja disponível.
- Pausar/Retomar continua usando o fluxo nativo já corrigido quando o fallback é acionado; no `MediaRecorder`, pausa e retomada são feitas pelo próprio gravador.
- O compartilhamento identifica o MIME real do Data URL e usa extensão correspondente, em vez de sempre forçar `.aac`.
- O objetivo é reduzir drasticamente o tamanho de gravações longas sem alterar a experiência de gravação.

## Organização modular
- A interface da área `Organização` foi retirada do JSX central do `App.tsx`.
- Novo módulo: `src/OrganizationWorkspace.tsx`.
- O módulo recebe estado e handlers pelo contexto `ctx`, preservando o comportamento existente.
- A modularização é estrutural: não houve redesign ou mudança deliberada das funções da Organização.
- Isso permite futuras alterações na Organização sem editar diretamente o bloco gigante de renderização do `App.tsx`.

## Supabase
A arquitetura de mídia do Supabase **não foi alterada nesta versão**. Os áudios continuam seguindo o mecanismo existente de persistência. A migração de mídia pesada para Supabase Storage será feita em uma etapa separada, depois de auditarmos o projeto/buckets/tabelas.

## Verificação
- `OrganizationWorkspace.tsx` e `App.tsx` passaram pela transpiração do TypeScript sem diagnósticos de sintaxe.
- O build completo Vite não foi executado porque a instalação das dependências excedeu o tempo disponível neste ambiente.
