# Checklist V80

- Standby continua isolado de Histórico, Feito hoje, financeiro e relatórios de atendimentos concluídos.
- Standby permanece visível na tela inicial e aceita somente sessões pausadas.
- Atendimento concluído não pode ser executado novamente pelo fluxo de execução.
- Movimentações financeiras de parcelas recebidas não duplicam o lançamento espelho `[WORK:...:INST:...]` / `[QUESTION:...:INST:...]` com a própria parcela.
- Editar Informações Recebidas abre dentro do render do atendimento ativo.
- Perguntas só entram no Histórico quando o atendimento é finalizado.
- Adicionada seção expansível “Resposta da consulente” por pergunta.
- Resposta suporta texto, fotos por câmera/galeria e áudios gravados/importados.
- Foto da resposta possui visualização ampliada.
- Nomes de consulentes não quebram letra por letra nos cards.
- Prioridade de agendamento é persistida de 1 a 10.
- Visão mensal e prioridades da tela inicial preservadas.
- Atualização de versão para 0.80.0.
