# Gestão Sacerdotisa Aimê — V46

V46 parte diretamente da V45 e mantém a linha de login/Supabase. Esta versão reorganiza a área Organização e corrige a restauração das novas funções após reinstalação.

## Principais mudanças

- Organização agora abre primeiro em um **índice** com atalhos em grade, sem uma fila horizontal de botões.
- Organização da Casa, Organização do Trabalho, Agenda da Família, Bem-estar & Saúde, Relatórios e Configuração ficam como áreas independentes.
- Botões do topo ficaram menores para caber melhor no celular.
- Humor passou a ser selecionado por botões visuais; há um botão separado para abrir uma janela e escrever livremente.
- Relatórios de Organização passaram a mostrar também o histórico/resumo de humor.
- Agenda profissional continua no botão inferior Agenda; a agenda familiar fica dentro de Organização.
- Agenda/Compras futuras/O que foi feito no dia deixaram de aparecer como atalhos principais no menu sanduíche; continuam acessíveis pelas áreas corretas.
- Pessoas normalizadas para: Aimê, Emê, Tuco e Taiguara.
- Restauração pós-login agora hidrata explicitamente rotinas, pessoas, logs, configurações, saúde, ciclo, medicamentos e demais dados novos depois que o snapshot Supabase é restaurado.
- As novas estruturas continuam sem tabelas Supabase novas: usam as chaves existentes do snapshot `app_snapshots` e armazenamento local.
- Adicionado exportar/importar de um arquivo JSON de Organização para backup durante o desenvolvimento.
- Reset continua preparado para limpar os dados locais e as chaves do snapshot remoto.

## Persistência

O snapshot existente do Supabase continua sendo usado para que as novas funções possam sobreviver à desinstalação/reinstalação sem alterar o esquema de tabelas. O arquivo JSON é uma cópia extra e não substitui a sincronização.

## Segurança de React

A V46 preserva a correção de Hooks da V44/V45: novos estados e efeitos permanecem no nível superior do componente, antes de retornos condicionais, seguindo as Rules of Hooks.

## Verificação

A instalação completa de dependências não foi executada neste ambiente. O pacote deve ser compilado pelo workflow do GitHub Actions como nas versões anteriores. Antes do envio, foi feita inspeção estática das alterações e preservada a estrutura de login/Supabase da V45.
