# Gestão Sacerdotista Aimê — V65

Base: V64 corrigida. Esta versão preserva a estrutura, módulos e fluxos existentes e concentra a evolução na área de relatórios e movimentações financeiras.

## V65 — principais mudanças

- Relatórios profissionais e mais dinâmicos, mantendo a interface geral do aplicativo.
- Filtros de relatório por mês, trimestre, ano e período personalizado.
- Gráfico de evolução de entradas x saídas.
- Gráfico de composição das entradas por origem.
- Indicadores de resultado líquido, entradas, saídas e número de movimentações.
- Indicadores de perguntas, trabalhos e vendas, incluindo arrecadação.
- Indicadores de orçamentos: aguardando, aprovados, reprovados e expirados.
- Detalhamento de orçamentos por perguntas, trabalhos e vendas, incluindo aprovados e os que não deram certo.
- Situação de atendimentos: concluídos, pausados e em andamento.
- Controle de parcelas recebidas, pendentes e valor pendente.
- Ranking de despesas por categoria.
- Ranking detalhado dos itens comprados individualmente (ex.: arroz, feijão, frango, leite etc.), conforme os itens registrados.
- Tela/modal de movimentações financeiras acessível diretamente pela seção Movimentações do painel inicial.
- Movimentações mostram somente dinheiro efetivamente recebido ou pago; valores pendentes/futuros ficam fora da lista.
- Parcelas efetivamente recebidas aparecem como entradas financeiras reais.

## Verificação

- `src/App.tsx` passou por verificação de sintaxe TSX com TypeScript `transpileModule`, sem diagnósticos de sintaxe.
- A versão foi criada a partir do pacote V64-CORRIGIDA, não da versão simplificada `gestao.docx`, para preservar os módulos e integrações existentes.
