# V172 — Edição salva sem reabrir checkout

## Correção principal

O fluxo de edição de um atendimento/tiragem foi separado definitivamente do checkout.

Antes, ao salvar uma edição de mídias, perguntas ou informações gerais, o atendimento permanecia em `activeConsultation`. Isso podia fazer a interface restaurar/reabrir a janela de checkout (`stage buy`) logo depois do salvamento.

### Agora

1. A edição continua sendo um rascunho isolado.
2. Ao clicar **Salvar edição**, o registro existente é atualizado pelo mesmo ID.
3. O status operacional original é preservado.
4. O checkout é explicitamente fechado e não é reaberto.
5. O `activeConsultation` é encerrado após o salvamento da edição.
6. O modo de sessão volta para `idle`.
7. O rascunho persistido é removido.
8. A tela retorna para o local de onde a edição foi iniciada (Histórico, Serviços etc.).
9. Fechar/cancelar a janela de edição agora usa o cancelamento seguro do rascunho, sem deixar uma sessão operacional aberta.
10. O salvamento de dados gerais também não volta a deixar o atendimento ativo quando a operação é uma edição.

## O que não muda

- Standby continua sendo exclusivamente uma sessão pausada de atendimento.
- Editar não cria Standby.
- Editar não cria um novo atendimento.
- Editar não altera automaticamente o checkout, valores, recebimentos ou parcelas.
- O histórico continua preservando o registro salvo.
- O checkout continua disponível somente pela ação específica **Editar checkout**.

## Validação realizada

- `App.tsx` analisado com parser TSX do TypeScript: **sem erros de sintaxe**.
- Workflow V172 atualizado com validações específicas para impedir a reabertura do checkout após salvar edição.
- ZIP deve ser testado com `unzip -t` antes do envio.

## Observação

A compilação Android completa depende do ambiente GitHub Actions e dos secrets de assinatura. Não é declarada como executada localmente apenas por esta correção.
