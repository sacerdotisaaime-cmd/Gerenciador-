# V170 — Histórico + Standby unificado + edição em rascunho

## Objetivos
- Corrigir o Histórico do consulente usando o vínculo por `clientId`, com fallback legado por nome apenas quando necessário.
- Remover o bloqueio por status que escondia atendimentos do Histórico.
- Unificar o estado operacional das tiragens: `active` não é mais um estado operacional persistido; registros não concluídos ficam em `standby`.
- Migrar registros antigos persistidos com `status: "active"` para `standby`.
- Remover o filtro separado de `Em atendimento` da Central de Tiragens.
- Fazer a Central de Tiragens abrir no filtro `Standby` e ordenar o Standby antes dos demais estados.
- Manter `active` somente como estado transitório da sessão aberta em memória.
- Criar modo de sessão `editing` separado do status do atendimento.
- Edições completas usam rascunho: alterações feitas durante a edição não substituem o registro salvo até `Salvar edição`.
- Cancelar/sair da edição descarta somente o rascunho e preserva a última versão salva no Histórico, Serviços e Financeiro.
- Salvar edição atualiza o mesmo `consultation.id`; não cria um novo atendimento.
- Preservar as correções anteriores de Standby/Áudio/Mídias/NFC-e.

## Regra de ciclo de vida
`Agendada -> Standby -> Concluída`.

`active` existe apenas em memória enquanto uma sessão está aberta. Nunca é usado como estado operacional persistido.

## Regra de edição
`Registro salvo -> Editando (rascunho) -> Salvar edição -> mesmo registro atualizado`

ou

`Registro salvo -> Editando (rascunho) -> Cancelar/Sair -> registro salvo intacto`.
