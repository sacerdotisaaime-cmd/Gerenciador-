# V171 — Standby, Histórico e Edição Separados

## Correções
- Edição não altera o status operacional salvo.
- Abrir uma edição não cria Standby.
- Cancelar/voltar durante edição descarta somente o rascunho.
- Salvar edição atualiza o mesmo `consultation.id`.
- Edição de conteúdo/informações e mídias foi separada visualmente de `Editar checkout`.
- Edição de conteúdo preserva valor, moeda, pagamento, parcelas e recebimentos existentes.
- Tiragens usam Standby como estado operacional de atendimento não concluído; `active` legado é exibido como Standby.
- Standby aparece no dashboard inicial e pode ser excluído/movido para a lixeira.
- Tiragens em Standby aparecem no filtro Standby da Central de Serviços.
- Trabalhos/vendas vinculados não desaparecem somente porque o atendimento pai está em Standby.
- Histórico continua vinculado ao consulente e independente do status operacional.
