# V168 — Auditoria profunda do Histórico de Consulentes

## Problema identificado
A V167 ainda filtrava o histórico por um critério de conclusão (`status === completed` ou estados específicos). Isso fazia desaparecer do Histórico registros que o módulo Serviços continuava encontrando: atendimentos ativos/agendados, tiragens/perguntas e trabalhos/vendas vinculados.

Além disso, registros legados/mesclados com `clientId` divergente podiam ficar invisíveis mesmo pertencendo ao mesmo consulente.

## Correção
- O Histórico agora usa o `clientId` como vínculo principal.
- Há fallback pelo nome normalizado do consulente para registros legados com vínculo de ID inconsistente.
- Registros não excluídos ficam visíveis no histórico mesmo se estiverem ativos, agendados ou concluídos.
- Somente registros em Standby ficam fora, exceto quando o próprio registro já contém trabalho/venda efetivamente concluído.
- A busca do histórico agora também considera tipo/status do trabalho ou venda e os registros em `relatedCharges`.
- A correção preserva a sanitização de áudio/Standby da V166/V167.

## Validação local
- `npx tsc --noEmit`: OK.
- `npx vite build`: iniciado, mas excedeu 120 segundos no ambiente local e foi interrompido; portanto não foi declarado como build completo local.
- O ZIP foi testado com `unzip -t`.
