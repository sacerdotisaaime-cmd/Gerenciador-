# V167 — Histórico de Consulentes

Correção da regressão do histórico de consulentes.

- Mantém a correção de Standby/áudio da V166.
- O histórico não depende mais exclusivamente de `status === completed`.
- Reconhece consultas concluídas, trabalhos com `workStatus === completed`, vendas entregues e registros com cobranças relacionadas concluídas/entregues.
- Exclui itens apagados e não promove Standby/ativos para o histórico.
- Atividades vinculadas concluídas/entregues também são exibidas.
