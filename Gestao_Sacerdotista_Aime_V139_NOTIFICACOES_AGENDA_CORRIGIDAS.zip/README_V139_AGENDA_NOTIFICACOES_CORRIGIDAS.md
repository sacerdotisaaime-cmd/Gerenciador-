# V139 — Agenda: notificações nativas corrigidas

Correções principais:
- canal nativo exclusivo da Agenda (`gestao-agenda-v139`) com alta importância, som padrão e vibração;
- verificação explícita da permissão de notificações ao salvar um agendamento;
- verificação da permissão de Alarmes e lembretes / alarmes exatos;
- abertura das configurações de alarmes exatos quando essa permissão estiver ausente;
- agendamentos de atendimento, trabalho, venda e compromisso continuam sendo sincronizados pela Agenda;
- reagendamento continua provocando a reconstrução dos avisos;
- os avisos da Agenda usam o canal dedicado para evitar configurações antigas de canal sem som.

O usuário ainda precisa permitir Notificações e, no Android 12+, permitir Alarmes e lembretes quando o sistema exigir.
