# V172 — Auditoria e correção do fluxo Edição / Checkout / Standby

Correções aplicadas:
- Salvar edição encerra a sessão de edição e retorna à tela de origem; não abre nem revela checkout.
- Checkout é fechado ao entrar em edição e permanece fechado ao salvar/cancelar.
- O botão de encerramento/checkout fica oculto enquanto a sessão está em modo Editando.
- Fechar X, Cancelar e voltar do Android cancelam corretamente o rascunho de edição; não deixam o estado interno preso em editing.
- O mesmo consultation.id é atualizado; o status original é preservado.
- O status active é exibido como Em andamento, distinto de Standby.
- A ação Excluir Standby aparece somente para registros realmente marcados como standby.
- Nenhum código de edição chama putOnStandby().

Auditoria estática:
- App.tsx analisado com parser TSX: sem erros de sintaxe.
- Não foi executado build Android completo nesta auditoria.
