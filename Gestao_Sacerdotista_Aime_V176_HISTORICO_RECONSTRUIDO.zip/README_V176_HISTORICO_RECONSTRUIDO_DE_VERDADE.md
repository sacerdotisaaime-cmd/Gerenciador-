# V176 — Histórico reconstruído de forma efetiva

Esta versão corrige uma falha da reconstrução anterior.

## O que mudou

- A recuperação do histórico agora é feita em `useEffect`, e não como efeito colateral durante o render.
- O histórico mantém uma coleção própria de registros recuperados (`historyRecoveredConsultations`, `historyRecoveredQuickSales`, `historyRecoveredExecutions`).
- O snapshot `app_snapshots.payload` é tratado como fonte rica, preservando perguntas, mídias, trabalhos e vendas quando esses dados ainda estiverem nele.
- A tabela `clients` é consultada para localizar IDs antigos do mesmo consulente por nome/telefone.
- A tabela `consultations` é consultada com `select("*")`, evitando perder colunas antigas que não estavam na seleção reduzida da V175.
- A tabela `questions` também é consultada com `select("*")`.
- O resultado relacional e o snapshot são mesclados sem substituir um registro rico por um registro parcial.
- Vendas rápidas e execuções de trabalhos existentes no snapshot também entram na reconstrução.
- A tela informa quando a recuperação está em andamento ou falhou.

## Importante

A recuperação só consegue restaurar dados que ainda existam no armazenamento local, no snapshot ou nas tabelas remotas acessíveis pela conta. Esta versão não apaga dados nem executa reset.

## Validação local

`src/App.tsx` passou pela análise sintática TSX do TypeScript nos dois projetos (raiz e `v174root`). A compilação Android completa não foi executada neste ambiente.
