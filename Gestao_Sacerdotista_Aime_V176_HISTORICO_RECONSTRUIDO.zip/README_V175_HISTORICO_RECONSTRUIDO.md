# V175 — Histórico do consulente reconstruído

Esta versão substitui a abordagem incremental por uma reconstrução compatível com o histórico funcional antigo.

- Mantém a lógica histórica por clientId e fallback por nome/telefone.
- Mescla consultas completas sem deixar um registro parcial apagar perguntas, fotos, áudios, cobranças ou objetos.
- Ao abrir o histórico, recupera dados disponíveis no app_snapshots e nas tabelas relacionais consultations/questions do Supabase.
- Vendas diretas e execuções órfãs continuam aparecendo como registros complementares.
- O histórico não depende de status operacional para decidir se um atendimento pertence ao consulente.
