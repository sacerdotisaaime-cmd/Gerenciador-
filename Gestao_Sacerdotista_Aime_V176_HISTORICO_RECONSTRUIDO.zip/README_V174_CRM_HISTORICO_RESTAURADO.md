# V174 — CRM / Histórico restaurado a partir da implementação funcional

Esta versão mantém as correções da V172/V173 de edição, Standby, áudio e NFC-e, mas restaura o caminho principal do Histórico do Consulente para o modelo que funcionava nas versões antigas:

- `consultations` é a fonte principal do histórico;
- vínculo principal por `clientId`;
- fallback por nome normalizado para registros legados/migrados;
- nenhum filtro por status operacional;
- exclusões são respeitadas pela Lixeira, não por um `deletedAt` aplicado dentro do índice principal;
- trabalhos, vendas e consultas continuam usando o mesmo `HistoryItem` quando são `Consultation`;
- vendas diretas do Financeiro e execuções órfãs aparecem como registros complementares.
