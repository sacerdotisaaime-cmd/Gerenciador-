# V169 — Auditoria profunda do Histórico de Consulentes

Correção baseada em comparação direta entre V160 (última versão em que o Histórico funcionava) e V168 (versão atual).

## Correção principal
- Mantida a arquitetura da V168.
- O histórico volta a usar `consultations` como fonte de verdade, como na V160.
- Removido o bloqueio por `status` do filtro do histórico.
- O vínculo usa `clientId` e fallback por nome normalizado para registros legados.
- Registros não excluídos pertencentes ao consulente não desaparecem por estarem `active`, `scheduled`, `standby`, `completed` etc.
- O status continua sendo mostrado visualmente no `HistoryItem`.
- Atividades vinculadas a trabalhos deixam de desaparecer por causa de um filtro de status diferente do histórico principal.
- Standby/áudio da V166/V168 permanece preservado.
