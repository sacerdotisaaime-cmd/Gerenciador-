import { useEffect, useState } from 'react';
import { getLunaApiBaseUrl, setLunaApiBaseUrl, lunaApi, type LunaLoginResult, type LunaClientRecord } from './lunaApi';

const TOKEN_KEY = 'luna_commercial_access_token_v1';
const LOGIN_KEY = 'luna_commercial_user_v1';

export default function LunaEntry() {
  const [baseUrl, setBaseUrl] = useState(getLunaApiBaseUrl());
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [token, setToken] = useState(localStorage.getItem(TOKEN_KEY) || '');
  const [account, setAccount] = useState<any>(() => { try { return JSON.parse(localStorage.getItem(LOGIN_KEY) || 'null'); } catch { return null; } });
  const [clients, setClients] = useState<LunaClientRecord[]>([]);
  const [clientName, setClientName] = useState('');
  const [clientPhone, setClientPhone] = useState('');
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const [showSettings, setShowSettings] = useState(false);

  async function refreshClients(currentToken = token) {
    const result = await lunaApi.listClients(currentToken, 100, 0);
    setClients(result.items || []);
  }
  useEffect(() => { if (token) { lunaApi.me(token).then(async profile => { setAccount(profile); localStorage.setItem(LOGIN_KEY, JSON.stringify(profile)); await refreshClients(token); }).catch(async e => { setMessage(e.message || 'Sessão expirada. Entre novamente.'); localStorage.removeItem(TOKEN_KEY); localStorage.removeItem(LOGIN_KEY); setToken(''); setAccount(null); }); } }, []);

  async function login(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setMessage('');
    try {
      const result: LunaLoginResult = await lunaApi.login(email.trim(), password, 'Luna Android');
      localStorage.setItem(TOKEN_KEY, result.access_token);
      localStorage.setItem(LOGIN_KEY, JSON.stringify({ user: result.user, organization: result.organization }));
      setToken(result.access_token); setAccount({ user: result.user, organization: result.organization }); setPassword('');
      await refreshClients(result.access_token); setMessage('Conectado ao banco central da Luna.');
    } catch (err: any) { setMessage(err?.message || 'Não foi possível entrar.'); }
    finally { setBusy(false); }
  }
  async function logout() {
    try { if (token) await lunaApi.logout(token); } catch { /* sessão local será encerrada mesmo sem rede */ }
    localStorage.removeItem(TOKEN_KEY); localStorage.removeItem(LOGIN_KEY); setToken(''); setAccount(null); setClients([]);
  }
  async function addClient(e: React.FormEvent) {
    e.preventDefault(); if (!clientName.trim()) return; setBusy(true); setMessage('');
    try {
      await lunaApi.createClient(token, { name: clientName.trim(), phone: clientPhone.trim() });
      setClientName(''); setClientPhone(''); await refreshClients(); setMessage('Consulente salva no banco central. A versão Web verá o mesmo cadastro.');
    } catch (err: any) { setMessage(err?.message || 'Falha ao salvar.'); }
    finally { setBusy(false); }
  }
  async function saveUrl() { try { setLunaApiBaseUrl(baseUrl); setMessage('Endereço da API salvo.'); setShowSettings(false); } catch (e: any) { setMessage(e.message); } }

  return <main className="luna-gate">
    <header className="luna-top"><div className="luna-brand"><span className="luna-mark">☾</span><div><strong>Luna</strong><small>Seu espaço de gestão</small></div></div><button className="luna-link" onClick={() => setShowSettings(v => !v)}>Conexão</button></header>
    {showSettings && <section className="luna-panel luna-settings"><label>Endereço da API (servidor Luna)</label><input value={baseUrl} onChange={e => setBaseUrl(e.target.value)} placeholder="https://seudominio.com/sistema_teste/public/api/v1"/><button className="luna-primary" onClick={saveUrl}>Salvar conexão</button><p>Em testes locais no celular, use o IP do computador na rede Wi-Fi. Em produção, use o endereço HTTPS do servidor.</p></section>}
    {!token ? <section className="luna-login luna-panel"><div className="luna-eyebrow">PLATAFORMA LUNA</div><h1>Bem-vinda à sua gestão.</h1><p>Entre com a mesma conta usada na versão Web. Seus dados são carregados da organização no banco central.</p><form onSubmit={login}><label>E-mail</label><input type="email" autoComplete="username" value={email} onChange={e => setEmail(e.target.value)} required/><label>Senha</label><input type="password" autoComplete="current-password" value={password} onChange={e => setPassword(e.target.value)} required/><button className="luna-primary" disabled={busy}>{busy ? 'Conectando…' : 'Entrar na Luna'}</button></form><a href="/comercial/login.php">Acessar a versão Web</a> <span>·</span> <a href="/comercial/cadastro.php">Criar conta</a></section> : <section className="luna-workspace"><div className="luna-welcome"><div><div className="luna-eyebrow">ESPAÇO DE TRABALHO</div><h1>Olá, {account?.user?.name || 'bem-vinda'}.</h1><p>{account?.organization?.name || 'Sua organização'} · {account?.organization?.role || 'membro'}</p></div><button className="luna-outline" onClick={logout}>Sair</button></div>
      <section className="luna-panel"><div className="luna-section-head"><div><div className="luna-eyebrow">CADASTROS</div><h2>Consulentes</h2></div><button className="luna-outline" onClick={() => refreshClients().catch(e => setMessage(e.message))}>Atualizar</button></div>
      <form className="luna-client-form" onSubmit={addClient}><input placeholder="Nome da consulente" value={clientName} onChange={e => setClientName(e.target.value)} required/><input placeholder="Telefone" value={clientPhone} onChange={e => setClientPhone(e.target.value)}/><button className="luna-primary" disabled={busy}>Adicionar</button></form>
      <div className="luna-client-list">{clients.length ? clients.map(c => <article key={c.id}><div><strong>{String(c.data?.name || 'Sem nome')}</strong><small>{String(c.data?.phone || 'Sem telefone')}</small></div><span>v{c.version}</span></article>) : <p className="luna-empty">Nenhuma consulente cadastrada nesta organização.</p>}</div>
      <p className="luna-sync-note">Os cadastros exibidos aqui vêm da API e do MySQL central. Alterações feitas na Web aparecem ao atualizar esta lista.</p></section>
    </section>}
    {message && <div className="luna-message" role="status">{message}</div>}
    <footer className="luna-footer">Luna · Web e Android conectados ao mesmo espaço de trabalho</footer>
  </main>;
}
