# Luna Android — entrada comercial e conexão com MySQL

## O que esta entrega corrige
- O Android deixa de iniciar diretamente o aplicativo legado V185.
- A inicialização agora abre a entrada comercial Luna.
- O login usa a mesma API PHP da versão Web.
- Após autenticar, o Android consulta `auth/me` e carrega a lista de consulentes (`gestao_clients`) do banco MySQL central.
- Novos cadastros de consulentes são gravados pela API no mesmo banco e aparecem na versão Web que usa a mesma organização.
- Não há importação automática dos dados antigos locais/Supabase. A nova organização começa limpa.
- O projeto antigo continua dentro do ZIP apenas como código-fonte preservado; ele não é iniciado por esta tela de entrada.

## Configurar endereço da API
1. Instale/compile o projeto Android normalmente.
2. Na tela inicial, toque em **Conexão**.
3. Informe a URL base da API, sem barra no final. Exemplo de produção: `https://SEU-DOMINIO/sistema_teste/public/api/v1`.
4. Em teste na mesma rede Wi-Fi do computador com XAMPP, use `http://IP-DO-COMPUTADOR/gestao-aime-comercial/sistema_teste/public/api/v1`.
5. Não use `127.0.0.1` no celular: esse endereço aponta para o próprio telefone.

## Entrar
Use o mesmo e-mail e senha cadastrados na plataforma Web, e uma organização com assinatura/avaliação ativa. O token fica no armazenamento local do aplicativo; esta entrega ainda não usa um cofre criptográfico nativo dedicado.

## Escopo real desta etapa
Esta é a primeira etapa funcional de integração Android ↔ Web: autenticação e cadastros de consulentes. Os demais módulos do V185 (atendimentos, perguntas, trabalhos, agenda, financeiro, estoque, mídia e relatórios) ainda não foram migrados para a API/MySQL. Eles não devem ser considerados sincronizados nesta etapa. A interface antiga foi isolada do fluxo inicial para impedir que dados locais antigos sejam confundidos com os dados novos da Luna.

## Limites de validação
O código-fonte foi alterado e o pacote foi organizado. Não foi possível executar `npm run build` ou gerar APK neste ambiente porque as dependências Node do projeto não estão instaladas. Antes de publicar, compile e teste login, cadastro no Android e conferência do mesmo registro na Web.
