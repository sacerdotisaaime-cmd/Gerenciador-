# Correção de rotas da API Luna — Android V185 Debug pós-login

## O que mudou
- As chamadas da API Android agora usam explicitamente `/api/v1/index.php/<rota>`.
- Mantém o endereço-base configurado terminado em `/api/v1`.
- Não altera token, sessão, banco SQL, dados locais ou coleções.
- Mantém o painel de diagnóstico pós-login.

## Por que
No teste feito no XAMPP, `/api/v1/index.php/health` respondeu online/connected, enquanto as chamadas do Android para as rotas sem `index.php` retornaram HTTP 404. Esta alteração faz o cliente Android usar o caminho que foi confirmado no navegador.

## Como aplicar
1. Extraia o ZIP e abra o projeto no ambiente usado para compilar o APK.
2. Execute `npm install` se necessário.
3. Execute `npm run build`.
4. Sincronize com Capacitor (`npx cap sync android`).
5. Gere o APK pelo fluxo habitual do projeto.
6. Instale e execute o diagnóstico pós-login.

## Limites da validação
A alteração foi conferida no código-fonte. É necessário testar no XAMPP e no aparelho para confirmar que todas as rotas (login, auth/me e snapshot) são aceitas pelo servidor.
