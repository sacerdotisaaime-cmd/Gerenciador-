# Gestão Sacerdotista Aimê — Android V185 / SQL

Projeto Vite + React + Capacitor para gestão de consulentes, atendimentos, financeiro, agenda, compras, estoque e demais módulos.

## Armazenamento e sincronização

O aplicativo utiliza exclusivamente a API PHP da plataforma e o banco MySQL/MariaDB no servidor XAMPP.

- Login: API comercial com token Bearer.
- Leitura e gravação: `GET /api/v1/snapshot` e `POST /api/v1/snapshot`.
- Persistência local: armazenamento do Android para funcionamento e fila de sincronização.
- Sincronização: leitura periódica do MySQL e envio das alterações locais.
- O Web e o Android usam as mesmas tabelas `tenant_records` e `tenant_settings`.
- Não há SDK, URL, chave ou projeto Supabase no runtime Android.

Consulte `LUNA_INTEGRACAO_V185_WEB_MYSQL.md` para instalação e homologação.

**Compatibilidade Android:** `@capacitor/barcode-scanner` está fixado em `2.2.1`, versão da linha 2 compatível com Capacitor 7. Não atualizar para 3.x sem migrar primeiro todo o projeto para Capacitor 8.
