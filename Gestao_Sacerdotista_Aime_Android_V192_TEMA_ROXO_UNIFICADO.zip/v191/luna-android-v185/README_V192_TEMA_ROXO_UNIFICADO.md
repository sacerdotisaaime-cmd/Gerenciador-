# V192 — Tema roxo unificado

Base: V191 redesign estrutural.

Objetivo: corrigir a mistura visual entre o tema antigo rosa/branco e o tema escuro, usando fundo roxo profundo, cartões roxos mais claros e contraste legível.

Alterações:
- paleta global roxa unificada;
- cartões em roxo médio, destacados do fundo;
- textos, rótulos e textos auxiliares com contraste;
- botões e campos de formulário com fundos e textos compatíveis;
- correção de botões claros nos modais, especialmente fluxo Novo atendimento;
- menu lateral e navegação inferior harmonizados;
- meta theme-color para aproximar a barra superior do Android ao tema.

Não altera regras de negócio, autenticação, API ou sincronização SQL.
Não foram adicionadas imagens ilustrativas novas nesta versão.
ZIP validado; APK não compilado nem testado fisicamente neste ambiente.
