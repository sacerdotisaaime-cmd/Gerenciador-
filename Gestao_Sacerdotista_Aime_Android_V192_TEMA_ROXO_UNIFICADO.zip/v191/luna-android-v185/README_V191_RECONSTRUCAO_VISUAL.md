# V191 — Reconstrução visual da navegação

Base: projeto-fonte V189 enviado pela usuária.

Alterações em `src/App.tsx`:
- inclusão de lockup de marca no cabeçalho;
- cabeçalho do menu lateral com emblema lunar e identidade Sacerdotista Aimê.

Alterações em `src/index.css`:
- tema global vinho escuro;
- abas superiores em superfícies escuras;
- menu lateral com cabeçalho editorial e navegação em superfícies translúcidas;
- barra inferior reconstruída em grid de cinco posições, botão central elevado e sem borda superior clara;
- ajustes responsivos para telas Android.

Preservação: não foram alterados autenticação, API, banco SQL, sincronização, estados de módulos ou regras de negócio.

Limitações e validação:
- não foram adicionadas imagens raster personalizadas de fundo, ervas, cristais ou pentagrama; o emblema usa glifos e CSS.
- não foi possível compilar o APK neste ambiente (projeto sem `node_modules`/dependências instaladas).
- requer build e teste no dispositivo para validar safe-area, barra de status e layout em diferentes larguras.
