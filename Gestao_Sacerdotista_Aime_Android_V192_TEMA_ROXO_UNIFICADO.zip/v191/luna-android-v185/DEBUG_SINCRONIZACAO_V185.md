# Diagnóstico de sincronização SQL — V185

O painel foi movido para dentro do aplicativo, em **Configurações**, disponível após o login.

O diagnóstico consulta a API, valida a sessão atual por `/auth/me` e baixa o snapshot SQL em modo somente leitura. Não grava, apaga ou substitui dados.

Para acessar: entre no aplicativo → menu → Configurações → Diagnóstico de sincronização → Executar diagnóstico.
