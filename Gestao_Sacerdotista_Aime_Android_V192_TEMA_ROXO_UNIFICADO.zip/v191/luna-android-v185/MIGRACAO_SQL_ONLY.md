# Migração para SQL único

A sincronização ativa do Android não utiliza Supabase. O antigo nome dos arquivos de compatibilidade foi substituído por `lunaSqlClient.ts` e `lunaSqlSync.ts`; ambos usam exclusivamente `lunaApi.ts`.

No servidor, o snapshot Web e o snapshot Android são atendidos por `AimeCommercialSnapshotAdapter` e persistidos em `tenant_records` / `tenant_settings` no MySQL do XAMPP.

Os arquivos SQL históricos de criação de tabelas Supabase foram retirados do pacote ativo. Os documentos antigos `README_Vxx.md` foram mantidos apenas como histórico de versões e não representam a arquitetura atual.

Não execute limpeza ou DROP no banco de produção para realizar esta migração. O banco MySQL atual é preservado; a remoção do Supabase significa desativar sua integração e deixar de utilizá-lo como fonte de dados.
