import React, { useState } from "react";
import { getLunaApiBaseUrl, lunaApi } from "./lunaApi";

type Line = { label: string; status: "ok" | "error" | "wait"; detail: string };
const TOKEN_KEY = "luna_access_token";
const USER_KEY = "luna_session_user";

export default function SqlSyncDebug() {
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [lines, setLines] = useState<Line[]>([]);
  const [report, setReport] = useState("");
  const run = async () => {
    setBusy(true);
    const next: Line[] = [];
    const add = (label: string, status: Line["status"], detail: string) => next.push({ label, status, detail });
    try {
      const health = await lunaApi.health();
      add("API", health.status === "online" ? "ok" : "error", `${health.status || "sem status"} · ${health.version || "versão não informada"}`);
      add("Banco SQL", health.database === "connected" ? "ok" : "error", health.database || "sem informação");
    } catch (e) { add("API / banco", "error", (e as Error)?.message || String(e)); }
    const token = localStorage.getItem(TOKEN_KEY) || "";
    if (!token) {
      add("Autenticação", "error", "Token não encontrado neste dispositivo. Faça login no aplicativo.");
      add("Download SQL", "wait", "Não executado: falta autenticação.");
    } else {
      try {
        const me = await lunaApi.me(token);
        add("Autenticação", "ok", `Autenticado: ${me.user?.email || "usuário validado"} · organização ${me.organization?.name || "identificada"}`);
        const snap = await lunaApi.getSnapshot(token);
        const payload = snap.payload || {};
        const collections = Object.keys(payload).length;
        const records = Object.values(payload).reduce((sum: number, value: any) => sum + (Array.isArray(value) ? value.length : 0), 0);
        add("Download SQL", "ok", `${collections} coleções · ${records} registros · atualização ${snap.updated_at || "sem data"}`);
      } catch (e) {
        const err = e as Error & { status?: number; code?: string };
        add("Autenticação / download SQL", "error", `${err.status ? `HTTP ${err.status} · ` : ""}${err.code ? `${err.code} · ` : ""}${err.message || String(e)}`);
      }
    }
    const rawUser = localStorage.getItem(USER_KEY);
    add("Sessão local", rawUser ? "ok" : "wait", rawUser ? "Dados de sessão encontrados." : "Sessão local não encontrada.");
    const text = [
      "DIAGNÓSTICO DE SINCRONIZAÇÃO SQL",
      `Data: ${new Date().toLocaleString()}`,
      `API configurada: ${getLunaApiBaseUrl()}`,
      ...next.map(x => `${x.status.toUpperCase()} — ${x.label}: ${x.detail}`),
      "Observação: diagnóstico somente leitura; nenhum dado foi gravado, apagado ou alterado."
    ].join("\n");
    setLines(next); setReport(text); setBusy(false);
  };
  const copy = async () => { if (report && navigator.clipboard?.writeText) await navigator.clipboard.writeText(report); };
  return <section style={{ marginTop: 14, border: "1px solid #e5d9ed", borderRadius: 12, padding: 12, background: "#fff" }}>
    <button type="button" onClick={() => setOpen(v => !v)} style={{ border: 0, background: "transparent", padding: 0, fontWeight: 800, color: "#54366d", cursor: "pointer" }}>🛠 Diagnóstico de sincronização {open ? "−" : "+"}</button>
    {open && <div style={{ marginTop: 12 }}>
      <p style={{ fontSize: 12, color: "#665b6d", margin: "0 0 10px" }}>Testes somente de leitura. Não altera nem apaga seus dados.</p>
      <button type="button" disabled={busy} onClick={() => void run()} style={{ width: "100%", padding: 11, border: 0, borderRadius: 10, background: "#54366d", color: "#fff", fontWeight: 800 }}>{busy ? "Executando diagnóstico..." : "Executar diagnóstico"}</button>
      {lines.map((line, i) => <div key={i} style={{ marginTop: 9, padding: 9, borderRadius: 9, background: line.status === "ok" ? "#edf8f1" : line.status === "error" ? "#fff0f0" : "#f5f2f7", fontSize: 12 }}>
        <strong>{line.status === "ok" ? "✓" : line.status === "error" ? "✕" : "•"} {line.label}</strong><div style={{ marginTop: 3, overflowWrap: "anywhere" }}>{line.detail}</div>
      </div>)}
      {report && <button type="button" onClick={() => void copy()} style={{ marginTop: 10, width: "100%", padding: 10, border: "1px solid #d9cce3", borderRadius: 10, background: "#fff", color: "#54366d", fontWeight: 700 }}>Copiar relatório</button>}
    </div>}
  </section>;
}
