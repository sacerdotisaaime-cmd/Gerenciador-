import { lunaApi, type LunaSession, type LunaUser } from './lunaApi';

const TOKEN_KEY = 'luna_access_token';
const SESSION_USER_KEY = 'luna_session_user';
const listeners = new Set<(event: string, session: LunaSession | null) => void>();

const readSession = (): LunaSession | null => {
  try {
    const token = localStorage.getItem(TOKEN_KEY) || '';
    const rawUser = localStorage.getItem(SESSION_USER_KEY) || '';
    if (!token || !rawUser) return null;
    const user = JSON.parse(rawUser) as LunaUser;
    if (!user?.id) return null;
    return { access_token: token, token_type: 'Bearer', expires_at: 0, user };
  } catch { return null; }
};

const emit = (event: string, session: LunaSession | null) => {
  for (const listener of listeners) {
    try { listener(event, session); } catch (error) { console.warn('Luna auth listener', error); }
  }
};

const getToken = () => localStorage.getItem(TOKEN_KEY) || '';
const authError = (error: unknown) => {
  const source = error as (Error & { status?: number; code?: string }) | null;
  return {
    message: source instanceof Error ? source.message : 'Falha de comunicação com a Luna API.',
    status: source?.status,
    code: source?.code,
  };
};

function toClientRow(item: any, userId: string) {
  return { ...item, id: String(item?.id || ''), user_id: userId, name: item?.name || '', phone: item?.phone || '', notes: item?.notes || '', created_at: item?.createdAt || item?.created_at || '', updated_at: item?.updatedAt || item?.updated_at || '', deleted_at: item?.deletedAt || item?.deleted_at || null };
}
function toConsultationRow(item: any, userId: string) {
  return { ...item, id: String(item?.id || ''), user_id: userId, client_id: item?.clientId || item?.client_id || null, client_name: item?.clientName || item?.client_name || '', title: item?.title || '', value: Number(item?.value || 0), paid: !!item?.paid, payment_date: item?.paymentDate || item?.payment_date || null, status: item?.status || 'active', service_type: item?.serviceType || item?.service_type || '', intake_notes: item?.intakeNotes || item?.intake_notes || '', scheduled_at: item?.scheduledAt || item?.scheduled_at || null, payment_plan: item?.paymentPlan || item?.payment_plan || null, created_at: item?.createdAt || item?.created_at || '', updated_at: item?.updatedAt || item?.updated_at || '', deleted_at: item?.deletedAt || item?.deleted_at || null };
}
function toQuestionRow(item: any, consultation: any, userId: string) {
  return { ...item, id: String(item?.id || ''), user_id: userId, consultation_id: String(consultation?.id || ''), question_number: Number(item?.number || item?.question_number || 1), text: item?.text || '', notes: item?.notes || '', completed: !!item?.completed, created_at: item?.createdAt || item?.created_at || '', updated_at: item?.updatedAt || item?.updated_at || '', deleted_at: item?.deletedAt || item?.deleted_at || null };
}

class LunaQueryBuilder {
  private table: string;
  private filters: Array<{ kind: 'eq' | 'in'; key: string; value: any }> = [];
  constructor(table: string) { this.table = table; }
  select(_columns = '*') { return this; }
  eq(key: string, value: any) { this.filters.push({ kind: 'eq', key, value }); return this; }
  in(key: string, value: any[]) { this.filters.push({ kind: 'in', key, value }); return this; }

  private async selectRows(): Promise<{ data: any; error: any }> {
    try {
      const token = getToken();
      if (!token) throw new Error('Entre na sua conta Luna para acessar os dados sincronizados.');
      const userId = readSession()?.user.id || '';
      const snapshotResult = await lunaApi.getSnapshot(token);
      const payload = snapshotResult.payload || {};
      if (this.table === 'app_snapshots') {
        const requestedUser = this.filters.find((f) => f.key === 'user_id' && f.kind === 'eq')?.value;
        if (requestedUser && requestedUser !== userId) return { data: null, error: null };
        return { data: { user_id: userId, payload, updated_at: snapshotResult.updated_at }, error: null };
      }
      let rows: any[] = [];
      if (this.table === 'clients') {
        rows = (Array.isArray(payload.gestao_clients) ? payload.gestao_clients : []).map((item: any) => toClientRow(item, userId));
      } else if (this.table === 'consultations') {
        rows = (Array.isArray(payload.gestao_consultations) ? payload.gestao_consultations : []).map((item: any) => toConsultationRow(item, userId));
      } else if (this.table === 'questions') {
        const consultations = Array.isArray(payload.gestao_consultations) ? payload.gestao_consultations : [];
        rows = consultations.flatMap((consultation: any) => (Array.isArray(consultation?.questions) ? consultation.questions : []).map((item: any) => toQuestionRow(item, consultation, userId)));
      } else {
        throw new Error(`Consulta compatível ainda não implementada para ${this.table}.`);
      }
      for (const filter of this.filters) {
        if (filter.kind === 'eq') rows = rows.filter((row) => String(row?.[filter.key] ?? '') === String(filter.value ?? ''));
        else if (filter.kind === 'in') { const allowed = new Set((filter.value || []).map(String)); rows = rows.filter((row) => allowed.has(String(row?.[filter.key] ?? ''))); }
      }
      return { data: rows, error: null };
    } catch (error) { return { data: null, error: authError(error) }; }
  }

  async maybeSingle() {
    const result = await this.selectRows();
    if (result.error) return result;
    if (Array.isArray(result.data)) return { data: result.data[0] || null, error: null };
    return result;
  }

  async upsert(input: any, _options?: any) {
    try {
      const token = getToken();
      if (!token) throw new Error('Entre na sua conta Luna para gravar os dados.');
      const userId = readSession()?.user.id || '';
      const snapshotResult = await lunaApi.getSnapshot(token);
      const payload: Record<string, any> = { ...(snapshotResult.payload || {}) };
      const values = Array.isArray(input) ? input : [input];
      if (this.table === 'app_snapshots') {
        const row = values[0] || {};
        await lunaApi.saveSnapshot(token, row.payload || {});
      } else if (this.table === 'clients') {
        const current = Array.isArray(payload.gestao_clients) ? payload.gestao_clients : [];
        const map = new Map(current.map((item: any) => [String(item?.id || ''), item]));
        for (const row of values) {
          const old: any = map.get(String(row.id)) || {};
          map.set(String(row.id), { ...old, id: String(row.id), name: row.name || '', phone: row.phone || '', notes: row.notes || '', createdAt: row.created_at || old.createdAt || new Date().toISOString(), updatedAt: row.updated_at || new Date().toISOString(), deletedAt: row.deleted_at || undefined });
        }
        payload.gestao_clients = [...map.values()];
        await lunaApi.saveSnapshot(token, payload);
      } else if (this.table === 'consultations') {
        const current = Array.isArray(payload.gestao_consultations) ? payload.gestao_consultations : [];
        const map = new Map(current.map((item: any) => [String(item?.id || ''), item]));
        for (const row of values) {
          const old: any = map.get(String(row.id)) || {};
          map.set(String(row.id), { ...old, ...row, id: String(row.id), clientId: row.client_id || old.clientId || '', clientName: row.client_name || old.clientName || '', serviceType: row.service_type || old.serviceType, intakeNotes: row.intake_notes || old.intakeNotes, scheduledAt: row.scheduled_at || old.scheduledAt, paymentPlan: row.payment_plan || old.paymentPlan, createdAt: row.created_at || old.createdAt || new Date().toISOString(), updatedAt: row.updated_at || new Date().toISOString(), deletedAt: row.deleted_at || undefined });
        }
        payload.gestao_consultations = [...map.values()];
        await lunaApi.saveSnapshot(token, payload);
      } else if (this.table === 'questions') {
        const consultations = Array.isArray(payload.gestao_consultations) ? payload.gestao_consultations : [];
        for (const row of values) {
          const parent = consultations.find((item: any) => String(item?.id || '') === String(row.consultation_id || ''));
          if (!parent) continue;
          const questions = Array.isArray(parent.questions) ? parent.questions : [];
          const index = questions.findIndex((item: any) => String(item?.id || '') === String(row.id));
          const next = { ...(index >= 0 ? questions[index] : {}), ...row, id: String(row.id), number: Number(row.question_number || 1), createdAt: row.created_at || new Date().toISOString(), updatedAt: row.updated_at || new Date().toISOString(), deletedAt: row.deleted_at || undefined };
          if (index >= 0) questions[index] = next; else questions.push(next);
          parent.questions = questions;
        }
        payload.gestao_consultations = consultations;
        await lunaApi.saveSnapshot(token, payload);
      } else {
        throw new Error(`Gravação compatível ainda não implementada para ${this.table}.`);
      }
      return { data: values, error: null };
    } catch (error) { return { data: null, error: authError(error) }; }
  }

  then<TResult1 = { data: any; error: any }, TResult2 = never>(
    onfulfilled?: ((value: { data: any; error: any }) => TResult1 | PromiseLike<TResult1>) | null,
    onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | null,
  ): Promise<TResult1 | TResult2> {
    return this.selectRows().then(onfulfilled, onrejected);
  }
}

const auth = {
  async getSession() {
    const session = readSession();
    return { data: { session }, error: null };
  },
  onAuthStateChange(callback: (event: string, session: LunaSession | null) => void) {
    listeners.add(callback);
    return { data: { subscription: { unsubscribe: () => listeners.delete(callback) } } };
  },
  async signInWithPassword(credentials: { email: string; password: string }) {
    try {
      const result = await lunaApi.login(credentials.email, credentials.password);
      const user: LunaUser = { ...result.user, organization: result.organization };
      const session: LunaSession = { access_token: result.access_token, token_type: 'Bearer', expires_at: Math.floor(Date.now() / 1000) + result.expires_in, user };
      localStorage.setItem(TOKEN_KEY, result.access_token);
      localStorage.setItem(SESSION_USER_KEY, JSON.stringify(user));
      emit('SIGNED_IN', session);
      return { data: { user, session }, error: null };
    } catch (error) { return { data: { user: null, session: null }, error: authError(error) }; }
  },
  async signOut() {
    const token = getToken();
    try { if (token) await lunaApi.logout(token); } catch (error) { console.warn('Logout Luna API', error); }
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(SESSION_USER_KEY);
    emit('SIGNED_OUT', null);
    return { error: null };
  },
};

export const lunaSqlClient = {
  auth,
  from: (table: string) => new LunaQueryBuilder(table),
};
