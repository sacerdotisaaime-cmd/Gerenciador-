import { lunaSqlClient } from './lunaSqlClient';
import { getPersistentRaw, setPersistentRaw } from './persistentStorage';

export const V13_STORAGE_KEYS = [
  'gestao_clients','gestao_consultations','gestao_purchases','gestao_suppliers',
  'gestao_stock_items','gestao_stock_movements','gestao_inventory','gestao_payables','gestao_loans',
  'gestao_overdrafts','gestao_household_sectors','gestao_household_categories',
  'gestao_quick_transactions','gestao_bank_accounts','gestao_reading_types',
  'gestao_future_purchases','gestao_notes','gestao_agenda','gestao_account_templates',
  'gestao_budgets','gestao_trash_consultations','gestao_reserves','gestao_investments','gestao_work_executions','gestao_trash','gestao_family_members','gestao_routine_templates','gestao_routine_logs','gestao_routine_settings','gestao_health_entries','gestao_cycle_entries','gestao_medications','gestao_medication_logs','gestao_routine_items','gestao_desfalques','gestao_work_types','gestao_sale_items','gestao_routine_notification_ids','currency-settings'
] as const;

type Snapshot = Record<string, unknown>;

export const LUNA_REMOTE_SNAPSHOT_UPDATED_EVENT = 'luna:remote-snapshot-updated';

const parse = (value: string | null): unknown => {
  if (!value) return [];
  try { return JSON.parse(value); } catch { return []; }
};

export const buildLocalSnapshot = (): Snapshot => {
  const snapshot: Snapshot = {};
  for (const key of V13_STORAGE_KEYS) snapshot[key] = parse(getPersistentRaw(key));
  return snapshot;
};

const itemTime = (item: any) => {
  const candidates = [item?.updatedAt, item?.createdAt, item?.deletedAt, item?.removedAt]
    .map((value) => value ? Date.parse(value) : 0)
    .filter((value) => Number.isFinite(value));
  return candidates.length ? Math.max(...candidates) : 0;
};

const mergeArray = (localValue: any, remoteValue: any): any[] => {
  const local = Array.isArray(localValue) ? localValue : [];
  const remote = Array.isArray(remoteValue) ? remoteValue : [];
  const byId = new Map<string, any>();
  const withoutId = new Map<string, any>();
  const keepWithoutId = (item: any) => {
    // Alguns módulos legados ainda possuem itens sem id. Evita duplicá-los
    // em cada sincronização; itens sem identidade não podem ser mesclados por versão.
    const key = JSON.stringify(item);
    if (!withoutId.has(key)) withoutId.set(key, item);
  };
  for (const item of remote) {
    if (item && typeof item === 'object' && item.id) byId.set(String(item.id), item);
    else keepWithoutId(item);
  }
  for (const item of local) {
    if (item && typeof item === 'object' && item.id) {
      const id = String(item.id);
      const old = byId.get(id);
      byId.set(id, !old || itemTime(item) >= itemTime(old) ? item : old);
    } else {
      keepWithoutId(item);
    }
  }
  return [...byId.values(), ...withoutId.values()];
};

const mergeConsultationRecord = (newer: any, older: any): any => {
  // A consulta é o agregado de consistência: quando uma versão mais nova
  // chega, suas listas aninhadas substituem as antigas. Fazer união cega aqui
  // ressuscitava fotos/áudios excluídos no outro dispositivo.
  const out = { ...(older || {}), ...(newer || {}) };
  for (const key of ['questions','photos','audios','intakePhotos','intakeAudios','relatedCharges','receivedObjects','sentObjects','termsInformedPhotos','termsInformedAudios','termsConsentPhotos','termsConsentAudios']) {
    if (newer && Object.prototype.hasOwnProperty.call(newer, key)) out[key] = newer[key];
    else if (older && Object.prototype.hasOwnProperty.call(older, key)) out[key] = older[key];
  }
  for (const key of Object.keys(older || {})) if (out[key] === undefined || out[key] === null || out[key] === '') out[key] = older[key];
  return out;
};

const mergeConsultationRecordArray = (localValue: any, remoteValue: any): any[] => {
  const local = Array.isArray(localValue) ? localValue : [];
  const remote = Array.isArray(remoteValue) ? remoteValue : [];
  const byId = new Map<string, any>();
  for (const item of [...remote, ...local]) {
    if (!item || typeof item !== 'object' || !item.id) continue;
    const id = String(item.id);
    const old = byId.get(id);
    if (!old) { byId.set(id, item); continue; }
    const a = itemTime(item), b = itemTime(old);
    byId.set(id, a >= b ? mergeConsultationRecord(item, old) : mergeConsultationRecord(old, item));
  }
  return [...byId.values()];
};

const mergeSnapshots = (local: Snapshot, remote: Snapshot): Snapshot => {
  const merged: Snapshot = {};
  for (const key of V13_STORAGE_KEYS) {
    if (key === 'currency-settings') {
      merged[key] = { ...((remote[key] && typeof remote[key] === 'object') ? remote[key] as object : {}), ...((local[key] && typeof local[key] === 'object') ? local[key] as object : {}) };
    } else {
      merged[key] = key === 'gestao_consultations' ? mergeConsultationRecordArray(local[key], remote[key]) : mergeArray(local[key], remote[key]);
    }
  }
  return applyLocalTrashTombstones(merged);
};

const TRASH_COLLECTIONS: Record<string, string> = {
  agenda: 'gestao_agenda', future_purchase: 'gestao_future_purchases', note: 'gestao_notes',
  budget: 'gestao_budgets', account_template: 'gestao_account_templates', supplier: 'gestao_suppliers',
  stock_item: 'gestao_stock_items', stock_movement: 'gestao_stock_movements', payable: 'gestao_payables',
  loan: 'gestao_loans', overdraft: 'gestao_overdrafts', bank_account: 'gestao_bank_accounts',
  quick_transaction: 'gestao_quick_transactions', inventory: 'gestao_inventory', desfalque: 'gestao_desfalques',
};

const applyTombstone = (snapshot: Snapshot, collection: string, id: unknown, deletedAt: string) => {
  if (!id || !Array.isArray(snapshot[collection])) return;
  const rows = snapshot[collection] as any[];
  const marker = { id: String(id), deletedAt, updatedAt: deletedAt, __lunaTombstone: true };
  const index = rows.findIndex((item) => String(item?.id || '') === String(id));
  if (index >= 0) rows[index] = { ...rows[index], ...marker };
  else rows.push(marker);
};

const applyLocalTrashTombstones = (snapshot: Snapshot): Snapshot => {
  const trash = Array.isArray(snapshot.gestao_trash) ? snapshot.gestao_trash as any[] : [];
  for (const item of trash) {
    const deletedAt = String(item?.deletedAt || item?.createdAt || new Date().toISOString());
    const payload = item?.payload || {};
    if (item?.removedAt) continue;
    if (item?.entityType === 'client_bundle') {
      const clientId = payload?.client?.id;
      applyTombstone(snapshot, 'gestao_clients', clientId, deletedAt);
      for (const consultation of Array.isArray(payload?.consultations) ? payload.consultations : []) {
        applyTombstone(snapshot, 'gestao_consultations', consultation?.id, deletedAt);
      }
    } else if (item?.entityType === 'consultation') {
      applyTombstone(snapshot, 'gestao_consultations', payload?.consultationId || payload?.id, deletedAt);
    } else if (item?.entityType === 'purchase_bundle') {
      applyTombstone(snapshot, 'gestao_purchases', payload?.purchase?.id, deletedAt);
      for (const movement of Array.isArray(payload?.movements) ? payload.movements : []) {
        applyTombstone(snapshot, 'gestao_stock_movements', movement?.id, deletedAt);
      }
    } else {
      const collection = TRASH_COLLECTIONS[String(item?.entityType || '')];
      if (collection) applyTombstone(snapshot, collection, payload?.id, deletedAt);
    }
  }
  return snapshot;
};

const hasRealLocalData = (snapshot: Snapshot) => {
  return V13_STORAGE_KEYS.some((key) => {
    const value = snapshot[key];
    return Array.isArray(value) && value.length > 0;
  });
};

export const writeSnapshotLocally = async (snapshot: Snapshot) => {
  const trashCollections = new Set(['gestao_trash', 'gestao_trash_consultations']);
  await Promise.all(V13_STORAGE_KEYS.map((key) => {
    const value = snapshot[key] ?? [];
    // Tombstones/removidos permanecem no payload enviado ao servidor, mas não
    // aparecem nas listas ativas nem na lixeira depois de restaurar/esvaziar.
    const localValue = Array.isArray(value)
      ? value.filter((item: any) => !item || typeof item !== 'object' || (
          !item.__lunaTombstone && !item.removedAt && (trashCollections.has(key) || !item.deletedAt)
        ))
      : value;
    return setPersistentRaw(key, JSON.stringify(localValue));
  }));
};

export const syncFullSqlSnapshot = async (userId: string, preferRemote = false) => {
  let local = buildLocalSnapshot();
  const project = (snapshot: Snapshot): Snapshot => Object.fromEntries(
    V13_STORAGE_KEYS.map((key) => [key, snapshot[key] ?? (key === 'currency-settings' ? {} : [])]),
  );

  // Se outro dispositivo gravar ao mesmo tempo, refazemos a leitura e a mesclagem
  // em vez de sobrescrever o snapshot que acabou de chegar.
  for (let attempt = 0; attempt < 3; attempt++) {
    const { data: remoteRow, error: readError } = await lunaSqlClient
      .from('app_snapshots')
      .select('user_id,payload,updated_at')
      .eq('user_id', userId)
      .maybeSingle();
    if (readError) throw readError;

    const remote = (remoteRow?.payload || {}) as Snapshot;
    const merged = preferRemote || !hasRealLocalData(local)
      ? remote
      : mergeSnapshots(local, remote);

    await writeSnapshotLocally(merged);

    const localChanged = JSON.stringify(project(local)) !== JSON.stringify(project(merged));
    const remoteChanged = JSON.stringify(project(remote)) !== JSON.stringify(project(merged));

    // Notifica imediatamente a interface quando o pull remoto alterou o armazenamento.
    if (localChanged && typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent(LUNA_REMOTE_SNAPSHOT_UPDATED_EVENT, {
        detail: { source: 'remote', updatedAt: remoteRow?.updated_at || new Date().toISOString() }
      }));
    }

    if (remoteChanged && hasRealLocalData(merged)) {
      const { error } = await lunaSqlClient.from('app_snapshots').upsert({
        user_id: userId, payload: merged, updated_at: new Date().toISOString()
      }, { onConflict: 'user_id' });
      if (error) {
        if ((error as any).status === 409 || (error as any).code === 'SYNC_CONFLICT') {
          if (attempt < 2) { local = buildLocalSnapshot(); continue; }
        }
        throw error;
      }
    }

    return { restored: localChanged, uploaded: remoteChanged, changed: localChanged || remoteChanged, source: 'remote' as const };
  }
  throw new Error('Não foi possível concluir a sincronização após três tentativas. Confira a conexão e tente novamente.');
};


export const resetSqlSnapshotKeys = async (userId: string, keys: string[]) => {
  const { data: remoteRow, error: readError } = await lunaSqlClient
    .from('app_snapshots')
    .select('user_id,payload')
    .eq('user_id', userId)
    .maybeSingle();
  if (readError) throw readError;

  const payload: Snapshot = { ...(remoteRow?.payload || buildLocalSnapshot()) };
  for (const key of keys) payload[key] = key === 'currency-settings'
    ? { paypalFeePercent: 0, wiseFeePercent: 0, otherFeePercent: 0 }
    : [];

  const { error } = await lunaSqlClient.from('app_snapshots').upsert({
    user_id: userId,
    payload,
    updated_at: new Date().toISOString(),
  }, { onConflict: 'user_id' });
  if (error) throw error;
  return payload;
};

export const updateSqlSnapshot = async (userId: string, updater: (payload: Snapshot) => Snapshot) => {
  const { data: remoteRow, error: readError } = await lunaSqlClient
    .from('app_snapshots')
    .select('user_id,payload')
    .eq('user_id', userId)
    .maybeSingle();
  if (readError) throw readError;
  const base = (remoteRow?.payload || buildLocalSnapshot()) as Snapshot;
  const payload = updater({ ...base });
  const { error } = await lunaSqlClient.from('app_snapshots').upsert({
    user_id: userId,
    payload,
    updated_at: new Date().toISOString(),
  }, { onConflict: 'user_id' });
  if (error) throw error;
  return payload;
};

export const pushFullSqlSnapshot = async (userId: string) => {
  // Não enviar somente o estado local: o Web pode ter criado/alterado registros
  // desde a última sincronização do Android. Primeiro lemos e mesclamos o snapshot
  // do servidor; a escrita só ocorre depois dessa reconciliação.
  return syncFullSqlSnapshot(userId, false);
};
