# Correção de atualização visual da sincronização Luna Web ↔ Android

## Causa encontrada

A API Luna e a camada de compatibilidade do Android já leem e gravam o snapshot central. O sincronizador Android escrevia dados recebidos do MySQL em localStorage/IndexedDB, mas o React mantinha os arrays dos módulos (por exemplo, `quickTransactions`) em memória. O polling fazia o download, porém a tela não recebia setters para refletir os dados recém-gravados até a próxima hidratação completa.

## Correção aplicada

- `supabaseSync.ts`: dispara `luna:remote-snapshot-updated` quando um merge remoto altera os dados locais.
- `App.tsx`: escuta o evento e recarrega do armazenamento persistente os arrays dos módulos, incluindo `gestao_quick_transactions` (entradas/saídas), compras, contas, agenda, estoque, consulentes, atendimentos, trabalhos, vendas, rotinas e demais coleções V185.
- Sincronização automática passa de 15 para 10 segundos e também roda ao voltar para o aplicativo, recuperar a rede ou receber foco.
- O status de sincronização passa a exibir quando os dados chegaram do Web ou quando há uma falha de sincronização.
- `@capacitor/barcode-scanner` permanece fixado em `2.2.0`, compatível com Capacitor 7.

## Validação

- Sintaxe TypeScript/TSX transpilada sem erros de parser nas alterações.
- O `package.json` aponta para Barcode Scanner 2.2.0.
- Ainda é necessária a compilação Android no GitHub Actions e o teste real com uma nova saída criada no Web.
