# Correção da sincronização Web → Android

## Causa identificada
- Ao abrir novamente o processo Android, o fluxo apenas carregava o armazenamento local e pulava o snapshot remoto.
- A sincronização de fundo bloqueava requisições quando `navigator.onLine` retornava falso, mesmo que a API na LAN estivesse acessível.
- As consultas SQL confirmaram que Web e Android usam a mesma organização e que os dois lançamentos de saída estão gravados.

## Alterações
- Ao reabrir o app, carrega os dados locais rapidamente e busca o snapshot remoto em segundo plano.
- Ao concluir a leitura remota, reidrata os estados React para atualizar os módulos, inclusive o financeiro.
- A sincronização de fundo tenta imediatamente, a cada 10 segundos, ao voltar ao foco e no evento online.
- Remove `navigator.onLine` como condição bloqueadora; erros reais são tratados e registrados no status.
- Inclui log de diagnóstico sem registrar token ou senha.

## Segurança
Mantém a mesclagem `syncFullSupabaseSnapshot(..., false)`, sem sobrescrita cega pelo servidor. Não altera o banco nem a API PHP.

## Validação
ZIP íntegro e trechos alterados conferidos. Ainda é necessária compilação no GitHub Actions e teste real no aparelho.
