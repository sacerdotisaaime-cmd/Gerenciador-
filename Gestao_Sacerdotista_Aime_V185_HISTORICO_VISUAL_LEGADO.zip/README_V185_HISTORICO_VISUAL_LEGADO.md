# V185 — Histórico visual legado restaurado

Base: V183, que comprovadamente voltou a renderizar registros recuperados.

A recuperação local/remota foi preservada. O componente usado para desenhar cada registro foi substituído pela estrutura visual do histórico antigo (V158), com normalização defensiva apenas na cópia de renderização.

Inclui perguntas, notas/respostas, fotos, áudios, parcelamento, trabalhos, vendas, termos, objetos, execução e a ação “Ver ficha completa”. A janela de diagnóstico/debug não é exibida na interface.

Nenhum dado salvo é apagado ou reescrito durante a renderização.
