# V181 — Histórico: correção da camada de exibição

O V180 comprovou que a recuperação encontrava atendimentos antigos, mas a tela continuava vazia. Esta versão trata os registros recuperados como fonte visual direta, evita depender de um segundo ciclo de hidratação de `consultations`, usa execuções recuperadas ao abrir um trabalho e exibe a contagem final pronta para exibição.

O diagnóstico continua ativo.
