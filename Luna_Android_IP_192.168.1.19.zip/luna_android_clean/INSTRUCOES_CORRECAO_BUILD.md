# Correção do build Android Luna

Esta correção remove a cópia duplicada `v174root` do ZIP e ajusta o workflow para selecionar explicitamente `app/luna_android_clean`.

O workflow original foi preservado integralmente nos demais passos: plugin nativo PermissionBridge, backup, permissões, assinatura, geração e validação do APK.

## Arquivos
- `Luna_Android_Entrada_Comercial_MySQL_Etapa2_CORRIGIDO.zip`: substitui o ZIP atual no repositório, mantendo o mesmo nome de destino.
- `build-android-release.yml`: substitui o arquivo `.github/workflows/build-android-release.yml` no repositório.

## Aplicação no GitHub
1. Substitua o ZIP atual pelo ZIP corrigido, na raiz do repositório.
2. Abra `.github/workflows/build-android-release.yml` e substitua seu conteúdo pelo arquivo `build-android-release.yml` deste pacote.
3. Faça commit das duas alterações na branch `main`.
4. Rode o workflow manualmente.
5. O log deve mostrar `Projeto validado: app/luna_android_clean`.
6. O workflow agora falha se detectar uma pasta de projeto duplicada ou se `src/main.tsx` não iniciar `LunaEntry`.

Não exclua os secrets de assinatura nem altere o banco de dados.

Observação: esta correção garante que o APK seja construído a partir da raiz correta do projeto Luna. Ela não declara todos os módulos do sistema antigo já sincronizados com MySQL; isso continua dependendo de integração e homologação por módulo.
