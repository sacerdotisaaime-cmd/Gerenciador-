# V149 — NFC-e/QR Code corrigido

Correções principais desta versão:

- Atualizado `@capacitor/barcode-scanner` para a linha 2.2.x compatível com Capacitor 7.
- Scanner usa as enums oficiais do plugin, câmera traseira e ZXing.
- Permissão de câmera é solicitada pelo plugin Camera antes de abrir o scanner.
- Leitura aceita o retorno oficial `ScanResult`.
- Extração da chave NF-e/NFC-e aceita chave de 44 dígitos e o parâmetro `p=` usado no QR da NFC-e de SP.
- Consulta por link preserva o link original do QR e também tenta a consulta pública pela chave.
- Parser de HTML foi reforçado para o formato de tabela do DANFE NFC-e de São Paulo.
- XML continua sendo a rota de importação mais confiável quando a consulta pública da SEFAZ não entrega os itens automaticamente.
- Workflow Android foi atualizado para não voltar a fixar o scanner na versão 2.0.4.

## Observação importante

A SEFAZ-SP disponibiliza consulta pública por chave e QR Code, e o DANFE NFC-e completo pode conter os itens. Porém, a página pública pode exigir mecanismos de proteção ou não entregar o conteúdo estruturado a uma requisição automática. Nesses casos, a chave/link continua sendo preservada e a importação por XML permanece disponível.
