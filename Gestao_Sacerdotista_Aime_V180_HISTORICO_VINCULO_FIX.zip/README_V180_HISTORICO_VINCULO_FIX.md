# V180 — Histórico: correção do vínculo visual dos registros recuperados

## Causa identificada na V179
O diagnóstico mostrava que os atendimentos antigos eram encontrados no snapshot, porém os registros recuperados podiam continuar com um `clientId` legado. A tela do histórico filtrava novamente pela identidade atual da ficha e descartava esses registros, fazendo parecer que a recuperação não tinha funcionado.

## Correção
A camada de recuperação agora vincula os registros recuperados ao `clientId` atual da ficha, sem alterar o `id` do atendimento nem apagar perguntas, mídias, cobranças ou demais campos. A mesma normalização é aplicada às vendas e execuções recuperadas.

O diagnóstico registra explicitamente a vinculação ao `clientId` atual.
