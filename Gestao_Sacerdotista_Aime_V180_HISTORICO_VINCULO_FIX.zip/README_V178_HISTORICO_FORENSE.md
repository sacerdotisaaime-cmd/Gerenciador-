# V178 — Histórico Forense / IDs Legados

Correção baseada no diagnóstico da V177: o aparelho tinha 14 consulentes e 14 atendimentos, mas apenas 1 atendimento correspondia ao ID atual da consulente. A V178 recupera IDs antigos também a partir de `gestao_clients` presente no snapshot do Supabase, além de ampliar os campos de identidade (client/consultant/consulente/customer/recipient). Isso permite vincular consultas históricas que ficaram com IDs antigos após migração.

O diagnóstico continua ativo e registra quantos clientes existem no snapshot e quais IDs legados foram associados antes de filtrar as consultas.
