# V179 — Histórico Forense: correção do vínculo por IDs legados

Esta versão corrige duas falhas identificadas pelo diagnóstico da V178:

1. `addMatchingLegacyClientIds` referenciava `clientName`/`clientPhone` fora do escopo, causando `clientName is not defined` e interrompendo a recuperação remota.
2. Os atendimentos do snapshot eram filtrados apenas pelo `historyClientMatches`, sem usar os IDs legados descobertos a partir da lista de clientes do snapshot. Agora a reconstrução usa `sameIdentity(..., allowedClientIds)` para recuperar registros ligados a IDs antigos.

Vendas e execuções do snapshot também usam o mesmo conjunto de IDs legados.

O diagnóstico permanece ativo e registra quantos atendimentos do snapshot foram vinculados pelos IDs legados.
