# V177 — Histórico local-first + diagnóstico

Esta versão corrige a estratégia de recuperação do Histórico dos Consulentes.

## Mudança principal
A recuperação agora começa pelo armazenamento persistente local do aparelho, usando a mesma camada que o aplicativo já usa para guardar os dados (`persistentStorage`, com IndexedDB para dados grandes/mídias e localStorage como fallback).

A busca local considera:
- ID atual do consulente;
- IDs antigos de fichas com o mesmo nome/telefone;
- nome normalizado;
- telefone normalizado;
- `gestao_consultations`;
- `gestao_quick_transactions`;
- `gestao_work_executions`.

Somente depois da recuperação local é feita a tentativa de complementar os dados pelo Supabase.

## Diagnóstico
A tela do Histórico agora mostra um painel `🛠️ Diagnóstico do histórico` com:
- quantidade de registros encontrados localmente;
- IDs candidatos do consulente;
- quantidade recuperada de atendimentos/vendas/execuções;
- quantidade encontrada no snapshot remoto;
- quantidade de perguntas remotas;
- erros específicos;
- timeout remoto de 12 segundos.

O objetivo é diferenciar claramente:
1. dados inexistentes no armazenamento local;
2. dados locais existentes, mas não vinculados ao consulente atual;
3. dados remotos existentes;
4. falha de acesso ao Supabase;
5. timeout de rede.

Nenhum dado é apagado durante a recuperação.
