# V143 — Importação automática de NF-e/NFC-e

## Auditoria e correção

O fluxo anterior apenas armazenava o QR Code/link e abria a consulta da SEFAZ. Não havia uma rotina que consultasse a página pública e transformasse os dados da nota em itens da compra.

A V143 adiciona:
- leitura do QR Code da NF-e/NFC-e;
- entrada de URL da consulta;
- consulta nativa no Android, evitando o bloqueio CORS típico do navegador;
- extração de chave de acesso;
- extração de estabelecimento/CNPJ/data/valor final quando disponíveis;
- extração de itens (descrição, quantidade, unidade, preço unitário e total) a partir de XML ou tabelas HTML;
- preenchimento automático do cadastro da compra;
- criação automática do estabelecimento quando ele ainda não existe;
- preservação do valor final oficial da nota quando disponível;
- botão para consultar/importar novamente;
- abertura externa da URL pelo Android quando necessário.

A compra não é gravada silenciosamente: os dados importados aparecem na tela para conferência antes de clicar em **Salvar compra**.

## Limitação importante
A SEFAZ define que o QR Code da NFC-e leva à consulta pública, que apresenta os itens da mercadoria. A estrutura visual dessas páginas varia entre UFs e pode haver CAPTCHA/bloqueio. Quando a consulta retornar uma página que não exponha os itens, o aplicativo informa isso em vez de registrar dados incompletos.
