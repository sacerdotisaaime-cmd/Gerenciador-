import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { supabaseClient } from "./supabase";
import { Camera, CameraResultType, CameraSource } from "@capacitor/camera";
import { Share } from "@capacitor/share";
import { Filesystem, Directory } from "@capacitor/filesystem";
import { Contacts } from "@capacitor-community/contacts";
import { VoiceRecorder } from "capacitor-voice-recorder";
import { Capacitor, registerPlugin } from "@capacitor/core";
import { LocalNotifications } from "@capacitor/local-notifications";
import { App as CapacitorApp } from "@capacitor/app";
import { CapacitorBarcodeScanner, CapacitorBarcodeScannerTypeHint } from "@capacitor/barcode-scanner";
import { zipSync, unzipSync, strToU8, strFromU8 } from "fflate";
import { syncFullSupabaseSnapshot, pushFullSupabaseSnapshot, resetSupabaseSnapshotKeys, updateSupabaseSnapshot, V13_STORAGE_KEYS } from "./supabaseSync";
import { InventoryModule, normalizeInventoryItem } from "./InventoryModule";
import type { InventoryItem } from "./InventoryModule";
import { OrganizationWorkspace } from "./OrganizationWorkspace";

type PermissionBridgePlugin = {
  requestContacts: () => Promise<{ granted: boolean; state: string }>;
  requestMicrophone: () => Promise<{ granted: boolean; state: string }>;
  requestCamera?: () => Promise<{ granted: boolean; state: string }>;
  openOverlaySettings?: () => Promise<void>;
  openAlarmSettings?: () => Promise<void>;
  getSpecialPermissionStates?: () => Promise<{ overlay: boolean; exactAlarm: boolean }>;
  openSettings: () => Promise<void>;
  getPermissionStates?: () => Promise<{ contacts: string; microphone: string }>;
  savePhotoToGallery?: (data: string, fileName: string) => Promise<{ granted: boolean }>;
};

const PermissionBridge = registerPlugin<PermissionBridgePlugin>("PermissionBridge");
/* =========================================================
TIPOS
========================================================= */
type ClientSource = "indication" | "instagram" | "facebook" | "facebook_comment" | "search" | "whatsapp" | "content" | "active_prospecting" | "other";
type Client = {
id: string;
name: string;
phone: string;
birthDate?: string;
cpf?: string;
address?: { street?: string; number?: string; complement?: string; neighborhood?: string; city?: string; state?: string; postalCode?: string; country?: string };
source?: ClientSource;
sourceReferrerClientId?: string;
sourceDetails?: string;
country?: string;
notes?: string;
createdAt?: string;
updatedAt?: string;
deletedAt?: string;
avatarPhoto?: string;
audios?: AudioItem[];
};
type AudioItem = {
id: string;
name: string;
data: string;
duration: number;
createdAt: string;
updatedAt?: string;
deletedAt?: string;
};
type PhotoItem = {
id: string;
name: string;
data: string;
createdAt: string;
updatedAt?: string;
deletedAt?: string;
note?: string;
audios: AudioItem[];
};
type QuestionBillingMode = "included" | "paid" | "pending" | "installments" | "free" | "desfalque";
const installmentReceivedAmount = (row: Installment) => {
  if (typeof row.receivedAmount === "number") return Math.max(0, Math.min(row.amount, row.receivedAmount));
  return row.status === "received" ? Math.max(0, row.amount) : 0;
};
const installmentOpenAmount = (row: Installment) => Math.max(0, Number(row.amount || 0) - installmentReceivedAmount(row));
const getInstallmentPaymentState = (row: Installment) => {
  const originalAmount = Math.max(0, Number(row.amount || 0));
  const receivedAmount = installmentReceivedAmount(row);
  const openAmount = Math.max(0, originalAmount - receivedAmount);
  const status = row.status === "defaulted" ? "defaulted" : openAmount <= 0.009 ? "paid" : receivedAmount > 0.009 ? "partial" : row.status === "overdue" ? "overdue" : "pending";
  return { originalAmount, receivedAmount, openAmount, status, payments: Array.isArray(row.payments) ? row.payments : [] };
};
const installmentPaymentDateLines = (row: Installment) => {
  const payments = Array.isArray(row.payments) ? row.payments.filter(p => p && p.date) : [];
  if (payments.length) return payments;
  if (row.receivedAt) return [{ id: `legacy-date-${row.id}`, amount: installmentReceivedAmount(row), date: row.receivedAt, paymentMethod: row.paymentMethod }];
  return [];
};
const installmentPaymentSummary = (row: Installment) => {
  const payments = installmentPaymentDateLines(row);
  if (!payments.length) return null;
  const received = payments.reduce((sum, p) => sum + Math.max(0, Number(p.amount || 0)), 0);
  const paid = received >= Number(row.amount || 0) - 0.01 || row.status === "received";
  if (paid) return `Pago integral em ${formatDateTime(payments[payments.length - 1].date)}`;
  return payments.map(p => `Pagamento parcial: ${formatMoney(p.amount)} em ${formatDateTime(p.date)}`).join(" · ");
};
const getPaymentStatusValue = (consultation: any): "paid" | "partial" | "pending" => {
  const rows = consultation?.paymentPlan?.installments || [];
  if (rows.length) {
    const received = rows.reduce((sum:number,row:Installment)=>sum+installmentReceivedAmount(row),0);
    const total = rows.reduce((sum:number,row:Installment)=>sum+Math.max(0,Number(row.amount||0)),0);
    if (total > 0 && received >= total - 0.01) return "paid";
    if (received > 0) return "partial";
    return "pending";
  }
  return consultation?.paid ? "paid" : "pending";
};
const consultationReceivedAmountValue = (item:any) => {
  if (item?.billingMode === "free") return 0;
  if (item?.paymentPlan?.installments?.length) return item.paymentPlan.installments.reduce((sum:number,row:Installment)=>sum+installmentReceivedAmount(row),0);
  return item?.paid ? Math.max(0, Number(item?.value || 0) - Number(item?.paymentPlan?.fee || 0)) : 0;
};
const paymentMethodLabelText = (method?: PaymentMethod) => ({pix:"Pix",paypal:"PayPal",wise:"Wise",cash:"Dinheiro",credit:"Cartão de crédito",debit:"Cartão de débito",transfer:"Transferência",other:"Outra"}[method || "other"] || method || "—");

type Question = {
id: string;
number: number;
text: string;
notes: string;
photos: PhotoItem[];
audios: AudioItem[];
responseText?: string;
responsePhotos?: PhotoItem[];
responseAudios?: AudioItem[];
createdAt: string;
updatedAt?: string;
deletedAt?: string;
completed: boolean;
billingMode?: QuestionBillingMode;
value?: number;
potentialValue?: number;
paymentDate?: string;
paymentMethod?: PaymentMethod;
paymentPlan?: PaymentPlan;
shortfall?: number;
currency?: CurrencyCode;
discount?: number;
  packageId?: string;
  packageTotal?: number;
  packageQuestionCount?: number;
  packageRole?: "total" | "included";
  relatedWorkId?: string;
  relatedWorkTitle?: string;
  workQuestionKind?: "benefit" | "paid" | "courtesy";
  workQuestionNumber?: number;
};
type WorkTemplateItem = { stockItemId: string; quantity: number };
type WorkType = { id: string; name: string; active: boolean; prices?: CurrencyPrices; standardItems?: WorkTemplateItem[]; createdAt: string; updatedAt?: string; deletedAt?: string; };
type WorkObject = { id: string; name: string; referenceValue?: number; notes?: string; createdAt: string; address?: string; postalCode?: string; country?: string; };
type WorkExecution = { id: string; consultationId: string; chargeId?: string; workTypeId?: string; workTitle: string; clientName: string; executedAt: string; executedDate?: string; totalCost: number; estimatedSavings: number; notes?: string; items: Array<{stockItemId:string; quantity:number; usage:"new"|"reused"; unitCost:number; cost:number}>; externalItems?: Array<{name:string; quantity:number; unit:string; cost:number; notes?:string}>; };
type SaleItem = { id: string; name: string; description: string; price: number; prices?: CurrencyPrices; category: string; active: boolean; createdAt: string; updatedAt?: string; deletedAt?: string; };
type RelatedCharge = {
  id: string;
  kind: "work" | "sale";
  title: string;
  amountBRL: number;
  originalAmount: number;
  currency: CurrencyCode;
  currencyRate: number;
  billingMode?: "paid" | "pending" | "installments" | "free" | "desfalque";
  paymentPlan?: PaymentPlan;
  potentialAmount?: number;
  workTypeId?: string;
  workTypeName?: string;
  saleItemId?: string;
  saleItemName?: string;
  budgetId?: string;
  scheduledAt?: string;
  status?: "approved" | "scheduled" | "in_progress" | "completed" | "cancelled" | "postponed";
  shippingEnabled?: boolean;
  shippingMethod?: "uber" | "correios" | "retirada" | "outro";
  shippingScheduledAt?: string;
  shippingUber?: number;
  shippingUberSpent?: boolean;
  shippingUberSpentAmount?: number;
  shippingRecipientName?: string;
  shippingPhone?: string;
  shippingAddress?: string;
  shippingZipCode?: string;
  shippingCity?: string;
  shippingState?: string;
  photos: PhotoItem[];
  audios: AudioItem[];
  receivedObjects?: WorkObject[];
  sentObjects?: WorkObject[];
  notes: string;
  saleStatus?: "approved" | "awaiting_confection" | "in_confection" | "awaiting_shipping" | "shipped" | "delivered" | "cancelled";
  priority?: number;
  createdAt?: string;
  updatedAt?: string;
  deletedAt?: string;
};
type Consultation = {
id: string;
clientId: string;
clientName: string;
title: string;
value: number;
paid: boolean;
paymentDate: string;
createdAt: string;
status: "active" | "standby" | "scheduled" | "completed" | "cancelled";
workStatus?: "approved" | "scheduled" | "in_progress" | "completed" | "cancelled" | "postponed";
questions: Question[];
intakeNotes?: string;
intakePhotos?: PhotoItem[];
intakeAudios?: AudioItem[];
serviceType?: "consultation" | "work" | "sale" | "other";
paymentPlan?: PaymentPlan;
paymentMethod?: PaymentMethod;
currency?: CurrencyCode;
currencyRate?: number;
scheduledAt?: string;
priority?: number;
billingMode?: "paid" | "pending" | "installments" | "free";
potentialValue?: number;
shortfall?: number;
linkedWorkId?: string;
activityType?: "main" | "reading" | "work_done" | "free_support";
preWorkReading?: boolean;
preWorkWorkTypeId?: string;
preWorkWorkTitle?: string;
budgetId?: string;
workTypeId?: string;
workTypeName?: string;
saleItemId?: string;
saleItemName?: string;
photos?: PhotoItem[];
audios?: AudioItem[];
shippingEnabled?: boolean;
shippingMethod?: "uber" | "correios" | "retirada" | "outro";
shippingScheduledAt?: string;
shippingUber?: number;
shippingUberSpent?: boolean;
shippingUberSpentAmount?: number;
shippingCorreios?: number;
shippingRecipientName?: string;
shippingPhone?: string;
shippingAddress?: string;
shippingZipCode?: string;
shippingCity?: string;
shippingState?: string;
relatedCharges?: RelatedCharge[];
receivedObjects?: WorkObject[];
sentObjects?: WorkObject[];
relatedWorkId?: string;
  saleStatus?: "approved" | "awaiting_confection" | "in_confection" | "awaiting_shipping" | "shipped" | "delivered" | "cancelled";
updatedAt?: string;
deletedAt?: string;
};
type ReadingType = {
id: string;
name: string;
questions: number;
active: boolean;
prices?: CurrencyPrices;
updatedAt?: string;
deletedAt?: string;
};
type FinanceArea = "home" | "work";
type SupplierType =
| "market"
| "store"
| "restaurant"
| "service"
| "other";
type Supplier = {
id: string;
name: string;
type: SupplierType;
phone: string;
document: string;
notes: string;
area: FinanceArea;
sectorId: string;
categoryIds: string[];
active: boolean;
updatedAt?: string;
deletedAt?: string;
};
type QuickExpenseItem = {
id: string;
name: string;
quantity: number;
unit: string;
unitPrice: number;
total: number;
sectorId: string;
categoryId: string;
notes: string;
};
type HouseholdSector = {
id: string;
name: string;
description: string;
active: boolean;
};
type HouseholdCategory = {
id: string;
sectorId: string;
name: string;
active: boolean;
};
type PurchaseItem = {
id: string;
name: string;
quantity: number;
unit: string;
unitPrice: number;
total: number;
destination: FinanceArea;
sectorId: string;
categoryId: string;
stockItem: boolean;
notes: string;
};
type Purchase = {
id: string;
supplierId: string;
supplierName: string;
date: string;
total: number;
source: "manual" | "nfe_qr";
qrCode: string;
accessKey: string;
items: PurchaseItem[];
notes: string;
createdAt: string;
updatedAt?: string;
deletedAt?: string;
};
type CurrencyCode = "BRL" | "EUR" | "USD" | "GBP";
type CurrencyPrices = Record<CurrencyCode, number>;

const emptyCurrencyPrices = (): CurrencyPrices => ({ BRL: 0, EUR: 0, USD: 0, GBP: 0 });
const normalizeCurrencyPrices = (prices?: Partial<Record<CurrencyCode, number>>, legacyBRL = 0): CurrencyPrices => ({
  BRL: Number.isFinite(Number(prices?.BRL)) ? Math.max(0, Number(prices?.BRL)) : Math.max(0, Number(legacyBRL) || 0),
  EUR: Number.isFinite(Number(prices?.EUR)) ? Math.max(0, Number(prices?.EUR)) : 0,
  USD: Number.isFinite(Number(prices?.USD)) ? Math.max(0, Number(prices?.USD)) : 0,
  GBP: Number.isFinite(Number(prices?.GBP)) ? Math.max(0, Number(prices?.GBP)) : 0,
});
const currencyList: CurrencyCode[] = ["BRL", "EUR", "USD", "GBP"];

type CurrencySettings = {
  paypalFeePercent: number;
  wiseFeePercent: number;
  otherFeePercent: number;
};
type PaymentMethod =
| "pix"
| "credit"
| "debit"
| "cash"
| "transfer"
| "combined"
| "paypal"
| "wise"
| "other";
type InstallmentPayment = { id: string; amount: number; date: string; paymentMethod: PaymentMethod; };
type Installment = {
id: string;
number: number;
amount: number;
dueDate: string;
receivedAmount?: number;
payments?: InstallmentPayment[];
postponedFrom?: string;
status: "pending" | "received" | "defaulted" | "overdue";
paymentMethod: PaymentMethod;
receivedAt: string;
lastPaymentAt?: string;
};
type PaymentPlan = {
id: string;
/** Valor original cadastrado no atendimento. */
originalTotal?: number;
/** Valor total efetivamente contratado no parcelamento. */
total: number;
/** Acréscimo cobrado pelo parcelamento. */
surcharge?: number;
fee?: number;
type: "full" | "installments";
installments: Installment[];
};
type InstallmentDraft = {
id: string;
amount: string;
dueDate: string;
};
type QuickTransactionType = "income" | "expense" | "sale";
type QuickTransaction = {
id: string;
type: QuickTransactionType;
area: FinanceArea;
amount: number;
source: string;
supplierId?: string;
supplierName?: string;
sectorId?: string;
categoryId?: string;
items?: QuickExpenseItem[];
description: string;
clientId: string;
clientName: string;
stockItemId: string;
quantity: number;
paymentMethod: PaymentMethod;
currency?: CurrencyCode;
currencyRate?: number;
grossAmount?: number;
paymentStatus?: "received" | "pending";
fee?: number;
date: string;
createdAt: string;
updatedAt?: string;
deletedAt?: string;
};
type BankAccount = {
id: string;
bank: string;
area: FinanceArea;
balance: number;
overdraftLimit: number;
overdraftInterestRate: number;
active: boolean;
updatedAt?: string;
deletedAt?: string;
};
type StockItem = {
id: string;
name: string;
area: FinanceArea;
quantity: number;
unit: string;
minimumQuantity: number;
averageCost: number;
category: string;
active: boolean;
notes: string;
updatedAt?: string;
deletedAt?: string;
};
type StockMovement = {
id: string;
stockItemId: string;
type:
| "entry"
| "consumption"
| "transfer_in"
| "transfer_out"
| "adjustment"
| "loss";
quantity: number;
unitCost: number;
date: string;
areaFrom?: FinanceArea;
areaTo?: FinanceArea;
referenceType?: "purchase" | "spell" | "consultation" | "manual" | "transfer" | "work_execution";
referenceId?: string;
notes: string;
updatedAt?: string;
deletedAt?: string;
};
type PayableAccount = {
id: string; description: string; area: FinanceArea; supplierId: string; amount: number; dueDate: string; status: "pending" | "paid" | "overdue"; paymentMethod: PaymentMethod; notes: string; recurrenceType?: "none" | "recurring" | "fixed"; recurrenceCount?: number; recurrenceNumber?: number; recurrenceGroupId?: string; recurrenceId?: string; recurrenceKey?: string; isVariable?: boolean; originalAmount?: number; interestAmount?: number; fineAmount?: number; paidAmount?: number; paidAt?: string; postponedFrom?: string; updatedAt?: string; deletedAt?: string;
};
type LoanInstallment = {
  id: string; number: number; dueDate: string; amount: number; principalAmount: number; interestAmount: number; status: "pending" | "paid" | "overdue"; paidAt?: string; paidAmount?: number; lateInterest?: number; lateFine?: number;
};
type Loan = {
id: string; name: string; area: FinanceArea; principal: number; interestRate: number; installments: number; paidInstallments: number; nextDueDate: string; notes: string; totalRepayable?: number; balanceDue?: number; installmentAmount?: number; installmentSchedule?: LoanInstallment[]; createdAt?: string; updatedAt?: string; deletedAt?: string;
};
type Overdraft = {
id: string;
bank: string;
area: FinanceArea;
limit: number;
used: number;
interestRate: number;
notes: string;
updatedAt?: string;
deletedAt?: string;
};
type FuturePurchasePriority = "low" | "medium" | "high" | "urgent";
type FuturePurchaseTimeframe = "today" | "7days" | "30days" | "90days" | "later";
type FuturePurchase = {
  id: string;
  title: string;
  description: string;
  link: string;
  area: FinanceArea;
  sectorId: string;
  priority: FuturePurchasePriority;
  timeframe: FuturePurchaseTimeframe;
  targetDate: string;
  completed: boolean;
  clientId?: string;
  createdAt: string;
updatedAt?: string;
deletedAt?: string;
};
type NoteItem = {
  id: string;
  title: string;
  content: string;
  createdAt: string;
  updatedAt?: string;
deletedAt?: string;
};
type DailyActivity = {
  id: string;
  date: string;
  kind: string;
  title: string;
  subtitle: string;
  amount?: number;
  details: string[];
  clientId?: string;
};
type AgendaCategory = "family" | "work" | "home";
type AgendaItem = {
  id: string;
  title: string;
  description: string;
  date: string;
  time: string;
  category: AgendaCategory;
  notify: boolean;
  completed: boolean;
  clientId?: string;
  createdAt: string;
updatedAt?: string;
deletedAt?: string;
relatedEntityType?: "consultation" | "work" | "reading" | "sale";
relatedEntityId?: string;
priority?: number;
};
type FamilyMember = {
  id: string;
  name: string;
  role: "adult" | "child";
  active: boolean;
  createdAt: string;
  updatedAt?: string;
};
type RoutineChecklistItem = { id: string; title: string; };
type RoutineTemplate = {
  id: string;
  title: string;
  area: "home" | "work";
  category: string;
  responsibleId: string;
  participantIds: string[];
  days: number[];
  time: string;
  priority: "low" | "medium" | "high" | "urgent";
  kind: "task" | "timer";
  durationMinutes?: number;
  checklist: RoutineChecklistItem[];
  notify: boolean;
  notifyBeforeMinutes: number;
  active: boolean;
  createdAt: string;
  updatedAt?: string;
};
type RoutineLog = {
  id: string;
  routineId: string;
  date: string;
  status: "pending" | "started" | "completed" | "skipped";
  startedAt?: string;
  completedAt?: string;
  checklistDoneIds?: string[];
  notes?: string;
  updatedAt: string;
};
type HealthEntry = {
  id: string;
  memberId: string;
  date: string;
  time: string;
  mood: "very-good" | "good" | "neutral" | "low" | "bad" | "tired" | "unwell";
  event: "normal" | "unwell" | "rest" | "unable-to-work" | "other";
  note: string;
  createdAt: string;
};
type CycleEntry = {
  id: string;
  memberId: string;
  startDate: string;
  endDate?: string;
  cramps: "none" | "mild" | "moderate" | "strong";
  notes: string;
  createdAt: string;
  updatedAt?: string;
};
type Medication = {
  id: string;
  memberId: string;
  name: string;
  unit: string;
  quantity: number;
  doseAmount: number;
  dosesPerDay: number;
  times: string[];
  stockAlertAt: number;
  notes: string;
  active: boolean;
  createdAt: string;
  updatedAt?: string;
};
type MedicationLog = {
  id: string;
  medicationId: string;
  memberId: string;
  date: string;
  time: string;
  quantityTaken: number;
  createdAt: string;
};
type RoutineSettings = {
  id: string;
  defaultNotifyBeforeMinutes: number;
  notificationEnabled: boolean;
  soundEnabled: boolean;
  createdAt: string;
  updatedAt?: string;
};
type AccountTemplate = {
  id: string; name: string; description: string; area: FinanceArea; dueDay: number; amount: number; supplierId: string; active: boolean; recurrenceType?: "fixed" | "variable"; lateInterestPercent?: number; lateFine?: number; category?: string; createdAt: string; updatedAt?: string; deletedAt?: string;
};
type Reserve = { id:string; name:string; balance:number; area:FinanceArea; cdiPercent?:number; createdAt:string; updatedAt?:string; deletedAt?:string; };
type Investment = { id:string; name:string; principal:number; balance:number; cdiPercent:number; estimatedMonthlyRate:number; createdAt:string; updatedAt?:string; deletedAt?:string; };
type BudgetItem = { id: string; description: string; kind?: "question" | "reading" | "work" | "sale" | "material" | "other"; quantity?: number; unitPrice: number; currency?: CurrencyCode; };
type Budget = {
  id: string;
  clientId?: string;
  clientName?: string;
  serviceType: "reading" | "spell" | "work" | "sale" | "product" | "other";
  serviceName: string;
  title: string;
  description: string;
  value: number;
  items?: BudgetItem[];
  discount: number;
  surcharge: number;
  validUntil: string;
  shippingEnabled?: boolean;
  shippingRecipientName?: string;
  shippingPhone?: string;
  shippingAddress?: string;
  shippingZipCode?: string;
  shippingCity?: string;
  shippingState?: string;
  shippingUber?: number;
  shippingCorreios?: number;
  shippingCorreiosPending?: boolean;
  currency?: CurrencyCode;
  paymentMode?: "paid" | "pending" | "installments";
  paymentMethod?: PaymentMethod;
  paymentDate?: string;
  installmentCount?: number;
  installmentFirstDate?: string;
  installmentEntry?: boolean;
  installmentEntryAmount?: number;
  sourceConsultationId?: string;
  status: "draft" | "sent" | "approved" | "rejected" | "expired";
  linkedWorkId?: string;
  createdAt: string;
updatedAt?: string;
deletedAt?: string;
};
 

type ShortfallReason = "discount" | "free_question" | "free_reading" | "free_work" | "default" | "gift" | "other";
type Desfalque = {
  id: string;
  clientId?: string;
  clientName?: string;
  consultationId?: string;
  questionId?: string;
  installmentId?: string;
  workId?: string;
  type: ShortfallReason;
  description: string;
  potentialValue: number;
  receivedValue: number;
  amount: number;
  date: string;
  createdAt: string;
  updatedAt?: string;
  deletedAt?: string;
};

type TrashEntity =
  | "client_bundle"
  | "consultation"
  | "purchase_bundle"
  | "agenda"
  | "future_purchase"
  | "note"
  | "budget"
  | "account_template"
  | "supplier"
  | "stock_item"
  | "stock_movement"
  | "payable"
  | "loan"
  | "overdraft"
  | "bank_account"
  | "quick_transaction"
  | "photo"
  | "photo_audio"
  | "question_audio"
  | "desfalque"
  | "inventory";
type TrashItem = {
  id: string;
  entityType: TrashEntity;
  label: string;
  payload: any;
  createdAt: string;
  deletedAt: string;
  schemaVersion: 1;
};

type Screen =
| "dashboard"
| "clients"
| "history"
| "finance"
| "purchases"
| "stock"
| "inventory"
| "suppliers"
| "accounts"
| "settings"
| "futurePurchases"
| "daily"
| "notes"
| "agenda"
| "consultation"
| "budgets"
| "trash"
| "reports"
| "services"
| "routine"
| "organization"
| "tools";
/* =========================================================
CHAVES
========================================================= */
const CLIENTS_KEY = "gestao_clients";
const CONSULTATIONS_KEY = "gestao_consultations";
const DRAFT_KEY = "gestao_current_draft";
const PHOTO_RETURN_KEY = "gestao_photo_return_v63";
const UI_STATE_KEY = "gestao_ui_state_v63";
const PURCHASES_KEY = "gestao_purchases";
const SUPPLIERS_KEY = "gestao_suppliers";
const STOCK_ITEMS_KEY = "gestao_stock_items";
const STOCK_MOVEMENTS_KEY = "gestao_stock_movements";
const INVENTORY_KEY = "gestao_inventory";
const PAYABLES_KEY = "gestao_payables";
const LOANS_KEY = "gestao_loans";
const OVERDRAFTS_KEY = "gestao_overdrafts";
const SECTORS_KEY = "gestao_household_sectors";
const CATEGORIES_KEY = "gestao_household_categories";
const QUICK_TRANSACTIONS_KEY = "gestao_quick_transactions";
const BANK_ACCOUNTS_KEY = "gestao_bank_accounts";
const READING_TYPES_KEY = "gestao_reading_types";
const FUTURE_PURCHASES_KEY = "gestao_future_purchases";
const NOTES_KEY = "gestao_notes";
const AGENDA_KEY = "gestao_agenda";
const ACCOUNT_TEMPLATES_KEY = "gestao_account_templates";
const BUDGETS_KEY = "gestao_budgets";
const TRASH_KEY = "gestao_trash";
const DESFALQUES_KEY = "gestao_desfalques";
const WORK_TYPES_KEY = "gestao_work_types";
const WORK_EXECUTIONS_KEY = "gestao_work_executions";
const SALE_ITEMS_KEY = "gestao_sale_items";
const RESERVES_KEY = "gestao_reserves";
const INVESTMENTS_KEY = "gestao_investments";
const ROUTINE_ITEMS_KEY = "gestao_routine_items";
const FAMILY_MEMBERS_KEY = "gestao_family_members";
const ROUTINE_TEMPLATES_KEY = "gestao_routine_templates";
const ROUTINE_LOGS_KEY = "gestao_routine_logs";
const ROUTINE_SETTINGS_KEY = "gestao_routine_settings";
const HEALTH_ENTRIES_KEY = "gestao_health_entries";
const CYCLE_ENTRIES_KEY = "gestao_cycle_entries";
const MEDICATIONS_KEY = "gestao_medications";
const MEDICATION_LOGS_KEY = "gestao_medication_logs";
const ROUTINE_NOTIFICATION_IDS_KEY = "gestao_routine_notification_ids";
/* =========================================================
HELPERS
========================================================= */
const makeId = () =>
`${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
const nowISO = () => new Date().toISOString();
const localDateKey = (date = new Date()) => {
  const y = date.getFullYear(); const m = String(date.getMonth()+1).padStart(2,"0"); const d = String(date.getDate()).padStart(2,"0");
  return `${y}-${m}-${d}`;
};
const localTimeKey = (date = new Date()) => `${String(date.getHours()).padStart(2,"0")}:${String(date.getMinutes()).padStart(2,"0")}`;
const formatDate = (date: string) => {
if (!date) return "-";
const parsed = new Date(date);
if (Number.isNaN(parsed.getTime())) {
return date;
}
return parsed.toLocaleDateString("pt-BR");
};
const formatDateTime = (date: string) => {
if (!date) return "-";
const parsed = new Date(date);
if (Number.isNaN(parsed.getTime())) {
return date;
}
return parsed.toLocaleString("pt-BR");
};
const formatMoney = (value: number) =>
Number(value || 0).toLocaleString("pt-BR", {
style: "currency",
currency: "BRL",
});
const currencySymbol = (currency: CurrencyCode) => currency === "EUR" ? "€" : currency === "USD" ? "$" : currency === "GBP" ? "£" : "R$";
const formatForeign = (amount: number, currency: CurrencyCode) => `${currencySymbol(currency)} ${Number(amount || 0).toFixed(2)}`;
const formatDuration = (seconds: number) => {
if (!Number.isFinite(seconds)) return "00:00";
const min = Math.floor(seconds / 60);
const sec = Math.floor(seconds % 60);
return `${String(min).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
};
const readFileAsDataUrl = (file: File): Promise<string> =>
new Promise((resolve, reject) => {
const reader = new FileReader();
reader.onload = () => resolve(String(reader.result));
reader.onerror = reject;
reader.readAsDataURL(file);
});

const compressImageFile = async (file: File, maxSize = 1280, quality = 0.68): Promise<string> => {
if (!file.type.startsWith("image/")) return readFileAsDataUrl(file);
const objectUrl = URL.createObjectURL(file);
try {
const image = new Image();
image.src = objectUrl;
await new Promise<void>((resolve, reject) => { image.onload = () => resolve(); image.onerror = () => reject(new Error("Imagem inválida")); });
const scale = Math.min(1, maxSize / Math.max(image.naturalWidth || 1, image.naturalHeight || 1));
const canvas = document.createElement("canvas");
canvas.width = Math.max(1, Math.round((image.naturalWidth || 1) * scale));
canvas.height = Math.max(1, Math.round((image.naturalHeight || 1) * scale));
const context = canvas.getContext("2d");
if (!context) return readFileAsDataUrl(file);
context.drawImage(image, 0, 0, canvas.width, canvas.height);
return canvas.toDataURL("image/jpeg", quality);
} finally { URL.revokeObjectURL(objectUrl); }
};

const base64FromDataUrl = (value: string) => value.includes(",") ? value.split(",", 2)[1] : value;

const shareDataFile = async (dataUrl: string, fileName: string, mimeType: string, title: string) => {
try {
const base64 = base64FromDataUrl(dataUrl);
const path = `gestao/${Date.now()}-${fileName}`;
const written = await Filesystem.writeFile({ path, data: base64, directory: Directory.Cache, recursive: true });
const uri = (await Filesystem.getUri({ path, directory: Directory.Cache })).uri || written.uri;
await Share.share({ title, text: title, files: [uri] });
return true;
} catch {
try {
const blob = await (await fetch(dataUrl)).blob();
const file = new File([blob], fileName, { type: mimeType });
const nav = navigator as Navigator & { canShare?: (data: ShareData) => boolean };
if (navigator.share && (!nav.canShare || nav.canShare({ files: [file] }))) {
await navigator.share({ title, text: title, files: [file] });
return true;
}
} catch {}
console.warn("Não foi possível abrir o compartilhamento do arquivo.");
return false;
}
};
const createEmptyQuestion = (number: number, currency: CurrencyCode = "BRL", value = 0): Question => ({
id: makeId(),
number,
text: "",
notes: "",
photos: [],
audios: [],
responseText: "",
responsePhotos: [],
responseAudios: [],
createdAt: nowISO(),
updatedAt: nowISO(),
completed: false,
billingMode: value > 0 ? "paid" : "included",
value: Math.max(0, Number(value) || 0),
potentialValue: Math.max(0, Number(value) || 0),
shortfall: 0,
currency,
});
const readingPrice = (type: ReadingType | undefined, currency: CurrencyCode) => normalizeCurrencyPrices(type?.prices)[currency] || 0;
const workPrice = (work: WorkType | undefined, currency: CurrencyCode) => normalizeCurrencyPrices(work?.prices)[currency] || 0;
const salePrice = (item: SaleItem | undefined, currency: CurrencyCode) => {
  if (!item) return 0;
  return normalizeCurrencyPrices(item.prices, item.price)[currency] || 0;
};
const initialClients: Client[] = [
{
id: "client-amanda",
name: "Amanda Silva",
phone: "",
},
{
id: "client-mariana",
name: "Mariana Oliveira",
phone: "",
},
];
const initialSectors: HouseholdSector[] = [
{
id: "kitchen",
name: "Cozinha",
description: "Alimentação e itens da cozinha",
active: true,
},
{
id: "bedroom",
name: "Quarto",
description: "Itens dos quartos",
active: true,
},
{
id: "bathroom",
name: "Banheiro",
description: "Higiene e banheiro",
active: true,
},
{
id: "laundry",
name: "Lavanderia",
description: "Limpeza e lavanderia",
active: true,
},
{
id: "general",
name: "Geral",
description: "Despesas gerais da casa",
active: true,
},
];
const initialCategories: HouseholdCategory[] = [
{
id: "shopping",
sectorId: "kitchen",
name: "Compras de mercado",
active: true,
},
{
id: "bed-table-bath",
sectorId: "bedroom",
name: "Cama, mesa e banho",
active: true,
},
{
id: "cleaning",
sectorId: "laundry",
name: "Produtos de limpeza",
active: true,
},
];
const initialReadingTypes: ReadingType[] = [
{
id: "simple",
name: "Pergunta simples",
questions: 1,
active: true,
prices: emptyCurrencyPrices(),
},
{
id: "complete",
name: "Tiragem completa",
questions: 4,
active: true,
prices: emptyCurrencyPrices(),
},
];
const normalizeReadingTypesList = (items: ReadingType[]): ReadingType[] => {
  const byKey = new Map<string, ReadingType>();
  for (const raw of items || []) {
    if (!raw || !raw.name) continue;
    const item: ReadingType = { ...raw, prices: normalizeCurrencyPrices(raw.prices) };
    const key = `${item.name.trim().toLocaleLowerCase("pt-BR")}::${Math.max(1, Number(item.questions) || 1)}`;
    const existing = byKey.get(key);
    if (!existing) { byKey.set(key, item); continue; }
    const existingPrices = normalizeCurrencyPrices(existing.prices);
    const itemPrices = normalizeCurrencyPrices(item.prices);
    byKey.set(key, {
      ...existing,
      active: existing.active || item.active,
      prices: {
        BRL: existingPrices.BRL || itemPrices.BRL,
        EUR: existingPrices.EUR || itemPrices.EUR,
        USD: existingPrices.USD || itemPrices.USD,
        GBP: existingPrices.GBP || itemPrices.GBP,
      },
    });
  }
  return Array.from(byKey.values());
};

const readStorage = <T,>(key: string, fallback: T): T => {
try {
const saved = localStorage.getItem(key);
return saved ? JSON.parse(saved) : fallback;
} catch {
return fallback;
}
};

const safeSetStorage = (key: string, value: unknown) => {
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch {
    // Large media (photo/audio) can exceed WebView localStorage. Keep the UI alive.
    return false;
  }
};

const normalizePackageQuestions = (questions: Question[]): Question[] => {
  if (!Array.isArray(questions)) return [];
  const groups = new Map<string, Question[]>();
  for (const q of questions) {
    if (q.packageId && (q.packageQuestionCount || 0) > 1) {
      const list = groups.get(q.packageId) || []; list.push(q); groups.set(q.packageId, list);
    }
  }
  const normalized = questions.map(q => {
    const group = q.packageId ? groups.get(q.packageId) : undefined;
    if (!group || !q.packageId) return q;
    const count = Math.max(1, Number(q.packageQuestionCount || group.length || 1));
    const total = Math.max(0, Number(q.packageTotal ?? 0));
    if (total <= 0) return { ...q, billingMode: q.billingMode === "included" ? "paid" : q.billingMode, packageRole: "included" as const };
    const base = Math.round((total / count) * 100) / 100;
    const idx = group.findIndex(item => item.id === q.id);
    const unit = idx === group.length - 1 ? Math.max(0, Number((total - base * Math.max(0, group.length - 1)).toFixed(2))) : base;
    return { ...q, value: unit, potentialValue: unit, billingMode: (q.billingMode === "free" ? "free" : "paid") as QuestionBillingMode, packageRole: "included" as const, packageQuestionCount: count, packageTotal: total };
  });
  return normalized;
};

const normalizeWorkLinkedQuestions = (consultation: Consultation): Consultation => {
  const questions = Array.isArray(consultation.questions) ? consultation.questions : [];
  if (!consultation.relatedWorkId && !questions.some(q => q.relatedWorkId)) return consultation;
  const linkedId = consultation.relatedWorkId;
  let sequence = 0;
  const migrated = questions.map((q) => {
    const shouldLinkLegacy = !!linkedId && !q.relatedWorkId;
    if (!q.relatedWorkId && !shouldLinkLegacy) return q;
    const relatedWorkId = q.relatedWorkId || linkedId!;
    sequence += 1;
    const kind = q.workQuestionKind || (q.billingMode === "free" ? "benefit" : "paid");
    return { ...q, relatedWorkId, relatedWorkTitle: q.relatedWorkTitle || consultation.title, workQuestionKind: kind, workQuestionNumber: q.workQuestionNumber || sequence };
  });
  return { ...consultation, questions: migrated };
};

const consultationPackageLabel = (consultation: Consultation): string => {
  const packageQuestion = consultation.questions?.find(q => !!q.packageId && (q.packageQuestionCount || 0) > 0);
  if (packageQuestion) {
    const packageCount = Math.max(1, Number(packageQuestion.packageQuestionCount || 1));
    const extras = Math.max(0, (consultation.questions || []).filter(q => q.packageId !== packageQuestion.packageId).length);
    return extras > 0 ? `Pacote ${packageCount} perguntas + ${extras} extra${extras === 1 ? "" : "s"}` : `Pacote ${packageCount} perguntas`;
  }
  const count = consultation.questions?.length || 0;
  return count > 0 ? `${count} pergunta${count === 1 ? "" : "s"} individuais` : "Sem perguntas";
};

const consultationPackageUnitPrice = (consultation: Consultation): number | null => {
  const packageQuestion = consultation.questions?.find(q => !!q.packageId && (q.packageQuestionCount || 0) > 0);
  if (!packageQuestion) return null;
  const count = Math.max(1, Number(packageQuestion.packageQuestionCount || 1));
  const total = Math.max(0, Number(packageQuestion.packageTotal ?? 0));
  return Number((total / count).toFixed(2));
};

const isUuid = (value: string) =>
/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value);

const newUuid = () =>
(typeof crypto !== "undefined" && typeof crypto.randomUUID === "function")
  ? crypto.randomUUID()
  : `${Date.now().toString(16)}-${Math.random().toString(16).slice(2)}-${Math.random().toString(16).slice(2)}-${Math.random().toString(16).slice(2)}-${Math.random().toString(16).slice(2)}`;

const normalizeLocalIdsForSupabase = (
  localClients: Client[],
  localConsultations: Consultation[],
) => {
  const clientIdMap = new Map<string, string>();
  const consultationIdMap = new Map<string, string>();
  const questionIdMap = new Map<string, string>();

  const normalizedClients = localClients.map((client) => {
    const id = isUuid(client.id) ? client.id : newUuid();
    clientIdMap.set(client.id, id);
    return { ...client, id };
  });

  const normalizedConsultations = localConsultations.map((consultation) => {
    const consultationId = isUuid(consultation.id) ? consultation.id : newUuid();
    consultationIdMap.set(consultation.id, consultationId);

    return {
      ...consultation,
      id: consultationId,
      clientId: clientIdMap.get(consultation.clientId) || consultation.clientId,
      questions: (consultation.questions || []).map((question) => {
        const questionId = isUuid(question.id) ? question.id : newUuid();
        questionIdMap.set(question.id, questionId);
        return { ...question, id: questionId };
      }),
    };
  });

  return { normalizedClients, normalizedConsultations, clientIdMap, consultationIdMap, questionIdMap };
};

const syncInitialSupabaseData = async (
  userId: string,
  localClients: Client[],
  localConsultations: Consultation[],
) => {
  const normalized = normalizeLocalIdsForSupabase(localClients, localConsultations);

  const { data: remoteClients, error: clientsReadError } = await supabaseClient
    .from("clients")
    .select("id,name,phone,notes,created_at,updated_at,deleted_at")
    .eq("user_id", userId);
  if (clientsReadError) throw clientsReadError;

  const remoteClientMap = new Map<string, Client>(
    (remoteClients || []).map((row: any) => [row.id, {
      id: row.id,
      name: row.name || "",
      phone: row.phone || "",
      notes: row.notes || "",
      createdAt: row.created_at || nowISO(),
      updatedAt: row.updated_at || row.created_at || nowISO(),
      deletedAt: row.deleted_at || undefined,
    }])
  );

  normalized.normalizedClients.forEach((client) => {
    remoteClientMap.set(client.id, client);
  });

  const mergedClients = [...remoteClientMap.values()];
  const { error: clientsWriteError } = await supabaseClient.from("clients").upsert(
    mergedClients.map((client) => ({
      id: client.id,
      user_id: userId,
      name: client.name,
      phone: client.phone || null,
      notes: client.notes || null,
      created_at: client.createdAt || nowISO(),
      updated_at: client.updatedAt || nowISO(),
      deleted_at: client.deletedAt || null,
    })),
    { onConflict: "id" },
  );
  if (clientsWriteError) throw clientsWriteError;

  const { data: remoteConsultations, error: consultationsReadError } = await supabaseClient
    .from("consultations")
    .select("id,client_id,client_name,title,value,paid,payment_date,status,service_type,intake_notes,scheduled_at,payment_plan,created_at,updated_at,deleted_at")
    .eq("user_id", userId);
  if (consultationsReadError) throw consultationsReadError;

  const { data: remoteQuestions, error: questionsReadError } = await supabaseClient
    .from("questions")
    .select("id,consultation_id,question_number,text,notes,completed,created_at,updated_at,deleted_at")
    .eq("user_id", userId);
  if (questionsReadError) throw questionsReadError;

  const remoteQuestionMap = new Map<string, Question[]>();
  (remoteQuestions || []).forEach((row: any) => {
    const list = remoteQuestionMap.get(row.consultation_id) || [];
    list.push({
      id: row.id,
      number: row.question_number || 1,
      text: row.text || "",
      notes: row.notes || "",
      photos: [],
      audios: [],
      createdAt: row.created_at || nowISO(),
      updatedAt: row.updated_at || row.created_at || nowISO(),
      deletedAt: row.deleted_at || undefined,
      completed: !!row.completed,
    });
    remoteQuestionMap.set(row.consultation_id, list);
  });

  const consultationMap = new Map<string, Consultation>();
  (remoteConsultations || []).forEach((row: any) => {
    consultationMap.set(row.id, {
      id: row.id,
      clientId: row.client_id || "",
      clientName: row.client_name || "",
      title: row.title || "",
      value: Number(row.value || 0),
      paid: !!row.paid,
      paymentDate: row.payment_date || "",
      createdAt: row.created_at || nowISO(),
      status: row.status || "active",
      questions: remoteQuestionMap.get(row.id) || [],
      intakeNotes: row.intake_notes || "",
      serviceType: row.service_type || undefined,
      paymentPlan: row.payment_plan || undefined,
      scheduledAt: row.scheduled_at || undefined,
      updatedAt: row.updated_at || row.created_at || nowISO(),
      deletedAt: row.deleted_at || undefined,
    });
  });

  normalized.normalizedConsultations.forEach((consultation) => {
    consultationMap.set(consultation.id, consultation);
  });

  const mergedConsultations = [...consultationMap.values()];

  const { error: consultationsWriteError } = await supabaseClient.from("consultations").upsert(
    mergedConsultations.map((consultation) => ({
      id: consultation.id,
      user_id: userId,
      client_id: consultation.clientId || null,
      client_name: consultation.clientName || null,
      title: consultation.title || null,
      value: Number(consultation.value || 0),
      paid: !!consultation.paid,
      payment_date: consultation.paymentDate || null,
      status: consultation.status,
      service_type: consultation.serviceType || null,
      intake_notes: consultation.intakeNotes || null,
      scheduled_at: consultation.scheduledAt || null,
      payment_plan: consultation.paymentPlan || null,
      created_at: consultation.createdAt || nowISO(),
      updated_at: consultation.updatedAt || nowISO(),
      deleted_at: consultation.deletedAt || null,
    })),
    { onConflict: "id" },
  );
  if (consultationsWriteError) throw consultationsWriteError;

  const mergedQuestions = mergedConsultations.flatMap((consultation) =>
    (consultation.questions || []).map((question) => ({
      id: question.id,
      user_id: userId,
      consultation_id: consultation.id,
      question_number: question.number,
      text: question.text || null,
      notes: question.notes || null,
      completed: !!question.completed,
      created_at: question.createdAt || nowISO(),
      updated_at: question.updatedAt || nowISO(),
      deleted_at: question.deletedAt || null,
    }))
  );

  if (mergedQuestions.length) {
    const { error: questionsWriteError } = await supabaseClient.from("questions").upsert(
      mergedQuestions,
      { onConflict: "id" },
    );
    if (questionsWriteError) throw questionsWriteError;
  }

  return {
    clients: mergedClients,
    consultations: mergedConsultations,
  };
};

/* =========================================================
APP
========================================================= */
function App() {
const [authReady, setAuthReady] = useState(false);
const [authUser, setAuthUser] = useState<any>(null);
const [authEmail, setAuthEmail] = useState("");
const [authPassword, setAuthPassword] = useState("");
const [authError, setAuthError] = useState("");
const [authLoading, setAuthLoading] = useState(false);
const [syncing, setSyncing] = useState(false);
const [syncMessage, setSyncMessage] = useState("");
const [appReady, setAppReady] = useState(false);
const syncStartedRef = useRef(false);

useEffect(() => {
  let mounted = true;
  let subscription: { unsubscribe?: () => void } | null = null;
  const finishAuth = (user: any) => {
    if (!mounted) return;
    setAuthUser(user || null);
    setAuthReady(true);
  };
  // Never leave the first screen blank if Supabase is temporarily unavailable.
  Promise.race([
    supabaseClient.auth.getSession(),
    new Promise<any>((_, reject) => window.setTimeout(() => reject(new Error("AUTH_TIMEOUT")), 8000)),
  ]).then(({ data }: any) => finishAuth(data?.session?.user || null))
    .catch((error) => {
      console.warn("Falha/timeout ao obter sessão Supabase; exibindo login local.", error);
      finishAuth(null);
    });
  try {
    const result = supabaseClient.auth.onAuthStateChange((_event, session) => finishAuth(session?.user || null));
    subscription = result?.data?.subscription || null;
  } catch (error) {
    console.warn("Não foi possível registrar o listener de autenticação.", error);
  }
  return () => {
    mounted = false;
    try { subscription?.unsubscribe?.(); } catch {}
  };
}, []);

const handleSupabaseLogin = async () => {
  setAuthError("");
  if (!authEmail.trim() || !authPassword) {
    setAuthError("Digite seu e-mail e sua senha.");
    return;
  }
  setAuthLoading(true);
  const { error } = await supabaseClient.auth.signInWithPassword({
    email: authEmail.trim(),
    password: authPassword,
  });
  setAuthLoading(false);
  if (error) setAuthError(error.message || "Não foi possível entrar.");
};

useEffect(() => {
  if (!authUser) {
    syncStartedRef.current = false;
    syncReadyRef.current = false;
    setAppReady(false);
    return;
  }
  if (syncStartedRef.current) return;
  syncStartedRef.current = true;
  let cancelled = false;
  const hydrateFromStorage = () => {
    if (cancelled) return;
    try {
      const storedClients = readStorage<unknown>(CLIENTS_KEY, initialClients);
      setClients(Array.isArray(storedClients) ? (storedClients as Client[]).map(c => ({...c, address: c.address || undefined})) : initialClients);
      const storedConsultations = readStorage<Consultation[]>(CONSULTATIONS_KEY, []);
      setConsultations(Array.isArray(storedConsultations) ? storedConsultations.map((consultation) => {
        const migratedCurrency = (consultation.currency || consultation.questions?.find((q:any)=>q.currency)?.currency || consultation.relatedCharges?.find((c:any)=>c.currency)?.currency || "BRL") as CurrencyCode;
        const migratedStatus = consultation.status === "standby" && consultation.scheduledAt && consultation.updatedAt === consultation.createdAt
          ? "scheduled"
          : consultation.status;
        return normalizeWorkLinkedQuestions({ ...consultation, status: migratedStatus as Consultation["status"], currency: migratedCurrency, questions: normalizePackageQuestions((consultation.questions || []).map((question) => ({ ...question, currency: question.currency || migratedCurrency, photos: (question.photos || []).map((photo) => ({ ...photo, audios: Array.isArray((photo as any).audios) ? (photo as any).audios : [], note: (photo as any).note || "", updatedAt: (photo as any).updatedAt || photo.createdAt || nowISO() })), audios: question.audios || [] }))) });
      }) : []);
      // V63: restaura contexto após câmera, Activity recriada ou retorno de outro aplicativo.
      try {
        const rawPhotoReturn = localStorage.getItem(PHOTO_RETURN_KEY);
        const rawUi = localStorage.getItem(UI_STATE_KEY);
        const photoSnapshot = rawPhotoReturn ? JSON.parse(rawPhotoReturn) : null;
        const uiSnapshot = rawUi ? JSON.parse(rawUi) : null;
        const shouldRestoreConsultation = !!photoSnapshot?.consultationId || uiSnapshot?.screen === "consultation";
        const consultationId = photoSnapshot?.consultationId || (shouldRestoreConsultation ? uiSnapshot?.activeConsultationId : null);
        const restoredConsultation = shouldRestoreConsultation && Array.isArray(storedConsultations) ? storedConsultations.find(c => c.id === consultationId) : null;
        if (restoredConsultation) {
          setActiveConsultation(restoredConsultation);
          const questions = Array.isArray(restoredConsultation.questions) ? restoredConsultation.questions : [];
          const qid = photoSnapshot?.questionId || uiSnapshot?.activeQuestionId;
          setActiveQuestionId(qid && questions.some(q => q.id === qid) ? qid : (questions[questions.length - 1]?.id || null));
          setScreen("consultation");
        } else if (uiSnapshot?.screen) {
          setScreen(uiSnapshot.screen as Screen);
          const restoredClient = uiSnapshot.historyClientId ? (readStorage<Client[]>(CLIENTS_KEY, []).find(c => c.id === uiSnapshot.historyClientId) || null) : null;
          if (restoredClient) setHistoryClient(restoredClient);
        }
        if (uiSnapshot) {
          if (uiSnapshot.newTitle !== undefined) setNewTitle(uiSnapshot.newTitle || "");
          if (uiSnapshot.newServiceType) setNewServiceType(uiSnapshot.newServiceType);
          if (uiSnapshot.selectedClientId !== undefined) setSelectedClientId(uiSnapshot.selectedClientId || "");
          if (uiSnapshot.selectedWorkTypeId !== undefined) setSelectedWorkTypeId(uiSnapshot.selectedWorkTypeId || "");
          if (uiSnapshot.selectedSaleItemId !== undefined) setSelectedSaleItemId(uiSnapshot.selectedSaleItemId || "");
          if (uiSnapshot.newReadingCurrency) setNewReadingCurrency(uiSnapshot.newReadingCurrency);
          if (uiSnapshot.selectedReadingTypeId) setSelectedReadingTypeId(uiSnapshot.selectedReadingTypeId);
          if (uiSnapshot.relatedReadingEnabled !== undefined) setRelatedReadingEnabled(!!uiSnapshot.relatedReadingEnabled);
          if (uiSnapshot.relatedReadingWorkId !== undefined) setRelatedReadingWorkId(uiSnapshot.relatedReadingWorkId || "");
          if (uiSnapshot.newClientSearch !== undefined) setNewClientSearch(uiSnapshot.newClientSearch || "");
          if (uiSnapshot.intakeNotes !== undefined) setIntakeNotes(uiSnapshot.intakeNotes || "");
          if (uiSnapshot.newScheduledDate !== undefined) setNewScheduledDate(uiSnapshot.newScheduledDate || "");
          if (uiSnapshot.newScheduledTime !== undefined) setNewScheduledTime(uiSnapshot.newScheduledTime || "");
          if (uiSnapshot.serviceValue !== undefined) setServiceValue(uiSnapshot.serviceValue || "");
          if (uiSnapshot.servicePaymentMode) setServicePaymentMode(uiSnapshot.servicePaymentMode);
          if (uiSnapshot.servicePaymentMethod) setServicePaymentMethod(uiSnapshot.servicePaymentMethod);
          if (uiSnapshot.serviceCurrency) setServiceCurrency(uiSnapshot.serviceCurrency);
          if (uiSnapshot.serviceForeignAmount !== undefined) setServiceForeignAmount(uiSnapshot.serviceForeignAmount || "");
          if (uiSnapshot.servicePaymentDate !== undefined) setServicePaymentDate(uiSnapshot.servicePaymentDate || "");
          if (uiSnapshot.serviceInstallmentCount !== undefined) setServiceInstallmentCount(uiSnapshot.serviceInstallmentCount || "2");
          if (uiSnapshot.serviceInstallmentFirstDate !== undefined) setServiceInstallmentFirstDate(uiSnapshot.serviceInstallmentFirstDate || "");
          if (uiSnapshot.serviceInstallmentEntry !== undefined) setServiceInstallmentEntry(!!uiSnapshot.serviceInstallmentEntry);
          if (uiSnapshot.serviceEntryAmount !== undefined) setServiceEntryAmount(uiSnapshot.serviceEntryAmount || "0");
          if (Array.isArray(uiSnapshot.serviceInstallmentRows)) setServiceInstallmentRows(uiSnapshot.serviceInstallmentRows);
          if (uiSnapshot.serviceNotes !== undefined) setServiceNotes(uiSnapshot.serviceNotes || "");
          if (uiSnapshot.serviceBudgetId !== undefined) setServiceBudgetId(uiSnapshot.serviceBudgetId || "");
          if (uiSnapshot.agendaTab) setAgendaTab(uiSnapshot.agendaTab);
          if (uiSnapshot.agendaDate) setAgendaDate(uiSnapshot.agendaDate);
          if (uiSnapshot.settingsTab) setSettingsTab(uiSnapshot.settingsTab);
          if (uiSnapshot.serviceHubTab) setServiceHubTab(uiSnapshot.serviceHubTab);
          if (uiSnapshot.serviceHubStatusFilter) setServiceHubStatusFilter(uiSnapshot.serviceHubStatusFilter);
          if (uiSnapshot.dashboardOperationalCollapsed !== undefined) setDashboardOperationalCollapsed(!!uiSnapshot.dashboardOperationalCollapsed);
          if (uiSnapshot.dashboardOperationalPeriod) setDashboardOperationalPeriod(uiSnapshot.dashboardOperationalPeriod);
          if (uiSnapshot.dashboardOperationalSort) setDashboardOperationalSort(uiSnapshot.dashboardOperationalSort);
          if (uiSnapshot.selectedServiceRecordId && !restoredConsultation) {
            const rid = uiSnapshot.selectedServiceRecordId; const rtype = uiSnapshot.selectedServiceRecordType;
            const direct = Array.isArray(storedConsultations) ? storedConsultations.find(c => c.id === rid) : null;
            let serviceRecord:any = null;
            if (direct) serviceRecord = {id:direct.id,recordType:rtype||direct.serviceType||"reading",consultationId:direct.id,clientName:direct.clientName,title:direct.serviceType==="sale"?(direct.saleItemName||direct.title):direct.serviceType==="work"?(direct.workTypeName||direct.title):direct.title,amount:direct.value,currency:direct.currency||"BRL",scheduledAt:direct.scheduledAt,createdAt:direct.createdAt,status:direct.serviceType==="work"?(direct.workStatus||"approved"):direct.serviceType==="sale"?(direct.saleStatus||"approved"):direct.status,saleStatus:direct.saleStatus||"approved",consultation:direct,execution:readStorage<WorkExecution[]>(WORK_EXECUTIONS_KEY,[]).find(e=>e.id===direct.id)};
            if (!serviceRecord) { const parent=Array.isArray(storedConsultations)?storedConsultations.find(c=>(c.relatedCharges||[]).some(ch=>ch.id===rid)):null; const charge=parent?.relatedCharges?.find(ch=>ch.id===rid); if(parent&&charge) serviceRecord={id:charge.id,recordType:rtype||charge.kind,consultationId:parent.id,chargeId:charge.id,clientName:parent.clientName,title:charge.title,amount:charge.originalAmount,currency:charge.currency||"BRL",scheduledAt:charge.scheduledAt,createdAt:charge.scheduledAt||parent.createdAt,status:charge.status||charge.saleStatus||"approved",saleStatus:charge.saleStatus||"approved",needsConfection:["awaiting_confection","in_confection"].includes(charge.saleStatus||""),shippingEnabled:!!charge.shippingEnabled,consultation:parent,execution:readStorage<WorkExecution[]>(WORK_EXECUTIONS_KEY,[]).find(e=>e.id===charge.id)}; }
            if (!serviceRecord && (rtype === "budget" || rtype === "reading")) { const storedBudgets=readStorage<Budget[]>(BUDGETS_KEY,[]); const budget=storedBudgets.find(b=>b.id===rid); if(budget) serviceRecord={...budget,recordType:"budget",clientName:budget.clientName||"Sem consulente",createdAt:budget.createdAt}; }
            if(serviceRecord) setSelectedServiceRecord(serviceRecord);
          }
          if (!restoredConsultation) {
            if (uiSnapshot.showNewConsultation) setShowNewConsultation(true);
            if (uiSnapshot.showNewClient) setShowNewClient(true);
            if (uiSnapshot.showIntakeModal) setShowIntakeModal(true);
            if (uiSnapshot.showScheduleModal) setShowScheduleModal(true);
            if (uiSnapshot.showFinishConsultation) setShowFinishConsultation(true);
            if (uiSnapshot.showEditConsultation) setShowEditConsultation(true);
            if (uiSnapshot.showRelatedChargeModal) setShowRelatedChargeModal(true);
            if (uiSnapshot.showRelatedActivity) setShowRelatedActivity(true);
            if (uiSnapshot.showServiceDetail) setShowServiceDetail(true);
            if (uiSnapshot.showDesfalqueModal) setShowDesfalqueModal(true);
            if (uiSnapshot.showRescheduleModal) setShowRescheduleModal(true);
            if (uiSnapshot.showPayableActionModal) setShowPayableActionModal(uiSnapshot.showPayableActionModal);
            if (uiSnapshot.showPurchaseModal) setShowPurchaseModal(true);
            if (uiSnapshot.showPayableModal) setShowPayableModal(true);
            if (uiSnapshot.showStockModal) setShowStockModal(true);
            if (uiSnapshot.showSupplierModal) setShowSupplierModal(true);
            if (uiSnapshot.showTransferModal) setShowTransferModal(true);
            if (uiSnapshot.showLoanManager) setShowLoanManager(true);
            if (uiSnapshot.showLoanForm) setShowLoanForm(true);
            if (uiSnapshot.showReserveManager) setShowReserveManager(true);
            if (uiSnapshot.showQuickBudgetModal) setShowQuickBudgetModal(true);
            if (uiSnapshot.showQuickIncomeModal) setShowQuickIncomeModal(true);
            if (uiSnapshot.showQuickExpenseModal) setShowQuickExpenseModal(true);
            if (uiSnapshot.quickCatalogKind) setQuickCatalogKind(uiSnapshot.quickCatalogKind);
            if (uiSnapshot.quickCatalogReturnContext) setQuickCatalogReturnContext(uiSnapshot.quickCatalogReturnContext);
          }
        }
        if (rawPhotoReturn) localStorage.removeItem(PHOTO_RETURN_KEY);
      } catch (error) { console.warn("V62 UI restore", error); }
      setTrash(readStorage(TRASH_KEY, []));
      setDesfalques(readStorage(DESFALQUES_KEY, []));
      setFuturePurchases(readStorage(FUTURE_PURCHASES_KEY, []));
      setNotes(readStorage(NOTES_KEY, []));
      const storedAgenda = readStorage<unknown>(AGENDA_KEY, []);
      setAgendaItems(Array.isArray(storedAgenda) ? (storedAgenda as AgendaItem[]).filter(Boolean) : []);
      setAccountTemplates(readStorage(ACCOUNT_TEMPLATES_KEY, []));
      const storedBudgets = readStorage<unknown>(BUDGETS_KEY, []);
      setBudgets(Array.isArray(storedBudgets) ? storedBudgets as Budget[] : []);
      setPurchases(readStorage(PURCHASES_KEY, []));
      setSuppliers(readStorage<Supplier[]>(SUPPLIERS_KEY, []).map((supplier) => ({ ...supplier, area: supplier.area || "home", sectorId: supplier.sectorId || "", categoryIds: supplier.categoryIds || [] })));
      const storedStock = readStorage<unknown>(STOCK_ITEMS_KEY, []);
      setStockItems(Array.isArray(storedStock) ? (storedStock as StockItem[]).filter(Boolean) : []);
      const storedInventory = readStorage<unknown>(INVENTORY_KEY, []);
      setInventoryItems(Array.isArray(storedInventory) ? storedInventory.filter(Boolean).map(item => normalizeInventoryItem(item as Partial<InventoryItem>)) : []);
      setStockMovements(readStorage(STOCK_MOVEMENTS_KEY, []));
      setPayables(readStorage(PAYABLES_KEY, []));
      setLoans(readStorage(LOANS_KEY, []));
      setReserves(readStorage(RESERVES_KEY, []));
      setInvestments(readStorage(INVESTMENTS_KEY, []));
      setOverdrafts(readStorage(OVERDRAFTS_KEY, []));
      setHouseholdSectors(readStorage(SECTORS_KEY, initialSectors));
      setHouseholdCategories(readStorage(CATEGORIES_KEY, initialCategories));
      setQuickTransactions(readStorage(QUICK_TRANSACTIONS_KEY, []));
      setBankAccounts(readStorage(BANK_ACCOUNTS_KEY, []));
      const storedReadingTypes = readStorage<unknown>(READING_TYPES_KEY, initialReadingTypes);
      setReadingTypes(Array.isArray(storedReadingTypes) ? normalizeReadingTypesList(storedReadingTypes as ReadingType[]) : initialReadingTypes);
      const storedWorkTypes = readStorage<unknown>(WORK_TYPES_KEY, []);
      setWorkTypes(Array.isArray(storedWorkTypes) ? (storedWorkTypes as WorkType[]).map(item => ({ ...item, prices: normalizeCurrencyPrices(item.prices), standardItems: Array.isArray(item.standardItems) ? item.standardItems : [] })) : []);
      setWorkExecutions(readStorage(WORK_EXECUTIONS_KEY, []));
      const storedSaleItems = readStorage<unknown>(SALE_ITEMS_KEY, []);
      setSaleItems(Array.isArray(storedSaleItems) ? (storedSaleItems as SaleItem[]).map(item => ({ ...item, prices: normalizeCurrencyPrices(item.prices, item.price) })) : []);
      setCurrencySettings(readStorage("currency-settings", { paypalFeePercent: 0, wiseFeePercent: 0, otherFeePercent: 0 }));
      const defaultMembers: FamilyMember[] = [
        {id:"member-aime",name:"Aimê",role:"adult",active:true,createdAt:nowISO()},
        {id:"member-eme",name:"Emê",role:"adult",active:true,createdAt:nowISO()},
        {id:"member-tuco",name:"Tuco",role:"child",active:true,createdAt:nowISO()},
        {id:"member-taiguara",name:"Taiguara",role:"child",active:true,createdAt:nowISO()},
      ];
      const storedMembers = readStorage<FamilyMember[]>(FAMILY_MEMBERS_KEY, defaultMembers);
      const normalizedMembers = defaultMembers.map(def => {
        const old = Array.isArray(storedMembers) ? storedMembers.find(m => m.id === def.id) : undefined;
        return old ? {...def, ...old, name:def.name, role:def.role} : def;
      });
      setFamilyMembers(normalizedMembers);
      setRoutineTemplates(readStorage(ROUTINE_TEMPLATES_KEY, []));
      setRoutineLogs(readStorage(ROUTINE_LOGS_KEY, []));
      const storedRoutineSettings = readStorage<RoutineSettings[]|RoutineSettings>(ROUTINE_SETTINGS_KEY, [] as RoutineSettings[]);
      const restoredRoutineSettings = Array.isArray(storedRoutineSettings) ? storedRoutineSettings[0] : storedRoutineSettings;
      if (restoredRoutineSettings) setRoutineSettings(restoredRoutineSettings);
      setHealthEntries(readStorage(HEALTH_ENTRIES_KEY, []));
      setCycleEntries(readStorage(CYCLE_ENTRIES_KEY, []));
      setMedications(readStorage(MEDICATIONS_KEY, []));
      setMedicationLogs(readStorage(MEDICATION_LOGS_KEY, []));
      setRoutineItems(readStorage(ROUTINE_ITEMS_KEY, []));
    } catch (error) {
      console.error("Falha ao restaurar estado local após sincronização", error);
    }
  };
  setSyncing(true);
  setAppReady(false);
  setSyncMessage("Restaurando seus dados...");
  Promise.race([
    syncFullSupabaseSnapshot(authUser.id, false),
    new Promise<any>((_, reject) => window.setTimeout(() => reject(new Error("SYNC_TIMEOUT")), 12000)),
  ])
    .then((result: any) => {
      if (cancelled) return;
      hydrateFromStorage();
      setSyncMessage(result.restored ? "Dados restaurados." : result.uploaded ? "Dados sincronizados." : "Sincronização pronta.");
      syncReadyRef.current = true;
      setAppReady(true);
    })
    .catch((error) => {
      if (cancelled) return;
      console.warn("Supabase V13 sync indisponível/timeout; seguindo com os dados locais.", error);
      hydrateFromStorage();
      setSyncMessage("Modo local ativo. A sincronização será tentada novamente quando houver conexão.");
      syncReadyRef.current = true;
      setAppReady(true);
    })
    .finally(() => { if (!cancelled) setSyncing(false); });
  return () => { cancelled = true; };
}, [authUser]);

// V13: mantém um backup/snapshot completo do estado local no Supabase.
// Isso garante restauração mesmo após desinstalar e instalar novamente.
useEffect(() => {
  if (!authUser) return;
  let busy = false;
  const sync = async () => {
    if (busy || backupOperationRef.current || !navigator.onLine || !syncReadyRef.current) return;
    busy = true;
    try { await pushFullSupabaseSnapshot(authUser.id); }
    catch (error) { console.warn("V13 background sync", error); }
    finally { busy = false; }
  };
  const timer = window.setInterval(sync, 15000);
  const onOnline = () => sync();
  window.addEventListener("online", onOnline);
  return () => {
    window.clearInterval(timer);
    window.removeEventListener("online", onOnline);
  };
}, [authUser]);

useEffect(() => {
  if (!authUser || !Capacitor.isNativePlatform()) return;
  let cancelled=false;
  const onboardingKey = "gestao_permissions_onboarding_v1";
  const prepare=async()=>{
    // V62: nunca redefinir a navegação para a tela inicial ao retomar o aplicativo.
    // O contexto da tela/modal é restaurado pelo snapshot persistido e a tiragem pelo registro salvo.
    // The onboarding is intentionally shown only once. Runtime permission state can be
    // reviewed later from Android settings or the app's own permission controls, but it
    // must never interrupt every subsequent launch.
    if (localStorage.getItem(onboardingKey) === "1") return;
    let notifications=false, camera=false, microphone=false, contacts=false, overlay=false, exactAlarm=false;
    try { const n=await LocalNotifications.requestPermissions(); notifications=n.display==="granted"; } catch {}
    try { const c=await Camera.requestPermissions({permissions:["camera"]}); camera=c.camera==="granted"; } catch {}
    try { const m=await PermissionBridge.requestMicrophone(); microphone=m.granted; } catch {}
    try { const c=await PermissionBridge.requestContacts(); contacts=c.granted; } catch {}
    try { const special=await PermissionBridge.getSpecialPermissionStates?.(); if(special){ overlay=!!special.overlay; exactAlarm=!!special.exactAlarm; } } catch {}
    if(!cancelled) {
      setPermissionSetupStatus({notifications,camera,microphone,contacts,overlay,exactAlarm});
      setPermissionSetupOpen(true);
      localStorage.setItem(onboardingKey,"1");
    }
  };
  void prepare();
  return ()=>{cancelled=true;};
}, [authUser]);

/* -------------------------------------------------------
CLIENTES / TAROT
------------------------------------------------------- */
const [clients, setClients] = useState<Client[]>(() =>
readStorage(CLIENTS_KEY, initialClients)
);
const [consultations, setConsultations] = useState<Consultation[]>(() => {
const stored = readStorage<Consultation[]>(CONSULTATIONS_KEY, []);
return Array.isArray(stored)
? stored.map((consultation) => {
  const migratedCurrency = (consultation.currency || consultation.questions?.find((q:any)=>q.currency)?.currency || consultation.relatedCharges?.find((c:any)=>c.currency)?.currency || "BRL") as CurrencyCode;
  return normalizeWorkLinkedQuestions({
    ...consultation,
    currency: migratedCurrency,
    questions: normalizePackageQuestions((consultation.questions || []).map((question) => ({
      ...question,
      currency: question.currency || migratedCurrency,
      photos: (question.photos || []).map((photo) => ({
        ...photo,
        audios: Array.isArray((photo as any).audios) ? (photo as any).audios : [],
        note: (photo as any).note || "",
        updatedAt: (photo as any).updatedAt || photo.createdAt || nowISO(),
      })),
      audios: question.audios || [],
    }))),
  });
})
: [];
});
const [screen, setScreen] = useState<Screen>("dashboard");
const [menuOpen, setMenuOpen] = useState(false);
const [showReserveManager, setShowReserveManager] = useState(false);
const [selectedReserveId, setSelectedReserveId] = useState<string | null>(null);
const [showLoanManager, setShowLoanManager] = useState(false);
const [selectedLoanId, setSelectedLoanId] = useState<string | null>(null);
const [showLoanForm, setShowLoanForm] = useState(false);
const [loanFormName, setLoanFormName] = useState("Empréstimo");
const [loanFormArea, setLoanFormArea] = useState<FinanceArea>("home");
const [loanFormPrincipal, setLoanFormPrincipal] = useState("");
const [loanFormRate, setLoanFormRate] = useState("0");
const [loanFormCount, setLoanFormCount] = useState("12");
const [loanFormFirstDate, setLoanFormFirstDate] = useState("");
const [loanFormNotes, setLoanFormNotes] = useState("");
const [routineItems, setRoutineItems] = useState<Array<{id:string;title:string;category:"home"|"family"|"children"|"self";done:boolean;date:string}>>(() => readStorage(ROUTINE_ITEMS_KEY, []));
const [routineTitle, setRoutineTitle] = useState("");
const [routineCategory, setRoutineCategory] = useState<"home"|"family"|"children"|"self">("home");
const [organizationSection, setOrganizationSection] = useState<"index"|"home"|"work"|"health"|"agenda"|"reports"|"config">("index");
const [toolsSection, setToolsSection] = useState<"notes">("notes");
const [dashboardActionsCollapsed, setDashboardActionsCollapsed] = useState(true);
const [dashboardOperationalCollapsed, setDashboardOperationalCollapsed] = useState(false);
const [dashboardOperationalPeriod, setDashboardOperationalPeriod] = useState<"today"|"3days"|"5days"|"7days"|"overdue">("today");
const [dashboardOperationalSort, setDashboardOperationalSort] = useState<"recent"|"oldest">("recent");
const [familyMembers, setFamilyMembers] = useState<FamilyMember[]>(() => readStorage(FAMILY_MEMBERS_KEY, [
  {id:"member-aime",name:"Aimê",role:"adult",active:true,createdAt:nowISO()},
  {id:"member-eme",name:"Emê",role:"adult",active:true,createdAt:nowISO()},
  {id:"member-tuco",name:"Tuco",role:"child",active:true,createdAt:nowISO()},
  {id:"member-taiguara",name:"Taiguara",role:"child",active:true,createdAt:nowISO()},
]));
const [routineTemplates, setRoutineTemplates] = useState<RoutineTemplate[]>(() => readStorage(ROUTINE_TEMPLATES_KEY, []));
const [routineLogs, setRoutineLogs] = useState<RoutineLog[]>(() => readStorage(ROUTINE_LOGS_KEY, []));
const [routineSettings, setRoutineSettings] = useState<RoutineSettings>(() => { const stored=readStorage<RoutineSettings[]|RoutineSettings>(ROUTINE_SETTINGS_KEY, [] as RoutineSettings[]); const value=Array.isArray(stored)?stored[0]:stored; return value || {id:"routine-settings",defaultNotifyBeforeMinutes:10,notificationEnabled:true,soundEnabled:true,createdAt:nowISO()}; });
const [healthEntries, setHealthEntries] = useState<HealthEntry[]>(() => readStorage(HEALTH_ENTRIES_KEY, []));
const [cycleEntries, setCycleEntries] = useState<CycleEntry[]>(() => readStorage(CYCLE_ENTRIES_KEY, []));
const [medications, setMedications] = useState<Medication[]>(() => readStorage(MEDICATIONS_KEY, []));
const [medicationLogs, setMedicationLogs] = useState<MedicationLog[]>(() => readStorage(MEDICATION_LOGS_KEY, []));
const [organizationAgendaDate, setOrganizationAgendaDate] = useState(localDateKey());
const [routineConfigArea, setRoutineConfigArea] = useState<"home"|"work">("home");
const [routineFormTitle, setRoutineFormTitle] = useState("");
const [routineFormResponsible, setRoutineFormResponsible] = useState("member-aime");
const [routineFormParticipants, setRoutineFormParticipants] = useState<string[]>([]);
const [routineFormTime, setRoutineFormTime] = useState("07:30");
const [routineFormDays, setRoutineFormDays] = useState<number[]>([1,2,3,4,5]);
const [routineFormPriority, setRoutineFormPriority] = useState<RoutineTemplate["priority"]>("medium");
const [routineFormKind, setRoutineFormKind] = useState<RoutineTemplate["kind"]>("task");
const [routineFormNotify, setRoutineFormNotify] = useState(true);
const [routineFormNotifyBefore, setRoutineFormNotifyBefore] = useState("10");
const [routineFormChecklist, setRoutineFormChecklist] = useState<string[]>([]);
const [routineChecklistDraft, setRoutineChecklistDraft] = useState("");
const [healthMemberId, setHealthMemberId] = useState("member-eme");
const [healthMood, setHealthMood] = useState<HealthEntry["mood"]>("neutral");
const [healthEvent, setHealthEvent] = useState<HealthEntry["event"]>("normal");
const [healthNote, setHealthNote] = useState("");
const [showHealthNoteModal, setShowHealthNoteModal] = useState(false);
const organizationBackupInputRef = useRef<HTMLInputElement | null>(null);
const fullBackupInputRef = useRef<HTMLInputElement | null>(null);
const backupOperationRef = useRef(false);
const [cycleStartDate, setCycleStartDate] = useState(localDateKey());
const [cycleEndDate, setCycleEndDate] = useState("");
const [cycleCramps, setCycleCramps] = useState<CycleEntry["cramps"]>("none");
const [cycleNotes, setCycleNotes] = useState("");
const [medicationFormMember, setMedicationFormMember] = useState("member-eme");
const [medicationFormName, setMedicationFormName] = useState("");
const [medicationFormUnit, setMedicationFormUnit] = useState("unidade");
const [medicationFormQuantity, setMedicationFormQuantity] = useState("0");
const [medicationFormDose, setMedicationFormDose] = useState("1");
const [medicationFormDosesPerDay, setMedicationFormDosesPerDay] = useState("1");
const [medicationFormTimes, setMedicationFormTimes] = useState("08:00");
const [medicationFormAlert, setMedicationFormAlert] = useState("5");
const [agendaComposerOpen, setAgendaComposerOpen] = useState(false);
const [expandedAgendaItemId, setExpandedAgendaItemId] = useState<string | null>(null);
const [expandedDashboardSection, setExpandedDashboardSection] = useState<string | null>(null);
const [exitPromptAt, setExitPromptAt] = useState(0);
const [trash, setTrash] = useState<TrashItem[]>(() => readStorage(TRASH_KEY, []));
const [desfalques, setDesfalques] = useState<Desfalque[]>(() => readStorage(DESFALQUES_KEY, []));
const [showRelatedActivity, setShowRelatedActivity] = useState(false);
const [showDesfalqueModal, setShowDesfalqueModal] = useState(false);
const [desfalquePotential, setDesfalquePotential] = useState("0");
const [desfalqueReceived, setDesfalqueReceived] = useState("0");
const [desfalqueDescription, setDesfalqueDescription] = useState("Desconto / serviço não cobrado");
const [desfalqueDate, setDesfalqueDate] = useState(localDateKey());
const [showRescheduleModal, setShowRescheduleModal] = useState(false);
const [reschedulePriority, setReschedulePriority] = useState(3);
const [rescheduleTarget, setRescheduleTarget] = useState<any>(null);
const [rescheduleDate, setRescheduleDate] = useState("");
const [rescheduleTime, setRescheduleTime] = useState("");
const [relatedWorkId, setRelatedWorkId] = useState("");
const [relatedActivityType, setRelatedActivityType] = useState<"reading" | "work_done" | "free_support">("reading");
const [relatedTitle, setRelatedTitle] = useState("");
const [relatedValue, setRelatedValue] = useState("");
const [relatedPotentialValue, setRelatedPotentialValue] = useState("");
const [relatedPaid, setRelatedPaid] = useState(true);
const [relatedPaymentMethod, setRelatedPaymentMethod] = useState<PaymentMethod>("pix");
const [reportMonthA, setReportMonthA] = useState(new Date(new Date().getFullYear(), new Date().getMonth() - 1, 1).toISOString().slice(0,7));
const [reportMonthB, setReportMonthB] = useState(new Date().toISOString().slice(0,7));
const [selectedPhotoId, setSelectedPhotoId] = useState<string | null>(null);
const [selectedResponsePhotoId, setSelectedResponsePhotoId] = useState<string | null>(null);
const [selectedIntakePhotoId, setSelectedIntakePhotoId] = useState<string | null>(null);
const [historySearch, setHistorySearch] = useState("");
const [newClientSearch, setNewClientSearch] = useState("");
const [returnToNewConsultationAfterClient, setReturnToNewConsultationAfterClient] = useState(false);
const [expandedBudgetId, setExpandedBudgetId] = useState<string | null>(null);
const [finishPaymentMode, setFinishPaymentMode] = useState<"paid" | "pending" | "installments" | "free">("paid");
const [finishPaymentMethod, setFinishPaymentMethod] = useState<PaymentMethod>("pix");
const [finishPaymentDate, setFinishPaymentDate] = useState("");
const [finishInstallmentCount, setFinishInstallmentCount] = useState("2");
const [finishInstallmentFirstDate, setFinishInstallmentFirstDate] = useState("");
const [finishInstallmentSurcharge, setFinishInstallmentSurcharge] = useState("0");
const [finishInstallmentEntry, setFinishInstallmentEntry] = useState(false);
const [finishEntryAmount, setFinishEntryAmount] = useState("0");
const [finishInstallmentRows, setFinishInstallmentRows] = useState<Array<{id:string; number:number; amount:string; dueDate:string; status:"received"|"pending"}>>([]);
const [finishCurrency, setFinishCurrency] = useState<CurrencyCode>("BRL");
const [finishForeignAmount, setFinishForeignAmount] = useState("");
const [editingCheckoutQuestionId, setEditingCheckoutQuestionId] = useState<string | null>(null);
const [editingCheckoutChargeId, setEditingCheckoutChargeId] = useState<string | null>(null);
const [editingRelatedChargeId, setEditingRelatedChargeId] = useState<string | null>(null);
const [relatedChargeReceivedObjects, setRelatedChargeReceivedObjects] = useState<WorkObject[]>([]);
const [relatedChargeSentObjects, setRelatedChargeSentObjects] = useState<WorkObject[]>([]);
const [checkoutCurrency, setCheckoutCurrency] = useState<CurrencyCode>("BRL");
const [currencyRates, setCurrencyRates] = useState<Record<string, number>>({});
const [currencyRateDate, setCurrencyRateDate] = useState("");
const [currencySettings, setCurrencySettings] = useState<CurrencySettings>(() => {
  const raw = readStorage<Partial<CurrencySettings>>("currency-settings", {});
  return { paypalFeePercent: Number(raw?.paypalFeePercent) || 0, wiseFeePercent: Number(raw?.wiseFeePercent) || 0, otherFeePercent: Number(raw?.otherFeePercent) || 0 };
});
const [photoNoteDraft, setPhotoNoteDraft] = useState("");
const [futurePurchases, setFuturePurchases] = useState<FuturePurchase[]>(() =>
 readStorage(FUTURE_PURCHASES_KEY, [])
);
const [notes, setNotes] = useState<NoteItem[]>(() =>
 readStorage(NOTES_KEY, [])
);
const [agendaItems, setAgendaItems] = useState<AgendaItem[]>(() =>
 readStorage(AGENDA_KEY, [])
);
const [accountTemplates, setAccountTemplates] = useState<AccountTemplate[]>(() =>
 readStorage(ACCOUNT_TEMPLATES_KEY, [])
);
const [budgets, setBudgets] = useState<Budget[]>(() => {
const stored = readStorage<unknown>(BUDGETS_KEY, []);
return Array.isArray(stored) ? stored as Budget[] : [];
});
const [budgetClientId, setBudgetClientId] = useState("");
const [budgetSourceConsultationId, setBudgetSourceConsultationId] = useState("");
const [budgetServiceType, setBudgetServiceType] = useState<Budget["serviceType"]>("reading");
const [budgetServiceName, setBudgetServiceName] = useState("");
const [budgetTitle, setBudgetTitle] = useState("");
const [budgetDescription, setBudgetDescription] = useState("");
const [budgetValue, setBudgetValue] = useState("");
const [budgetItems, setBudgetItems] = useState<BudgetItem[]>([]);
const [budgetItemDescription, setBudgetItemDescription] = useState("");
const [budgetItemKind, setBudgetItemKind] = useState<BudgetItem["kind"]>("other");
const [budgetItemQuantity, setBudgetItemQuantity] = useState("1");
const [budgetItemUnitPrice, setBudgetItemUnitPrice] = useState("");
const [budgetDiscount, setBudgetDiscount] = useState("0");
const [budgetSurcharge, setBudgetSurcharge] = useState("0");
const [budgetValidUntil, setBudgetValidUntil] = useState("");
const [budgetShippingEnabled, setBudgetShippingEnabled] = useState(false);
const [budgetShippingRecipientName, setBudgetShippingRecipientName] = useState("");
const [budgetShippingPhone, setBudgetShippingPhone] = useState("");
const [budgetShippingAddress, setBudgetShippingAddress] = useState("");
const [budgetShippingZipCode, setBudgetShippingZipCode] = useState("");
const [budgetShippingCity, setBudgetShippingCity] = useState("");
const [budgetShippingState, setBudgetShippingState] = useState("");
const [budgetShippingUber, setBudgetShippingUber] = useState("");
const [budgetShippingCorreios, setBudgetShippingCorreios] = useState("");
const [budgetShippingCorreiosPending, setBudgetShippingCorreiosPending] = useState(false);
const [budgetCurrency, setBudgetCurrency] = useState<CurrencyCode>("BRL");
const [budgetPaymentMethod, setBudgetPaymentMethod] = useState<PaymentMethod>("pix");
const [budgetPaymentMode, setBudgetPaymentMode] = useState<"paid"|"pending"|"installments">("pending");
const [budgetPaymentDate, setBudgetPaymentDate] = useState("");
const [budgetInstallmentCount, setBudgetInstallmentCount] = useState("2");
const [budgetInstallmentFirstDate, setBudgetInstallmentFirstDate] = useState("");
const [budgetInstallmentEntry, setBudgetInstallmentEntry] = useState(false);
const [budgetInstallmentEntryAmount, setBudgetInstallmentEntryAmount] = useState("0");
const [showQuickBudgetModal, setShowQuickBudgetModal] = useState(false);
const [agendaTab, setAgendaTab] = useState<AgendaCategory | "accounts" | "consultants">("work");
const [consultantAgendaView, setConsultantAgendaView] = useState<"open" | "archived">("open");
const [expandedConsultantPaymentClientId, setExpandedConsultantPaymentClientId] = useState<string | null>(null);
const [consultantAgendaSearch, setConsultantAgendaSearch] = useState("");
const [agendaDate, setAgendaDate] = useState(new Date().toISOString().slice(0, 10));
const [agendaFilterDate, setAgendaFilterDate] = useState("");
const [agendaTitle, setAgendaTitle] = useState("");
const [agendaDescription, setAgendaDescription] = useState("");
const [agendaClientId, setAgendaClientId] = useState("");
const [agendaTime, setAgendaTime] = useState("09:00");
const [agendaCategory, setAgendaCategory] = useState<AgendaCategory>("work");
const [organizationAgendaTab, setOrganizationAgendaTab] = useState<"routines"|"appointments">("routines");
const [organizationAppointmentComposerOpen, setOrganizationAppointmentComposerOpen] = useState(false);
const [agendaNotify, setAgendaNotify] = useState(true);
const [agendaPriority, setAgendaPriority] = useState(3);
const [newServicePriority, setNewServicePriority] = useState(3);
const [workSetupPriority, setWorkSetupPriority] = useState(3);
const [dashboardMonthOffset, setDashboardMonthOffset] = useState(0);
const [agendaEditingId, setAgendaEditingId] = useState<string | null>(null);
const [accountTemplateName, setAccountTemplateName] = useState("");
const [accountTemplateDescription, setAccountTemplateDescription] = useState("");
const [accountTemplateArea, setAccountTemplateArea] = useState<FinanceArea>("home");
const [accountTemplateDueDay, setAccountTemplateDueDay] = useState("10");
const [accountTemplateAmount, setAccountTemplateAmount] = useState("");
const [accountTemplateSupplierId, setAccountTemplateSupplierId] = useState("");
const [futureTitle, setFutureTitle] = useState("");
const [futureDescription, setFutureDescription] = useState("");
const [futureLink, setFutureLink] = useState("");
const [futureArea, setFutureArea] = useState<FinanceArea>("home");
const [futureSectorId, setFutureSectorId] = useState("");
const [futurePriority, setFuturePriority] = useState<FuturePurchasePriority>("medium");
const [futureTimeframe, setFutureTimeframe] = useState<FuturePurchaseTimeframe>("30days");
const [futureTargetDate, setFutureTargetDate] = useState("");
const [noteTitle, setNoteTitle] = useState("");
const [noteContent, setNoteContent] = useState("");
const [editingNoteId, setEditingNoteId] = useState<string | null>(null);
const [dailyDate, setDailyDate] = useState(new Date().toISOString().slice(0, 10));
const [dailyFilter, setDailyFilter] = useState("all");
const [dailySearch, setDailySearch] = useState("");
const [expandedDailyId, setExpandedDailyId] = useState<string | null>(null);
const [showNewConsultation, setShowNewConsultation] =
useState(false);
const [showNewClient, setShowNewClient] =
useState(false);
const [returnToAgendaClientContext, setReturnToAgendaClientContext] = useState<"composer" | "schedule" | null>(null);
const [editingClientId, setEditingClientId] = useState<string | null>(null);
const [activeConsultation, setActiveConsultation] =
useState<Consultation | null>(null);
const [historyClient, setHistoryClient] =
useState<Client | null>(null);
const [selectedClientId, setSelectedClientId] =
useState(clients[0]?.id || "");
const [activeQuestionId, setActiveQuestionId] =
useState<string | null>(null);
const [newTitle, setNewTitle] = useState("");
const [newValue, setNewValue] = useState("");
const [newPaid, setNewPaid] = useState(true);
const [newPaymentDate, setNewPaymentDate] = useState("");
const [showIntakeModal, setShowIntakeModal] = useState(false);
const [showScheduleModal, setShowScheduleModal] = useState(false);
const [newPaymentMode, setNewPaymentMode] = useState<"paid" | "pending" | "installments" | "free">("pending");
const [newInstallmentCount, setNewInstallmentCount] = useState("2");
const [newInstallmentFirstDate, setNewInstallmentFirstDate] = useState("");
const [newInstallmentPaymentMethod, setNewInstallmentPaymentMethod] = useState<PaymentMethod>("pix");
const [newInstallmentDrafts, setNewInstallmentDrafts] = useState<InstallmentDraft[]>([]);
const [newInstallmentSurcharge, setNewInstallmentSurcharge] = useState("0");
const [newClientName, setNewClientName] = useState("");
const [clientPhotoDraft, setClientPhotoDraft] = useState<string>("");
const [selectedClientPhoto, setSelectedClientPhoto] = useState<{id?:string;name:string;data:string}|null>(null);
const [newClientPhone, setNewClientPhone] = useState("");
const [newClientBirthDate, setNewClientBirthDate] = useState("");
const [newClientCPF, setNewClientCPF] = useState("");
const [newClientStreet, setNewClientStreet] = useState("");
const [newClientNumber, setNewClientNumber] = useState("");
const [newClientComplement, setNewClientComplement] = useState("");
const [newClientNeighborhood, setNewClientNeighborhood] = useState("");
const [newClientCity, setNewClientCity] = useState("");
const [newClientState, setNewClientState] = useState("");
const [newClientPostalCode, setNewClientPostalCode] = useState("");
const [newClientCountry, setNewClientCountry] = useState("");
const [clientSearch, setClientSearch] = useState("");
const [newClientNotes, setNewClientNotes] = useState("");
const [newClientSource, setNewClientSource] = useState<ClientSource>("instagram");
const [newClientReferrerId, setNewClientReferrerId] = useState("");
const [newClientSourceDetails, setNewClientSourceDetails] = useState("");
const [newScheduledDate, setNewScheduledDate] = useState("");
const [newScheduledTime, setNewScheduledTime] = useState("");
const [showFinishConsultation, setShowFinishConsultation] =
useState(false);
const syncReadyRef = useRef(false);
const [editingConsultationId, setEditingConsultationId] = useState<string | null>(null);
const [editConsultationTitle, setEditConsultationTitle] = useState("");
const [editConsultationValue, setEditConsultationValue] = useState("");
const [editConsultationPaid, setEditConsultationPaid] = useState(false);
const [editConsultationPaymentDate, setEditConsultationPaymentDate] = useState("");
const [editConsultationNotes, setEditConsultationNotes] = useState("");
const [showEditConsultation, setShowEditConsultation] = useState(false);
const [editingPurchaseId, setEditingPurchaseId] = useState<string | null>(null);
const [recording, setRecording] = useState(false);
const [audioRecorderOpen, setAudioRecorderOpen] = useState(false);
const [audioRecorderStarting, setAudioRecorderStarting] = useState(false);
const [recordingPaused, setRecordingPaused] = useState(false);
const [recordingTime, setRecordingTime] = useState(0);
const [recordingPreviewUrl, setRecordingPreviewUrl] = useState<string | null>(null);
const [pendingRecordedAudio, setPendingRecordedAudio] = useState<AudioItem | null>(null);
const [pendingRecordedTarget, setPendingRecordedTarget] = useState<RecordingTarget | null>(null);
const [audioRecorderSavedNotice, setAudioRecorderSavedNotice] = useState(false);
const [playingAudio, setPlayingAudio] =
useState<string | null>(null);
const [trimAudio, setTrimAudio] =
useState<AudioItem | null>(null);
const [trimStart, setTrimStart] = useState("0");
const [trimEnd, setTrimEnd] = useState("");
const [partialPaymentTarget, setPartialPaymentTarget] = useState<any | null>(null);
const [partialPaymentAmount, setPartialPaymentAmount] = useState("");
const [partialPaymentMethod, setPartialPaymentMethod] = useState<PaymentMethod>("pix");
/* -------------------------------------------------------
FINANCEIRO
------------------------------------------------------- */
const [purchases, setPurchases] =
useState<Purchase[]>(() =>
readStorage(PURCHASES_KEY, [])
);
const [suppliers, setSuppliers] =
useState<Supplier[]>(() =>
readStorage<Supplier[]>(SUPPLIERS_KEY, []).map((supplier) => ({ ...supplier, area: supplier.area || "home", sectorId: supplier.sectorId || "", categoryIds: supplier.categoryIds || [] }))
);
const [stockItems, setStockItems] =
useState<StockItem[]>(() =>
readStorage(STOCK_ITEMS_KEY, [])
);
const [stockMovements, setStockMovements] =
useState<StockMovement[]>(() =>
readStorage(STOCK_MOVEMENTS_KEY, [])
);
const [inventoryItems, setInventoryItems] = useState<InventoryItem[]>(() => {
  const stored = readStorage<unknown>(INVENTORY_KEY, []);
  return Array.isArray(stored) ? stored.filter(Boolean).map(item => normalizeInventoryItem(item as Partial<InventoryItem>)) : [];
});
const [payables, setPayables] =
useState<PayableAccount[]>(() =>
readStorage(PAYABLES_KEY, [])
);
const [loans, setLoans] =
useState<Loan[]>(() =>
readStorage(LOANS_KEY, [])
);
const [reserves, setReserves] = useState<Reserve[]>(() => readStorage(RESERVES_KEY, []));
const [investments, setInvestments] = useState<Investment[]>(() => readStorage(INVESTMENTS_KEY, []));
const [overdrafts, setOverdrafts] =
useState<Overdraft[]>(() =>
readStorage(OVERDRAFTS_KEY, [])
);
const [householdSectors, setHouseholdSectors] =
useState<HouseholdSector[]>(() =>
readStorage(SECTORS_KEY, initialSectors)
);
const [householdCategories, setHouseholdCategories] =
useState<HouseholdCategory[]>(() =>
readStorage(CATEGORIES_KEY, initialCategories)
);
/* -------------------------------------------------------
MODAIS FINANCEIROS
------------------------------------------------------- */
const [showPurchaseModal, setShowPurchaseModal] =
useState(false);
const [showSupplierModal, setShowSupplierModal] =
useState(false);
const [showStockModal, setShowStockModal] = useState(false);
const [editingStockItemId, setEditingStockItemId] = useState<string | null>(null);
const [showPayableModal, setShowPayableModal] =
useState(false);
const [showTransferModal, setShowTransferModal] =
useState(false);
const [showPayableActionModal, setShowPayableActionModal] = useState<null | {kind:"pay"|"postpone"; id:string}>(null);
const [payableActionDate, setPayableActionDate] = useState("");
const [payableActionInterest, setPayableActionInterest] = useState("0");
const [payableActionFine, setPayableActionFine] = useState("0");
const [payableActionAmount, setPayableActionAmount] = useState("");
const [quickCatalogKind, setQuickCatalogKind] = useState<null | "stock"|"work"|"category"|"sale"|"reading">(null);
const [quickCatalogReturnContext, setQuickCatalogReturnContext] = useState<null | "relatedChargeSale">(null);
const [quickCatalogName, setQuickCatalogName] = useState("");
const [quickCatalogPrice, setQuickCatalogPrice] = useState("0");
const [quickCatalogQuestions, setQuickCatalogQuestions] = useState("1");
const [quickCatalogSectorId, setQuickCatalogSectorId] = useState("");
/* -------------------------------------------------------
COMPRA
------------------------------------------------------- */
const [purchaseSupplierId, setPurchaseSupplierId] =
useState("");
const [purchaseDate, setPurchaseDate] =
useState(new Date().toISOString().slice(0, 10));
const [purchaseSource, setPurchaseSource] =
useState<"manual" | "nfe_qr">("manual");
const [purchaseQrCode, setPurchaseQrCode] =
useState("");
const [purchaseAccessKey, setPurchaseAccessKey] =
useState("");
const [purchaseNotes, setPurchaseNotes] =
useState("");
const [purchaseItems, setPurchaseItems] =
useState<PurchaseItem[]>([]);
/* -------------------------------------------------------
FORNECEDOR
------------------------------------------------------- */
const [supplierName, setSupplierName] =
useState("");
const [supplierType, setSupplierType] =
useState<SupplierType>("market");
const [supplierPhone, setSupplierPhone] =
useState("");
const [supplierDocument, setSupplierDocument] =
useState("");
const [supplierNotes, setSupplierNotes] =
useState("");
const [supplierArea, setSupplierArea] =
useState<FinanceArea>("home");
const [supplierSectorId, setSupplierSectorId] =
useState("");
const [supplierCategoryIds, setSupplierCategoryIds] =
useState<string[]>([]);
/* -------------------------------------------------------
ESTOQUE
------------------------------------------------------- */
const [stockName, setStockName] =
useState("");
const [stockArea, setStockArea] =
useState<FinanceArea>("home");
const [stockQuantity, setStockQuantity] =
useState("");
const [stockUnit, setStockUnit] =
useState("un");
const [stockMinimum, setStockMinimum] =
useState("");
const [stockCost, setStockCost] =
useState("");
const [stockCategory, setStockCategory] =
useState("");
/* -------------------------------------------------------
CONTAS
------------------------------------------------------- */
const [payableDescription, setPayableDescription] =
useState("");
const [payableArea, setPayableArea] =
useState<FinanceArea>("home");
const [payableAmount, setPayableAmount] =
useState("");
const [payableDueDate, setPayableDueDate] =
useState("");
const [payableSupplierId, setPayableSupplierId] =
useState("");
const [payableMethod, setPayableMethod] = useState<PaymentMethod>("pix");
const [payableRecurrenceType, setPayableRecurrenceType] = useState<"none"|"recurring"|"fixed">("none");
const [payableRecurrenceCount, setPayableRecurrenceCount] = useState("1");
/* -------------------------------------------------------
TRANSFERÊNCIA
------------------------------------------------------- */
const [transferStockId, setTransferStockId] =
useState("");
const [transferQuantity, setTransferQuantity] =
useState("");
const [transferDestination, setTransferDestination] =
useState<FinanceArea>("work");
const [toast, setToast] = useState("");
const [quickTransactions, setQuickTransactions] =
useState<QuickTransaction[]>(() =>
readStorage(QUICK_TRANSACTIONS_KEY, [])
);
const [bankAccounts, setBankAccounts] =
useState<BankAccount[]>(() =>
readStorage(BANK_ACCOUNTS_KEY, [])
);
const [readingTypes, setReadingTypes] =
useState<ReadingType[]>(() => {
const stored = readStorage<unknown>(READING_TYPES_KEY, initialReadingTypes);
if (!Array.isArray(stored)) return initialReadingTypes;
return normalizeReadingTypesList(stored as ReadingType[]);
});
const [selectedReadingTypeId, setSelectedReadingTypeId] =
useState("simple");
const [newReadingCurrency, setNewReadingCurrency] = useState<CurrencyCode>("BRL");
const [workTypes, setWorkTypes] = useState<WorkType[]>(() => {
const stored = readStorage<unknown>(WORK_TYPES_KEY, [
  { id: "work-prosperity", name: "Trabalho de prosperidade", active: true, prices: emptyCurrencyPrices(), createdAt: nowISO() },
  { id: "work-love", name: "Dominação amorosa", active: true, prices: emptyCurrencyPrices(), createdAt: nowISO() },
  { id: "work-obsession", name: "Obsessão", active: true, prices: emptyCurrencyPrices(), createdAt: nowISO() },
  { id: "work-protection", name: "Proteção", active: true, prices: emptyCurrencyPrices(), createdAt: nowISO() },
  { id: "work-opening", name: "Abertura de caminhos", active: true, prices: emptyCurrencyPrices(), createdAt: nowISO() },
]);
if (!Array.isArray(stored)) return [];
return (stored as WorkType[]).map(item => ({ ...item, prices: normalizeCurrencyPrices(item.prices), standardItems: Array.isArray(item.standardItems) ? item.standardItems : [] }));
});
const [workExecutions, setWorkExecutions] = useState<WorkExecution[]>(() => readStorage(WORK_EXECUTIONS_KEY, []));
const [selectedWorkExecutionId, setSelectedWorkExecutionId] = useState<string | null>(null);
const [executionItems, setExecutionItems] = useState<Array<{stockItemId:string; quantity:string; usage:"new"|"reused"}>>([]);
const [executionStockOpen, setExecutionStockOpen] = useState(true);
const [executionFinanceOpen, setExecutionFinanceOpen] = useState(false);
const [executionInfoOpen, setExecutionInfoOpen] = useState(false);
const [questionResponseExpanded, setQuestionResponseExpanded] = useState(false);
const [executionValue, setExecutionValue] = useState("0");
const [executionCurrency, setExecutionCurrency] = useState<CurrencyCode>("BRL");
const [executionPaymentFee, setExecutionPaymentFee] = useState(0);
const [executionPaymentFeePercent, setExecutionPaymentFeePercent] = useState(0);
const [executionPaymentNetBRL, setExecutionPaymentNetBRL] = useState(0);
const [executionPaymentMode, setExecutionPaymentMode] = useState<"paid"|"pending"|"installments">("pending");
const [executionPaymentMethod, setExecutionPaymentMethod] = useState<PaymentMethod>("pix");
const [executionPaymentDate, setExecutionPaymentDate] = useState("");
const [executionInstallmentRows, setExecutionInstallmentRows] = useState<Array<InstallmentDraft & {status?: Installment["status"]}>>([]);
const [executionScheduleOpen, setExecutionScheduleOpen] = useState(false);
const [executionScheduleDate, setExecutionScheduleDate] = useState("");
const [executionScheduleTime, setExecutionScheduleTime] = useState("");
const [executionScheduleRequested, setExecutionScheduleRequested] = useState(false);
const [executionDate, setExecutionDate] = useState(localDateKey());
const [showEditRecordModal, setShowEditRecordModal] = useState(false);
const [editRecordTarget, setEditRecordTarget] = useState<any | null>(null);
const [editRecordStatus, setEditRecordStatus] = useState<string>("approved");
const [editRecordValue, setEditRecordValue] = useState("0");
const [editRecordPaymentMethod, setEditRecordPaymentMethod] = useState<PaymentMethod>("pix");
const [editRecordInstallments, setEditRecordInstallments] = useState<Array<InstallmentDraft & {status: Installment["status"]; receivedAmount?: string}>>([]);
const [editRecordExecutionDate, setEditRecordExecutionDate] = useState(localDateKey());
const [selectedServicePhotoId, setSelectedServicePhotoId] = useState<string | null>(null);

const [saleItems, setSaleItems] = useState<SaleItem[]>(() => {
const stored = readStorage<unknown>(SALE_ITEMS_KEY, []);
if (!Array.isArray(stored)) return [];
return (stored as SaleItem[]).map(item => ({ ...item, prices: normalizeCurrencyPrices(item.prices, item.price) }));
});
const [selectedWorkTypeId, setSelectedWorkTypeId] = useState("");
const [selectedSaleItemId, setSelectedSaleItemId] = useState("");
const [serviceValue, setServiceValue] = useState("");
const [servicePaymentMode, setServicePaymentMode] = useState<"paid"|"pending"|"installments"|"free">("pending");
const [servicePaymentMethod, setServicePaymentMethod] = useState<PaymentMethod>("pix");
const [serviceCurrency, setServiceCurrency] = useState<CurrencyCode>("BRL");
const [serviceForeignAmount, setServiceForeignAmount] = useState("");
const [servicePaymentDate, setServicePaymentDate] = useState("");
const [serviceInstallmentCount, setServiceInstallmentCount] = useState("2");
const [serviceInstallmentFirstDate, setServiceInstallmentFirstDate] = useState("");
const [serviceInstallmentEntry, setServiceInstallmentEntry] = useState(false);
const [serviceEntryAmount, setServiceEntryAmount] = useState("0");
const [serviceInstallmentRows, setServiceInstallmentRows] = useState<Array<InstallmentDraft & {status?: Installment["status"]}>>([]);
const [servicePhotos, setServicePhotos] = useState<PhotoItem[]>([]);
const [serviceAudios, setServiceAudios] = useState<AudioItem[]>([]);
const [serviceNotes, setServiceNotes] = useState("");
const [serviceBudgetId, setServiceBudgetId] = useState("");
const [serviceReceivedObjects, setServiceReceivedObjects] = useState<WorkObject[]>([]);
const [serviceSentObjects, setServiceSentObjects] = useState<WorkObject[]>([]);
const [objectModalKind, setObjectModalKind] = useState<"received"|"sent"|null>(null);
const [objectModalContext, setObjectModalContext] = useState<"service"|"relatedCharge"|"workSetup">("service");
const [objectAddress, setObjectAddress] = useState("");
const [objectPostalCode, setObjectPostalCode] = useState("");
const [objectCountry, setObjectCountry] = useState("Brasil");
const [objectDraftName, setObjectDraftName] = useState("");
const [objectDraftValue, setObjectDraftValue] = useState("");
const [objectDraftNotes, setObjectDraftNotes] = useState("");
const [serviceShippingEnabled, setServiceShippingEnabled] = useState(false);
const [serviceShippingMethod, setServiceShippingMethod] = useState<"uber"|"correios"|"retirada"|"outro">("uber");
const [serviceShippingScheduledAt, setServiceShippingScheduledAt] = useState("");
const [serviceShippingRecipientName, setServiceShippingRecipientName] = useState("");
const [serviceShippingPhone, setServiceShippingPhone] = useState("");
const [serviceShippingAddress, setServiceShippingAddress] = useState("");
const [serviceShippingZipCode, setServiceShippingZipCode] = useState("");
const [serviceShippingCity, setServiceShippingCity] = useState("");
const [serviceShippingState, setServiceShippingState] = useState("");
const [serviceShippingUber, setServiceShippingUber] = useState("");
const [serviceShippingUberSpent, setServiceShippingUberSpent] = useState(false);
const [serviceShippingUberSpentAmount, setServiceShippingUberSpentAmount] = useState("");
const [serviceShippingCorreios, setServiceShippingCorreios] = useState("");
const [serviceNeedsConfection, setServiceNeedsConfection] = useState(false);
const [relatedChargeNeedsConfection, setRelatedChargeNeedsConfection] = useState(false);
const [relatedCharges, setRelatedCharges] = useState<RelatedCharge[]>([]);
const [settingsTab, setSettingsTab] = useState<"home" | "work" | "financial" | "backup" | "maintenance">("home");
const [serviceHubTab, setServiceHubTab] = useState<"works"|"sales"|"readings"|"budgets">("works");
const [serviceHubSearch, setServiceHubSearch] = useState("");
const [serviceHubStatusFilter, setServiceHubStatusFilter] = useState("waiting");
const [serviceHubSort, setServiceHubSort] = useState<"recent"|"oldest">("recent");
const [selectedServiceRecord, setSelectedServiceRecord] = useState<any | null>(null);
const [showServiceDetail, setShowServiceDetail] = useState(false);
const [workSetupTarget, setWorkSetupTarget] = useState<Budget | null>(null);
const [workSetupValue, setWorkSetupValue] = useState("");
const [workSetupScheduleEnabled, setWorkSetupScheduleEnabled] = useState(false);
const [workSetupDate, setWorkSetupDate] = useState("");
const [workSetupTime, setWorkSetupTime] = useState("09:00");
const [workSetupNotes, setWorkSetupNotes] = useState("");
const [workSetupPaymentMode, setWorkSetupPaymentMode] = useState<"paid"|"pending"|"installments">("pending");
const [workSetupPaymentMethod, setWorkSetupPaymentMethod] = useState<PaymentMethod>("pix");
const [workSetupPaymentDate, setWorkSetupPaymentDate] = useState("");
const [workSetupInstallmentRows, setWorkSetupInstallmentRows] = useState<InstallmentDraft[]>([]);
const [workSetupReceivedObjects, setWorkSetupReceivedObjects] = useState<WorkObject[]>([]);
const [workSetupSentObjects, setWorkSetupSentObjects] = useState<WorkObject[]>([]);
const [permissionSetupOpen, setPermissionSetupOpen] = useState(false);
const [permissionSetupStatus, setPermissionSetupStatus] = useState({notifications:false,camera:false,microphone:false,contacts:false,overlay:false,exactAlarm:false});
const [resetDialog, setResetDialog] = useState<{groupId:string; mode:"module"|"selected"|"all"; target:"local"|"supabase"|"both"}|null>(null);
const [selectedResetGroups, setSelectedResetGroups] = useState<string[]>([]);
const [resetCountdown, setResetCountdown] = useState(3);
const [executionNotes, setExecutionNotes] = useState("");
const [executionExternalItems, setExecutionExternalItems] = useState<Array<{name:string;quantity:string;unit:string;cost:string;notes:string}>>([]);
const [externalItemDraft, setExternalItemDraft] = useState({name:"",quantity:"1",unit:"un",cost:"0",notes:""});
const [templateWorkId, setTemplateWorkId] = useState("");
const [templateStockId, setTemplateStockId] = useState("");
const [templateStockQty, setTemplateStockQty] = useState("1");
const [showMoreMovements, setShowMoreMovements] = useState(false);
const [movementSearch, setMovementSearch] = useState("");
const [movementPeriod, setMovementPeriod] = useState<"today"|"week"|"month"|"all">("month");
const [dashboardInstallmentPeriod, setDashboardInstallmentPeriod] = useState<"today"|"week"|"month"|"all">("all");
const [dashboardInstallmentTab, setDashboardInstallmentTab] = useState<"paid" | "pending" | "defaulted">("pending");
const [dashboardInstallmentSearch, setDashboardInstallmentSearch] = useState("");
const [selectedDashboardPayment, setSelectedDashboardPayment] = useState<any | null>(null);
const [dashboardNoticePeriod, setDashboardNoticePeriod] = useState<"3days"|"today"|"7days"|"15days"|"overdue">("3days");
const [expandedDashboardAccounts, setExpandedDashboardAccounts] = useState(false);
const [reportTab, setReportTab] = useState<"general"|"home"|"work"|"contacts"|"routines">("work");
const [reportPeriod, setReportPeriod] = useState<"month"|"quarter"|"year"|"custom">("month");
const [reportSearch, setReportSearch] = useState("");
const [reportCustomFrom, setReportCustomFrom] = useState(new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().slice(0,10));
const [reportCustomTo, setReportCustomTo] = useState(new Date().toISOString().slice(0,10));
const [showFinancialMovements, setShowFinancialMovements] = useState(false);
const [financialMovementFilter, setFinancialMovementFilter] = useState<"all"|"income"|"expense">("all");
const [showRelatedChargeModal, setShowRelatedChargeModal] = useState(false);
const [relatedChargeKind, setRelatedChargeKind] = useState<"work" | "sale">("work");
const [relatedChargeWorkTypeId, setRelatedChargeWorkTypeId] = useState("");
const [relatedChargeSaleItemId, setRelatedChargeSaleItemId] = useState("");
const [relatedChargeTitle, setRelatedChargeTitle] = useState("");
const [relatedChargeAmount, setRelatedChargeAmount] = useState("");
const [relatedChargeCurrency, setRelatedChargeCurrency] = useState<CurrencyCode>("BRL");
const [relatedChargeForeignAmount, setRelatedChargeForeignAmount] = useState("");
const [relatedChargeBillingMode, setRelatedChargeBillingMode] = useState<"paid" | "pending" | "installments" | "free" | "desfalque">("pending");
const [relatedChargePriority, setRelatedChargePriority] = useState(3);
const [relatedChargeBudgetId, setRelatedChargeBudgetId] = useState("");
const [relatedChargeScheduledAt, setRelatedChargeScheduledAt] = useState("");
const [relatedChargeShippingEnabled, setRelatedChargeShippingEnabled] = useState(false);
const [relatedChargeShippingScheduledAt, setRelatedChargeShippingScheduledAt] = useState("");
const [relatedChargeShippingAddress, setRelatedChargeShippingAddress] = useState("");
const [relatedChargeShippingPhone, setRelatedChargeShippingPhone] = useState("");
const [relatedChargeShippingUber, setRelatedChargeShippingUber] = useState("");
const [relatedChargeShippingUberSpent, setRelatedChargeShippingUberSpent] = useState(false);
const [relatedChargeShippingUberSpentAmount, setRelatedChargeShippingUberSpentAmount] = useState("");
const [relatedChargeNotes, setRelatedChargeNotes] = useState("");
const [relatedChargePhotos, setRelatedChargePhotos] = useState<PhotoItem[]>([]);
const [relatedChargeAudios, setRelatedChargeAudios] = useState<AudioItem[]>([]);
const [relatedReadingWorkId, setRelatedReadingWorkId] = useState("");
const [relatedReadingEnabled, setRelatedReadingEnabled] = useState(false);
const [preWorkReadingEnabled, setPreWorkReadingEnabled] = useState(false);
const [preWorkReadingWorkTypeId, setPreWorkReadingWorkTypeId] = useState("");
const [showQuickIncomeModal, setShowQuickIncomeModal] = useState(false);
const [showQuickExpenseModal, setShowQuickExpenseModal] = useState(false);
const [quickType, setQuickType] = useState<QuickTransactionType>("income");
const [quickArea, setQuickArea] = useState<FinanceArea>("work");
const [quickAmount, setQuickAmount] = useState("");
const [quickSource, setQuickSource] = useState("");
const [quickDescription, setQuickDescription] = useState("");
const [quickClientId, setQuickClientId] = useState("");
const [quickStockItemId, setQuickStockItemId] = useState("");
const [quickQuantity, setQuickQuantity] = useState("1");
const [quickPaymentMethod, setQuickPaymentMethod] = useState<PaymentMethod>("pix");
const [quickCurrency, setQuickCurrency] = useState<CurrencyCode>("BRL");
const [quickSupplierId, setQuickSupplierId] = useState("");
const [quickSectorId, setQuickSectorId] = useState("");
const [quickCategoryId, setQuickCategoryId] = useState("");
const [quickExpenseItems, setQuickExpenseItems] = useState<QuickExpenseItem[]>([]);
const [showQrScanner, setShowQrScanner] = useState(false);
const [intakeNotes, setIntakeNotes] = useState("");
const [intakePhotos, setIntakePhotos] = useState<PhotoItem[]>([]);
const [intakeAudios, setIntakeAudios] = useState<AudioItem[]>([]);
const [intakeEditingExisting, setIntakeEditingExisting] = useState(false);
type RecordingTarget = { kind: "intake" } | { kind: "question" } | { kind: "photo"; photoId: string } | { kind: "questionResponse" } | { kind: "service" } | { kind: "client"; clientId: string };
const [recordingTarget, setRecordingTarget] = useState<RecordingTarget>({ kind: "intake" });
const [newServiceType, setNewServiceType] =
useState<"consultation" | "work" | "sale" | "other">("consultation");
/* -------------------------------------------------------
REFS
------------------------------------------------------- */
const mediaRecorderRef =
useRef<MediaRecorder | null>(null);
const audioChunksRef =
useRef<Blob[]>([]);
const recordingIntervalRef =
useRef<number | null>(null);
const recordingElapsedRef = useRef(0);
const audioRefs =
useRef<Record<string, HTMLAudioElement | null>>({});
const qrVideoRef = useRef<HTMLVideoElement | null>(null);
const qrStreamRef = useRef<MediaStream | null>(null);
const nativeRecordingRef = useRef(false);
const nativeRecordedSegmentsRef = useRef<Array<{ data: string; duration: number }>>([]);
// No Android, quando pausamos usamos segmentos finalizados para permitir
// ouvir imediatamente o trecho já gravado. Nesse modo, retomar SEMPRE inicia
// um novo segmento; nunca tentamos chamar resumeRecording() sobre uma
// gravação que já foi encerrada com stopRecording().
const nativeSegmentPauseRef = useRef(false);
const recordingStartRef = useRef(false);
const cancelRecordingRef = useRef(false);
/* -------------------------------------------------------
QUESTION ATIVA
------------------------------------------------------- */
const currentQuestion =
activeConsultation?.questions.find(
(question) =>
question.id ===
(activeQuestionId ||
activeConsultation.questions[
activeConsultation.questions.length - 1
]?.id)
);

// V62 · snapshot de navegação para retorno do Android/segundo plano.
const uiStateRef = useRef<any>(null);
uiStateRef.current = {
  screen, activeConsultationId: activeConsultation?.id || null, activeQuestionId,
  historyClientId: historyClient?.id || null,
  showNewConsultation, showNewClient, showIntakeModal, showScheduleModal, showFinishConsultation,
  showEditConsultation, showRelatedChargeModal, showRelatedActivity, showServiceDetail,
  showDesfalqueModal, showRescheduleModal, showPayableActionModal, showPurchaseModal, showPayableModal,
  showStockModal, showSupplierModal, showTransferModal, showLoanManager, showLoanForm, showReserveManager,
  showQuickBudgetModal, showQuickIncomeModal, showQuickExpenseModal, quickCatalogKind, quickCatalogReturnContext,
  selectedServiceRecordId: selectedServiceRecord?.id || null, selectedServiceRecordType: selectedServiceRecord?.recordType || null,
  newTitle, newServiceType, selectedClientId, selectedWorkTypeId, selectedSaleItemId, newReadingCurrency,
  selectedReadingTypeId, relatedReadingEnabled, relatedReadingWorkId, preWorkReadingEnabled, preWorkReadingWorkTypeId, newClientSearch, intakeEditingExisting,
  intakeNotes, newScheduledDate, newScheduledTime, serviceValue, servicePaymentMode, servicePaymentMethod,
  serviceCurrency, serviceForeignAmount, servicePaymentDate, serviceInstallmentCount, serviceInstallmentFirstDate,
  serviceInstallmentEntry, serviceEntryAmount, serviceInstallmentRows, serviceNotes, serviceBudgetId, serviceReceivedObjects, serviceSentObjects,
  agendaTab, agendaDate, settingsTab, serviceHubTab, serviceHubStatusFilter, dashboardOperationalCollapsed, dashboardOperationalPeriod, dashboardOperationalSort,
};
const persistUiState = () => { try { safeSetStorage(UI_STATE_KEY, { ...uiStateRef.current, savedAt: Date.now() }); } catch {} };
useEffect(() => {
  if (!authUser || !appReady) return;
  const timer = window.setTimeout(persistUiState, 120);
  return () => window.clearTimeout(timer);
}, [authUser, appReady, screen, activeConsultation?.id, activeQuestionId, historyClient?.id,
  showNewConsultation, showNewClient, showIntakeModal, showScheduleModal, showFinishConsultation, showEditConsultation,
  showRelatedChargeModal, showRelatedActivity, showServiceDetail, showDesfalqueModal, showRescheduleModal, showPayableActionModal,
  showPurchaseModal, showPayableModal, showStockModal, showSupplierModal, showTransferModal, showLoanManager, showLoanForm, showReserveManager,
  showQuickBudgetModal, showQuickIncomeModal, showQuickExpenseModal, quickCatalogKind, quickCatalogReturnContext, newTitle, newServiceType, selectedClientId,
  selectedWorkTypeId, selectedSaleItemId, newReadingCurrency, selectedReadingTypeId, relatedReadingEnabled, relatedReadingWorkId, preWorkReadingEnabled, preWorkReadingWorkTypeId,
  newClientSearch, intakeEditingExisting, intakeNotes, newScheduledDate, newScheduledTime, serviceValue, servicePaymentMode, servicePaymentMethod,
  serviceCurrency, serviceForeignAmount, servicePaymentDate, serviceInstallmentCount, serviceInstallmentFirstDate, serviceInstallmentEntry,
  serviceEntryAmount, serviceInstallmentRows, serviceNotes, serviceBudgetId, serviceReceivedObjects, serviceSentObjects, agendaTab, agendaDate, settingsTab, serviceHubTab, serviceHubStatusFilter, dashboardOperationalCollapsed, dashboardOperationalPeriod, dashboardOperationalSort]);
useEffect(() => {
  const persist = () => persistUiState();
  window.addEventListener("pagehide", persist);
  window.addEventListener("beforeunload", persist);
  let handle: { remove: () => Promise<void> } | null = null;
  if (Capacitor.isNativePlatform()) CapacitorApp.addListener("appStateChange", ({ isActive }) => { if (!isActive) persistUiState(); }).then(listener => { handle = listener; }).catch(() => {});
  return () => { window.removeEventListener("pagehide", persist); window.removeEventListener("beforeunload", persist); if (handle) void handle.remove(); };
}, [authUser]);
// currencyRates guarda quantos BRL valem 1 unidade da moeda estrangeira.
// A API consultada usa base=BRL e quote=EUR/USD/GBP, portanto o retorno precisa ser invertido.
const convertToBRL = (amount: number, currency: CurrencyCode) => currency === "BRL" ? amount : amount * (currencyRates[currency] || 0);
const convertFromBRL = (amount: number, currency: CurrencyCode) => currency === "BRL" ? amount : (currencyRates[currency] ? amount / currencyRates[currency] : 0);
const convertCurrency = (amount: number, from: CurrencyCode, to: CurrencyCode) => {
  if (from === to) return amount;
  const brl = convertToBRL(amount, from);
  return to === "BRL" ? brl : convertFromBRL(brl, to);
};
const checkoutQuestions = (activeConsultation?.questions || []).filter(q => q.text.trim() || q.completed);
const inferredCheckoutCurrency: CurrencyCode = (activeConsultation?.currency || checkoutQuestions.find(q => q.currency)?.currency || activeConsultation?.relatedCharges?.find(c => c.currency)?.currency || "BRL") as CurrencyCode;
const effectiveCheckoutCurrency: CurrencyCode = finishCurrency || inferredCheckoutCurrency;
const questionCheckoutAmount = (q: Question) => {
  const mode = q.billingMode || "included";
  if (mode === "free" || mode === "desfalque" || mode === "included") return 0;
  const raw = Math.max(0, Number(q.value || 0));
  const discount = Math.min(raw, Math.max(0, Number(q.discount || 0)));
  return Math.max(0, raw - discount);
};
const questionPotentialAmount = (q: Question) => Math.max(0, Number(q.potentialValue ?? q.value ?? 0));
const checkoutQuestionTotal = (currency: CurrencyCode) => checkoutQuestions.reduce((sum, q) => sum + convertCurrency(questionCheckoutAmount(q), (q.currency || currency) as CurrencyCode, currency), 0);
const checkoutRelatedTotal = (currency: CurrencyCode) => (activeConsultation?.relatedCharges || []).reduce((sum, item) => { const mode = item.kind === "work" ? (item.billingMode || "pending") : "pending"; if (mode === "paid" || mode === "free" || mode === "desfalque") return sum; return sum + convertCurrency(Number(item.originalAmount || 0), item.currency || "BRL", currency); }, 0);
const checkoutQuestionTotalBRL = checkoutQuestionTotal("BRL");
const checkoutRelatedTotalBRL = checkoutRelatedTotal("BRL");
const checkoutStoredBaseBRL = Number(activeConsultation?.value || 0) || 0;
const checkoutTotalBRL = (checkoutQuestions.length === 0 && (activeConsultation?.relatedCharges || []).length === 0) ? checkoutStoredBaseBRL : checkoutQuestionTotalBRL + checkoutRelatedTotalBRL;
const checkoutTotal = checkoutQuestionTotal(effectiveCheckoutCurrency) + checkoutRelatedTotal(effectiveCheckoutCurrency);
const checkoutDesfalqueTotal = checkoutQuestions.reduce((sum, q) => {
  if (q.billingMode !== "desfalque" && !(q.billingMode === "free" && !q.workQuestionKind)) return sum;
  const potential = Math.max(0, Number(q.potentialValue ?? q.value ?? 0));
  return sum + convertCurrency(potential, (q.currency || effectiveCheckoutCurrency) as CurrencyCode, effectiveCheckoutCurrency);
}, 0) + (activeConsultation?.relatedCharges || []).reduce((sum, item) => {
  const mode = item.kind === "work" ? (item.billingMode || "pending") : "pending";
  return sum + (item.kind === "work" && mode === "desfalque" ? convertCurrency(Math.max(0, Number(item.potentialAmount ?? item.originalAmount ?? 0)), (item.currency || effectiveCheckoutCurrency) as CurrencyCode, effectiveCheckoutCurrency) : 0);
}, 0);
const checkoutDesfalqueTotalBRL = checkoutQuestions.reduce((sum, q) => (q.billingMode === "desfalque" || (q.billingMode === "free" && !q.workQuestionKind)) ? sum + convertCurrency(Math.max(0, Number(q.potentialValue ?? q.value ?? 0)), (q.currency || "BRL") as CurrencyCode, "BRL") : sum, 0) + (activeConsultation?.relatedCharges || []).reduce((sum, item) => { const mode=item.kind === "work" ? (item.billingMode || "pending") : "pending"; return sum + (item.kind === "work" && (mode === "desfalque" || mode === "free") ? convertCurrency(Math.max(0, Number(item.potentialAmount ?? item.originalAmount ?? 0)), (item.currency || "BRL") as CurrencyCode, "BRL") : 0); }, 0);
const checkoutPotentialTotalBRL = ((checkoutQuestions.length === 0 && (activeConsultation?.relatedCharges || []).length === 0) ? checkoutStoredBaseBRL : checkoutQuestionTotalBRL + checkoutRelatedTotalBRL) + checkoutDesfalqueTotalBRL;
const finishEnteredAmount = checkoutTotal;
const finishSelectedRate = finishCurrency === "BRL" ? 1 : (currencyRates[finishCurrency] || 0);
const finishGrossBRLPreview = convertToBRL(finishEnteredAmount, finishCurrency);
const getFeePercent = (method: PaymentMethod) => {
  const value = method === "paypal" ? currencySettings.paypalFeePercent : method === "wise" ? currencySettings.wiseFeePercent : method === "other" ? currencySettings.otherFeePercent : 0;
  const numeric = Number(value);
  return Number.isFinite(numeric) ? Math.max(0, numeric) : 0;
};
const finishFeePercentPreview = getFeePercent(finishPaymentMethod);
const finishFeeBRLPreview = (finishPaymentMode === "paid" || finishPaymentMode === "installments") && finishPaymentMethod !== "pix" ? finishGrossBRLPreview * Math.max(0, finishFeePercentPreview) / 100 : 0;
const finishNetBRLPreview = Math.max(0, finishGrossBRLPreview - finishFeeBRLPreview);
const finishNetForeignPreview = finishCurrency === "BRL" ? finishNetBRLPreview : convertFromBRL(finishNetBRLPreview, finishCurrency);

const COUNTRY_DDI: Array<[string, string]> = [
  ["55", "Brasil"], ["351", "Portugal"], ["34", "Espanha"], ["33", "França"],
  ["39", "Itália"], ["49", "Alemanha"], ["44", "Reino Unido"], ["353", "Irlanda"],
  ["31", "Países Baixos"], ["32", "Bélgica"], ["41", "Suíça"], ["43", "Áustria"],
  ["45", "Dinamarca"], ["46", "Suécia"], ["47", "Noruega"], ["48", "Polônia"],
  ["30", "Grécia"], ["40", "Romênia"], ["36", "Hungria"], ["420", "República Tcheca"],
  ["421", "Eslováquia"], ["385", "Croácia"], ["386", "Eslovênia"], ["359", "Bulgária"],
  ["90", "Turquia"], ["7", "Rússia / Cazaquistão"], ["1", "Estados Unidos / Canadá"],
  ["52", "México"], ["54", "Argentina"], ["56", "Chile"], ["57", "Colômbia"],
  ["58", "Venezuela"], ["51", "Peru"], ["598", "Uruguai"], ["595", "Paraguai"],
  ["27", "África do Sul"], ["61", "Austrália"], ["64", "Nova Zelândia"], ["81", "Japão"],
  ["82", "Coreia do Sul"], ["86", "China"], ["91", "Índia"], ["971", "Emirados Árabes Unidos"],
];
const detectCountryFromPhone = (phone: string) => {
  let digits = String(phone || "").replace(/\D/g, "");
  if (digits.startsWith("00")) digits = digits.slice(2);
  if (digits.startsWith("55") && digits.length >= 12) return "Brasil";
  const match = COUNTRY_DDI.slice().sort((a,b) => b[0].length - a[0].length).find(([ddi]) => digits.startsWith(ddi));
  if (match) return match[1];
  // Números brasileiros frequentemente são salvos sem +55.
  if (digits.length === 10 || digits.length === 11) return "Brasil";
  return "";
};
const clientCountry = (client: Client) => client.country || detectCountryFromPhone(client.phone) || "Não identificado";

useEffect(() => {
  const loadRates = async () => {
    try {
      const response = await fetch("https://api.frankfurter.dev/v2/rates?base=BRL&quotes=EUR,USD,GBP&providers=BCB");
      if (!response.ok) throw new Error("rates");
      const rows = await response.json();
      const next: Record<string, number> = {};
      (Array.isArray(rows) ? rows : []).forEach((row: any) => {
        const quote = String(row.quote || "").toUpperCase();
        const rateBRLToForeign = Number(row.rate);
        if (quote && rateBRLToForeign > 0) next[quote] = 1 / rateBRLToForeign;
      });
      if (next.EUR && next.USD && next.GBP) {
        setCurrencyRates(next);
        const latestDate = Array.isArray(rows) && rows.length ? rows.map((row:any) => row.date).filter(Boolean).sort().at(-1) : "";
        setCurrencyRateDate(latestDate || new Date().toISOString().slice(0,10));
      }
    } catch { console.warn("Não foi possível atualizar a cotação diária."); }
  };
  loadRates();
}, []);

useEffect(() => {
  if (finishPaymentMode !== "installments") return;
  const count = Math.max(2, Number(finishInstallmentCount) || 2);
  const baseDate = new Date();
  const total = Math.max(0, checkoutTotal) + Math.max(0, Number(String(finishInstallmentSurcharge).replace(",",".")) || 0);
  const entry = finishInstallmentEntry ? Math.min(total, Math.max(0, Number(String(finishEntryAmount).replace(",",".")) || 0)) : 0;
  setFinishInstallmentRows(previous => {
    if (previous.length === count) return previous;
    const rest = Math.max(0, total-entry);
    const each = count > 0 ? rest / count : 0;
    return Array.from({length:count},(_,i)=>{
      const d=new Date(baseDate);
      d.setDate(1);
      d.setMonth(d.getMonth()+i+1);
      return {id:makeId(),number:i+1,amount:String(Number(each.toFixed(2))),dueDate:d.toISOString().slice(0,10),status:"pending" as "received"|"pending"};
    });
  });
}, [finishPaymentMode, finishInstallmentCount, finishInstallmentFirstDate, finishInstallmentEntry, finishEntryAmount, finishInstallmentSurcharge, checkoutTotal, finishCurrency]);

/* =========================================================
EFFECTS
========================================================= */
/* =========================================================
   NAVEGAÇÃO DO APLICATIVO / BOTÃO VOLTAR DO ANDROID
========================================================= */
const navigationPopRef = useRef(false);
const navigationReadyRef = useRef(false);
const rootHistoryKeyRef = useRef<string>(`root-${makeId()}`);
useEffect(() => {
  if (!navigationReadyRef.current) {
    window.history.replaceState({ ...(window.history.state || {}), appScreen: screen, appRoot: true, navKey: rootHistoryKeyRef.current }, "", window.location.href);
    window.history.pushState({ appScreen: screen, appRoot: true, navKey: rootHistoryKeyRef.current }, "", window.location.href);
    navigationReadyRef.current = true;
    return;
  }
  if (navigationPopRef.current) { navigationPopRef.current = false; return; }
  window.history.pushState({ ...(window.history.state || {}), appScreen: screen, appRoot: screen === "dashboard" }, "", window.location.href);
}, [screen]);
useEffect(() => {
  const onPopState = (event: PopStateEvent) => {
    if (menuOpen) {
      setMenuOpen(false);
      window.history.pushState({ appScreen: screen, appRoot: screen === "dashboard" }, "", window.location.href);
      return;
    }
    const target = event.state?.appScreen as Screen | undefined;
    if (target && target !== screen) {
      navigationPopRef.current = true;
      setScreen(target);
      return;
    }
    if (screen !== "dashboard") {
      navigationPopRef.current = true;
      setScreen("dashboard");
      return;
    }
    const now = Date.now();
    if (now - exitPromptAt < 1800) {
      try { window.history.back(); } catch {}
      return;
    }
    setExitPromptAt(now);
    showToast("Pressione voltar novamente para sair.");
    window.history.pushState({ appScreen: "dashboard", appRoot: true, navKey: rootHistoryKeyRef.current }, "", window.location.href);
  };
  window.addEventListener("popstate", onPopState);
  return () => window.removeEventListener("popstate", onPopState);
}, [menuOpen, screen, exitPromptAt]);

useEffect(() => {
  if (!Capacitor.isNativePlatform()) return;
  let handle: { remove: () => Promise<void> } | null = null;
  CapacitorApp.addListener("backButton", () => {
    if (menuOpen) { setMenuOpen(false); return; }
    // A janela de cadastro rápido é filha das demais janelas. O botão
    // Voltar deve fechar primeiro somente a filha, preservando a janela pai.
    if (quickCatalogKind) {
      const confirmed = window.confirm("Há informações abertas nesta janela. Deseja sair dela?");
      if (!confirmed) return;
      setQuickCatalogKind(null); setQuickCatalogReturnContext(null);
      return;
    }
    const overlay = quickCatalogKind || showNewConsultation || showQuickBudgetModal || showQuickExpenseModal || showQuickIncomeModal || showEditConsultation || showEditRecordModal || showFinishConsultation || showRelatedChargeModal || showRelatedActivity || showIntakeModal || showScheduleModal || showServiceDetail || !!workSetupTarget || !!selectedWorkExecutionId || permissionSetupOpen || showPurchaseModal || showPayableModal || showStockModal || showSupplierModal || showTransferModal || showNewClient || showQrScanner || showDesfalqueModal || showRescheduleModal || !!consumeStockId || showLoanForm || !!partialPaymentTarget;
    if (overlay) {
      const confirmed = window.confirm("Há informações abertas nesta janela. Deseja sair dela?");
      if (!confirmed) return;
      setShowNewConsultation(false); setShowQuickBudgetModal(false); setShowQuickExpenseModal(false); setShowQuickIncomeModal(false); setShowEditConsultation(false); setShowFinishConsultation(false); setShowRelatedChargeModal(false); setShowRelatedActivity(false); setShowIntakeModal(false); setShowScheduleModal(false); setShowServiceDetail(false); setWorkSetupTarget(null); setSelectedWorkExecutionId(null); setPermissionSetupOpen(false); setShowPurchaseModal(false); setShowPayableModal(false); setShowStockModal(false); setShowSupplierModal(false); setShowTransferModal(false); setShowNewClient(false); setShowQrScanner(false); setShowDesfalqueModal(false); setShowRescheduleModal(false); setConsumeStockId(null); setShowLoanForm(false);
      return;
    }
    if (screen !== "dashboard") { window.history.back(); return; }
    const now = Date.now();
    if (now - exitPromptAt < 1800) { CapacitorApp.exitApp(); return; }
    setExitPromptAt(now);
    showToast("Pressione voltar novamente para sair.");
  }).then(listener => { handle = listener; }).catch(() => {});
  return () => { if (handle) void handle.remove(); };
}, [menuOpen, screen, exitPromptAt, quickCatalogKind]);

useEffect(() => {
safeSetStorage(CLIENTS_KEY, clients);
}, [clients]);
useEffect(() => {
safeSetStorage(CONSULTATIONS_KEY, consultations);
}, [consultations]);
useEffect(() => {
if (activeConsultation) {
safeSetStorage(DRAFT_KEY, activeConsultation);
}
}, [activeConsultation]);
useEffect(() => {
safeSetStorage(PURCHASES_KEY, purchases);
}, [purchases]);
useEffect(() => {
safeSetStorage(SUPPLIERS_KEY, suppliers);
}, [suppliers]);
useEffect(() => {
safeSetStorage(STOCK_ITEMS_KEY, stockItems);
}, [stockItems]);
useEffect(() => {
safeSetStorage(STOCK_MOVEMENTS_KEY, stockMovements);
}, [stockMovements]);
useEffect(() => { safeSetStorage(INVENTORY_KEY, inventoryItems); }, [inventoryItems]);
useEffect(() => {
  setConsultations(previous => {
    let changed = false;
    const next = previous.map(c => {
      const workStatus = c.workStatus === "in_progress" ? "approved" as const : c.workStatus;
      const relatedCharges = (c.relatedCharges || []).map(ch => ch.kind === "work" && ch.status === "in_progress" ? { ...ch, status:"approved" as const } : ch);
      const chargeChanged = relatedCharges.some((ch,i) => ch !== (c.relatedCharges || [])[i]);
      if (workStatus !== c.workStatus || chargeChanged) { changed = true; return { ...c, workStatus, relatedCharges, updatedAt: nowISO() }; }
      return c;
    });
    return changed ? next : previous;
  });
}, []);

useEffect(() => {
  const today = localDateKey();
  setPayables(previous => {
    let changed = false;
    const next = previous.map(item => {
      if (item.status === "paid") return item;
      const shouldBeOverdue = item.dueDate < today;
      const nextStatus = shouldBeOverdue ? "overdue" : (item.status === "overdue" ? "pending" : item.status);
      if (nextStatus !== item.status) { changed = true; return { ...item, status: nextStatus, updatedAt: nowISO() }; }
      return item;
    });
    return changed ? next : previous;
  });
}, []);

useEffect(() => {
  const today = localDateKey();
  setConsultations(previous => {
    let changed = false;
    const next = previous.map(c => {
      let cChanged = false;
      const paymentPlan = c.paymentPlan ? { ...c.paymentPlan, installments: c.paymentPlan.installments.map(i => {
        const nextStatus = i.status === "pending" && i.dueDate < today ? "overdue" as const : (i.status === "overdue" && i.dueDate >= today ? "pending" as const : i.status);
        if (nextStatus !== i.status) { cChanged = true; return { ...i, status: nextStatus }; }
        return i;
      }) } : c.paymentPlan;
      const questions = (c.questions || []).map(q => {
        if (!q.paymentPlan) return q;
        let qChanged = false;
        const qPlan = { ...q.paymentPlan, installments: q.paymentPlan.installments.map(i => {
          const nextStatus = i.status === "pending" && i.dueDate < today ? "overdue" as const : (i.status === "overdue" && i.dueDate >= today ? "pending" as const : i.status);
          if (nextStatus !== i.status) { qChanged = true; return { ...i, status: nextStatus }; }
          return i;
        }) };
        if (qChanged) { cChanged = true; return { ...q, paymentPlan: qPlan }; }
        return q;
      });
      if (!cChanged) return c;
      changed = true;
      return { ...c, paymentPlan, questions, updatedAt: nowISO() };
    });
    return changed ? next : previous;
  });
}, []);

// V98: normaliza parcelas antigas e mantém payments[] como histórico oficial dos recebimentos.
useEffect(() => {
  if (!appReady) return;
  setConsultations(previous => {
    let changed = false;
    const normalizeRows = (rows: Installment[]) => rows.map(row => {
      const payments = Array.isArray(row.payments) ? row.payments : [];
      let next = row;
      if (payments.length) {
        const received = Math.min(Math.max(0, Number(row.amount || 0)), payments.reduce((sum, p) => sum + Math.max(0, Number(p.amount || 0)), 0));
        const last = payments.slice().sort((a,b) => String(a.date || "").localeCompare(String(b.date || ""))).at(-1)?.date || row.lastPaymentAt;
        const fullyPaid = received >= Number(row.amount || 0) - 0.01;
        if (row.receivedAmount !== received || row.lastPaymentAt !== last || (fullyPaid && row.status !== "received") || (!fullyPaid && row.status === "received")) {
          next = { ...row, receivedAmount: received, lastPaymentAt: last, status: fullyPaid ? "received" : (row.status === "defaulted" ? "defaulted" : row.status === "overdue" ? "overdue" : "pending"), receivedAt: fullyPaid ? (row.receivedAt || last || "") : row.receivedAt };
        }
      } else if (row.status === "received" && Number(row.amount || 0) > 0) {
        const date = row.receivedAt || row.lastPaymentAt || nowISO();
        next = { ...row, receivedAmount: Number(row.amount || 0), payments: [{ id: `legacy-${row.id}`, amount: Number(row.amount || 0), date, paymentMethod: row.paymentMethod }], lastPaymentAt: date, receivedAt: row.receivedAt || date };
      }
      if (next !== row) changed = true;
      return next;
    });
    const nextConsultations = previous.map(c => {
      let cChanged = false;
      const paymentPlan = c.paymentPlan ? { ...c.paymentPlan, installments: normalizeRows(c.paymentPlan.installments) } : c.paymentPlan;
      if (paymentPlan && paymentPlan.installments.some((r,i) => r !== c.paymentPlan?.installments[i])) cChanged = true;
      const questions = (c.questions || []).map(q => {
        if (!q.paymentPlan) return q;
        const installments = normalizeRows(q.paymentPlan.installments);
        if (installments.some((r,i) => r !== q.paymentPlan?.installments[i])) { cChanged = true; return { ...q, paymentPlan: { ...q.paymentPlan, installments } }; }
        return q;
      });
      if (!cChanged) return c;
      changed = true;
      const primary = paymentPlan?.installments || [];
      const allPrimaryPaid = primary.length > 0 && primary.every(i => installmentReceivedAmount(i) >= i.amount - 0.01);
      return { ...c, paymentPlan, questions, paid: primary.length ? allPrimaryPaid : c.paid, paymentDate: primary.length && allPrimaryPaid ? (primary.flatMap(i => i.payments || []).sort((a,b)=>String(b.date).localeCompare(String(a.date)))[0]?.date || c.paymentDate) : c.paymentDate, updatedAt: nowISO() };
    });
    return changed ? nextConsultations : previous;
  });
}, [appReady]);

useEffect(() => {
safeSetStorage(PAYABLES_KEY, payables);
}, [payables]);
useEffect(() => { safeSetStorage(LOANS_KEY, loans); }, [loans]);
useEffect(() => { safeSetStorage(RESERVES_KEY, reserves); }, [reserves]);
useEffect(() => { safeSetStorage(INVESTMENTS_KEY, investments); }, [investments]);
useEffect(() => {
safeSetStorage(OVERDRAFTS_KEY, overdrafts);
}, [overdrafts]);
useEffect(() => {
safeSetStorage(SECTORS_KEY, householdSectors);
}, [householdSectors]);
useEffect(() => {
safeSetStorage(CATEGORIES_KEY, householdCategories);
}, [householdCategories]);
useEffect(() => {
safeSetStorage(QUICK_TRANSACTIONS_KEY, quickTransactions);
}, [quickTransactions]);
useEffect(() => {
safeSetStorage(BANK_ACCOUNTS_KEY, bankAccounts);
}, [bankAccounts]);
useEffect(() => {
safeSetStorage(READING_TYPES_KEY, readingTypes);
}, [readingTypes]);
useEffect(() => {
 safeSetStorage(FUTURE_PURCHASES_KEY, futurePurchases);
}, [futurePurchases]);
useEffect(() => {
 safeSetStorage(NOTES_KEY, notes);
}, [notes]);
useEffect(() => {
 safeSetStorage(AGENDA_KEY, agendaItems);
}, [agendaItems]);
useEffect(() => {
  const checkAgendaNotifications = () => {
    if (typeof Notification === "undefined" || Notification.permission !== "granted") return;
    const now = new Date(); const today = now.toISOString().slice(0,10); const hm = now.toTimeString().slice(0,5);
    agendaItems.filter(a=>a.notify && !a.completed && a.date===today && a.time===hm).forEach(a=>{ try { new Notification("Gestão · compromisso", { body: a.title }); } catch {} });
  };
  checkAgendaNotifications(); const timer=window.setInterval(checkAgendaNotifications,60000); return ()=>window.clearInterval(timer);
}, [agendaItems]);

useEffect(() => {
  const notify = (title:string, body:string) => {
    try { if (typeof Notification !== "undefined" && Notification.permission === "granted") new Notification(title, {body}); } catch {}
  };
  const check = () => {
    if (!routineSettings.notificationEnabled) return;
    const now = new Date(); const date = localDateKey(now); const hm = localTimeKey(now);
    routineTemplates.filter(r=>r.active && r.notify && r.days.includes(now.getDay())).forEach(r=>{
      const [hh,mm] = r.time.split(":").map(Number); const total=hh*60+mm; const current=now.getHours()*60+now.getMinutes();
      const target=total-Math.max(0,r.notifyBeforeMinutes || 0);
      if (current===target) notify("Gestão · rotina", `${r.title} · ${r.area === "home" ? "Casa" : "Trabalho"}`);
      if (current===total) notify("Gestão · rotina", `Está na hora: ${r.title}`);
    });
    medications.filter(m=>m.active).forEach(m=>m.times.forEach(t=>{ if(t===hm) notify("Gestão · medicamento", `Está na hora de registrar ${m.name}.`); }));
  };
  check(); const timer=window.setInterval(check,60000); return ()=>window.clearInterval(timer);
}, [routineTemplates, routineSettings, medications]);

useEffect(() => {
  if (!Capacitor.isNativePlatform()) return;
  let cancelled = false;
  const scheduleNativeReminders = async () => {
    try {
      const permission = await LocalNotifications.checkPermissions();
      if (permission.display !== "granted" || cancelled) return;
      const oldIds = readStorage<number[]>(ROUTINE_NOTIFICATION_IDS_KEY, []);
      if (oldIds.length) { try { await LocalNotifications.cancel({notifications: oldIds.map(id=>({id}))}); } catch {} }
      const notifications:any[] = []; const ids:number[]=[];
      const today=new Date();
      const hash=(text:string)=>{ let h=0; for(let i=0;i<text.length;i++) h=((h<<5)-h+text.charCodeAt(i))|0; return Math.abs(h)%2000000000; };
      for(let offset=0;offset<90;offset++){
        const d=new Date(today); d.setHours(0,0,0,0); d.setDate(d.getDate()+offset); const date=localDateKey(d);
        if (routineSettings.notificationEnabled) {
          routineTemplates.filter(r=>r.active&&r.notify&&r.days.includes(d.getDay())).forEach(r=>{
            const [hh,mm]=r.time.split(":").map(Number); const at=new Date(d); at.setHours(hh,mm,0,0); const id=hash(`routine:${r.id}:${date}:${r.time}`);
            if(at.getTime()>Date.now()+15000){ ids.push(id); notifications.push({id,title:"Gestão · rotina",body:`Está na hora: ${r.title}`,schedule:{at,allowWhileIdle:true}}); }
          });
          medications.filter(m=>m.active).forEach(m=>m.times.forEach(t=>{ const [hh,mm]=t.split(":").map(Number); const at=new Date(d); at.setHours(hh,mm,0,0); const id=hash(`med:${m.id}:${date}:${t}`); if(at.getTime()>Date.now()+15000){ ids.push(id); notifications.push({id,title:"Gestão · medicamento",body:`Está na hora de registrar ${m.name}.`,schedule:{at,allowWhileIdle:true}}); } }));
        }
      }
      agendaItems.filter(a=>a.notify&&!a.completed&&!a.deletedAt).forEach(a=>{
        const at=new Date(`${a.date}T${a.time}:00`); const id=hash(`agenda:${a.id}:${a.date}:${a.time}`);
        if(at.getTime()>Date.now()+15000 && at.getTime()<Date.now()+1000*60*60*24*90){ ids.push(id); notifications.push({id,title:a.relatedEntityType==="work"?"Gestão · trabalho":a.relatedEntityType==="sale"?"Gestão · envio":"Gestão · agenda",body:a.title,schedule:{at,allowWhileIdle:true}}); }
      });
      if(!cancelled && notifications.length){ await LocalNotifications.schedule({notifications}); localStorage.setItem(ROUTINE_NOTIFICATION_IDS_KEY,JSON.stringify(ids)); }
      else if(!cancelled) localStorage.setItem(ROUTINE_NOTIFICATION_IDS_KEY,JSON.stringify([]));
    } catch (error) { console.warn("Falha ao programar alarmes nativos",error); }
  };
  void scheduleNativeReminders();
  return ()=>{cancelled=true;};
}, [routineTemplates, routineSettings, medications, agendaItems]);

useEffect(() => {
 safeSetStorage(ACCOUNT_TEMPLATES_KEY, accountTemplates);
}, [accountTemplates]);
useEffect(() => {
  if (!accountTemplates.length) return;
  const now = new Date(); const year=now.getFullYear(); const month=now.getMonth()+1; const monthKey=`${year}-${String(month).padStart(2,"0")}`;
  setPayables(prev => {
    let changed=false; const next=[...prev];
    accountTemplates.filter(t=>t.active).forEach(t=>{
      const recurrenceKey=`${t.id}-${monthKey}`;
      if(next.some(p=>p.recurrenceKey===recurrenceKey)) return;
      const lastDay=new Date(year,month,0).getDate(); const day=Math.min(Math.max(1,t.dueDay),lastDay);
      next.unshift({id:makeId(),description:t.name,area:t.area,supplierId:t.supplierId||"",amount:Number(t.amount||0),originalAmount:Number(t.amount||0),dueDate:`${year}-${String(month).padStart(2,"0")}-${String(day).padStart(2,"0")}`,status:"pending",paymentMethod:"pix",notes:t.description||"",recurrenceId:t.id,recurrenceKey,isVariable:t.recurrenceType==="variable" || !t.amount}); changed=true;
    });
    return changed?next:prev;
  });
}, [accountTemplates]);
useEffect(() => {
 safeSetStorage(BUDGETS_KEY, budgets);
}, [budgets]);
useEffect(() => {
 safeSetStorage(TRASH_KEY, trash);
}, [trash]);
useEffect(() => {
 safeSetStorage(DESFALQUES_KEY, desfalques);
}, [desfalques]);
useEffect(() => { safeSetStorage("currency-settings", currencySettings); }, [currencySettings]);
useEffect(() => { safeSetStorage(WORK_TYPES_KEY, workTypes); }, [workTypes]);
useEffect(() => { safeSetStorage(WORK_EXECUTIONS_KEY, workExecutions); }, [workExecutions]);
useEffect(() => { safeSetStorage(SALE_ITEMS_KEY, saleItems); }, [saleItems]);
useEffect(()=>{ safeSetStorage(ROUTINE_ITEMS_KEY,routineItems); },[routineItems]);
useEffect(()=>{ safeSetStorage(FAMILY_MEMBERS_KEY,familyMembers); },[familyMembers]);
useEffect(()=>{ safeSetStorage(ROUTINE_TEMPLATES_KEY,routineTemplates); },[routineTemplates]);
useEffect(()=>{ safeSetStorage(ROUTINE_LOGS_KEY,routineLogs); },[routineLogs]);
useEffect(()=>{ safeSetStorage(ROUTINE_SETTINGS_KEY,[routineSettings]); },[routineSettings]);
useEffect(()=>{ safeSetStorage(HEALTH_ENTRIES_KEY,healthEntries); },[healthEntries]);
useEffect(()=>{ safeSetStorage(CYCLE_ENTRIES_KEY,cycleEntries); },[cycleEntries]);
useEffect(()=>{ safeSetStorage(MEDICATIONS_KEY,medications); },[medications]);
useEffect(()=>{ safeSetStorage(MEDICATION_LOGS_KEY,medicationLogs); },[medicationLogs]);
// V100: agenda e inventário são dados críticos. O snapshot anterior só era enviado
// em intervalo de 15s; se o app fosse desinstalado antes do próximo ciclo, uma
// alteração recente podia ficar apenas no localStorage. Agora essas duas áreas
// também fazem upload curto e debounced assim que o estado local muda.
useEffect(() => {
  if (!authUser || !appReady || !syncReadyRef.current || !navigator.onLine) return;
  const timer = window.setTimeout(() => {
    // V101: grava explicitamente os dois módulos críticos no snapshot remoto.
    // Não dependemos apenas de uma leitura intermediária do localStorage.
    void updateSupabaseSnapshot(authUser.id, payload => ({
      ...payload,
      [AGENDA_KEY]: agendaItems,
      [INVENTORY_KEY]: inventoryItems,
    })).catch(error => console.warn("V101 sync agenda/inventário", error));
  }, 350);
  return () => window.clearTimeout(timer);
}, [agendaItems, inventoryItems, authUser, appReady]);

useEffect(() => {
  if (!authUser || !appReady || !syncReadyRef.current) return;
  const flushCriticalData = () => {
    if (!navigator.onLine) return;
    void updateSupabaseSnapshot(authUser.id, payload => ({
      ...payload,
      [AGENDA_KEY]: agendaItems,
      [INVENTORY_KEY]: inventoryItems,
    })).catch(error => console.warn("V101 flush agenda/inventário", error));
  };
  window.addEventListener("pagehide", flushCriticalData);
  window.addEventListener("beforeunload", flushCriticalData);
  return () => {
    window.removeEventListener("pagehide", flushCriticalData);
    window.removeEventListener("beforeunload", flushCriticalData);
  };
}, [authUser, appReady, agendaItems, inventoryItems]);

useEffect(() => {
return () => {
if (recordingIntervalRef.current) {
window.clearInterval(
recordingIntervalRef.current
);
}
};
}, []);
useEffect(() => {
return () => stopQrScanner();
}, []);
useEffect(() => {
if (!toast) return;
const timer = window.setTimeout(() => {
setToast("");
}, 2800);
return () => window.clearTimeout(timer);
}, [toast]);
useEffect(() => {
const notifiedKey = "gestao_agenda_notified";
const checkAgenda = () => {
 const notified = readStorage<string[]>(notifiedKey, []);
 const now = new Date();
 const today = now.toISOString().slice(0, 10);
 const currentTime = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
 const reminders: Array<{ id: string; title: string; description: string; notify: boolean; completed?: boolean }> = [
  ...agendaItems.map(item => ({ id: `manual-${item.id}`, title: item.title, description: item.description, notify: item.notify, completed: item.completed })),
  ...consultations.filter(item => !!item.scheduledAt).map(item => ({
   id: `consultation-${item.id}`,
   title: `🔮 ${item.title}`,
   description: `Atendimento de ${item.clientName}`,
   notify: true,
   completed: item.status === "completed",
  })),
  ...payables.filter(item => item.dueDate === today && item.status !== "paid").map(item => ({
   id: `payable-${item.id}`,
   title: `💳 ${item.description}`,
   description: `Conta para pagar · ${item.area === "home" ? "Casa" : "Trabalho"}`,
   notify: true,
  })),
  ...accountTemplates.filter(item => item.active).map(item => {
   const year = now.getFullYear();
   const month = now.getMonth();
   const lastDay = new Date(year, month + 1, 0).getDate();
   const day = Math.min(item.dueDay, lastDay);
   return {
    id: `account-template-${item.id}-${year}-${month + 1}`,
    title: `💳 ${item.name}`,
    description: `Conta recorrente · ${item.area === "home" ? "Casa" : "Trabalho"}`,
    notify: true,
    dueDate: `${year}-${String(month + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`,
   };
  }).filter(item => item.dueDate === today).map(item => ({ id: item.id, title: item.title, description: item.description, notify: item.notify })),
 ];
 reminders.forEach((item) => {
  const source = agendaItems.find(a => `manual-${a.id}` === item.id);
  const consultation = consultations.find(c => `consultation-${c.id}` === item.id);
  const payable = payables.find(a => `payable-${a.id}` === item.id);
  const accountTemplate = item.id.startsWith("account-template-");
  const shouldNotify = item.notify && !item.completed && (
   source ? source.date === today && source.time === currentTime :
   consultation ? consultation.scheduledAt?.slice(0, 10) === today && consultation.scheduledAt?.slice(11, 16) === currentTime :
   payable ? currentTime === "08:00" :
   accountTemplate ? currentTime === "08:00" : false
  );
  if (!shouldNotify || notified.includes(item.id)) return;
  const message = item.description ? `${item.title} — ${item.description}` : item.title;
  try {
   if (typeof Notification !== "undefined" && Notification.permission === "granted") {
    new Notification("Lembrete da agenda", { body: message });
   }
  } catch {}
  try {
   const AudioContextClass = (window as any).AudioContext || (window as any).webkitAudioContext;
   if (AudioContextClass) {
    const ctx = new AudioContextClass();
    const oscillator = ctx.createOscillator();
    const gain = ctx.createGain();
    oscillator.connect(gain);
    gain.connect(ctx.destination);
    oscillator.frequency.value = 880;
    gain.gain.value = 0.08;
    oscillator.start();
    oscillator.stop(ctx.currentTime + 0.4);
   }
  } catch {}
  safeSetStorage(notifiedKey, [...notified, item.id]);
 });
};
checkAgenda();
const interval = window.setInterval(checkAgenda, 15000);
return () => window.clearInterval(interval);
}, [agendaItems, consultations, payables, accountTemplates]);
/* =========================================================
TOAST
========================================================= */
const showToast = (message: string) => {
setToast(message);
};

/* =========================================================
   V41 · CENTRAL DE RESET / LIMPEZA DE TESTES
   O reset primeiro atualiza o snapshot autoritativo no Supabase.
   Só depois limpa o cache local e recarrega a interface.
   Login/Supabase Auth nunca é apagado por estas ações.
========================================================= */
const RESET_GROUPS: Record<string, { label: string; icon: string; description: string; keys: string[] }> = {
  clients: { label: "Consulentes", icon: "👤", description: "Apaga os consulentes cadastrados.", keys: [CLIENTS_KEY] },
  consultations: { label: "Atendimentos e tiragens", icon: "🔮", description: "Apaga atendimentos, tiragens, perguntas e respectivos parcelamentos.", keys: [CONSULTATIONS_KEY] },
  works: { label: "Trabalhos", icon: "🔥", description: "Apaga trabalhos, execuções e vínculos de trabalho sem apagar as consultas comuns.", keys: [CONSULTATIONS_KEY, WORK_EXECUTIONS_KEY, AGENDA_KEY, DESFALQUES_KEY] },
  sales: { label: "Vendas", icon: "🛍️", description: "Apaga vendas e seus registros operacionais/financeiros relacionados.", keys: [CONSULTATIONS_KEY, AGENDA_KEY, QUICK_TRANSACTIONS_KEY] },
  agenda: { label: "Agenda", icon: "📅", description: "Apaga compromissos e agendamentos.", keys: [AGENDA_KEY] },
  budgets: { label: "Orçamentos", icon: "💼", description: "Apaga todos os orçamentos.", keys: [BUDGETS_KEY] },
  services: { label: "Execuções de serviços", icon: "✨", description: "Apaga os registros de execução de trabalhos.", keys: [WORK_EXECUTIONS_KEY] },
  finance: { label: "Financeiro", icon: "💰", description: "Apaga entradas, saídas, compras, contas pagas e a pagar, empréstimos, parcelas, caixinhas, movimentações, desfalques, bancos e aplicações.", keys: [PURCHASES_KEY, PAYABLES_KEY, LOANS_KEY, OVERDRAFTS_KEY, QUICK_TRANSACTIONS_KEY, BANK_ACCOUNTS_KEY, DESFALQUES_KEY, RESERVES_KEY, INVESTMENTS_KEY, ACCOUNT_TEMPLATES_KEY] },
  stock: { label: "Estoque", icon: "📦", description: "Apaga itens e movimentações do estoque.", keys: [STOCK_ITEMS_KEY, STOCK_MOVEMENTS_KEY] },
  inventory: { label: "Inventário", icon: "🗃️", description: "Apaga os itens fixos cadastrados no inventário.", keys: [INVENTORY_KEY] },
  suppliers: { label: "Fornecedores", icon: "🏪", description: "Apaga os fornecedores/estabelecimentos cadastrados.", keys: [SUPPLIERS_KEY] },
  futurePurchases: { label: "Compras futuras", icon: "🛒", description: "Apaga a lista de compras futuras.", keys: [FUTURE_PURCHASES_KEY] },
  notes: { label: "Bloco de notas", icon: "📝", description: "Apaga todas as notas.", keys: [NOTES_KEY] },
  trash: { label: "Lixeira", icon: "🗑️", description: "Apaga definitivamente os itens que estão na lixeira.", keys: [TRASH_KEY] },
  configurations: { label: "Cadastros e configurações", icon: "⚙️", description: "Volta tipos de tiragem, trabalhos, produtos, setores, categorias, contas recorrentes e taxas ao estado vazio/padrão.", keys: [READING_TYPES_KEY, WORK_TYPES_KEY, SALE_ITEMS_KEY, SECTORS_KEY, CATEGORIES_KEY, ACCOUNT_TEMPLATES_KEY, "currency-settings"] },
  organization: { label: "Organização e rotinas", icon: "🏠", description: "Apaga pessoas, rotinas, registros de execução, saúde, ciclo e medicamentos.", keys: [FAMILY_MEMBERS_KEY, ROUTINE_TEMPLATES_KEY, ROUTINE_LOGS_KEY, ROUTINE_SETTINGS_KEY, HEALTH_ENTRIES_KEY, CYCLE_ENTRIES_KEY, MEDICATIONS_KEY, MEDICATION_LOGS_KEY, ROUTINE_ITEMS_KEY, ROUTINE_NOTIFICATION_IDS_KEY] },
};

const cancelStoredNativeNotifications = async () => {
  try {
    const ids = readStorage<number[]>(ROUTINE_NOTIFICATION_IDS_KEY, []);
    if (ids.length && Capacitor.isNativePlatform()) await LocalNotifications.cancel({ notifications: ids.map(id => ({ id })) });
  } catch (error) { console.warn("Falha ao cancelar notificações no reset", error); }
};

const isWorkRecord = (c:any) => c?.serviceType === "work" || c?.workStatus !== undefined || c?.relatedWorkId;
const isSaleRecord = (c:any) => c?.serviceType === "sale" || c?.saleStatus !== undefined;
const installmentReceivedAmount = (row: Installment) => {
  const paymentTotal = Array.isArray(row.payments) && row.payments.length
    ? row.payments.reduce((sum, payment) => sum + Math.max(0, Number(payment.amount || 0)), 0)
    : null;
  if (paymentTotal !== null) return Math.max(0, Math.min(Number(row.amount || 0), paymentTotal));
  if (typeof row.receivedAmount === "number") return Math.max(0, Math.min(Number(row.amount || 0), row.receivedAmount));
  return row.status === "received" ? Math.max(0, Number(row.amount || 0)) : 0;
};
const installmentOpenAmount = (row: Installment) => Math.max(0, Number(row.amount || 0) - installmentReceivedAmount(row));
const getInstallmentPaymentState = (row: Installment) => {
  const originalAmount = Math.max(0, Number(row.amount || 0));
  const receivedAmount = installmentReceivedAmount(row);
  const openAmount = Math.max(0, originalAmount - receivedAmount);
  const status = row.status === "defaulted" ? "defaulted" : openAmount <= 0.009 ? "paid" : receivedAmount > 0.009 ? "partial" : row.status === "overdue" ? "overdue" : "pending";
  return { originalAmount, receivedAmount, openAmount, status, payments: Array.isArray(row.payments) ? row.payments : [] };
};
const getPaymentStatus = (consultation?: Consultation): "paid" | "partial" | "pending" => {
  const rows = consultation?.paymentPlan?.installments || [];
  if (rows.length) {
    const received = rows.reduce((sum,row)=>sum+installmentReceivedAmount(row),0);
    const total = rows.reduce((sum,row)=>sum+Math.max(0,Number(row.amount||0)),0);
    if (total > 0 && received >= total - 0.01) return "paid";
    if (received > 0) return "partial";
    return "pending";
  }
  return consultation?.paid ? "paid" : "pending";
};

const resetGroupPayload = (groupId:string, payload:any) => {
  const next = { ...payload };
  if (groupId === "finance") {
    next[QUICK_TRANSACTIONS_KEY] = [];
    next[PURCHASES_KEY] = [];
    next[PAYABLES_KEY] = [];
    next[LOANS_KEY] = [];
    next[OVERDRAFTS_KEY] = [];
    next[BANK_ACCOUNTS_KEY] = [];
    next[DESFALQUES_KEY] = [];
    next[RESERVES_KEY] = [];
    next[INVESTMENTS_KEY] = [];
    next[ACCOUNT_TEMPLATES_KEY] = [];
    next[CONSULTATIONS_KEY] = (Array.isArray(next[CONSULTATIONS_KEY]) ? next[CONSULTATIONS_KEY] : []).map((c:any)=>({
      ...c, paid:false, paymentDate:"", billingMode:"pending", paymentPlan:undefined, shortfall:0,
      questions:Array.isArray(c.questions)?c.questions.map((q:any)=>({...q,paymentPlan:undefined,paymentDate:""})):c.questions,
    }));
    return next;
  }
  if (groupId === "works") {
    const workIds = new Set((Array.isArray(next[CONSULTATIONS_KEY]) ? next[CONSULTATIONS_KEY] : []).filter(isWorkRecord).map((c:any)=>c.id));
    next[CONSULTATIONS_KEY] = (Array.isArray(next[CONSULTATIONS_KEY]) ? next[CONSULTATIONS_KEY] : []).filter((c:any)=>!isWorkRecord(c)).map((c:any)=>({
      ...c,
      questions:Array.isArray(c.questions)?c.questions.filter((q:any)=>!q.relatedWorkId):c.questions,
      relatedCharges:Array.isArray(c.relatedCharges)?c.relatedCharges.filter((ch:any)=>ch.kind!=="work"):c.relatedCharges,
      relatedWorkId: workIds.has(c.relatedWorkId) ? undefined : c.relatedWorkId,
    }));
    next[WORK_EXECUTIONS_KEY] = [];
    next[BUDGETS_KEY] = (Array.isArray(next[BUDGETS_KEY]) ? next[BUDGETS_KEY] : []).filter((b:any)=>!workIds.has(b.linkedWorkId));
    next[AGENDA_KEY] = (Array.isArray(next[AGENDA_KEY]) ? next[AGENDA_KEY] : []).filter((a:any)=>!(a.relatedEntityType==="work" || workIds.has(a.relatedEntityId)));
    next[DESFALQUES_KEY] = (Array.isArray(next[DESFALQUES_KEY]) ? next[DESFALQUES_KEY] : []).filter((d:any)=>!workIds.has(d.workId));
    return next;
  }
  if (groupId === "sales") {
    const saleIds = new Set((Array.isArray(next[CONSULTATIONS_KEY]) ? next[CONSULTATIONS_KEY] : []).filter(isSaleRecord).map((c:any)=>c.id));
    next[CONSULTATIONS_KEY] = (Array.isArray(next[CONSULTATIONS_KEY]) ? next[CONSULTATIONS_KEY] : []).filter((c:any)=>!isSaleRecord(c)).map((c:any)=>({
      ...c,
      relatedCharges:Array.isArray(c.relatedCharges)?c.relatedCharges.filter((ch:any)=>ch.kind!=="sale"):c.relatedCharges,
    }));
    next[AGENDA_KEY] = (Array.isArray(next[AGENDA_KEY]) ? next[AGENDA_KEY] : []).filter((a:any)=>!(a.relatedEntityType==="sale" || saleIds.has(a.relatedEntityId)));
    return next;
  }
  for (const key of RESET_GROUPS[groupId]?.keys || []) next[key] = key === "currency-settings" ? { paypalFeePercent: 0, wiseFeePercent: 0, otherFeePercent: 0 } : [];
  return next;
};

const applyLocalResetGroup = (groupId:string) => {
  const local = buildLocalSnapshotForReset();
  const next = resetGroupPayload(groupId, local);
  for (const key of V13_STORAGE_KEYS) if (Object.prototype.hasOwnProperty.call(next,key)) safeSetStorage(key,next[key]);
  safeSetStorage(ROUTINE_NOTIFICATION_IDS_KEY, []);
  localStorage.removeItem(DRAFT_KEY);
};

const buildLocalSnapshotForReset = () => {
  const snapshot:any = {};
  for (const key of V13_STORAGE_KEYS) snapshot[key] = readStorage<any>(key, key === "currency-settings" ? {paypalFeePercent:0,wiseFeePercent:0,otherFeePercent:0} : []);
  return snapshot;
};

const openResetConfirmation = (groupId:string, mode:"module"|"selected"|"all"="module") => {
  setResetCountdown(3);
  setResetDialog({groupId,mode,target:"both"});
};
const toggleResetGroup = (groupId:string) => {
  setSelectedResetGroups(previous => previous.includes(groupId) ? previous.filter(id=>id!==groupId) : [...previous, groupId]);
};
const resetSelectedGroups = async () => {
  if (!selectedResetGroups.length) { showToast("Selecione pelo menos um módulo para resetar."); return; }
  openResetConfirmation("__selected__","selected");
};

useEffect(()=>{
  if(!resetDialog) return;
  if(resetCountdown<=0) return;
  const timer=window.setTimeout(()=>setResetCountdown(v=>Math.max(0,v-1)),1000);
  return ()=>window.clearTimeout(timer);
},[resetDialog,resetCountdown]);

const executeReset = async () => {
  if(!resetDialog || resetCountdown>0) return;
  const {groupId,target,mode}=resetDialog;
  if((target==="supabase" || target==="both") && !authUser?.id){ showToast("Entre na conta para limpar o Supabase."); return; }
  const selectedIds = mode === "selected" ? [...selectedResetGroups] : [];
  if(mode === "selected" && !selectedIds.length){ setResetDialog(null); showToast("Selecione pelo menos um módulo para resetar."); return; }
  try {
    syncReadyRef.current=false;
    setSyncing(true);
    setSyncMessage("Executando limpeza segura...");
    if(mode==="all" || mode==="module" || selectedIds.includes("organization")) await cancelStoredNativeNotifications();
    if(target==="supabase" || target==="both") {
      if(mode==="all") {
        const allKeys=Array.from(new Set([...V13_STORAGE_KEYS,ROUTINE_NOTIFICATION_IDS_KEY]));
        await resetSupabaseSnapshotKeys(authUser!.id,allKeys);
      } else if(mode==="selected") {
        await updateSupabaseSnapshot(authUser!.id,(payload)=>selectedIds.reduce((next,id)=>resetGroupPayload(id,next),{...payload}));
      } else {
        await updateSupabaseSnapshot(authUser!.id,(payload)=>resetGroupPayload(groupId,payload));
      }
    }
    if(target==="local" || target==="both") {
      if(mode==="all") {
        for(const key of V13_STORAGE_KEYS) safeSetStorage(key,key==="currency-settings"?{paypalFeePercent:0,wiseFeePercent:0,otherFeePercent:0}:[]);
        safeSetStorage(ROUTINE_NOTIFICATION_IDS_KEY,[]);
        localStorage.removeItem(DRAFT_KEY);
      } else if(mode==="selected") {
        let next = buildLocalSnapshotForReset();
        selectedIds.forEach(id => { next = resetGroupPayload(id,next); });
        for (const key of V13_STORAGE_KEYS) if (Object.prototype.hasOwnProperty.call(next,key)) safeSetStorage(key,next[key]);
        if (selectedIds.includes("organization")) safeSetStorage(ROUTINE_NOTIFICATION_IDS_KEY,[]);
        if (selectedIds.includes("organization")) localStorage.removeItem(DRAFT_KEY);
      } else applyLocalResetGroup(groupId);
    }
    setResetDialog(null);
    if(mode==="selected") {
      const labels = selectedIds.map(id=>RESET_GROUPS[id]?.label).filter(Boolean);
      setSelectedResetGroups([]);
      showToast(`Resetados: ${labels.join(", ")}.`);
    } else {
      showToast(mode==="all"?"Reset geral concluído.":`${RESET_GROUPS[groupId]?.label || "Módulo"} resetado.`);
    }
    window.setTimeout(()=>window.location.reload(),250);
  } catch(error) {
    console.error("Falha no reset seguro",error);
    syncReadyRef.current=true;
    setSyncing(false);
    setSyncMessage("Sincronização pronta.");
    showToast("Não foi possível concluir o reset. Nenhuma limpeza parcial foi aplicada.");
  }
};

const resetApplicationGroup = async (groupId:string) => openResetConfirmation(groupId,"module");
const resetEverything = async () => openResetConfirmation("all","all");

const resetFinanceArea = async (area: FinanceArea) => {
  const label=area==="home"?"Casa":"Trabalho";
  if(!window.confirm(`ZERAR FINANCEIRO · ${label}\n\nIsso apagará os registros financeiros dessa área no aparelho e no Supabase.\n\nContinuar?`)) return;
  if(!authUser?.id){showToast("Entre na conta para usar o reset sincronizado.");return;}
  try{
    syncReadyRef.current=false; setSyncing(true);
    const keys=[PURCHASES_KEY,PAYABLES_KEY,QUICK_TRANSACTIONS_KEY,DESFALQUES_KEY,LOANS_KEY,OVERDRAFTS_KEY,BANK_ACCOUNTS_KEY,RESERVES_KEY,INVESTMENTS_KEY];
    const local=buildLocalSnapshotForReset();
    const filterArea=(key:string)=>Array.isArray(local[key])?local[key].filter((x:any)=>x?.area!==area):local[key];
    await updateSupabaseSnapshot(authUser.id,(payload)=>{const n={...payload}; keys.forEach(k=>{if(Array.isArray(n[k])) n[k]=n[k].filter((x:any)=>x?.area!==area)});return n;});
    keys.forEach(k=>safeSetStorage(k,filterArea(k)));
    showToast(`Financeiro da ${label.toLowerCase()} zerado.`); window.location.reload();
  }catch(error){console.error(error);syncReadyRef.current=true;setSyncing(false);showToast("Não foi possível zerar o financeiro.");}
};

const selectedQuickSupplier = suppliers.find((item) => item.id === quickSupplierId);
const quickExpenseItemsTotal = quickExpenseItems.reduce((sum, item) => sum + item.total, 0);
const quickSupplierCategoryIds = selectedQuickSupplier?.categoryIds || [];
const quickCategories = householdCategories.filter((item) => {
  if (!item.active) return false;
  if (quickSectorId && item.sectorId !== quickSectorId) return false;
  if (quickSupplierCategoryIds.length > 0 && !quickSupplierCategoryIds.includes(item.id)) return false;
  return true;
});
const addQuickExpenseItem = () => {
const sectorId = quickSectorId || householdSectors.find((item) => item.active)?.id || "";
const categoryId = quickCategoryId || householdCategories.find((item) => item.active && item.sectorId === sectorId)?.id || "";
setQuickExpenseItems((previous) => [...previous, { id: makeId(), name: "", quantity: 1, unit: "un", unitPrice: 0, total: 0, sectorId, categoryId, notes: "" }]);
};
const updateQuickExpenseItem = (id: string, changes: Partial<QuickExpenseItem>) => {
setQuickExpenseItems((previous) => previous.map((item) => {
if (item.id !== id) return item;
const updated = { ...item, ...changes };
if (changes.quantity !== undefined || changes.unitPrice !== undefined) updated.total = Number(updated.quantity) * Number(updated.unitPrice);
return updated;
}));
};
const removeQuickExpenseItem = (id: string) => setQuickExpenseItems((previous) => previous.filter((item) => item.id !== id));
const getSupplierCategoriesLabel = (supplier: Supplier) => {
const names = supplier.categoryIds.map((id) => householdCategories.find((item) => item.id === id)?.name).filter(Boolean) as string[];
return names.length ? names.join(", ") : "Sem categoria específica";
};
const stopQrScanner = () => {
if (qrStreamRef.current) qrStreamRef.current.getTracks().forEach((track) => track.stop());
qrStreamRef.current = null;
if (qrVideoRef.current) qrVideoRef.current.srcObject = null;
};
const extractNfeAccessKey = (value: string) => {
const match = value.match(/\b\d{44}\b/);
return match?.[0] || "";
};
const openNfeQr = () => {
if (!purchaseQrCode.trim()) { showToast("Leia ou informe o QR Code da NF-e primeiro."); return; }
const value = purchaseQrCode.trim();
const url = /^https?:\/\//i.test(value) ? value : "https://www.sefaz.sp.gov.br/";
window.open(url, "_blank", "noopener,noreferrer");
};
const startQrScanner = async () => {
try {
const result = await CapacitorBarcodeScanner.scanBarcode({ hint: CapacitorBarcodeScannerTypeHint.QR_CODE, scanInstructions: "Aponte para o QR Code da NF-e", scanText: "Cancelar", cameraDirection: 1, scanOrientation: 1, android: { scanningLibrary: "ZXING" } });
const value = (result as any)?.ScanResult || "";
if (!value) { showToast("Nenhum QR Code foi lido."); return; }
setPurchaseQrCode(value);
const key = extractNfeAccessKey(value);
if (key) setPurchaseAccessKey(key);
setShowQrScanner(false);
showToast("QR Code da NF-e lido.");
} catch {
showToast("Não foi possível iniciar o leitor de QR Code. Você pode informar a chave/URL da NF-e manualmente.");
} finally { stopQrScanner(); }
};
const requestAgendaNotification = async () => {
if (typeof Notification === "undefined") {
 showToast("Seu navegador não oferece notificações.");
 return;
}
try {
 const permission = await Notification.requestPermission();
 showToast(permission === "granted" ? "Notificações da agenda ativadas." : "Permissão de notificação não concedida.");
} catch {
 showToast("Não foi possível ativar as notificações.");
}
};
const openQuickBudgetForClient = (clientId: string) => {
  setBudgetClientId(clientId);
  setBudgetSourceConsultationId("");
  setBudgetServiceType("reading");
  setBudgetServiceName("");
  setBudgetTitle("");
  setBudgetDescription("");
  setBudgetValue("");
  setBudgetItems([]); setBudgetItemDescription(""); setBudgetItemKind("other"); setBudgetItemQuantity("1"); setBudgetItemUnitPrice("");
  setBudgetDiscount("0");
  setBudgetSurcharge("0");
  setBudgetValidUntil("");
  setBudgetShippingEnabled(false); setBudgetShippingRecipientName(clientId ? (clients.find(c=>c.id===clientId)?.name || "") : ""); setBudgetShippingPhone(clientId ? (clients.find(c=>c.id===clientId)?.phone || "") : ""); setBudgetShippingAddress(clientId ? clientAddressText(clients.find(c=>c.id===clientId)) : ""); setBudgetShippingZipCode(clientId ? clientPostalCodeText(clients.find(c=>c.id===clientId)) : ""); setBudgetShippingCity(clientId ? (clients.find(c=>c.id===clientId)?.address?.city || "") : ""); setBudgetShippingState(clientId ? (clients.find(c=>c.id===clientId)?.address?.state || "") : ""); setBudgetShippingUber(""); setBudgetShippingCorreios(""); setBudgetShippingCorreiosPending(false); setBudgetCurrency("BRL"); setBudgetPaymentMethod("pix"); setBudgetPaymentMode("pending"); setBudgetPaymentDate(""); setBudgetInstallmentCount("2"); setBudgetInstallmentFirstDate(""); setBudgetInstallmentEntry(false); setBudgetInstallmentEntryAmount("0");
  setShowQuickBudgetModal(true);
};

const openPreWorkBudget = (consultation: Consultation) => {
  const workName = consultation.preWorkWorkTitle || "Trabalho";
  setBudgetClientId(consultation.clientId);
  setBudgetSourceConsultationId(consultation.id);
  setBudgetServiceType("work");
  setBudgetServiceName(workName);
  setBudgetTitle(workName);
  setBudgetDescription(`Orçamento originado da leitura pré-trabalho “${consultation.title}”.`);
  setBudgetValue("");
  setBudgetItems([]); setBudgetItemDescription(""); setBudgetItemKind("other"); setBudgetItemQuantity("1"); setBudgetItemUnitPrice("");
  setBudgetDiscount("0"); setBudgetSurcharge("0"); setBudgetValidUntil("");
  setBudgetShippingEnabled(false); setBudgetShippingRecipientName(consultation.clientName); setBudgetShippingPhone(""); setBudgetShippingAddress(""); setBudgetShippingZipCode(""); setBudgetShippingCity(""); setBudgetShippingState(""); setBudgetShippingUber(""); setBudgetShippingCorreios(""); setBudgetShippingCorreiosPending(false); setBudgetCurrency(consultation.currency||"BRL"); setBudgetPaymentMethod("pix"); setBudgetPaymentMode("pending"); setBudgetPaymentDate(""); setBudgetInstallmentCount("2"); setBudgetInstallmentFirstDate(""); setBudgetInstallmentEntry(false); setBudgetInstallmentEntryAmount("0");
  setShowQuickBudgetModal(true);
};

const saveQuickBudget = () => {
  const client=clients.find(c=>c.id===budgetClientId);
  const value=Math.max(0,Number(String(budgetValue).replace(",","."))||0); const discount=Math.max(0,Number(String(budgetDiscount).replace(",","."))||0); const surcharge=Math.max(0,Number(String(budgetSurcharge).replace(",","."))||0);
  if(!budgetTitle.trim()){showToast("Informe o título do orçamento.");return;} if(value+surcharge-discount<=0){showToast("Informe um valor final maior que zero.");return;}
  const now=nowISO(); const finalValue=Math.max(0,value+surcharge-discount);
  const budget:Budget={id:makeId(),clientId:client?.id,clientName:client?.name,serviceType:budgetServiceType,serviceName:budgetServiceName.trim()||budgetTitle.trim(),title:budgetTitle.trim(),description:budgetDescription.trim(),value,items:budgetItems,discount,surcharge,validUntil:budgetValidUntil,shippingEnabled:budgetShippingEnabled,shippingRecipientName:budgetShippingRecipientName.trim(),shippingPhone:budgetShippingPhone.trim(),shippingAddress:budgetShippingAddress.trim(),shippingZipCode:budgetShippingZipCode.trim(),shippingCity:budgetShippingCity.trim(),shippingState:budgetShippingState.trim(),shippingUber:Number(String(budgetShippingUber).replace(",","."))||0,shippingCorreios:Number(String(budgetShippingCorreios).replace(",","."))||0,shippingCorreiosPending:budgetShippingCorreiosPending,currency:budgetCurrency,paymentMode:budgetPaymentMode,paymentMethod:budgetPaymentMethod,paymentDate:budgetPaymentDate,installmentCount:budgetPaymentMode==="installments"?Math.max(2,Number(budgetInstallmentCount)||2):undefined,installmentFirstDate:budgetInstallmentFirstDate,installmentEntry:budgetInstallmentEntry,installmentEntryAmount:Number(String(budgetInstallmentEntryAmount).replace(",","."))||0,status:"draft",sourceConsultationId:budgetSourceConsultationId || undefined,createdAt:now,updatedAt:now};
  setBudgets(prev=>[budget,...prev]); if (budgetSourceConsultationId) setConsultations(prev=>prev.map(c=>c.id===budgetSourceConsultationId?{...c,budgetId:budget.id,updatedAt:now}:c)); setShowQuickBudgetModal(false); setScreen("budgets");
  setBudgetValue(""); setBudgetDiscount("0"); setBudgetSurcharge("0"); setBudgetItems([]); setBudgetSourceConsultationId(""); setBudgetPaymentMode("pending"); setBudgetPaymentDate(""); setBudgetInstallmentCount("2"); setBudgetInstallmentFirstDate(""); setBudgetInstallmentEntry(false); setBudgetInstallmentEntryAmount("0");
  showToast("Orçamento cadastrado com as condições de pagamento.");
};
const saveBudget = saveQuickBudget;

const updateBudgetStatus = (id: string, status: Budget["status"]) => setBudgets(previous => previous.map(item => item.id === id ? { ...item, status } : item));
const sendToTrash = (entityType: TrashEntity, label: string, payload: any) => {
  const item: TrashItem = {
    id: makeId(),
    entityType,
    label,
    payload,
    createdAt: nowISO(),
    deletedAt: nowISO(),
    schemaVersion: 1,
  };
  setTrash(previous => [item, ...previous]);
  return item;
};

const restoreTrashItem = (item: TrashItem) => {
  switch (item.entityType) {
    case "client_bundle": {
      const payload = item.payload as { client: Client; consultations: Consultation[] };
      setClients(previous => previous.some(x => x.id === payload.client.id) ? previous : [payload.client, ...previous]);
      setConsultations(previous => {
        const ids = new Set(previous.map(x => x.id));
        return [...payload.consultations.filter(x => !ids.has(x.id)), ...previous];
      });
      break;
    }
    case "consultation": { const payload=item.payload; const {__sideEffects,...consultationPayload}=payload||{}; setConsultations(previous => previous.some(x => x.id === consultationPayload.id) ? previous : [consultationPayload, ...previous]); if(__sideEffects?.execution)setWorkExecutions(previous=>previous.some(x=>x.id===__sideEffects.execution.id)?previous:[__sideEffects.execution,...previous]); if(__sideEffects?.relatedMovements)setStockMovements(previous=>{const ids=new Set(previous.map(x=>x.id));return [...__sideEffects.relatedMovements.filter((x:any)=>!ids.has(x.id)),...previous];}); if(__sideEffects?.relatedTransactions)setQuickTransactions(previous=>{const ids=new Set(previous.map(x=>x.id));return [...__sideEffects.relatedTransactions.filter((x:any)=>!ids.has(x.id)),...previous];}); if(__sideEffects?.relatedDesfalques)setDesfalques(previous=>{const ids=new Set(previous.map(x=>x.id));return [...__sideEffects.relatedDesfalques.filter((x:any)=>!ids.has(x.id)),...previous];}); break; }
    case "purchase_bundle": {
      const { purchase, movements } = item.payload;
      setPurchases(previous => previous.some(x => x.id === purchase.id) ? previous : [purchase, ...previous]);
      setStockMovements(previous => { const ids = new Set(previous.map(x => x.id)); return [...(movements || []).filter((x: StockMovement) => !ids.has(x.id)), ...previous]; });
      break;
    }
    case "agenda": setAgendaItems(previous => previous.some(x => x.id === item.payload.id) ? previous : [item.payload, ...previous]); break;
    case "future_purchase": setFuturePurchases(previous => previous.some(x => x.id === item.payload.id) ? previous : [item.payload, ...previous]); break;
    case "note": setNotes(previous => previous.some(x => x.id === item.payload.id) ? previous : [item.payload, ...previous]); break;
    case "budget": setBudgets(previous => previous.some(x => x.id === item.payload.id) ? previous : [item.payload, ...previous]); break;
    case "account_template": setAccountTemplates(previous => previous.some(x => x.id === item.payload.id) ? previous : [item.payload, ...previous]); break;
    case "supplier": setSuppliers(previous => previous.some(x => x.id === item.payload.id) ? previous : [item.payload, ...previous]); break;
    case "stock_item": setStockItems(previous => previous.some(x => x.id === item.payload.id) ? previous : [item.payload, ...previous]); break;
    case "inventory": setInventoryItems(previous => previous.some(x => x.id === item.payload.id) ? previous : [item.payload, ...previous]); break;
    case "stock_movement": setStockMovements(previous => previous.some(x => x.id === item.payload.id) ? previous : [item.payload, ...previous]); break;
    case "payable": setPayables(previous => previous.some(x => x.id === item.payload.id) ? previous : [item.payload, ...previous]); break;
    case "loan": setLoans(previous => previous.some(x => x.id === item.payload.id) ? previous : [item.payload, ...previous]); break;
    case "overdraft": setOverdrafts(previous => previous.some(x => x.id === item.payload.id) ? previous : [item.payload, ...previous]); break;
    case "bank_account": setBankAccounts(previous => previous.some(x => x.id === item.payload.id) ? previous : [item.payload, ...previous]); break;
    case "quick_transaction": setQuickTransactions(previous => previous.some(x => x.id === item.payload.id) ? previous : [item.payload, ...previous]); break;
    case "photo": {
      const { consultationId, questionId, photo } = item.payload;
      setConsultations(previous => previous.map(c => c.id !== consultationId ? c : ({ ...c, questions: c.questions.map(q => q.id !== questionId ? q : ({ ...q, photos: q.photos.some(p => p.id === photo.id) ? q.photos : [photo, ...q.photos] })) })));
      break;
    }
    case "photo_audio": {
      const { consultationId, questionId, photoId, audio } = item.payload;
      setConsultations(previous => previous.map(c => c.id !== consultationId ? c : ({ ...c, questions: c.questions.map(q => q.id !== questionId ? q : ({ ...q, photos: q.photos.map(p => p.id !== photoId ? p : ({ ...p, audios: (p.audios || []).some(a => a.id === audio.id) ? p.audios : [...(p.audios || []), audio] })) })) })));
      break;
    }
    case "question_audio": {
      const { consultationId, questionId, audio } = item.payload;
      setConsultations(previous => previous.map(c => c.id !== consultationId ? c : ({ ...c, questions: c.questions.map(q => q.id !== questionId ? q : ({ ...q, audios: q.audios.some(a => a.id === audio.id) ? q.audios : [audio, ...q.audios] })) })));
      break;
    }
  }
  setTrash(previous => previous.filter(x => x.id !== item.id));
  showToast("Item restaurado da lixeira.");
};

const permanentlyDeleteTrashItem = (id: string) => {
  if (!window.confirm("Excluir definitivamente este item? Esta ação não poderá ser desfeita.")) return;
  setTrash(previous => previous.filter(x => x.id !== id));
  showToast("Item excluído definitivamente.");
};

const emptyTrash = () => {
  if (!trash.length) return;
  if (!window.confirm(`Excluir definitivamente ${trash.length} item(ns) da lixeira?`)) return;
  setTrash([]);
  showToast("Lixeira esvaziada.");
};

const deleteBudget = (id: string) => { const item = budgets.find(x => x.id === id); if (!item) return; if (window.confirm("Mover este orçamento para a lixeira?")) { sendToTrash("budget", `Orçamento: ${item.title}`, item); setBudgets(previous => previous.filter(x => x.id !== id)); showToast("Orçamento enviado para a lixeira."); } };

const saveAgendaItem = () => {
if (!agendaTitle.trim()) { showToast("Digite o título."); return; }
if (!agendaDate || !agendaTime) { showToast("Informe data e hora."); return; }
const existing = agendaEditingId ? agendaItems.find(x => x.id === agendaEditingId) : undefined;
const item: AgendaItem = {
 id: agendaEditingId || makeId(),
 title: agendaTitle.trim(),
 description: agendaDescription.trim(),
 date: agendaDate,
 time: agendaTime,
 category: organizationAppointmentComposerOpen ? "family" : (agendaCategory === "home" ? "family" : agendaCategory),
 notify: agendaNotify,
 completed: existing?.completed || false,
 clientId: agendaClientId || undefined,
 priority: Math.min(5, Math.max(1, Number(agendaPriority) || 3)),
 createdAt: existing?.createdAt || nowISO(),
 updatedAt: nowISO(),
};
setAgendaItems(previous => agendaEditingId
 ? previous.map(old => old.id === agendaEditingId ? { ...old, ...item, createdAt: old.createdAt } : old)
 : [item, ...previous]);
setAgendaTitle("");
setAgendaDescription("");
setAgendaTime("09:00");
setAgendaNotify(true);
setAgendaPriority(5);
setAgendaClientId("");
setAgendaEditingId(null);
showToast(agendaEditingId ? "Compromisso atualizado." : "Compromisso agendado.");
};
const editAgendaItem = (item: AgendaItem) => {
setAgendaEditingId(item.id);
setAgendaTitle(item.title);
setAgendaDescription(item.description);
setAgendaDate(item.date);
setAgendaTime(item.time || "09:00");
setAgendaCategory(item.category === "home" ? "family" : item.category);
setAgendaNotify(item.notify);
setAgendaPriority(Math.min(5, Math.max(1, Number(item.priority) || 3)));
setAgendaClientId(item.clientId || "");
if(item.category === "family" || item.category === "home") {
  setOrganizationAgendaTab("appointments");
  setOrganizationAppointmentComposerOpen(true);
  setScreen("organization");
  setOrganizationSection("agenda");
} else {
  setOrganizationAppointmentComposerOpen(false);
  setAgendaComposerOpen(true);
  setScreen("agenda");
}
};
const toggleAgendaItem = (id: string) =>
setAgendaItems(previous => previous.map(item => item.id === id ? { ...item, completed: !item.completed } : item));
const deleteAgendaItem = (id: string) => {
const item = agendaItems.find(x => x.id === id);
if (!item) return;
if (!window.confirm("Mover este compromisso para a lixeira?")) return;
sendToTrash("agenda", `Agenda: ${item.title}`, item);
setAgendaItems(previous => previous.filter(x => x.id !== id));
showToast("Compromisso enviado para a lixeira.");
};
const saveAccountTemplate = () => {
if (!accountTemplateName.trim()) { showToast("Digite o nome da conta."); return; }
const amount = Number(String(accountTemplateAmount).replace(",", ".")) || 0;
const day = Math.floor(Number(accountTemplateDueDay) || 0);
if (day < 1 || day > 31) { showToast("Informe um dia entre 1 e 31."); return; }
if (amount < 0) { showToast("Informe um valor válido."); return; }
setAccountTemplates(previous => [{
 id: makeId(),
 name: accountTemplateName.trim(),
 description: accountTemplateDescription.trim(),
 area: accountTemplateArea,
 dueDay: day,
 amount,
 supplierId: accountTemplateSupplierId,
 active: true,
 recurrenceType: amount > 0 ? "fixed" : "variable",
 createdAt: nowISO(),
}, ...previous]);
setAccountTemplateName("");
setAccountTemplateDescription("");
setAccountTemplateAmount("");
setAccountTemplateDueDay("10");
setAccountTemplateSupplierId("");
showToast("Conta cadastrada.");
};
const toggleAccountTemplate = (id: string) =>
setAccountTemplates(previous => previous.map(item => item.id === id ? { ...item, active: !item.active } : item));
const deleteAccountTemplate = (id: string) => {
const item = accountTemplates.find(x => x.id === id);
if (!item) return;
if (!window.confirm("Mover este cadastro de conta para a lixeira?")) return;
sendToTrash("account_template", `Modelo de conta: ${item.name}`, item);
setAccountTemplates(previous => previous.filter(x => x.id !== id));
showToast("Modelo enviado para a lixeira.");
};
const saveQuickTransaction = () => {
const itemTotal = quickType === "expense" ? quickExpenseItemsTotal : 0;
const enteredAmount = itemTotal > 0 ? itemTotal : (Number(String(quickAmount).replace(",", ".")) || 0);
const amount = quickCurrency === "BRL" ? enteredAmount : enteredAmount * (currencyRates[quickCurrency] || 0);
if (amount <= 0) {
showToast("Digite um valor válido.");
return;
}
if (!quickSource.trim()) {
showToast("Informe a fonte da movimentação.");
return;
}
const client = clients.find((item) => item.id === quickClientId);
const stock = stockItems.find((item) => item.id === quickStockItemId);
const isSale = quickType === "sale";
const isExpense = quickType === "expense";
if (isExpense) {
  if (!quickSupplierId || !selectedQuickSupplier) {
    showToast("Selecione um fornecedor/estabelecimento cadastrado para esta saída.");
    return;
  }
  if (!quickSectorId) {
    showToast("Selecione o setor da despesa.");
    return;
  }
  if (!quickCategoryId) {
    showToast("Selecione a categoria da despesa.");
    return;
  }
  if (quickExpenseItems.some((item) => !item.name.trim())) {
    showToast("Preencha o nome de todos os itens ou remova os itens vazios.");
    return;
  }
}
const quantity = Number(String(quickQuantity).replace(",", ".")) || 0;
if (isSale && !stock) {
showToast("Selecione o item do estoque vendido.");
return;
}
if (isSale && (quantity <= 0 || quantity > (stock?.quantity || 0))) {
showToast("Quantidade de estoque inválida.");
return;
}
const feePercent = getFeePercent(quickPaymentMethod);
const transactionFee = !isExpense && quickType !== "sale" && feePercent > 0 ? amount * Math.max(0,feePercent)/100 : 0;
const transaction: QuickTransaction = {
id: makeId(),
type: quickType,
area: quickArea,
amount: Math.max(0, amount - transactionFee),
fee: transactionFee,
source: isExpense && selectedQuickSupplier ? selectedQuickSupplier.name : quickSource.trim(),
supplierId: isExpense ? (selectedQuickSupplier?.id || "") : (selectedQuickSupplier?.id || ""),
supplierName: isExpense ? (selectedQuickSupplier?.name || "") : (selectedQuickSupplier?.name || ""),
sectorId: quickSectorId,
categoryId: quickCategoryId,
items: quickExpenseItems,
description: quickDescription.trim(),
clientId: client?.id || "",
clientName: client?.name || "",
stockItemId: stock?.id || "",
quantity: isSale ? quantity : 0,
paymentMethod: quickPaymentMethod,
currency: quickCurrency,
currencyRate: quickCurrency === "BRL" ? 1 : (currencyRates[quickCurrency] || 0),
grossAmount: amount,
paymentStatus: "received",
date: nowISO(),
createdAt: nowISO(),
};
setQuickTransactions((previous) => [transaction, ...previous]);
if (isSale && stock) {
setStockItems((previous) =>
previous.map((item) =>
item.id === stock.id
? { ...item, quantity: item.quantity - quantity }
: item
)
);
setStockMovements((previous) => [
...previous,
{
id: makeId(),
stockItemId: stock.id,
type: "consumption",
quantity,
unitCost: stock.averageCost,
date: nowISO(),
referenceType: "manual",
referenceId: transaction.id,
notes: `Venda rápida${client ? ` para ${client.name}` : ""}`,
},
]);
}
setQuickAmount("");
setQuickSource("");
setQuickDescription("");
setQuickClientId("");
setQuickSupplierId("");
setQuickSectorId("");
setQuickCategoryId("");
setQuickExpenseItems([]);
setQuickStockItemId("");
setQuickQuantity("1");
setQuickType("income");
setShowQuickIncomeModal(false);
setShowQuickExpenseModal(false);
showToast(
isSale
? `Venda de ${formatMoney(amount)} registrada e estoque atualizado.`
: `${quickType === "income" ? "Entrada" : "Saída"} de ${formatMoney(amount)}
registrada.`
);
};
const openQuickIncome = () => {
setQuickType("income");
setQuickArea("work");
setShowQuickIncomeModal(true);
};
const openQuickExpense = () => {
setQuickType("expense");
setQuickArea("home");
setShowQuickExpenseModal(true);
};
const addIntakePhotos = async (event: React.ChangeEvent<HTMLInputElement>) => {
const files = Array.from(event.target.files || []);
if (!files.length) return;
const photos: PhotoItem[] = [];
for (const file of files) photos.push({ id: makeId(), name: file.name, data: await compressImageFile(file), createdAt: nowISO(), audios: [], note: "", updatedAt: nowISO() });
setIntakePhotos(previous => [...previous, ...photos]);
event.target.value = "";
showToast(`${photos.length} imagem(ns) anexada(s).`);
};
const addServicePhotos = async (event: React.ChangeEvent<HTMLInputElement>) => {
  const files = Array.from(event.target.files || []); if (!files.length) return;
  const photos: PhotoItem[] = [];
  for (const file of files) photos.push({ id: makeId(), name: file.name, data: await compressImageFile(file), createdAt: nowISO(), audios: [], note: "", updatedAt: nowISO() });
  setServicePhotos(previous => [...previous, ...photos]); event.target.value = ""; showToast(`${photos.length} imagem(ns) adicionada(s) ao trabalho.`);
};
const deleteDraftServicePhoto = (photoId:string) => { setServicePhotos(prev=>prev.filter(p=>p.id!==photoId)); if(selectedServicePhotoId===photoId)setSelectedServicePhotoId(null); };
const addIntakeAudios = async (event: React.ChangeEvent<HTMLInputElement>) => {
const files = Array.from(event.target.files || []);
if (!files.length) return;
const audios: AudioItem[] = [];
for (const file of files) {
audios.push({
id: makeId(),
name: file.name,
data: await readFileAsDataUrl(file),
duration: 0,
createdAt: nowISO(),
});
}
setIntakeAudios((previous) => [...previous, ...audios]);
event.target.value = "";
showToast(`${audios.length} áudio(s) anexado(s).`);
};
const addQuestionAudiosFromFiles = async (event: React.ChangeEvent<HTMLInputElement>) => {
  const files = Array.from(event.target.files || []);
  if (!files.length || !currentQuestion || !activeConsultation) return;
  const audios: AudioItem[] = [];
  for (const file of files) audios.push({ id: makeId(), name: file.name, data: await readFileAsDataUrl(file), duration: 0, createdAt: nowISO(), updatedAt: nowISO() });
  updateCurrentQuestion({ audios: [...(currentQuestion.audios || []), ...audios] });
  event.target.value = "";
  showToast(`${audios.length} áudio(s) importado(s) e salvo(s) no histórico da consulente.`);
};

const addPhotoAudiosFromFiles = async (event: React.ChangeEvent<HTMLInputElement>, photoId: string) => {
  const files = Array.from(event.target.files || []);
  if (!files.length || !currentQuestion || !activeConsultation) return;
  const audios: AudioItem[] = [];
  for (const file of files) audios.push({ id: makeId(), name: file.name, data: await readFileAsDataUrl(file), duration: 0, createdAt: nowISO(), updatedAt: nowISO() });
  const updatedConsultation: Consultation = { ...activeConsultation, questions: activeConsultation.questions.map(q => q.id !== currentQuestion.id ? q : ({ ...q, photos: q.photos.map(p => p.id !== photoId ? p : ({ ...p, audios: [...(p.audios || []), ...audios], updatedAt: nowISO() })) })) , updatedAt: nowISO() };
  updateConsultation(updatedConsultation);
  setActiveConsultation(updatedConsultation);
  event.target.value = "";
  showToast(`${audios.length} áudio(s) do aparelho vinculado(s) à foto.`);
};
/* =========================================================
TAROT
========================================================= */
const updateConsultation = (
updated: Consultation
) => {
setActiveConsultation(updated);
safeSetStorage(DRAFT_KEY, updated);
setConsultations((previous) => {
const exists = previous.some(
(item) => item.id === updated.id
);
if (!exists) {
return [updated, ...previous];
}
return previous.map((item) =>
item.id === updated.id
? updated
: item
);
});
};

// Atualização exclusivamente de registro. Operações financeiras iniciadas
// pelo dashboard/histórico nunca devem abrir ou reabrir o atendimento.
const updateConsultationRecordOnly = (updated: Consultation) => {
  setConsultations((previous) => {
    const exists = previous.some(item => item.id === updated.id);
    if (!exists) return [updated, ...previous];
    return previous.map(item => item.id === updated.id ? updated : item);
  });
};
const updateCurrentQuestion = (
changes: Partial<Question>
) => {
if (!activeConsultation || !currentQuestion) {
return;
}
const questions =
activeConsultation.questions.map(
(question) =>
question.id === currentQuestion.id
? {
...question,
...changes,
updatedAt: nowISO(),
}
: question
);
updateConsultation({
...activeConsultation,
questions,
});
};
const buildInstallmentDrafts = (count: number, firstDate: string, total: number) => {
const safeCount = Math.max(1, Math.floor(count || 1));
const base = Math.floor((Math.max(0, total) / safeCount) * 100) / 100;
const remainder = Math.round((Math.max(0, total) - base * (safeCount - 1)) * 100) / 100;
const startDate = firstDate || new Date().toISOString().slice(0, 10);
return Array.from({ length: safeCount }, (_, index) => {
const date = new Date(`${startDate}T12:00:00`);
date.setMonth(date.getMonth() + index);
return {
id: makeId(),
amount: (index === safeCount - 1 ? remainder : base).toFixed(2),
dueDate: date.toISOString().slice(0, 10),
};
});
};
const openInstallmentPayment = () => {
const total = Number(String(newValue).replace(",", ".")) || 0;
const firstDate = newInstallmentFirstDate || newPaymentDate || new Date().toISOString().slice(0, 10);
setNewPaymentMode("installments");
setNewInstallmentFirstDate(firstDate);
setNewInstallmentSurcharge("0");
setNewInstallmentDrafts(buildInstallmentDrafts(Number(newInstallmentCount) || 2, firstDate, total));
};
const updateInstallmentCount = (value: string) => {
setNewInstallmentCount(value);
const count = Math.max(1, Number(value) || 1);
const total = Number(String(newValue).replace(",", ".")) || 0;
setNewInstallmentDrafts(buildInstallmentDrafts(count, newInstallmentFirstDate || newPaymentDate, total));
};
const updateInstallmentFirstDate = (value: string) => {
setNewInstallmentFirstDate(value);
setNewInstallmentDrafts(previous => previous.map((item, index) => {
const date = new Date(`${value}T12:00:00`);
date.setMonth(date.getMonth() + index);
return { ...item, dueDate: date.toISOString().slice(0, 10) };
}));
};
const updateInstallmentDraft = (id: string, changes: Partial<InstallmentDraft>) => {
setNewInstallmentDrafts(previous => previous.map(item => item.id === id ? { ...item, ...changes } : item));
};
const createPaymentPlanForConsultation = (value: number) => {
const now = nowISO();
if (newPaymentMode === "free") {
return undefined;
}
if (newPaymentMode === "paid") {
return { id: makeId(), originalTotal: value, total: value, surcharge: 0, type: "full" as const, installments: [{ id: makeId(), number: 1, amount: value, dueDate: newPaymentDate || new Date().toISOString().slice(0, 10), status: "received" as const, paymentMethod: newInstallmentPaymentMethod, receivedAt: now }] };
}
if (newPaymentMode === "pending") {
if (!newPaymentDate) return null;
return { id: makeId(), originalTotal: value, total: value, surcharge: 0, type: "full" as const, installments: [{ id: makeId(), number: 1, amount: value, dueDate: newPaymentDate, status: "pending" as const, paymentMethod: newInstallmentPaymentMethod, receivedAt: "" }] };
}
if (!newInstallmentDrafts.length) {
setNewInstallmentDrafts(buildInstallmentDrafts(Number(newInstallmentCount) || 2, newInstallmentFirstDate || newPaymentDate, value));
return null;
}
const installments = newInstallmentDrafts.map((draft, index) => ({ id: draft.id || makeId(), number: index + 1, amount: Number(String(draft.amount).replace(",", ".")) || 0, dueDate: draft.dueDate, status: "pending" as const, paymentMethod: newInstallmentPaymentMethod, receivedAt: "" }));
const totalInstallments = installments.reduce((sum, item) => sum + item.amount, 0);
if (installments.some(item => !item.dueDate || item.amount <= 0)) { showToast("Preencha o valor e o vencimento de todas as parcelas."); return null; }
const surcharge = Math.max(0, Number(String(newInstallmentSurcharge).replace(",", ".")) || 0);
const expectedTotal = Math.round((value + surcharge) * 100) / 100;
if (Math.abs(totalInstallments - expectedTotal) > 0.01) {
showToast(`As parcelas devem somar ${formatMoney(expectedTotal)} (original ${formatMoney(value)} + acréscimo ${formatMoney(surcharge)}).`);
return null;
}
return { id: makeId(), originalTotal: value, total: expectedTotal, surcharge, type: "installments" as const, installments };
};
const addInstallmentPaymentTransaction = (
  target: Consultation,
  inst: Installment,
  payment: InstallmentPayment,
  questionId?: string,
) => {
  const marker = questionId
    ? `[QUESTION:${target.id}:${questionId}:INST:${inst.id}:PAY:${payment.id}]`
    : `[WORK:${target.id}:INST:${inst.id}:PAY:${payment.id}]`;
  const currency = questionId
    ? (target.questions.find(q => q.id === questionId)?.currency || target.currency || "BRL")
    : (target.currency || "BRL");
  setQuickTransactions(prev => [
    {
      id: makeId(),
      type: "income",
      area: "work",
      amount: payment.amount,
      source: `Recebimento de parcela · ${target.title} ${marker}`,
      description: `${questionId ? "Pergunta" : "Parcela"} ${inst.number} · ${payment.amount.toFixed(2)} recebido · ${target.clientName}`,
      clientId: target.clientId,
      clientName: target.clientName,
      stockItemId: "",
      quantity: 0,
      paymentMethod: payment.paymentMethod,
      currency,
      currencyRate: target.currencyRate || 1,
      paymentStatus: "received",
      fee: Number((payment.amount * getFeePercent(payment.paymentMethod) / 100).toFixed(2)),
      grossAmount: payment.amount,
      date: payment.date,
      createdAt: payment.date,
    },
    ...prev,
  ]);
};

const recordInstallmentPartialPayment = (
  consultationId: string,
  installmentId: string,
  amount: number,
  questionId?: string,
  paymentMethodOverride?: PaymentMethod,
  successToast = true,
) => {
  const target = consultations.find(c => c.id === consultationId);
  if (!target) return false;
  const sourceRows = questionId
    ? target.questions.find(q => q.id === questionId)?.paymentPlan?.installments
    : target.paymentPlan?.installments;
  const inst = sourceRows?.find(i => i.id === installmentId);
  if (!inst) return false;

  const safe = Math.max(0, Math.min(installmentOpenAmount(inst), Number(amount) || 0));
  if (safe <= 0) {
    showToast("Informe um valor maior que zero e menor ou igual ao restante da parcela.");
    return false;
  }

  const payment: InstallmentPayment = {
    id: makeId(),
    amount: safe,
    date: nowISO(),
    paymentMethod: paymentMethodOverride || inst.paymentMethod,
  };
  const nextReceived = installmentReceivedAmount(inst) + safe;
  const nextStatus: Installment["status"] = nextReceived >= inst.amount - 0.01 ? "received" : "pending";
  const updateRows = (rows: Installment[]) => rows.map(i => i.id === installmentId ? {
    ...i,
    receivedAmount: nextReceived,
    payments: [...(i.payments || []), payment],
    status: nextStatus,
    lastPaymentAt: payment.date,
    receivedAt: nextStatus === "received" ? payment.date : i.receivedAt,
  } : i);

  const updated: Consultation = questionId
    ? {
        ...target,
        questions: target.questions.map(q => q.id === questionId && q.paymentPlan
          ? { ...q, paymentPlan: { ...q.paymentPlan, installments: updateRows(q.paymentPlan.installments) } }
          : q),
        updatedAt: nowISO(),
      }
    : {
        ...target,
        paymentPlan: target.paymentPlan
          ? { ...target.paymentPlan, installments: updateRows(target.paymentPlan.installments) }
          : target.paymentPlan,
        updatedAt: nowISO(),
      };

  const rows = questionId
    ? (updated.questions.find(q => q.id === questionId)?.paymentPlan?.installments || [])
    : (updated.paymentPlan?.installments || []);
  const all = rows.length > 0 && rows.every(i => installmentReceivedAmount(i) >= i.amount - 0.01);
  if (!questionId) {
    updated.paid = all;
    updated.paymentDate = all ? payment.date : updated.paymentDate;
  }

  // Financeiro: salva somente o registro. Não toca em activeConsultation/DRAFT_KEY.
  updateConsultationRecordOnly(updated);
  addInstallmentPaymentTransaction(target, inst, payment, questionId);

  // Se havia um desfalque anterior, o valor recebido agora reduz o saldo do desfalque.
  const existingDesfalque = desfalques.find(d =>
    d.consultationId === consultationId &&
    !d.deletedAt &&
    (questionId ? d.questionId === questionId && d.installmentId === installmentId : d.installmentId === installmentId)
  );
  if (existingDesfalque) {
    const totalReceivedAfter = nextReceived;
    const remainingLoss = Math.max(0, inst.amount - totalReceivedAfter);
    setDesfalques(prev => prev.map(d => d.id === existingDesfalque.id
      ? { ...d, receivedValue: totalReceivedAfter, amount: remainingLoss, updatedAt: nowISO() }
      : d));
  }

  if (successToast) {
    showToast(nextStatus === "received"
      ? "Parcela quitada com o último pagamento. Financeiro e histórico atualizados."
      : `Pagamento parcial de ${formatMoney(safe)} registrado. Restante: ${formatMoney(Math.max(0, inst.amount - nextReceived))}.`);
  }
  return true;
};

const setConsultationInstallmentStatus = (
  consultationId: string,
  installmentId: string,
  status: Installment["status"],
) => {
  const target = consultations.find(c => c.id === consultationId);
  const inst = target?.paymentPlan?.installments.find(i => i.id === installmentId);
  if (!target || !inst) return;

  if (status === "received") {
    const remaining = installmentOpenAmount(inst);
    if (remaining > 0.009) {
      recordInstallmentPartialPayment(consultationId, installmentId, remaining, undefined, inst.paymentMethod);
    } else {
      showToast("Parcela já está totalmente recebida.");
    }
    return;
  }

  const now = nowISO();
  const installments = target.paymentPlan!.installments.map(item => item.id === installmentId
    ? { ...item, status, receivedAt: status === "pending" ? item.receivedAt : "" }
    : item);
  const allReceived = installments.length > 0 && installments.every(item => installmentReceivedAmount(item) >= item.amount - 0.01);
  const updated: Consultation = {
    ...target,
    paid: allReceived,
    paymentDate: allReceived ? (target.paymentDate || now) : target.paymentDate,
    paymentPlan: { ...target.paymentPlan!, installments },
    updatedAt: now,
  };
  updateConsultationRecordOnly(updated);

  if (status === "defaulted") {
    const received = installmentReceivedAmount(inst);
    const remaining = Math.max(0, inst.amount - received);
    const existing = desfalques.find(d => d.consultationId === consultationId && !d.deletedAt && d.installmentId === installmentId);
    if (remaining > 0.009) {
      const payload: any = {
        clientId: target.clientId,
        clientName: target.clientName,
        consultationId,
        workId: target.linkedWorkId,
        installmentId,
        type: "default",
        description: `Calote · Parcela ${inst.number} · ${target.title}`,
        potentialValue: inst.amount,
        receivedValue: received,
        amount: remaining,
        date: now,
        createdAt: now,
      };
      if (existing) setDesfalques(prev => prev.map(d => d.id === existing.id ? { ...d, ...payload, updatedAt: now } : d));
      else setDesfalques(prev => [
        { id: makeId(), ...payload },
        ...prev,
      ] as any);
    }
    showToast(`Parcela marcada como não paga. Desfalque restante: ${formatMoney(remaining)}.`);
    return;
  }

  if (status === "pending" || status === "overdue") {
    const existing = desfalques.find(d => d.consultationId === consultationId && !d.deletedAt && d.installmentId === installmentId);
    if (existing) setDesfalques(prev => prev.map(d => d.id === existing.id ? { ...d, amount: 0, updatedAt: now } : d));
  }
  showToast(status === "pending" ? "Parcela voltou para pendente." : "Status da parcela atualizado.");
};

const setAnyInstallmentStatus = (
  consultationId: string,
  installmentId: string,
  status: Installment["status"],
  questionId?: string,
) => {
  if (!questionId) {
    setConsultationInstallmentStatus(consultationId, installmentId, status);
    return;
  }
  const target = consultations.find(c => c.id === consultationId);
  const question = target?.questions?.find(q => q.id === questionId);
  const inst = question?.paymentPlan?.installments.find(i => i.id === installmentId);
  if (!target || !question || !inst) return;

  if (status === "received") {
    const remaining = installmentOpenAmount(inst);
    if (remaining > 0.009) {
      recordInstallmentPartialPayment(consultationId, installmentId, remaining, questionId, inst.paymentMethod);
    } else {
      showToast("Parcela já está totalmente recebida.");
    }
    return;
  }

  const now = nowISO();
  const updated: Consultation = {
    ...target,
    questions: target.questions.map(q => q.id === questionId && q.paymentPlan
      ? {
          ...q,
          paymentPlan: {
            ...q.paymentPlan,
            installments: q.paymentPlan.installments.map(i => i.id === installmentId
              ? { ...i, status, receivedAt: status === "pending" ? i.receivedAt : "" }
              : i),
          },
        }
      : q),
    updatedAt: now,
  };
  updateConsultationRecordOnly(updated);

  if (status === "defaulted") {
    const received = installmentReceivedAmount(inst);
    const remaining = Math.max(0, inst.amount - received);
    const existing = desfalques.find(d => d.consultationId === consultationId && !d.deletedAt && d.installmentId === installmentId && d.questionId === questionId);
    if (remaining > 0.009) {
      const payload: any = {
        clientId: target.clientId,
        clientName: target.clientName,
        consultationId,
        questionId,
        installmentId,
        workId: target.linkedWorkId,
        type: "default",
        description: `Calote · Parcela ${inst.number} · ${question.text || "Pergunta"}`,
        potentialValue: inst.amount,
        receivedValue: received,
        amount: remaining,
        date: now,
        createdAt: now,
      };
      if (existing) setDesfalques(prev => prev.map(d => d.id === existing.id ? { ...d, ...payload, updatedAt: now } : d));
      else setDesfalques(prev => [{ id: makeId(), ...payload }, ...prev] as any);
    }
    showToast(`Parcela marcada como não paga. Desfalque restante: ${formatMoney(remaining)}.`);
    return;
  }
  if (status === "pending" || status === "overdue") {
    const existing = desfalques.find(d => d.consultationId === consultationId && !d.deletedAt && d.installmentId === installmentId && d.questionId === questionId);
    if (existing) setDesfalques(prev => prev.map(d => d.id === existing.id ? { ...d, amount: 0, updatedAt: now } : d));
  }
  showToast(status === "pending" ? "Parcela voltou para pendente." : "Status da parcela atualizado.");
};

const receiveConsultationInstallment = (consultationId: string, installmentId: string) =>
  setConsultationInstallmentStatus(consultationId, installmentId, "received");

const promptInstallmentPartialPayment = (payment: any) => {
  const c = consultations.find(x => x.id === payment?.consultationId);
  if (!c || !payment?.installmentId) return;
  const rows = payment.questionId
    ? c.questions.find(q => q.id === payment.questionId)?.paymentPlan?.installments
    : c.paymentPlan?.installments;
  const inst = rows?.find(i => i.id === payment.installmentId);
  if (!inst) return;
  setPartialPaymentTarget({ ...payment, openAmount: installmentOpenAmount(inst), installment: inst, consultation: c });
  setPartialPaymentAmount("");
  setPartialPaymentMethod(inst.paymentMethod || c.paymentMethod || "pix");
};

const confirmPartialPayment = () => {
  if (!partialPaymentTarget) return;
  const amount = Number(String(partialPaymentAmount).replace(",", ".")) || 0;
  const target = partialPaymentTarget;
  const saved = recordInstallmentPartialPayment(target.consultationId, target.installmentId, amount, target.questionId, partialPaymentMethod);
  if (saved) {
    setPartialPaymentTarget(null);
    setPartialPaymentAmount("");
  }
};

const postponeDashboardPayment = (payment: any) => {
  const next = window.prompt("Novo vencimento (AAAA-MM-DD):", payment?.dueDate || "");
  if (!next || !/^[0-9]{4}-[0-9]{2}-[0-9]{2}$/.test(next)) return;
  const target = consultations.find(c => c.id === payment.consultationId);
  if (!target) return;
  if (payment.questionId) {
    const questions = target.questions.map(q => q.id !== payment.questionId || !q.paymentPlan ? q : {
      ...q,
      paymentPlan: {
        ...q.paymentPlan,
        installments: q.paymentPlan.installments.map(x => x.id === payment.installmentId
          ? { ...x, dueDate: next, postponedFrom: x.dueDate, status: "pending" as Installment["status"] }
          : x),
      },
    });
    updateConsultationRecordOnly({ ...target, questions, updatedAt: nowISO() });
  } else if (target.paymentPlan) {
    const installments = target.paymentPlan.installments.map(x => x.id === payment.installmentId
      ? { ...x, dueDate: next, postponedFrom: x.dueDate, status: "pending" as Installment["status"] }
      : x);
    updateConsultationRecordOnly({ ...target, paymentPlan: { ...target.paymentPlan, installments }, paid: false, updatedAt: nowISO() });
  }
  const existing = desfalques.find(d => d.consultationId === payment.consultationId && !d.deletedAt && d.installmentId === payment.installmentId && (payment.questionId ? d.questionId === payment.questionId : !d.questionId));
  if (existing) setDesfalques(prev => prev.map(d => d.id === existing.id ? { ...d, amount: 0, updatedAt: nowISO() } : d));
  setSelectedDashboardPayment(null);
  showToast("Vencimento atualizado sem abrir o atendimento.");
};

const setCurrentQuestionBilling = (billingMode: QuestionBillingMode) => {
  if (!activeConsultation || !currentQuestion) return;
  const value = Math.max(0, Number(currentQuestion.value || 0));
  const potential = Math.max(0, Number(currentQuestion.potentialValue ?? value));
  updateCurrentQuestion({
    billingMode,
    value,
    potentialValue: (billingMode === "free" || billingMode === "desfalque") ? (potential || value) : potential,
    shortfall: billingMode === "desfalque" ? (potential || value) : 0,
    paymentDate: billingMode === "pending" ? (currentQuestion.paymentDate || new Date().toISOString().slice(0,10)) : currentQuestion.paymentDate,
    paymentPlan: billingMode === "installments" ? currentQuestion.paymentPlan : undefined,
  });
};

const configureCurrentQuestionInstallments = () => {
  if (!currentQuestion) return;
  const value = Math.max(0, Number(currentQuestion.value || 0));
  if (value <= 0) { showToast("Informe primeiro o valor da pergunta extra."); return; }
  const count = Math.max(2, Number(window.prompt("Quantidade de parcelas:", "2") || "2"));
  const firstDate = window.prompt("Primeiro vencimento (AAAA-MM-DD):", new Date().toISOString().slice(0,10));
  if (!firstDate) return;
  const drafts = buildInstallmentDrafts(count, firstDate, value);
  const installments: Installment[] = drafts.map((draft,index) => ({ id: draft.id, number:index+1, amount:Number(draft.amount), dueDate:draft.dueDate, status:"pending", paymentMethod: currentQuestion.paymentMethod || "pix", receivedAt:"" }));
  updateCurrentQuestion({ billingMode:"installments", paymentPlan:{ id:makeId(), originalTotal:value, total:value, surcharge:0, type:"installments", installments }, shortfall:0 });
  showToast("Parcelamento da pergunta configurado.");
};

const newQuestion = () => {
  if (!activeConsultation) return;
  const currency = (activeConsultation.currency || "BRL") as CurrencyCode;
  const simpleType = (Array.isArray(readingTypes) ? readingTypes : initialReadingTypes).find(item => item.id === "simple");
  const unitPrice = readingPrice(simpleType, currency);
  const linkedWorkId = activeConsultation.relatedWorkId || activeConsultation.questions.find(q => q.relatedWorkId)?.relatedWorkId;
  const linkedWork = linkedWorkId ? getClientWorkOptions(activeConsultation.clientId).find(w => w.id === linkedWorkId) : undefined;
  const workStats = linkedWorkId ? getWorkQuestionStats(linkedWorkId) : { total: 0, paid: 0, courtesy: 0, benefitUsed: false };
  const question = createEmptyQuestion(activeConsultation.questions.length + 1, currency, unitPrice);
  const canUseBenefit = !!linkedWork && !workStats.benefitUsed;
  const workQuestion = linkedWork ? { relatedWorkId: linkedWork.id, relatedWorkTitle: linkedWork.title, workQuestionKind: canUseBenefit ? "benefit" as const : "paid" as const, workQuestionNumber: workStats.total + 1, billingMode: canUseBenefit ? "free" as const : "paid" as const, value: canUseBenefit ? 0 : unitPrice, potentialValue: unitPrice } : {};
  const updated: Consultation = { ...activeConsultation, relatedWorkId: linkedWork?.id || activeConsultation.relatedWorkId, questions: [...activeConsultation.questions, { ...question, ...workQuestion }], status: "active" };
  updateConsultation(updated);
  setActiveQuestionId(question.id);
  showToast(`Pergunta ${question.number} criada.`);
};

const deleteQuestion = (questionId: string) => {
  if (!activeConsultation) return;
  if (activeConsultation.questions.length <= 1) { showToast("O atendimento precisa ter pelo menos uma pergunta."); return; }
  const removed = activeConsultation.questions.find(q => q.id === questionId);
  if (!removed) return;
  const remaining = activeConsultation.questions.filter(q => q.id !== questionId).map((q, index) => ({ ...q, number: index + 1, updatedAt: nowISO() }));
  const updated: Consultation = { ...activeConsultation, questions: remaining, updatedAt: nowISO() };
  updateConsultation(updated);
  if (activeQuestionId === questionId) setActiveQuestionId(remaining[Math.max(0, remaining.length - 1)]?.id || null);
  showToast(`Pergunta ${removed.number} excluída.`);
};

const putOnStandby = () => {
  if (!activeConsultation) return;
  // Standby representa exclusivamente uma sessão que estava realmente em andamento.
  // Um atendimento concluído/agendado nunca pode ser convertido em standby durante uma edição.
  if (activeConsultation.status !== "active") {
    showToast(activeConsultation.status === "completed"
      ? "Este atendimento já foi finalizado. Edite e salve normalmente; ele continuará no histórico."
      : "Somente um atendimento em andamento pode ser colocado em standby.");
    return;
  }
  const standby: Consultation = { ...activeConsultation, status: "standby", updatedAt: nowISO() };
  updateConsultation(standby); safeSetStorage(DRAFT_KEY, standby);
  setActiveConsultation(null); setActiveQuestionId(null); setScreen("dashboard");
  showToast("Atendimento salvo em standby.");
};

const startScheduledConsultation = (consultation: Consultation) => {
  // Ação direta: nunca passa pela Agenda. Recupera exatamente o registro agendado.
  const questions = Array.isArray(consultation.questions) ? consultation.questions : [];
  const normalizedQuestions = questions.length > 0 ? questions : [createEmptyQuestion(1)];
  const started: Consultation = {
    ...consultation,
    questions: normalizedQuestions,
    status: "active",
    updatedAt: nowISO(),
  };
  setShowServiceDetail(false);
  setShowScheduleModal(false);
  setShowRescheduleModal(false);
  setSelectedServiceRecord(null);
  setActiveConsultation(started);
  setActiveQuestionId(normalizedQuestions[normalizedQuestions.length - 1]?.id || null);
  setConsultations(previous => previous.map(item => item.id === started.id ? started : item));
  setAgendaItems(previous => previous.map(item => item.relatedEntityType === "consultation" && item.relatedEntityId === started.id ? { ...item, completed: true, notify: false, updatedAt: nowISO() } : item));
  safeSetStorage(DRAFT_KEY, started);
  setScreen("consultation");
  showToast("Atendimento agendado iniciado. Você pode continuar a tiragem.");
};

const resumeConsultation = (consultation: Consultation) => startScheduledConsultation(consultation);

const upsertLinkedAgendaItem = (params: {
  entityType: "consultation" | "work" | "sale";
  entityId: string;
  scheduledAt: string;
  title: string;
  description: string;
  clientId?: string;
  priority?: number;
  notify?: boolean;
}) => {
  const { entityType, entityId, scheduledAt, title, description, clientId, priority, notify = true } = params;
  if (!scheduledAt || !entityId) return;
  const [date, time] = scheduledAt.split("T");
  if (!date || !time) return;
  setAgendaItems(previous => {
    const existing = previous.find(item => item.relatedEntityId === entityId && item.relatedEntityType === entityType);
    const next: AgendaItem = {
      id: existing?.id || makeId(),
      title,
      description,
      date,
      time: time.slice(0, 5),
      category: "work",
      notify: existing?.notify ?? notify,
      completed: false,
      clientId: clientId || existing?.clientId,
      priority: Math.min(5, Math.max(1, Number(priority || existing?.priority || 3))),
      createdAt: existing?.createdAt || nowISO(),
      updatedAt: nowISO(),
      relatedEntityType: entityType,
      relatedEntityId: entityId,
    };
    return existing ? previous.map(item => item.id === existing.id ? next : item) : [next, ...previous];
  });
};

const removeLinkedAgendaItem = (entityType: "consultation" | "work" | "sale", entityId: string) => {
  setAgendaItems(previous => previous.filter(item => !(item.relatedEntityType === entityType && item.relatedEntityId === entityId)));
};

const saveConsultationSchedule = () => {
  if (!newScheduledDate || !newScheduledTime) {
    showToast("Escolha a data e o horário do atendimento.");
    return;
  }

  // Um agendamento pode existir por si só. Ele não precisa de um atendimento
  // já iniciado para ser criado. Quando não há atendimento ativo, criamos
  // somente o registro agendado; ele poderá ser iniciado posteriormente.
  if (!activeConsultation) {
    const client = clients.find(item => item.id === selectedClientId);
    const now = nowISO();
    const scheduledAt = `${newScheduledDate}T${newScheduledTime}`;
    const record: Consultation = {
      id: makeId(),
      clientId: client?.id || "",
      clientName: client?.name || "",
      title: newTitle.trim() || "Atendimento",
      value: 0,
      paid: false,
      paymentDate: "",
      createdAt: now,
      updatedAt: now,
      status: "scheduled",
      questions: [],
      serviceType: "consultation",
      billingMode: "pending",
      currency: newReadingCurrency,
      currencyRate: newReadingCurrency === "BRL" ? 1 : (currencyRates[newReadingCurrency] || 0),
      priority: Math.min(5, Math.max(1, Number(newServicePriority) || 3)),
      scheduledAt,
    };
    setConsultations(previous => [record, ...previous]);
    upsertLinkedAgendaItem({
      entityType: "consultation",
      entityId: record.id,
      scheduledAt,
      title: `Atendimento · ${record.title}`,
      description: `Atendimento de ${record.clientName || "consulente"}`,
      clientId: record.clientId,
      priority: record.priority,
    });
    setAgendaDate(newScheduledDate);
    setAgendaFilterDate("");
    setNewScheduledDate("");
    setNewScheduledTime("");
    setShowScheduleModal(false);
    setShowNewConsultation(false);
    setScreen("agenda");
    showToast("Atendimento agendado e sincronizado com a Agenda.");
    return;
  }
  const scheduledAt = `${newScheduledDate}T${newScheduledTime}`;
  const updated: Consultation = {
    ...activeConsultation,
    scheduledAt,
    status: "scheduled",
    updatedAt: nowISO(),
  };
  updateConsultation(updated);
  const [date] = scheduledAt.split("T");
  upsertLinkedAgendaItem({
    entityType: "consultation",
    entityId: updated.id,
    scheduledAt,
    title: `Atendimento · ${updated.title}`,
    description: `Atendimento de ${updated.clientName}`,
    clientId: updated.clientId,
    priority: updated.priority,
  });
  setAgendaDate(date);
  setAgendaFilterDate("");
  setNewScheduledDate("");
  setNewScheduledTime("");
  setShowScheduleModal(false);
  setScreen("agenda");
  showToast("Atendimento agendado e sincronizado com a Agenda.");
};

const updateFinalQuestionBilling = (questionId: string, changes: Partial<Question>) => {
  if (!activeConsultation) return;
  const questions = activeConsultation.questions.map(question => question.id === questionId ? { ...question, ...changes, updatedAt: nowISO() } : question);
  const updated={ ...activeConsultation, questions, updatedAt:nowISO() };
  updateConsultation(updated);
  syncQuestionDesfalques(updated);
};

const finalizeConsultationPayment = () => {
  if (!activeConsultation) return;
  const now = nowISO();
  const selectedRate = finishCurrency === "BRL" ? 1 : (currencyRates[finishCurrency] || 0);
  const totalInCheckoutCurrency = Math.max(0, checkoutTotal);
  const totalBRL = convertToBRL(totalInCheckoutCurrency, finishCurrency);
  const entered = finishPaymentMode === "free" ? totalInCheckoutCurrency : totalInCheckoutCurrency;
  const installmentSurchargeValue = Math.max(0, Number(String(finishInstallmentSurcharge).replace(",", ".")) || 0);
  const installmentTotal = entered + installmentSurchargeValue;
  const grossBRL = convertToBRL(entered, finishCurrency);
  const hasCheckoutDesfalque = checkoutDesfalqueTotalBRL > 0.009;
  if (finishPaymentMode !== "free" && grossBRL <= 0 && !hasCheckoutDesfalque) { showToast("Informe um valor válido."); return; }
  if (finishCurrency !== "BRL" && selectedRate <= 0) { showToast("A cotação desta moeda ainda não foi carregada."); return; }
  if (finishPaymentMode === "pending" && !finishPaymentDate) { showToast("Informe o vencimento."); return; }
  const feePercent = getFeePercent(finishPaymentMethod);
  const fee = finishPaymentMode === "paid" ? grossBRL * Math.max(0, feePercent) / 100 : 0;
  let paymentPlan: PaymentPlan | undefined;
  if (finishPaymentMode === "paid") {
    paymentPlan = { id: makeId(), originalTotal: grossBRL, total: grossBRL, surcharge: 0, fee, type: "full", installments: [{ id: makeId(), number: 1, amount: grossBRL, dueDate: now.slice(0,10), status: "received", paymentMethod: finishPaymentMethod, receivedAt: now }] };
  } else if (finishPaymentMode === "pending") {
    paymentPlan = { id: makeId(), originalTotal: grossBRL, total: grossBRL, surcharge: 0, fee: 0, type: "full", installments: [{ id: makeId(), number: 1, amount: grossBRL, dueDate: finishPaymentDate, status: "pending", paymentMethod: finishPaymentMethod, receivedAt: "" }] };
  } else if (finishPaymentMode === "installments") {
    const count = Math.max(2, Number(finishInstallmentCount) || 2);
    const surcharge = installmentSurchargeValue;
    const total = installmentTotal;
    const entry = finishInstallmentEntry ? Math.max(0, Number(String(finishEntryAmount).replace(",", ".")) || 0) : 0;
    const safeEntry = Math.min(total, entry);
    const baseDate = new Date();
    const fallbackRows = Array.from({ length: count }, (_, i) => { const d = new Date(baseDate); d.setDate(1); d.setMonth(d.getMonth() + i + 1); const rest = Math.max(0, total-safeEntry); return { amount: count > 0 ? rest / count : 0, dueDate: d.toISOString().slice(0,10) }; });
    const rows = finishInstallmentRows.length === count ? finishInstallmentRows : fallbackRows.map((d,i)=>({id:makeId(),number:i+1,amount:String(d.amount),dueDate:d.dueDate,status:"pending" as "received"|"pending"}));
    const installments: Installment[] = [];
    if (safeEntry > 0) installments.push({ id: makeId(), number: 0, amount: convertToBRL(safeEntry, finishCurrency), dueDate: now.slice(0,10), status: "received", paymentMethod: finishPaymentMethod, receivedAt: now });
    rows.forEach((d,i)=>installments.push({ id:d.id||makeId(), number:i+1, amount:convertToBRL(Math.max(0,Number(String(d.amount).replace(",","."))||0), finishCurrency), dueDate:d.dueDate, status:(d.status || "pending") as Installment["status"], paymentMethod:finishPaymentMethod, receivedAt:d.status==="received"?now:"" }));
    const actualTotalBRL = installments.reduce((sum,item)=>sum + Math.max(0, Number(item.amount)||0), 0);
    paymentPlan = { id: makeId(), originalTotal: grossBRL, total: actualTotalBRL, surcharge: Math.max(0, actualTotalBRL - grossBRL), fee: 0, type: "installments", installments };
  }
  const receivedNow = paymentPlan?.installments.filter(i=>i.status === "received").reduce((s,i)=>s+i.amount,0) || 0;
  const allReceived = paymentPlan ? paymentPlan.installments.every(i=>i.status === "received") : finishPaymentMode === "paid";
  const actualGrossBRL = finishPaymentMode === "installments" && paymentPlan ? paymentPlan.total : grossBRL;
  const actualPotentialBRL = checkoutPotentialTotalBRL;
  const automaticDesfalqueBRL = checkoutDesfalqueTotalBRL;
  const updated: Consultation = { ...activeConsultation, value: actualGrossBRL, paid: allReceived || (actualGrossBRL <= 0 && automaticDesfalqueBRL > 0), paymentDate: allReceived ? now : (finishPaymentDate || ""), paymentPlan, currency: finishCurrency, currencyRate: selectedRate, paymentMethod: finishPaymentMethod, billingMode: finishPaymentMode, relatedWorkId: relatedReadingEnabled ? relatedReadingWorkId : activeConsultation.relatedWorkId, shortfall: automaticDesfalqueBRL, potentialValue: actualPotentialBRL, updatedAt: now };
  if (finishPaymentMode === "free" && totalBRL > 0) setDesfalques(previous => [{ id:makeId(), clientId:updated.clientId, clientName:updated.clientName, consultationId:updated.id, type:"free_reading", description:`${updated.title} grátis`, potentialValue:totalBRL, receivedValue:0, amount:totalBRL, date:now, createdAt:now }, ...previous]);
  if (finishInstallmentEntry && receivedNow > 0 && !allReceived) showToast(`Entrada de ${formatMoney(receivedNow)} registrada; restante parcelado.`);
  syncQuestionDesfalques(updated);
  syncRelatedChargeDesfalques(updated);
  finishConsultation(updated);
};

const syncRelatedChargeDesfalques = (consultation: Consultation) => {
  const relevant = (consultation.relatedCharges || []).filter(c => c.kind === "work" && c.billingMode === "desfalque" && !c.deletedAt);
  setDesfalques(previous => {
    const keep = previous.filter(d => d.consultationId !== consultation.id || d.type !== "work_default" || d.deletedAt);
    const now = nowISO();
    const created = relevant.map(c => {
      const potential = Math.max(0, Number(c.potentialAmount ?? c.originalAmount ?? 0));
      const marker = `[WORK-DESFALQUE:${consultation.id}:${c.id}]`;
      const old = previous.find(d => d.consultationId === consultation.id && d.type === "work_default" && d.description.includes(marker) && !d.deletedAt);
      return old ? {...old, potentialValue: potential, receivedValue: 0, amount: potential, updatedAt: now} : {id:makeId(), clientId:consultation.clientId, clientName:consultation.clientName, consultationId:consultation.id, workId:c.id, type:"work_default", description:`Desfalque · Trabalho ${c.title} ${marker}`, potentialValue:potential, receivedValue:0, amount:potential, date:now, createdAt:now};
    });
    return [...created, ...keep] as any;
  });
};

const syncQuestionDesfalques = (consultation: Consultation) => {
  const relevant = consultation.questions.filter(q => (q.billingMode === "desfalque" || (q.billingMode === "free" && !q.workQuestionKind)) && q.workQuestionKind !== "benefit" && q.workQuestionKind !== "courtesy");
  setDesfalques(previous => {
    const keep = previous.filter(d => d.consultationId !== consultation.id || d.deletedAt);
    const now = nowISO();
    const created = relevant.map(q => {
      const potential = Math.max(0, Number(q.potentialValue || q.value || 0));
      const marker = `[QUESTION-DESFALQUE:${consultation.id}:${q.id}]`;
      const old = previous.find(d => d.consultationId === consultation.id && d.description.includes(marker) && !d.deletedAt);
      return old ? {...old,potentialValue:potential,receivedValue:0,amount:potential,updatedAt:now} : {id:makeId(),clientId:consultation.clientId,clientName:consultation.clientName,consultationId:consultation.id,workId:q.relatedWorkId || consultation.linkedWorkId,type:"question_default",description:`Desfalque · Pergunta ${q.number} · ${consultation.title} ${marker}`,potentialValue:potential,receivedValue:0,amount:potential,date:now,createdAt:now};
    });
    return [...created,...keep] as any;
  });
};

const finishConsultation = (source?: Consultation) => {
  const base = source || activeConsultation;
  if (!base) return;
  const completed: Consultation = { ...base, status: "completed", questions: Array.isArray(base.questions) ? base.questions : [], updatedAt: nowISO() };
  updateConsultation(completed);
  const client = clients.find(item => item.id === completed.clientId);
  setActiveConsultation(null);
  setActiveQuestionId(null);
  setShowFinishConsultation(false);
  if (client) { setHistoryClient(client); setScreen("history"); } else { setScreen("dashboard"); }
  showToast("Atendimento encerrado e salvo no histórico.");
};

const deleteHistoryPhoto = (consultationId:string, photoId:string) => {
  const c=consultations.find(x=>x.id===consultationId);if(!c)return;
  if(!window.confirm("Excluir esta foto do registro?"))return;
  const updated={...c,intakePhotos:(c.intakePhotos||[]).filter(p=>p.id!==photoId),photos:(c.photos||[]).filter(p=>p.id!==photoId),questions:c.questions.map(q=>({...q,photos:(q.photos||[]).filter(p=>p.id!==photoId),responsePhotos:(q.responsePhotos||[]).filter(p=>p.id!==photoId)})),relatedCharges:(c.relatedCharges||[]).map(ch=>({...ch,photos:(ch.photos||[]).filter(p=>p.id!==photoId)})),updatedAt:nowISO()};
  updateConsultation(updated);showToast("Foto excluída do registro.");
};

const deleteConsultation = (id: string, allowCompleted = false) => {
  const consultation = consultations.find(item => item.id === id);
  if (!consultation) return;
  // Atendimento concluído só pode ser excluído a partir do Histórico do consulente.
  if (consultation.status === "completed" && !allowCompleted) {
    showToast("Atendimento finalizado só pode ser excluído pelo Histórico da consulente.");
    return;
  }
  if (consultation.status === "scheduled" && !allowCompleted) {
    showToast("Este atendimento está agendado. Reagende ou inicie o atendimento antes de excluir.");
    return;
  }
  if (!window.confirm(`Mover o atendimento "${consultation.title}" de ${consultation.clientName} para a lixeira?`)) return;
  const execution=workExecutions.find(e=>e.id===id || e.consultationId===id);
  const relatedMovements=stockMovements.filter(m=>m.referenceType==="work_execution" && m.referenceId===id);
  const relatedTransactions=quickTransactions.filter(t=>{const text=`${t.source||""} ${t.description||""}`;return text.includes(`[WORK:${id}:`)||text.includes(`[QUESTION:${id}:`);});
  const relatedDesfalques=desfalques.filter(d=>d.consultationId===id);
  sendToTrash("consultation", `Atendimento: ${consultation.clientName} · ${consultation.title}`, {...consultation,__sideEffects:{execution,relatedMovements,relatedTransactions,relatedDesfalques}});
  setConsultations(previous => previous.filter(item => item.id !== id));
  setAgendaItems(previous => previous.filter(item => item.relatedEntityId !== id));
  setWorkExecutions(previous=>previous.filter(e=>e.id!==id&&e.consultationId!==id));
  setStockMovements(previous=>previous.filter(m=>!(m.referenceType==="work_execution"&&m.referenceId===id)));
  if(execution){const used=execution.items.filter(i=>i.usage==="new").reduce((map,i)=>{map[i.stockItemId]=(map[i.stockItemId]||0)+i.quantity;return map;},{} as Record<string,number>);setStockItems(previous=>previous.map(st=>used[st.id]?{...st,quantity:st.quantity+used[st.id],updatedAt:nowISO()}:st));}
  setQuickTransactions(previous=>previous.filter(t=>!relatedTransactions.some(x=>x.id===t.id)));
  setDesfalques(previous=>previous.filter(d=>!relatedDesfalques.some(x=>x.id===d.id)));
  if (activeConsultation?.id === id) { setActiveConsultation(null); setActiveQuestionId(null); }
  showToast("Atendimento enviado para a lixeira.");
};

const openEditConsultation = (consultation: Consultation) => {
  setEditingConsultationId(consultation.id);
  setEditConsultationTitle(consultation.title);
  setEditConsultationValue(String(consultation.value));
  setEditConsultationPaid(Boolean(consultation.paid));
  setEditConsultationPaymentDate(consultation.paymentDate || "");
  setEditConsultationNotes(consultation.intakeNotes || "");
  setShowEditConsultation(true);
};

const openIntakeEditorForActiveConsultation = () => {
  const latest = activeConsultation ? consultations.find(item => item.id === activeConsultation.id) || activeConsultation : null;
  if (!latest) { showToast("Nenhum atendimento ativo para editar as informações recebidas."); return; }
  setActiveConsultation(latest);
  setIntakeEditingExisting(true);
  setIntakeNotes(latest.intakeNotes || "");
  setIntakePhotos([...(latest.intakePhotos || [])]);
  setIntakeAudios([...(latest.intakeAudios || [])]);
  setShowIntakeModal(true);
};
const saveIntakeModal = () => {
  if (intakeEditingExisting && activeConsultation) {
    updateConsultation({ ...activeConsultation, intakeNotes: intakeNotes.trim(), intakePhotos: [...intakePhotos], intakeAudios: [...intakeAudios], updatedAt: nowISO() });
    setIntakeEditingExisting(false); setShowIntakeModal(false); showToast("Informações recebidas atualizadas."); return;
  }
  setShowIntakeModal(false);
};

const saveEditedConsultation = () => {
  if (!editingConsultationId) return;
  const value = Number(String(editConsultationValue).replace(",", "."));
  if (!editConsultationTitle.trim()) { showToast("Digite o título do atendimento."); return; }
  if (!Number.isFinite(value) || value < 0) { showToast("Informe um valor válido."); return; }
  const paymentDate = editConsultationPaid ? (editConsultationPaymentDate || new Date().toISOString().slice(0, 10)) : "";
  setConsultations(previous => previous.map(item => {
    if (item.id !== editingConsultationId) return item;
    let paymentPlan = item.paymentPlan;
    if (paymentPlan?.installments?.length) {
      const rows=[...paymentPlan.installments];
      const received=rows.filter(i=>i.status==="received").reduce((s,i)=>s+Number(i.amount||0),0);
      const pending=rows.filter(i=>i.status!=="received"&&i.status!=="defaulted");
      if (editConsultationPaid && rows.every(i=>i.status==="received")) {
        const delta=value-received;
        rows[rows.length-1]={...rows[rows.length-1],amount:Math.max(0,Number(rows[rows.length-1].amount||0)+delta),receivedAt:rows[rows.length-1].receivedAt||paymentDate,status:"received"};
      } else if (pending.length) {
        const remaining=Math.max(0,value-received);
        const oldPending=pending.reduce((s,i)=>s+Number(i.amount||0),0);
        let left=remaining;
        pending.forEach((row,index)=>{
          const isLast=index===pending.length-1;
          const amount=isLast?left:(oldPending>0?remaining*(Number(row.amount||0)/oldPending):remaining/pending.length);
          row.amount=Math.max(0,Number(amount.toFixed(2)));
          left=Math.max(0,left-row.amount);
        });
      }
      if (!editConsultationPaid && rows.length===1 && rows[0].status==="received") rows[0]={...rows[0],status:"pending",receivedAt:"",amount:value,dueDate:paymentDate||rows[0].dueDate};
      paymentPlan={...paymentPlan,originalTotal:value,total:rows.reduce((s,i)=>s+Number(i.amount||0),0),surcharge:Math.max(0,rows.reduce((s,i)=>s+Number(i.amount||0),0)-value),installments:rows};
    } else if (editConsultationPaid) {
      paymentPlan={id:makeId(),originalTotal:value,total:value,surcharge:0,type:"full",installments:[{id:makeId(),number:1,amount:value,dueDate:paymentDate,status:"received",paymentMethod:item.paymentMethod||"pix",receivedAt:paymentDate}]};
    }
    return { ...item, title: editConsultationTitle.trim(), value, paid: editConsultationPaid, paymentDate, intakeNotes: editConsultationNotes.trim(), paymentPlan, updatedAt:nowISO() };
  }));
  setActiveConsultation(previous => previous?.id===editingConsultationId ? {...previous,title:editConsultationTitle.trim(),value,paid:editConsultationPaid,paymentDate, paymentPlan: previous.paymentPlan, intakeNotes:editConsultationNotes.trim(),updatedAt:nowISO()} : previous);
  setShowEditConsultation(false); setEditingConsultationId(null);
  showToast("Atendimento/trabalho atualizado sem duplicar recebimentos; parcelas pendentes foram recalculadas.");
};

const deleteDailyActivity = (item: DailyActivity) => {
  const rawId = item.id.replace(/^[^-]+-/, "");
  if (item.kind === "consultation") { deleteConsultation(rawId); return; }
  if (item.kind === "purchase") { deletePurchase(rawId); return; }
  if (item.kind === "agenda") { deleteAgendaItem(rawId); return; }
  if (item.kind === "budget") { deleteBudget(rawId); return; }
  if (item.kind === "income" || item.kind === "expense") { const transaction = quickTransactions.find(entry => entry.id === rawId); if (transaction && window.confirm("Mover este lançamento para a lixeira?")) { sendToTrash("quick_transaction", `Lançamento: ${transaction.source}`, transaction); setQuickTransactions(previous => previous.filter(x => x.id !== rawId)); showToast("Lançamento enviado para a lixeira."); } return; }
  showToast("Este tipo de registro não pode ser excluído diretamente daqui.");
};

const editDailyActivity = (item: DailyActivity) => {
  const rawId = item.id.replace(/^[^-]+-/, "");
  if (item.kind === "consultation") { const consultation = consultations.find(entry => entry.id === rawId); if (consultation) openEditConsultation(consultation); return; }
  if (item.kind === "purchase") { const purchase = purchases.find(entry => entry.id === rawId); if (purchase) { setScreen("finance"); editPurchase(purchase); } return; }
  if (item.kind === "agenda") { const agenda = agendaItems.find(entry => entry.id === rawId); if (agenda) { setAgendaFilterDate(agenda.date); setScreen("agenda"); editAgendaItem(agenda); } return; }
  if (item.kind === "budget") { const budget = budgets.find(entry => entry.id === rawId); if (budget) editBudgetDirect(budget); return; }
  if (item.kind === "income" || item.kind === "expense") { const transaction = quickTransactions.find(entry => entry.id === rawId); if (transaction) editQuickTransactionDirect(transaction); return; }
  showToast("Este tipo de registro não possui edição direta ainda.");
};

const openRelatedChargeEditor = (charge: RelatedCharge) => {
  setEditingRelatedChargeId(charge.id);
  setRelatedChargeKind(charge.kind); setRelatedChargeWorkTypeId(charge.workTypeId || ""); setRelatedChargeSaleItemId(charge.saleItemId || "");
  setRelatedChargeTitle(charge.title || ""); setRelatedChargeBillingMode(charge.billingMode || "pending"); setRelatedChargePriority(Math.min(5, Math.max(1, Number(charge.priority || activeConsultation?.priority || 3)))); setRelatedChargeCurrency((charge.currency || "BRL") as CurrencyCode);
  if ((charge.currency || "BRL") === "BRL") { setRelatedChargeAmount(String(charge.originalAmount ?? 0)); setRelatedChargeForeignAmount(""); } else { setRelatedChargeForeignAmount(String(charge.originalAmount ?? 0)); setRelatedChargeAmount(""); }
  setRelatedChargeBudgetId(charge.budgetId || ""); setRelatedChargeScheduledAt(charge.scheduledAt || ""); setRelatedChargeShippingEnabled(!!charge.shippingEnabled); setRelatedChargeShippingScheduledAt(charge.shippingScheduledAt || ""); setRelatedChargeShippingAddress(charge.shippingAddress || ""); setRelatedChargeShippingPhone(charge.shippingPhone || ""); setRelatedChargeShippingUber(String(charge.shippingUber || "")); setRelatedChargeShippingUberSpent(!!charge.shippingUberSpent); setRelatedChargeShippingUberSpentAmount(String(charge.shippingUberSpentAmount ?? charge.shippingUber ?? "")); setRelatedChargeNotes(charge.notes || ""); setRelatedChargeNeedsConfection(!!charge.saleStatus && ["awaiting_confection","in_confection"].includes(charge.saleStatus));
  setRelatedChargePhotos(charge.photos || []); setRelatedChargeAudios(charge.audios || []); setRelatedChargeReceivedObjects(charge.receivedObjects || []); setRelatedChargeSentObjects(charge.sentObjects || []); setShowRelatedChargeModal(true);
};
const startNewRelatedCharge = (kind: "work" | "sale") => {
  setEditingRelatedChargeId(null); setRelatedChargeKind(kind); setRelatedChargePriority(3); setRelatedChargeBillingMode("pending"); setRelatedChargeCurrency((activeConsultation?.currency || "BRL") as CurrencyCode); setRelatedChargeTitle(""); setRelatedChargeAmount(""); setRelatedChargeForeignAmount(""); setRelatedChargeBillingMode("pending"); setRelatedChargeWorkTypeId(""); setRelatedChargeSaleItemId(""); setRelatedChargeBudgetId(""); setRelatedChargeScheduledAt(""); setRelatedChargeShippingEnabled(false); setRelatedChargeShippingScheduledAt(""); setRelatedChargeShippingUber(""); setRelatedChargeShippingUberSpent(false); setRelatedChargeShippingUberSpentAmount(""); setRelatedChargeNotes(""); setRelatedChargePhotos([]); setRelatedChargeAudios([]); setRelatedChargeReceivedObjects([]); setRelatedChargeSentObjects([]);
  if(kind==="sale" && activeConsultation){const c=clients.find(x=>x.id===activeConsultation.clientId);setRelatedChargeShippingAddress(clientAddressText(c));setRelatedChargeShippingPhone(c?.phone||"");} else { setRelatedChargeShippingAddress(""); setRelatedChargeShippingPhone(""); }
  setShowRelatedChargeModal(true);
};
const removeRelatedChargeFinancialSideEffects = (consultationId:string, chargeId:string) => {
  const execution=workExecutions.find(e=>e.id===chargeId || e.chargeId===chargeId);
  if(execution){ const used=execution.items.filter(i=>i.usage==="new").reduce((map,i)=>{map[i.stockItemId]=(map[i.stockItemId]||0)+i.quantity;return map;},{} as Record<string,number>); setStockItems(prev=>prev.map(st=>used[st.id]?{...st,quantity:st.quantity+used[st.id],updatedAt:nowISO()}:st)); }
  setStockMovements(prev=>prev.filter(m=>!(m.referenceType==="work_execution" && (m.referenceId===chargeId || m.referenceId===consultationId))));
  setWorkExecutions(prev=>prev.filter(e=>e.id!==chargeId && e.chargeId!==chargeId));
  const markerPrefix=`[WORK:${consultationId}:`;
  setQuickTransactions(prev=>prev.filter(t=>{const text=`${t.source||""} ${t.description||""}`; return !text.includes(`${markerPrefix}INST:${chargeId}`) && !text.includes(`[WORK:${chargeId}:`);}));
  setDesfalques(prev=>prev.filter(d=>!(d.workId===chargeId && d.consultationId===consultationId)));
};
const deleteRelatedCharge = (chargeId: string) => {
  if (!activeConsultation) return; const charge=(activeConsultation.relatedCharges||[]).find(x=>x.id===chargeId); if(!charge)return;
  if(!window.confirm(`Excluir ${charge.kind === "work" ? "este trabalho" : "esta venda"}?`))return;
  removeRelatedChargeFinancialSideEffects(activeConsultation.id, chargeId);
  const updated={...activeConsultation,relatedCharges:(activeConsultation.relatedCharges||[]).filter(x=>x.id!==chargeId),updatedAt:nowISO()};
  updateConsultation(updated); setRelatedCharges(updated.relatedCharges||[]); setAgendaItems(prev=>prev.filter(a=>a.relatedEntityId!==charge.id)); showToast("Registro removido do atendimento.");
};

const removeConsultationFinancialSideEffects = (consultationId:string) => {
  setQuickTransactions(prev=>prev.filter(t=>{const text=`${t.source||""} ${t.description||""}`;return !text.includes(`[WORK:${consultationId}:`) && !text.includes(`[QUESTION:${consultationId}:`);}));
  setDesfalques(prev=>prev.filter(d=>d.consultationId!==consultationId));
  setStockMovements(prev=>prev.filter(m=>!(m.referenceType==="work_execution" && m.referenceId===consultationId)));
  const execution=workExecutions.find(e=>e.id===consultationId || e.consultationId===consultationId);
  if(execution){const used=execution.items.filter(i=>i.usage==="new").reduce((map,i)=>{map[i.stockItemId]=(map[i.stockItemId]||0)+i.quantity;return map;},{} as Record<string,number>);setStockItems(prev=>prev.map(st=>used[st.id]?{...st,quantity:st.quantity+used[st.id],updatedAt:nowISO()}:st));}
  setWorkExecutions(prev=>prev.filter(e=>e.id!==consultationId && e.consultationId!==consultationId));
};
const deleteServiceRecord = (record:any) => {
  const consultation=record?.consultation as Consultation|undefined; if(!consultation)return;
  const label=record.recordType==="work"?"trabalho":record.recordType==="sale"?"venda":"consulta/tiragem";
  if(!window.confirm(`Excluir este ${label}? Isso removerá o registro e recalculará histórico, financeiro e demais áreas relacionadas.`))return;
  if(record.chargeId){const charge=(consultation.relatedCharges||[]).find(c=>c.id===record.chargeId);if(!charge)return;removeRelatedChargeFinancialSideEffects(consultation.id, record.chargeId);const updated={...consultation,relatedCharges:(consultation.relatedCharges||[]).filter(c=>c.id!==record.chargeId),updatedAt:nowISO()};updateConsultation(updated);setShowServiceDetail(false);setSelectedServiceRecord(null);showToast("Registro excluído e áreas relacionadas atualizadas.");return;}
  deleteConsultation(consultation.id,true);setShowServiceDetail(false);setSelectedServiceRecord(null);
};
const openEditRecordModal = (record:any) => {
  const consultation=record?.consultation as Consultation|undefined;if(!consultation)return;setEditRecordTarget(record);
  const status=record.recordType==="work"?(record.chargeId?((consultation.relatedCharges||[]).find(c=>c.id===record.chargeId)?.status||"approved"):(consultation.workStatus||"approved")):record.recordType==="sale"?(record.chargeId?((consultation.relatedCharges||[]).find(c=>c.id===record.chargeId)?.saleStatus||"approved"):(consultation.saleStatus||"approved")):consultation.status;
  setEditRecordStatus(status);setEditRecordValue(String(consultation.value||record.amount||0));setEditRecordPaymentMethod((consultation.paymentMethod||consultation.paymentPlan?.installments?.[0]?.paymentMethod||"pix") as PaymentMethod);setEditRecordInstallments((consultation.paymentPlan?.installments||[]).map(i=>({id:i.id,amount:String(i.amount),dueDate:i.dueDate,status:i.status,receivedAmount:String(installmentReceivedAmount(i))})));
  const ex=workExecutions.find(e=>e.id===record.id||e.consultationId===consultation.id);setEditRecordExecutionDate(ex?.executedDate||ex?.executedAt?.slice(0,10)||localDateKey());setShowEditRecordModal(true);
};
const saveEditRecord = () => {
  const record=editRecordTarget;const consultation=record?.consultation as Consultation|undefined;if(!record||!consultation)return;const now=nowISO();
  const value=Math.max(0,Number(String(editRecordValue).replace(",","."))||0);
  const oldRows=consultation.paymentPlan?.installments||[];
  const rows=editRecordInstallments.map((r,i)=>{const amount=Math.max(0,Number(String(r.amount).replace(",","."))||0);const old=oldRows.find(x=>x.id===r.id);const paymentTotal=old?.payments?.length?old.payments.reduce((s,p)=>s+Math.max(0,Number(p.amount||0)),0):null;const received=Math.max(0,Math.min(amount,paymentTotal!==null?paymentTotal:Number(String(r.receivedAmount||"0").replace(",","."))||0));return {id:r.id||makeId(),number:old?.number||i+1,amount,dueDate:r.dueDate,status:(received>=amount-0.01?"received":r.status) as Installment["status"],paymentMethod:editRecordPaymentMethod,receivedAmount:received,payments:old?.payments,lastPaymentAt:old?.lastPaymentAt,receivedAt:received>=amount-0.01?(old?.receivedAt||old?.lastPaymentAt||now):old?.receivedAt||""};});
  const paymentPlan=rows.length?{...(consultation.paymentPlan||{id:makeId(),originalTotal:value,total:value,surcharge:0,type:rows.length>1?"installments":"full" as const}),originalTotal:consultation.paymentPlan?.originalTotal??value,total:rows.reduce((a,b)=>a+b.amount,0),installments:rows as Installment[]}:consultation.paymentPlan;
  let updated:Consultation={...consultation,value:record.recordType==="reading"?consultation.value:value,paymentMethod:editRecordPaymentMethod,paymentPlan,paid:paymentPlan?.installments?.length?paymentPlan.installments.every(i=>installmentReceivedAmount(i)>=i.amount-0.01):consultation.paid,updatedAt:now};
  if(record.chargeId)updated={...updated,relatedCharges:(updated.relatedCharges||[]).map(c=>c.id!==record.chargeId?c:record.recordType==="work"?{...c,status:editRecordStatus as RelatedCharge["status"],originalAmount:value,amountBRL:c.currency==="BRL"?value:value*(c.currencyRate||1)}:{...c,saleStatus:editRecordStatus as RelatedCharge["saleStatus"],originalAmount:value,amountBRL:c.currency==="BRL"?value:value*(c.currencyRate||1)})};
  else if(record.recordType==="work")updated.workStatus=editRecordStatus as Consultation["workStatus"];else if(record.recordType==="sale")updated.saleStatus=editRecordStatus as Consultation["saleStatus"];else updated.status=editRecordStatus as Consultation["status"];
  updateConsultation(updated);
  if(record.recordType==="work"){const ex=workExecutions.find(e=>e.id===record.id||e.consultationId===consultation.id);if(ex){const t=ex.executedAt?.slice(11)||now.slice(11);setWorkExecutions(prev=>prev.map(e=>e.id===ex.id?{...e,executedDate:editRecordExecutionDate,executedAt:`${editRecordExecutionDate}T${t}`}:e));}}
  setShowEditRecordModal(false);setEditRecordTarget(null);setSelectedServiceRecord({...record,consultation:updated,value:updated.value,paymentStatus:getPaymentStatus(updated),status:record.recordType==="work"?updated.workStatus:record.recordType==="sale"?updated.saleStatus:updated.status});showToast("Status, condições e pagamentos atualizados em todas as áreas.");
};
const openWorkExecution = (record: {id:string; consultationId:string; chargeId?:string; workTypeId?:string; title:string; clientName:string; amount?:number}) => {
  const workType = record.workTypeId ? workTypes.find(w => w.id === record.workTypeId) : undefined;
  const existing = workExecutions.find(x => x.id === record.id || x.chargeId === record.chargeId);
  const consultation = consultations.find(c => c.id === record.consultationId);
  const plan = consultation?.paymentPlan;
  setSelectedWorkExecutionId(record.id);
  setExecutionItems(existing?.items.map(i => ({stockItemId:i.stockItemId, quantity:String(i.quantity), usage:i.usage})) || (workType?.standardItems || []).map(i => ({stockItemId:i.stockItemId, quantity:String(i.quantity), usage:"new" as const})));
  setExecutionExternalItems((existing?.externalItems || []).map(i => ({name:i.name,quantity:String(i.quantity),unit:i.unit,cost:String(i.cost),notes:i.notes || ""})));
  setExecutionNotes(existing?.notes || "");
  const currentCurrency = (consultation?.currency || "BRL") as CurrencyCode;
  const currentRate = currentCurrency === "BRL" ? 1 : (consultation?.currencyRate || currencyRates[currentCurrency] || 0);
  const currentBRL = Number(consultation?.value ?? record.amount ?? 0) || 0;
  setExecutionCurrency(currentCurrency);
  setExecutionValue(String(currentCurrency === "BRL" ? currentBRL : (currentRate > 0 ? Number((currentBRL / currentRate).toFixed(2)) : 0)));
  const initialMethod = (consultation?.paymentMethod || plan?.installments?.[0]?.paymentMethod || "pix") as PaymentMethod;
  setExecutionPaymentMethod(initialMethod);
  setExecutionPaymentFeePercent(initialMethod === "paypal" ? currencySettings.paypalFeePercent : initialMethod === "wise" ? currencySettings.wiseFeePercent : initialMethod === "other" ? currencySettings.otherFeePercent : 0);
  setExecutionPaymentFee(plan?.fee || 0);
  setExecutionPaymentNetBRL(Math.max(0, currentBRL - Number(plan?.fee || 0)));
  setExecutionPaymentMode(plan?.type === "installments" ? "installments" : plan?.installments?.[0]?.status === "received" ? "paid" : "pending");
  setExecutionPaymentDate(plan?.installments?.[0]?.dueDate || localDateKey());
  setExecutionInstallmentRows((plan?.installments || []).map(i => ({id:i.id,amount:String(i.amount),dueDate:i.dueDate,status:i.status})));
  if (!plan && Number(consultation?.value ?? record.amount ?? 0) > 0) setExecutionInstallmentRows([{id:makeId(),amount:String(Number(consultation?.value ?? record.amount ?? 0)),dueDate:localDateKey()}]);
  const scheduled = consultation?.scheduledAt || (record as any).scheduledAt || "";
  setExecutionScheduleDate(scheduled.slice(0,10)); setExecutionScheduleTime(scheduled.slice(11,16) || "09:00");
  setExecutionDate(existing?.executedDate || existing?.executedAt?.slice(0,10) || localDateKey());
  setExecutionScheduleRequested(false);
  setExecutionStockOpen(true); setExecutionFinanceOpen(false); setExecutionInfoOpen(false); setExecutionScheduleOpen(false);
  setExternalItemDraft({name:"",quantity:"1",unit:"un",cost:"0",notes:""});
};
const saveWorkScheduled = (record: {id:string; consultationId:string; chargeId?:string; workTypeId?:string; title:string; clientName:string}) => {
  if (!executionScheduleDate || !executionScheduleTime) { showToast("Escolha a data e o horário do agendamento."); return; }
  const consultation = consultations.find(c => c.id === record.consultationId);
  if (!consultation) return;
  const scheduledAt = `${executionScheduleDate}T${executionScheduleTime}`;
  const updated = record.chargeId
    ? { ...consultation, relatedCharges:(consultation.relatedCharges||[]).map(ch=>ch.id===record.chargeId?{...ch,status:"scheduled" as const,scheduledAt}:ch), updatedAt:nowISO() }
    : { ...consultation, scheduledAt, workStatus:"scheduled" as const, updatedAt:nowISO() };
  updateConsultation(updated);
  const [date,time] = scheduledAt.split("T");
  setAgendaItems(prev => {
    const existing = prev.find(a=>a.relatedEntityId===record.id);
    if(existing) return prev.map(a=>a.relatedEntityId===record.id?{...a,date,time,completed:false,notify:true,title:`Trabalho · ${record.title}`,description:`Trabalho de ${record.clientName}`,priority:Math.min(5,Math.max(1,Number((record as any).priority)||Number(a.priority)||3)),updatedAt:nowISO()}:a);
    return [{id:makeId(),title:`Trabalho · ${record.title}`,description:`Trabalho de ${record.clientName}`,date,time,category:"work",notify:true,completed:false,createdAt:nowISO(),relatedEntityType:"work",relatedEntityId:record.id,priority:Math.min(5,Math.max(1,Number((record as any).priority)||3))},...prev];
  });
  setSelectedWorkExecutionId(null); setExecutionItems([]); setExecutionExternalItems([]); setExecutionNotes(""); setExecutionScheduleRequested(false);
  showToast("Trabalho agendado. Ele aparecerá na Agenda e nos próximos agendamentos.");
};

const saveWorkExecution = (record: {id:string; consultationId:string; chargeId?:string; workTypeId?:string; title:string; clientName:string}) => {
  const consultation = consultations.find(c=>c.id===record.consultationId);
  const alreadyExecuted = !!consultation && (
    workExecutions.some(x => x.id === record.id) ||
    (record.chargeId ? (consultation.relatedCharges || []).some(ch => ch.id === record.chargeId && ch.status === "completed") : consultation.workStatus === "completed")
  );
  if (alreadyExecuted) {
    showToast("Este trabalho já foi executado. O sistema bloqueou uma segunda execução para evitar duplicação financeira.");
    setSelectedWorkExecutionId(null);
    return;
  }
  const items = executionItems.map(i => { const stock = stockItems.find(x=>x.id===i.stockItemId); const quantity = Math.max(0, Number(String(i.quantity).replace(",",".")) || 0); return {stockItemId:i.stockItemId, quantity, usage:i.usage, unitCost:stock?.averageCost||0, cost:i.usage === "new" ? quantity*(stock?.averageCost||0) : 0}; }).filter(i=>i.quantity>0);
  for (const item of items) { const stock=stockItems.find(x=>x.id===item.stockItemId); if (!stock) { showToast("Um item do estoque não foi encontrado."); return; } if (item.usage === "new" && item.quantity > stock.quantity) { showToast(`Estoque insuficiente para ${stock.name}.`); return; } }
  const externalItems = executionExternalItems.map(i=>({name:i.name.trim(),quantity:Math.max(0,Number(String(i.quantity).replace(",","."))||0),unit:i.unit.trim()||"un",cost:Math.max(0,Number(String(i.cost).replace(",","."))||0),notes:i.notes.trim()||undefined})).filter(i=>i.name && i.quantity>0);
  const externalCost = externalItems.reduce((s,i)=>s+i.cost,0);
  const workAmountForeign = Math.max(0, Number(String(executionValue).replace(",",".")) || 0);
  const executionRate = executionCurrency === "BRL" ? 1 : (currencyRates[executionCurrency] || consultation?.currencyRate || 0);
  if (executionCurrency !== "BRL" && executionRate <= 0) { showToast("A cotação desta moeda ainda não está disponível."); return; }
  const workAmount = executionCurrency === "BRL" ? workAmountForeign : workAmountForeign * executionRate;
  const feePercent = getFeePercent(executionPaymentMethod);
  const fee = workAmount * Math.max(0, feePercent) / 100;
  setExecutionPaymentFeePercent(feePercent);
  setExecutionPaymentFee(fee);
  setExecutionPaymentNetBRL(Math.max(0, workAmount - fee));
  const existingPlanRows = consultation?.paymentPlan?.installments || [];
  const newExecutionPayments: Array<{ installmentId:string; payment:InstallmentPayment }> = [];
  const buildExecutionRow = (base:any, old?:Installment) => {
    const amount = Math.max(0, Number(base.amount || 0));
    const oldReceived = old ? installmentReceivedAmount(old) : 0;
    const oldPayments = old?.payments || [];
    const shouldReceive = base.status === "received";
    let payments = [...oldPayments];
    let received = Math.min(amount, oldReceived);
    let lastPaymentAt = old?.lastPaymentAt;
    let receivedAt = old?.receivedAt || "";
    if (shouldReceive && received < amount - 0.009) {
      const payment: InstallmentPayment = { id: makeId(), amount: Math.max(0, amount - received), date: nowISO(), paymentMethod: base.paymentMethod };
      payments = [...payments, payment];
      received += payment.amount;
      lastPaymentAt = payment.date;
      receivedAt = payment.date;
      newExecutionPayments.push({ installmentId: base.id, payment });
    }
    if (shouldReceive && !old) {
      received = amount;
      if (!payments.length) {
        const payment: InstallmentPayment = { id: makeId(), amount, date: nowISO(), paymentMethod: base.paymentMethod };
        payments = [payment];
        lastPaymentAt = payment.date;
        receivedAt = payment.date;
        newExecutionPayments.push({ installmentId: base.id, payment });
      }
    }
    const finalStatus: Installment["status"] = received >= amount - 0.009 ? "received" : (old?.status === "defaulted" ? "defaulted" : old?.status === "overdue" ? "overdue" : "pending");
    return { ...base, amount, status: finalStatus, receivedAmount: received, payments, lastPaymentAt, receivedAt: finalStatus === "received" ? (receivedAt || lastPaymentAt || nowISO()) : receivedAt };
  };
  const existingFirstInstallment = existingPlanRows[0];
  const paymentRows = executionPaymentMode === "paid"
    ? [buildExecutionRow({id:existingFirstInstallment?.id||makeId(),number:1,amount:workAmount,dueDate:executionPaymentDate||localDateKey(),status:"received" as const,paymentMethod:executionPaymentMethod,receivedAt:""}, existingFirstInstallment)]
    : executionPaymentMode === "pending"
      ? [buildExecutionRow({id:existingFirstInstallment?.id||makeId(),number:1,amount:workAmount,dueDate:executionPaymentDate||localDateKey(),status:"pending" as const,paymentMethod:executionPaymentMethod,receivedAt:""}, existingFirstInstallment)]
      : executionInstallmentRows.map((r,i)=>{ const displayAmount=Math.max(0,Number(String(r.amount).replace(",","."))||0); const amount=executionCurrency==="BRL"?displayAmount:displayAmount*executionRate; const old=existingPlanRows.find(x=>x.id===r.id); return buildExecutionRow({id:r.id||makeId(),number:i+1,amount,dueDate:r.dueDate,status:(r.status||"pending") as Installment["status"],paymentMethod:executionPaymentMethod,receivedAt:""}, old); }).filter(r=>r.amount>0&&r.dueDate);
  if (executionPaymentMode === "installments" && paymentRows.length && Math.abs(paymentRows.reduce((a,b)=>a+b.amount,0)-workAmount)>0.01) { showToast(`As parcelas devem somar ${formatMoney(workAmount)}.`); return; }
  const paymentPlan: PaymentPlan | undefined = workAmount > 0 ? {id:makeId(),originalTotal:workAmount,total:workAmount,surcharge:0,fee:fee,type:paymentRows.length>1?"installments":"full",installments:paymentRows} : undefined;
  const executionNow = nowISO();
  const executionTimestamp = `${executionDate || localDateKey()}T${executionNow.slice(11,19)}`;
  const execution: WorkExecution = { id: record.id, consultationId: record.consultationId, chargeId: record.chargeId, workTypeId: record.workTypeId, workTitle: record.title, clientName: record.clientName, executedAt: executionTimestamp, executedDate: executionDate || localDateKey(), totalCost: items.reduce((s,i)=>s+i.cost,0)+externalCost, estimatedSavings: items.reduce((s,i)=>{const stock=stockItems.find(x=>x.id===i.stockItemId);return s+(i.usage==="reused"?(i.quantity*(stock?.averageCost||0)):0)},0), notes: executionNotes.trim() || undefined, items, externalItems };
  setStockItems(previous => previous.map(stock => { const used = items.filter(i=>i.stockItemId===stock.id && i.usage === "new").reduce((s,i)=>s+i.quantity,0); return used ? {...stock, quantity: stock.quantity-used} : stock; }));
  setStockMovements(previous => [...previous, ...items.filter(i=>i.usage === "new").map(i=>({id:makeId(),stockItemId:i.stockItemId,type:"consumption" as const,quantity:i.quantity,unitCost:i.unitCost,date:nowISO(),referenceType:"work_execution" as const,referenceId:record.id,notes:`Uso no trabalho ${record.title}`}))]);
  setWorkExecutions(previous => [...previous.filter(x=>x.id!==record.id), execution]);
  const scheduleAt = executionScheduleDate && executionScheduleTime ? `${executionScheduleDate}T${executionScheduleTime}` : "";
  setConsultations(previous => previous.map(c => {
    if (c.id !== record.consultationId) return c;
    if (record.chargeId) return {...c, relatedCharges:(c.relatedCharges||[]).map(ch=>ch.id===record.chargeId?{...ch,status:"completed",scheduledAt:scheduleAt||ch.scheduledAt,amountBRL:workAmount,originalAmount:workAmountForeign,currency:executionCurrency,currencyRate:executionRate}:ch), value:workAmount, paymentPlan, paymentMethod:executionPaymentMethod, currency:executionCurrency, currencyRate:executionRate, paid:paymentRows.length>0 && paymentRows.every(i=>i.status==="received"), paymentDate:paymentRows.find(i=>i.status==="received")?.receivedAt || c.paymentDate, updatedAt:nowISO()};
    return {...c, value:workAmount, paymentPlan, paymentMethod:executionPaymentMethod, currency:executionCurrency, currencyRate:executionRate, paid:paymentRows.length>0 && paymentRows.every(i=>i.status==="received"), paymentDate:paymentRows.find(i=>i.status==="received")?.receivedAt || c.paymentDate, scheduledAt:scheduleAt||c.scheduledAt, workStatus:"completed", updatedAt:nowISO()};
  }));
  setAgendaItems(previous => previous.map(a => a.relatedEntityId === record.id ? {...a, completed:true, notify:false, description:`Trabalho concluído · ${record.clientName}`, updatedAt:nowISO()} : a));
  newExecutionPayments.forEach(({ installmentId, payment }) => {
    const marker=`[WORK:${record.consultationId}:INST:${installmentId}:PAY:${payment.id}]`;
    setQuickTransactions(prev=>prev.some(t=>`${t.source} ${t.description}`.includes(marker)) ? prev : [{id:makeId(),type:"income",area:"work",amount:payment.amount,source:`Recebimento · ${record.title} ${marker}`,description:`Pagamento de parcela · ${record.clientName}`,clientId:consultation?.clientId||"",clientName:record.clientName,stockItemId:"",quantity:0,paymentMethod:payment.paymentMethod,currency:consultation?.currency||"BRL",paymentStatus:"received",fee:Number((payment.amount*feePercent/100).toFixed(2)),grossAmount:payment.amount,date:payment.date,createdAt:payment.date},...prev]);
  });
  paymentRows.forEach(inst => {
    const desfalqueExists=desfalques.find(d=>d.consultationId===record.consultationId&&d.installmentId===inst.id&&!d.questionId&&!d.deletedAt);
    const received=installmentReceivedAmount(inst);
    const remaining=installmentOpenAmount(inst);
    if(inst.status==="defaulted") setDesfalques(prev=>desfalqueExists?prev.map(d=>d.id===desfalqueExists.id?{...d,potentialValue:inst.amount,amount:remaining,receivedValue:received,updatedAt:nowISO()}:d):[{id:makeId(),clientId:consultation?.clientId,clientName:record.clientName,consultationId:record.consultationId,installmentId:inst.id,workId:record.consultationId,type:"default",description:`Calote · Parcela ${inst.number} · ${record.title}`,potentialValue:inst.amount,receivedValue:received,amount:remaining,date:nowISO(),createdAt:nowISO()},...prev] as any);
    if((inst.status==="pending"||inst.status==="overdue") && desfalqueExists) setDesfalques(prev=>prev.map(d=>d.id===desfalqueExists.id?{...d,amount:0,updatedAt:nowISO()}:d));
  });
  setSelectedWorkExecutionId(null); setExecutionItems([]); setExecutionExternalItems([]); setExecutionNotes("");
  showToast(`Trabalho concluído. Valor: ${formatForeign(workAmountForeign, executionCurrency)} · taxa: ${formatMoney(fee)} · líquido: ${formatMoney(Math.max(0, workAmount-fee))}.`);
};

const closeAgendaActionOverlays = () => {
  // Reagendar/cancelar são ações de agenda. Nunca devem abrir ou restaurar checkout
  // nem deixar um atendimento ativo para que efeitos da tela o restaurem.
  setShowFinishConsultation(false);
  setShowServiceDetail(false);
  setShowEditConsultation(false);
  setShowScheduleModal(false);
  setShowRelatedChargeModal(false);
  setShowRelatedActivity(false);
  setShowIntakeModal(false);
  setShowRescheduleModal(false);
  setActiveConsultation(null);
  setActiveQuestionId(null);
};

const updateWorkLifecycle = (record:any, status: "approved"|"scheduled"|"completed"|"cancelled"|"postponed") => {
  const consultation = consultations.find((c:any)=>c.id===record.consultationId); if(!consultation)return;
  const now = nowISO();
  if(record.chargeId){
    const updated={...consultation,relatedCharges:(consultation.relatedCharges||[]).map((ch:any)=>ch.id===record.chargeId?{...ch,status,scheduledAt:status==="cancelled"?"":ch.scheduledAt,updatedAt:now}:ch),updatedAt:now};
    updateConsultation(updated);
  } else {
    updateConsultation({...consultation,workStatus:status,scheduledAt:status==="cancelled"?"":consultation.scheduledAt,updatedAt:now});
  }
  if(status === "cancelled") {
    const chargeKind = record.chargeId
      ? ((consultation.relatedCharges || []).find((ch:any) => ch.id === record.chargeId)?.kind || record.serviceType)
      : record.serviceType;
    closeAgendaActionOverlays();
    removeLinkedAgendaItem(chargeKind === "sale" ? "sale" : "work", record.chargeId || record.id);
  }
  if(status === "postponed") setAgendaItems(prev=>prev.map(a=>a.relatedEntityId===record.id?{...a,completed:false,description:`Trabalho adiado · ${record.clientName}`,updatedAt:now}:a));
  if(status === "completed") setAgendaItems(prev=>prev.map(a=>a.relatedEntityId===record.id?{...a,completed:true,notify:false,updatedAt:now}:a));
  showToast(status === "cancelled" ? "Agendamento cancelado." : status === "postponed" ? "Trabalho marcado como adiado. Reagende quando definir a nova data." : "Status do trabalho atualizado.");
};

const cancelScheduledConsultation = (consultation: Consultation) => {
  if (!window.confirm(`Cancelar o agendamento de ${consultation.clientName}?`)) return;
  const now=nowISO();
  const updated = consultation.serviceType === "sale"
    ? {...consultation,saleStatus:"cancelled" as const,shippingScheduledAt:"",scheduledAt:"",updatedAt:now}
    : consultation.serviceType === "work"
      ? {...consultation,workStatus:"cancelled" as const,scheduledAt:"",updatedAt:now}
      : {...consultation,status:"cancelled" as const,scheduledAt:"",updatedAt:now};
  updateConsultation(updated);
  removeLinkedAgendaItem("consultation", consultation.id);
  closeAgendaActionOverlays();
  setScreen("agenda");
  showToast("Agendamento cancelado.");
};

const rescheduleWork = (record:any) => {
  // Reagendamento é uma operação exclusiva da Agenda. Encerramos qualquer
  // contexto de atendimento antes de abrir o modal para impedir retorno ao checkout.
  closeAgendaActionOverlays();
  setScreen("agenda");
  const agendaRecord = record.id ? agendaItems.find(a => a.id === record.id && !a.relatedEntityType) : undefined;
  const parent = record.consultationId ? consultations.find((c:any)=>c.id===record.consultationId) : undefined;
  const charge = record.chargeId ? (parent?.relatedCharges||[]).find((ch:any)=>ch.id===record.chargeId) : undefined;
  const linkedAgendaRecord = record.chargeId
    ? agendaItems.find(a => a.relatedEntityId === record.chargeId && a.relatedEntityType === (charge?.kind === "sale" ? "sale" : "work"))
    : record.consultationId
      ? agendaItems.find(a => a.relatedEntityId === record.consultationId && a.relatedEntityType === "consultation")
      : undefined;
  const current = record.scheduledAt || record.shippingScheduledAt || charge?.shippingScheduledAt || charge?.scheduledAt || parent?.scheduledAt || parent?.shippingScheduledAt || (agendaRecord ? `${agendaRecord.date}T${agendaRecord.time}` : "");
  // Fechar qualquer checkout que tenha ficado aberto por restauração de estado.
  setShowFinishConsultation(false);
  setShowServiceDetail(false);
  setShowEditConsultation(false);
  setShowRescheduleModal(true);
  setRescheduleTarget({...record, serviceType: record.serviceType || charge?.kind || parent?.serviceType || "manual", manualAgendaId: agendaRecord?.id});
  setRescheduleDate(current.slice(0,10)||localDateKey());
  setRescheduleTime(current.slice(11,16)||"09:00");
  setReschedulePriority(Math.min(5, Math.max(1, Number(record.priority || charge?.priority || parent?.priority || linkedAgendaRecord?.priority || 3))));
};

const saveRescheduleWork = () => {
 const record=rescheduleTarget;
 if(!record||!rescheduleDate||!rescheduleTime){showToast("Escolha a data e o horário.");return;}
 const scheduledAt=`${rescheduleDate}T${rescheduleTime}`;
 if(record.serviceType === "manual" && record.manualAgendaId){
   const [date,time]=scheduledAt.split("T");
   setAgendaItems(previous => previous.map(item => item.id === record.manualAgendaId ? {...item,date,time:time.slice(0,5),completed:false,notify:true,priority:Math.min(5,Math.max(1,Number(reschedulePriority)||3)),updatedAt:nowISO()} : item));
   setAgendaDate(date); setAgendaFilterDate(""); setShowRescheduleModal(false); setRescheduleTarget(null); setScreen("agenda");
   showToast("Compromisso reagendado e sincronizado com a agenda.");
   return;
 }
 const consultation=consultations.find((c:any)=>c.id===record.consultationId);
 if(!consultation){showToast("O compromisso não foi encontrado.");return;}
 const charge = record.chargeId ? (consultation.relatedCharges||[]).find((ch:any)=>ch.id===record.chargeId) : undefined;
 const serviceType=(record.serviceType || charge?.kind || consultation.serviceType || "consultation") as string;
 const now=nowISO();
 if(record.chargeId){
   const isSale=serviceType==="sale";
   const updated={...consultation,relatedCharges:(consultation.relatedCharges||[]).map((ch:any)=>{
     if(ch.id!==record.chargeId)return ch;
     return isSale
       ? {...ch,shippingScheduledAt:scheduledAt,scheduledAt:ch.scheduledAt||scheduledAt,priority:Math.min(5,Math.max(1,Number(reschedulePriority)||Number(ch.priority)||3)),saleStatus:ch.saleStatus==="delivered"||ch.saleStatus==="cancelled"?"approved":(ch.saleStatus||"awaiting_shipping"),updatedAt:now}
       : {...ch,scheduledAt,status:"scheduled",priority:Math.min(5,Math.max(1,Number(reschedulePriority)||Number(ch.priority)||3)),updatedAt:now};
   }),updatedAt:now};
   updateConsultation(updated);
 } else {
   const updated: Consultation = serviceType==="sale"
     ? {...consultation,scheduledAt:consultation.scheduledAt || scheduledAt,shippingScheduledAt:scheduledAt,saleStatus:consultation.saleStatus==="delivered"||consultation.saleStatus==="cancelled"?"approved":(consultation.saleStatus||"awaiting_shipping"),updatedAt:now}
     : serviceType==="work"
       ? {...consultation,scheduledAt,priority:Math.min(5,Math.max(1,Number(reschedulePriority)||Number(consultation.priority)||3)),workStatus:"scheduled" as Consultation["workStatus"],status:consultation.status==="completed"?"scheduled":consultation.status,updatedAt:now}
       : {...consultation,scheduledAt,priority:Math.min(5,Math.max(1,Number(reschedulePriority)||Number(consultation.priority)||3)),status:"scheduled",updatedAt:now};
   updateConsultation(updated);
 }
 const kind=serviceType==="sale"?"sale":serviceType==="work"?"work":"consultation";
 const entityId=record.chargeId || record.consultationId;
 const [date,time]=scheduledAt.split("T");
 const title=kind==="sale"?`Envio · ${record.title || consultation.title}`:kind==="consultation"?`Atendimento · ${record.title || consultation.title}`:`Trabalho · ${record.title || consultation.title}`;
 const description=kind==="sale"?`Envio para ${record.clientName || consultation.clientName}`:kind==="consultation"?`Atendimento de ${record.clientName || consultation.clientName}`:`Trabalho de ${record.clientName || consultation.clientName}`;
 setAgendaItems(prev=>{
   const existing=prev.find(a=>a.relatedEntityId===entityId && a.relatedEntityType===kind);
   if(existing)return prev.map(a=>a.id===existing.id?{...a,date,time,completed:false,notify:true,title,description,priority:Math.min(5,Math.max(1,Number(reschedulePriority)||Number(a.priority)||3)),updatedAt:now}:a);
   return [{id:makeId(),title,description,date,time,category:"work",notify:true,completed:false,createdAt:now,relatedEntityType:kind,relatedEntityId:entityId,priority:Math.min(5,Math.max(1,Number(reschedulePriority)||Number(record.priority)||Number(consultation.priority)||3))},...prev.filter(a=>!(a.relatedEntityId===entityId && a.relatedEntityType===kind))];
 });
 setAgendaDate(date);
 setAgendaFilterDate("");
 setShowFinishConsultation(false);
 setShowServiceDetail(false);
 setShowRescheduleModal(false);
 setRescheduleTarget(null);
 setActiveConsultation(null);
 setActiveQuestionId(null);
 setScreen("agenda");
 showToast(kind==="consultation"?"Atendimento reagendado e sincronizado com a agenda.":kind==="sale"?"Venda/envio reagendado e sincronizado com a agenda.":"Trabalho reagendado e sincronizado com a agenda.");
};

const openQuickCatalog = (kind:"stock"|"work"|"category"|"sale"|"reading") => {
  // V70: o cadastro rápido é uma janela filha. Mantemos a janela pai aberta
  // para que o usuário volte exatamente ao contexto que estava preenchendo.
  setQuickCatalogReturnContext(null);
  setQuickCatalogKind(kind); setQuickCatalogName(""); setQuickCatalogPrice("0"); setQuickCatalogQuestions("1"); setQuickCatalogSectorId(householdSectors.find(x=>x.active)?.id||"");
};
const saveQuickCatalog = () => {
 const name=quickCatalogName.trim(); if(!name||!quickCatalogKind){showToast("Informe o nome do cadastro.");return;}
 if(quickCatalogKind==="work"){ const item:WorkType={id:makeId(),name,active:true,prices:{...emptyCurrencyPrices(),BRL:Math.max(0,Number(String(quickCatalogPrice).replace(",","."))||0)},createdAt:nowISO()}; setWorkTypes(p=>[...p,item]); if(showRelatedChargeModal && relatedChargeKind==="work"){ setRelatedChargeWorkTypeId(item.id); setRelatedChargeTitle(item.name); const price=workPrice(item, relatedChargeCurrency); if(relatedChargeCurrency==="BRL") setRelatedChargeAmount(String(price)); else setRelatedChargeForeignAmount(String(price)); } if(showNewConsultation && newServiceType==="work"){ setSelectedWorkTypeId(item.id); setNewTitle(item.name); const servicePrice=workPrice(item, serviceCurrency); if(serviceCurrency==="BRL") setServiceValue(String(servicePrice)); else setServiceForeignAmount(String(servicePrice)); } }
 else if(quickCatalogKind==="stock"){ const item:StockItem={id:makeId(),name,area:"work",quantity:0,unit:"un",minimumQuantity:0,averageCost:Math.max(0,Number(String(quickCatalogPrice).replace(",","."))||0),category:"",active:true,notes:""}; setStockItems(p=>[...p,item]); setTemplateStockId(item.id); setExecutionItems(p=>[...p,{stockItemId:item.id,quantity:"1",usage:"new"}]); }
 else if(quickCatalogKind==="category"){ const sectorId=quickCatalogSectorId||householdSectors.find(x=>x.active)?.id||""; if(!sectorId){showToast("Cadastre um setor primeiro.");return;} const item:HouseholdCategory={id:makeId(),sectorId,name,active:true}; setHouseholdCategories(p=>[...p,item]); setQuickCategoryId(item.id); }
 else if(quickCatalogKind==="sale"){ const price=Math.max(0,Number(String(quickCatalogPrice).replace(",","."))||0); const item:SaleItem={id:makeId(),name,price,prices:{...emptyCurrencyPrices(),BRL:price},description:"",category:"",active:true,createdAt:nowISO()}; setSaleItems(p=>[...p,item]); setRelatedChargeSaleItemId(item.id); setSelectedSaleItemId(item.id); }
 else { const questions=Math.max(1,Math.floor(Number(quickCatalogQuestions)||1)); const duplicate=readingTypes.find(x=>x.name.trim().toLocaleLowerCase("pt-BR")===name.toLocaleLowerCase("pt-BR") && Number(x.questions)===questions); if(duplicate){ setSelectedReadingTypeId(duplicate.id); setQuickCatalogKind(null); showToast("Esse tipo de tiragem já está cadastrado."); return; } const item:ReadingType={id:makeId(),name,questions,active:true,prices:{...emptyCurrencyPrices(),BRL:Math.max(0,Number(String(quickCatalogPrice).replace(",","."))||0)}}; setReadingTypes(p=>[...p,item]); setSelectedReadingTypeId(item.id); }
 const returnContext=quickCatalogReturnContext; setQuickCatalogKind(null); setQuickCatalogReturnContext(null); if(returnContext === "relatedChargeSale") setShowRelatedChargeModal(true); showToast("Cadastro criado e disponível para seleção.");
};

const addWorkTemplateItem = () => { const work=workTypes.find(x=>x.id===templateWorkId); const stock=stockItems.find(x=>x.id===templateStockId); const qty=Math.max(0,Number(String(templateStockQty).replace(",","."))||0); if(!work||!stock||qty<=0){showToast("Selecione o trabalho, o item e uma quantidade válida.");return;} setWorkTypes(prev=>prev.map(x=>x.id===work.id?{...x,standardItems:[...(x.standardItems||[]).filter(i=>i.stockItemId!==stock.id),{stockItemId:stock.id,quantity:qty}]}:x)); setTemplateStockId(""); setTemplateStockQty("1"); showToast("Material padrão adicionado ao trabalho."); };
const removeWorkTemplateItem = (workId:string, stockId:string) => setWorkTypes(prev=>prev.map(x=>x.id===workId?{...x,standardItems:(x.standardItems||[]).filter(i=>i.stockItemId!==stockId)}:x));

const updateSaleLifecycle = (record:any, saleStatus: "approved"|"awaiting_confection"|"in_confection"|"awaiting_shipping"|"shipped"|"delivered"|"cancelled") => {
  const consultation = consultations.find((c:any)=>c.id===record.consultationId);
  if(!consultation) return;
  const now = nowISO();
  const updatedConsultation = record.chargeId
    ? {...consultation,relatedCharges:(consultation.relatedCharges||[]).map((ch:any)=>ch.id===record.chargeId?{...ch,saleStatus,updatedAt:now}:ch),updatedAt:now}
    : {...consultation,saleStatus,updatedAt:now};
  // Lifecycle da venda é uma operação operacional interna.
  // Nunca deve transformar a venda em atendimento ativo nem gravar DRAFT_KEY,
  // pois isso pode reabrir/mostrar o checkout de uma tiragem.
  updateConsultationRecordOnly(updatedConsultation);
  if (activeConsultation?.id === consultation.id && screen !== "consultation") {
    setActiveConsultation(null);
    setActiveQuestionId(null);
    localStorage.removeItem(DRAFT_KEY);
  }

  // Keep the service-detail modal on the same sale. Never route a lifecycle action to checkout.
  setSelectedServiceRecord((previous:any) => previous ? {
    ...previous,
    status: saleStatus,
    saleStatus,
    consultation: updatedConsultation,
    needsConfection: ["awaiting_confection","in_confection"].includes(saleStatus),
  } : previous);

  if(saleStatus === "awaiting_shipping") {
    const scheduledAt=record.shippingScheduledAt||consultation.shippingScheduledAt;
    if(scheduledAt) upsertLinkedAgendaItem({ entityType: "sale", entityId: record.id, scheduledAt, title: `Envio · ${record.title}`, description: `Envio para ${record.clientName}`, clientId: consultation.clientId });
  }
  if(saleStatus === "shipped" || saleStatus === "delivered" || saleStatus === "cancelled") {
    if (saleStatus === "cancelled") {
      removeLinkedAgendaItem("sale", record.chargeId || record.id);
      if (record.fromAgendaAction) closeAgendaActionOverlays();
    } else setAgendaItems(prev=>prev.map(a=>a.relatedEntityType==="sale"&&a.relatedEntityId===record.id?{...a,completed:saleStatus==="delivered",updatedAt:now}:a));
  }
  showToast(saleStatus === "awaiting_confection" ? "✓ Venda registrada. Próxima etapa: 🧵 Aguardando confecção." : saleStatus === "in_confection" ? "✓ Confecção iniciada. Próxima etapa: 🧵 Concluir confecção." : saleStatus === "awaiting_shipping" ? "✓ Confecção concluída. Próxima etapa: 📦 Aguardando envio." : saleStatus === "shipped" ? "✓ Venda enviada. Próxima etapa: 📬 Aguardando recebimento." : saleStatus === "delivered" ? "✓ Venda concluída." : saleStatus === "cancelled" ? "✓ Venda cancelada." : "✓ Status da venda atualizado.");
};

const addRelatedCharge = () => {
  if (!activeConsultation) { showToast("Inicie a tiragem antes de adicionar trabalho ou venda."); return; }
  const work = relatedChargeKind === "work" ? workTypes.find(x => x.id === relatedChargeWorkTypeId) : undefined;
  const sale = relatedChargeKind === "sale" ? saleItems.find(x => x.id === relatedChargeSaleItemId) : undefined;
  if (relatedChargeKind === "work" && !work) { showToast("Selecione o tipo de trabalho."); return; }
  if (relatedChargeKind === "sale" && !sale) { showToast("Selecione o item para venda."); return; }
  const rate = relatedChargeCurrency === "BRL" ? 1 : (currencyRates[relatedChargeCurrency] || 0);
  const original = relatedChargeCurrency === "BRL" ? Math.max(0, Number(String(relatedChargeAmount || (sale?.price || 0)).replace(",", ".")) || 0) : Math.max(0, Number(String(relatedChargeForeignAmount || "").replace(",", ".")) || 0);
  if (original <= 0 || rate <= 0) { showToast("Informe um valor válido e aguarde a cotação."); return; }
  const shippingAmount = relatedChargeKind === "sale" && relatedChargeShippingEnabled ? Math.max(0, Number(String(relatedChargeShippingUber).replace(",", ".")) || 0) : 0;
  const chargeOriginalTotal = original + shippingAmount;
  if (relatedChargeKind === "sale" && relatedChargeShippingEnabled && shippingAmount <= 0) { showToast("Informe o frete cobrado da cliente."); return; }
  const charge: RelatedCharge = { id: editingRelatedChargeId || makeId(), kind: relatedChargeKind, title: (relatedChargeTitle.trim() || work?.name || sale?.name || "Registro"), amountBRL: relatedChargeCurrency === "BRL" ? chargeOriginalTotal : chargeOriginalTotal * rate, originalAmount: chargeOriginalTotal, currency: relatedChargeCurrency, currencyRate: rate, billingMode: relatedChargeKind === "work" ? relatedChargeBillingMode : undefined, potentialAmount: relatedChargeKind === "work" ? chargeOriginalTotal : undefined, priority: Math.min(5, Math.max(1, Number(relatedChargePriority) || 3)), workTypeId: work?.id, workTypeName: work?.name, saleItemId: sale?.id, saleItemName: sale?.name, budgetId: relatedChargeBudgetId || undefined, scheduledAt: relatedChargeScheduledAt || undefined, shippingEnabled: relatedChargeKind === "sale" ? relatedChargeShippingEnabled : false, shippingScheduledAt: relatedChargeKind === "sale" ? relatedChargeShippingScheduledAt : undefined, shippingUber: relatedChargeKind === "sale" ? shippingAmount : 0, shippingUberSpent: relatedChargeKind === "sale" ? relatedChargeShippingUberSpent : false, shippingUberSpentAmount: relatedChargeKind === "sale" ? (Number(String(relatedChargeShippingUberSpentAmount || relatedChargeShippingUber).replace(",", ".")) || 0) : 0, shippingRecipientName: activeConsultation.clientName, shippingPhone: relatedChargeKind === "sale" ? relatedChargeShippingPhone.trim() : undefined, shippingAddress: relatedChargeKind === "sale" ? relatedChargeShippingAddress.trim() : undefined, saleStatus: relatedChargeKind === "sale" ? (relatedChargeNeedsConfection ? "awaiting_confection" : (relatedChargeShippingEnabled ? "awaiting_shipping" : "approved")) : undefined, photos: relatedChargePhotos, audios: relatedChargeAudios, receivedObjects: relatedChargeKind === "work" ? relatedChargeReceivedObjects : undefined, sentObjects: relatedChargeKind === "work" ? relatedChargeSentObjects : undefined, notes: relatedChargeNotes.trim() };
  const existingCharges = activeConsultation.relatedCharges || [];
  const nextCharges = editingRelatedChargeId ? existingCharges.map(item => item.id === editingRelatedChargeId ? charge : item) : [...existingCharges, charge];
  const updated = { ...activeConsultation, currency: activeConsultation.currency || relatedChargeCurrency, relatedCharges: nextCharges, updatedAt: nowISO() };
  setActiveConsultation(updated);
  setConsultations(previous => previous.map(item => item.id === updated.id ? updated : item));
  setRelatedCharges(updated.relatedCharges || []);
  if (charge.kind === "work") {
    if (charge.scheduledAt) upsertLinkedAgendaItem({ entityType: "work", entityId: charge.id, scheduledAt: charge.scheduledAt, title: `Trabalho · ${charge.title}`, description: `Trabalho de ${activeConsultation.clientName}`, clientId: activeConsultation.clientId, priority: (charge as any).priority || activeConsultation.priority || 5 });
    else removeLinkedAgendaItem("work", charge.id);
  }
  if (charge.kind === "sale") {
    const when = charge.shippingScheduledAt || charge.scheduledAt;
    if (when) upsertLinkedAgendaItem({ entityType: "sale", entityId: charge.id, scheduledAt: when, title: `Envio · ${charge.title}`, description: `Envio para ${activeConsultation.clientName}`, clientId: activeConsultation.clientId, priority: (charge as any).priority || 3 });
    else removeLinkedAgendaItem("sale", charge.id);
  }
  setShowRelatedChargeModal(false);
  setEditingRelatedChargeId(null);
  setRelatedChargePriority(3);
  setRelatedChargeTitle(""); setRelatedChargeAmount(""); setRelatedChargeForeignAmount(""); setRelatedChargeWorkTypeId(""); setRelatedChargeSaleItemId(""); setRelatedChargeBudgetId(""); setRelatedChargeScheduledAt(""); setRelatedChargeShippingEnabled(false); setRelatedChargeShippingScheduledAt(""); setRelatedChargeShippingAddress(""); setRelatedChargeShippingPhone(""); setRelatedChargeShippingUber(""); setRelatedChargeShippingUberSpent(false); setRelatedChargeShippingUberSpentAmount(""); setRelatedChargeNotes(""); setRelatedChargePhotos([]); setRelatedChargeAudios([]); setRelatedChargeReceivedObjects([]); setRelatedChargeSentObjects([]);
  showToast(editingRelatedChargeId ? "Registro atualizado." : charge.kind === "work" ? "Trabalho adicionado ao checkout." : "Venda adicionada ao checkout.");
};

const updateRelatedCharge = (chargeId: string, changes: Partial<RelatedCharge>) => {
  if (!activeConsultation) return;
  const relatedCharges = (activeConsultation.relatedCharges || []).map(item => item.id === chargeId ? { ...item, ...changes, amountBRL: changes.originalAmount !== undefined || changes.currency !== undefined ? convertToBRL(Number(changes.originalAmount ?? item.originalAmount) || 0, (changes.currency || item.currency) as CurrencyCode) : item.amountBRL } : item);
  const updated = { ...activeConsultation, relatedCharges, updatedAt: nowISO() };
  updateConsultation(updated);
  setRelatedCharges(relatedCharges);
  const charge = relatedCharges.find(item => item.id === chargeId);
  if (charge?.kind === "work") {
    if (charge.scheduledAt) upsertLinkedAgendaItem({ entityType: "work", entityId: charge.id, scheduledAt: charge.scheduledAt, title: `Trabalho · ${charge.title}`, description: `Trabalho de ${updated.clientName}`, clientId: updated.clientId, priority: (charge as any).priority || 3 });
    else removeLinkedAgendaItem("work", charge.id);
  }
  if (charge?.kind === "sale") {
    const when = charge.shippingScheduledAt || charge.scheduledAt;
    if (when) upsertLinkedAgendaItem({ entityType: "sale", entityId: charge.id, scheduledAt: when, title: `Envio · ${charge.title}`, description: `Envio para ${updated.clientName}`, clientId: updated.clientId, priority: (charge as any).priority || 3 });
    else removeLinkedAgendaItem("sale", charge.id);
  }
};

const getClientWorkOptions = (clientId: string) => {
  const related = consultations.flatMap(parent => (parent.relatedCharges || [])
    .filter(ch => ch.kind === "work" && !ch.deletedAt && parent.clientId === clientId)
    .map(ch => ({
      id: ch.id,
      consultationId: parent.id,
      title: ch.title || ch.workTypeName || "Trabalho",
      createdAt: parent.createdAt,
      scheduledAt: ch.scheduledAt,
      status: ch.status || "approved",
      amount: ch.originalAmount || 0,
      currency: (ch.currency || parent.currency || "BRL") as CurrencyCode,
    })));
  const direct = consultations
    .filter(c => c.clientId === clientId && c.serviceType === "work" && !c.deletedAt)
    .map(c => ({
      id: c.id,
      consultationId: c.id,
      title: c.workTypeName || c.title || "Trabalho",
      createdAt: c.createdAt,
      scheduledAt: c.scheduledAt,
      status: c.workStatus || "approved",
      amount: c.value || 0,
      currency: (c.currency || "BRL") as CurrencyCode,
    }));
  const seen = new Set<string>();
  return [...related, ...direct].filter(work => {
    if (seen.has(work.id)) return false;
    seen.add(work.id);
    return true;
  }).sort((a,b) => (b.createdAt || "").localeCompare(a.createdAt || ""));
};

const getWorkQuestionStats = (workId: string) => {
  const questions = consultations.flatMap(c => c.questions || []).filter(q => q.relatedWorkId === workId && (q.text?.trim() || q.completed));
  const benefit = questions.find(q => q.workQuestionKind === "benefit" || (q.relatedWorkId === workId && q.billingMode === "free" && q.workQuestionKind !== "courtesy"));
  return { total: questions.length, paid: questions.filter(q => q.workQuestionKind === "paid" || (!q.workQuestionKind && q.billingMode !== "free")).length, courtesy: questions.filter(q => q.workQuestionKind === "courtesy").length, benefitUsed: !!benefit };
};

const rebuildServiceInstallmentRows = (countValue: string, firstDateValue: string, total: number, force = false) => {
  const count = Math.max(2, Math.floor(Number(countValue) || 2)); const first = firstDateValue || localDateKey();
  setServiceInstallmentRows(previous => {
    if (!force && previous.length === count) return previous;
    return Array.from({length:count},(_,index)=>{ const d=new Date(`${first}T12:00:00`); d.setMonth(d.getMonth()+index); return {id:previous[index]?.id||makeId(),amount:previous[index]?.amount ?? (total/count).toFixed(2),dueDate:previous[index]?.dueDate||d.toISOString().slice(0,10),status:previous[index]?.status}; });
  });
};
const updateServiceInstallmentFirstDate = (value: string) => {
  setServiceInstallmentFirstDate(value);
  setServiceInstallmentRows(previous => previous.map((row,index)=>{ const d=new Date(`${value}T12:00:00`); d.setMonth(d.getMonth()+index); return {...row,dueDate:d.toISOString().slice(0,10)}; }));
};
useEffect(() => {
  if (servicePaymentMode !== "installments") return;
  const total = serviceCurrency === "BRL" ? (Number(String(serviceValue).replace(",",".")) || 0) : (Number(String(serviceForeignAmount).replace(",",".")) || 0) * (currencyRates[serviceCurrency] || 0);
  rebuildServiceInstallmentRows(serviceInstallmentCount, serviceInstallmentFirstDate || servicePaymentDate, total, false);
}, [servicePaymentMode, serviceInstallmentCount]);

const saveServiceObject = () => {
  if (!objectModalKind || !objectDraftName.trim()) { showToast("Informe qual objeto foi recebido/enviado."); return; }
  const item: WorkObject = { id: makeId(), name: objectDraftName.trim(), referenceValue: Math.max(0, Number(String(objectDraftValue).replace(",",".")) || 0) || undefined, notes: objectDraftNotes.trim() || undefined, createdAt: nowISO(), address: objectModalKind === "sent" ? (objectAddress.trim() || undefined) : undefined, postalCode: objectModalKind === "sent" ? (objectPostalCode.trim() || undefined) : undefined, country: objectModalKind === "sent" ? (objectCountry.trim() || undefined) : undefined };
  if (objectModalKind === "received") setServiceReceivedObjects(prev=>[...prev,item]); else setServiceSentObjects(prev=>[...prev,item]);
  setObjectModalKind(null); setObjectDraftName(""); setObjectDraftValue(""); setObjectDraftNotes(""); setObjectAddress(""); setObjectPostalCode(""); setObjectCountry("Brasil");
};
const removeServiceObject = (kind:"received"|"sent", id:string) => { if(kind==="received") setServiceReceivedObjects(prev=>prev.filter(x=>x.id!==id)); else setServiceSentObjects(prev=>prev.filter(x=>x.id!==id)); };
const saveWorkSetupObject = () => {
  if (!objectModalKind || !objectDraftName.trim()) { showToast("Informe qual objeto foi recebido/enviado."); return; }
  const item: WorkObject = { id: makeId(), name: objectDraftName.trim(), referenceValue: Math.max(0, Number(String(objectDraftValue).replace(",",".")) || 0) || undefined, notes: objectDraftNotes.trim() || undefined, createdAt: nowISO(), address: objectModalKind === "sent" ? (objectAddress.trim() || undefined) : undefined, postalCode: objectModalKind === "sent" ? (objectPostalCode.trim() || undefined) : undefined, country: objectModalKind === "sent" ? (objectCountry.trim() || undefined) : undefined };
  if (objectModalKind === "received") setWorkSetupReceivedObjects(prev=>[...prev,item]); else setWorkSetupSentObjects(prev=>[...prev,item]);
  setObjectModalKind(null); setObjectDraftName(""); setObjectDraftValue(""); setObjectDraftNotes(""); setObjectAddress(""); setObjectPostalCode(""); setObjectCountry("Brasil");
};
const saveRelatedChargeObject = () => {
  if (!objectModalKind || !objectDraftName.trim()) { showToast("Informe qual objeto foi recebido/enviado."); return; }
  const item: WorkObject = { id: makeId(), name: objectDraftName.trim(), referenceValue: Math.max(0, Number(String(objectDraftValue).replace(",",".")) || 0) || undefined, notes: objectDraftNotes.trim() || undefined, createdAt: nowISO(), address: objectModalKind === "sent" ? (objectAddress.trim() || undefined) : undefined, postalCode: objectModalKind === "sent" ? (objectPostalCode.trim() || undefined) : undefined, country: objectModalKind === "sent" ? (objectCountry.trim() || undefined) : undefined };
  if (objectModalKind === "received") setRelatedChargeReceivedObjects(prev=>[...prev,item]); else setRelatedChargeSentObjects(prev=>[...prev,item]);
  setObjectModalKind(null); setObjectDraftName(""); setObjectDraftValue(""); setObjectDraftNotes(""); setObjectAddress(""); setObjectPostalCode(""); setObjectCountry("Brasil");
};
const removeRelatedChargeObject = (kind:"received"|"sent", id:string) => { if(kind==="received") setRelatedChargeReceivedObjects(prev=>prev.filter(x=>x.id!==id)); else setRelatedChargeSentObjects(prev=>prev.filter(x=>x.id!==id)); };

const createConsultation = () => {
  const client = clients.find(item => item.id === selectedClientId);
  if (!client) { showToast("Selecione um consulente."); return; }
  const now = nowISO();
  const rate = serviceCurrency === "BRL" ? 1 : (currencyRates[serviceCurrency] || 0);
  const selectedWork = workTypes.find(x => x.id === selectedWorkTypeId);
  const selectedSale = saleItems.find(x => x.id === selectedSaleItemId);
  const selectedRelatedWork = newServiceType === "consultation" && relatedReadingEnabled ? getClientWorkOptions(client.id).find(w => w.id === relatedReadingWorkId) : undefined;
  const selectedRelatedWorkStats = selectedRelatedWork ? getWorkQuestionStats(selectedRelatedWork.id) : { total: 0, paid: 0, courtesy: 0, benefitUsed: false };
  if (newServiceType === "work" && !selectedWork) { showToast("Selecione o tipo de trabalho."); return; }
  if (newServiceType === "sale" && !selectedSale) { showToast("Cadastre ou selecione um item para vender."); return; }
  if (newServiceType === "consultation" && !newTitle.trim()) { showToast("Digite o título do atendimento."); return; }
  if (newServiceType === "consultation" && relatedReadingEnabled && !selectedRelatedWork) { showToast("Selecione o trabalho desta consulente para vincular a tiragem."); return; }
  if (newServiceType === "consultation" && preWorkReadingEnabled && !preWorkReadingWorkTypeId) { showToast("Selecione o trabalho da leitura pré-trabalho."); return; }
  const title = newServiceType === "work" ? (newTitle.trim() || selectedWork!.name) : newServiceType === "sale" ? (newTitle.trim() || selectedSale!.name) : newTitle.trim();
  let grossBRL = Math.max(0, Number(String(serviceValue || (newServiceType === "sale" ? selectedSale?.price || 0 : 0)).replace(",", ".")) || 0);
  if (serviceCurrency !== "BRL") {
    const foreign = Math.max(0, Number(String(serviceForeignAmount || "0").replace(",", ".")) || 0);
    if (foreign <= 0 || rate <= 0) { showToast("Informe o valor na moeda e aguarde a cotação."); return; }
    grossBRL = foreign * rate;
  }
  const shippingChargedBRL = newServiceType === "sale" && serviceShippingEnabled
    ? (serviceShippingMethod === "uber" ? Math.max(0, Number(String(serviceShippingUber).replace(",", ".")) || 0) : serviceShippingMethod === "correios" ? Math.max(0, Number(String(serviceShippingCorreios).replace(",", ".")) || 0) : 0)
    : 0;
  if (newServiceType === "sale" && serviceShippingEnabled && serviceShippingMethod !== "retirada" && shippingChargedBRL <= 0) { showToast("Informe o valor do frete cobrado da cliente."); return; }
  if ((newServiceType === "work" || newServiceType === "sale") && shippingChargedBRL > 0) grossBRL += shippingChargedBRL;
  if ((newServiceType === "work" || newServiceType === "sale") && servicePaymentMode !== "free" && grossBRL <= 0) { showToast("Informe o valor da cobrança."); return; }
  if ((newServiceType === "work" || newServiceType === "sale") && servicePaymentMode === "pending" && !servicePaymentDate) { showToast("Informe o vencimento do pagamento."); return; }
  const fee = servicePaymentMode === "paid" ? grossBRL * Math.max(0, getFeePercent(servicePaymentMethod)) / 100 : 0;
  let paymentPlan: PaymentPlan | undefined;
  if (servicePaymentMode === "paid") paymentPlan = { id: makeId(), originalTotal: grossBRL, total: grossBRL, surcharge: 0, fee, type: "full", installments: [{ id: makeId(), number: 1, amount: grossBRL, dueDate: now.slice(0,10), status: "received", paymentMethod: servicePaymentMethod, receivedAt: now }] };
  else if (servicePaymentMode === "pending") paymentPlan = { id: makeId(), originalTotal: grossBRL, total: grossBRL, surcharge: 0, fee: 0, type: "full", installments: [{ id: makeId(), number: 1, amount: grossBRL, dueDate: servicePaymentDate, status: "pending", paymentMethod: servicePaymentMethod, receivedAt: "" }] };
  else if (servicePaymentMode === "installments") {
    const count = Math.max(2, Number(serviceInstallmentCount) || 2);
    const first = serviceInstallmentFirstDate || servicePaymentDate || now.slice(0,10);
    const rows = serviceInstallmentRows.length === count ? serviceInstallmentRows : Array.from({length:count},(_,i)=>{const d=new Date(first+"T12:00:00");d.setMonth(d.getMonth()+i);return {id:makeId(),amount:(grossBRL/count).toFixed(2),dueDate:d.toISOString().slice(0,10),status:"pending" as Installment["status"]};});
    const entry = serviceInstallmentEntry ? Math.min(grossBRL, Math.max(0, Number(String(serviceEntryAmount).replace(",", ".")) || 0)) : 0;
    const installments = rows.map((row,index)=>({id:row.id||makeId(),number:index+1,amount:Math.max(0,Number(String(row.amount).replace(",","."))||0),dueDate:row.dueDate,status:(serviceInstallmentEntry&&index===0&&entry>0?"received":(row.status||"pending")) as Installment["status"],paymentMethod:servicePaymentMethod,receivedAt:serviceInstallmentEntry&&index===0&&entry>0?now:""}));
    if(serviceInstallmentEntry&&entry>0) installments[0].amount=entry;
    const totalInstallments=installments.reduce((sum,item)=>sum+item.amount,0);
    if(installments.some(item=>!item.dueDate||item.amount<=0)){showToast("Preencha o valor e o vencimento de todas as parcelas.");return;}
    if(totalInstallments + 0.01 < grossBRL){showToast(`As parcelas não podem ficar abaixo de ${formatMoney(grossBRL)}. Total configurado: ${formatMoney(totalInstallments)}.`);return;}
    paymentPlan={id:makeId(),originalTotal:grossBRL,total:totalInstallments,surcharge:Math.max(0,totalInstallments-grossBRL),fee:0,type:"installments",installments};
  }
  const isConsultation = newServiceType === "consultation";
  const record: Consultation = {
    id: makeId(), clientId: client.id, clientName: client.name, title, value: grossBRL, paid: servicePaymentMode === "paid", paymentDate: servicePaymentMode === "paid" ? now : servicePaymentDate, billingMode: servicePaymentMode, potentialValue: grossBRL, shortfall: servicePaymentMode === "free" ? grossBRL : 0, createdAt: now, updatedAt: now, status: (isConsultation || newServiceType === "work") && newScheduledDate && newScheduledTime
      ? "scheduled"
      : isConsultation
        ? "active"
        : "completed",
    workStatus: newServiceType === "work" ? (newScheduledDate && newScheduledTime ? "scheduled" : "approved") : undefined,
    questions: isConsultation ? (() => {
      const selectedReading = (Array.isArray(readingTypes) ? readingTypes : initialReadingTypes).find(item => item.id === selectedReadingTypeId);
      const questionCount = Math.max(1, selectedReading?.questions || 1);
      const packageTotal = Math.max(0, readingPrice(selectedReading, newReadingCurrency));
      const packageId = makeId();
      const baseUnit = Math.round((packageTotal / questionCount) * 100) / 100;
      return Array.from({ length: questionCount }, (_, index) => {
        const unitPrice = index === questionCount - 1 ? Math.max(0, Number((packageTotal - baseUnit * Math.max(0, questionCount - 1)).toFixed(2))) : baseUnit;
        const question = createEmptyQuestion(index + 1, newReadingCurrency, unitPrice);
        const isWorkBenefit = index === 0 && !!selectedRelatedWork && !selectedRelatedWorkStats.benefitUsed;
        const workQuestionNumber = selectedRelatedWork ? selectedRelatedWorkStats.total + index + 1 : undefined;
        return {
          ...question,
          packageId, packageTotal, packageQuestionCount: questionCount, packageRole: "included" as const,
          billingMode: isWorkBenefit ? "free" as const : "paid" as const,
          value: isWorkBenefit ? 0 : unitPrice,
          potentialValue: unitPrice,
          relatedWorkId: selectedRelatedWork?.id,
          relatedWorkTitle: selectedRelatedWork?.title,
          workQuestionKind: selectedRelatedWork ? (isWorkBenefit ? "benefit" as const : "paid" as const) : undefined,
          workQuestionNumber,
        };
      });
    })() : [],
    intakeNotes: isConsultation ? intakeNotes.trim() : serviceNotes.trim(), intakePhotos: isConsultation ? intakePhotos : undefined, intakeAudios: isConsultation ? intakeAudios : undefined,
    serviceType: newServiceType, paymentPlan, paymentMethod: servicePaymentMethod, currency: isConsultation ? newReadingCurrency : serviceCurrency, currencyRate: isConsultation ? (newReadingCurrency === "BRL" ? 1 : (currencyRates[newReadingCurrency] || 0)) : rate, priority: Math.min(5, Math.max(1, Number(newServicePriority) || 3)), scheduledAt: (isConsultation || newServiceType === "work") && newScheduledDate && newScheduledTime ? `${newScheduledDate}T${newScheduledTime}` : "",
    relatedWorkId: selectedRelatedWork?.id, preWorkReading: isConsultation ? preWorkReadingEnabled : undefined, preWorkWorkTypeId: isConsultation && preWorkReadingEnabled ? preWorkReadingWorkTypeId : undefined, preWorkWorkTitle: isConsultation && preWorkReadingEnabled ? workTypes.find(w=>w.id===preWorkReadingWorkTypeId)?.name : undefined, workTypeId: newServiceType === "work" ? selectedWork?.id : undefined, workTypeName: newServiceType === "work" ? selectedWork?.name : undefined, saleItemId: newServiceType === "sale" ? selectedSale?.id : undefined, saleItemName: newServiceType === "sale" ? selectedSale?.name : undefined,
    photos: !isConsultation ? servicePhotos : undefined, audios: !isConsultation ? serviceAudios : undefined, receivedObjects: newServiceType === "work" ? serviceReceivedObjects : undefined, sentObjects: newServiceType === "work" ? serviceSentObjects : undefined, budgetId: serviceBudgetId || undefined, shippingEnabled: newServiceType === "sale" ? serviceShippingEnabled : false, shippingMethod: newServiceType === "sale" ? serviceShippingMethod : undefined, shippingScheduledAt: newServiceType === "sale" ? serviceShippingScheduledAt : undefined, shippingUber: newServiceType === "sale" ? (Number(String(serviceShippingUber).replace(",", ".")) || 0) : 0, shippingUberSpent: newServiceType === "sale" ? serviceShippingUberSpent : false, shippingUberSpentAmount: newServiceType === "sale" ? (Number(String(serviceShippingUberSpentAmount || serviceShippingUber).replace(",", ".")) || 0) : 0, shippingCorreios: newServiceType === "sale" ? (Number(String(serviceShippingCorreios).replace(",", ".")) || 0) : 0, shippingRecipientName: newServiceType === "sale" ? (serviceShippingRecipientName.trim() || client.name) : undefined, shippingPhone: newServiceType === "sale" ? serviceShippingPhone.trim() : undefined, shippingAddress: newServiceType === "sale" ? serviceShippingAddress.trim() : undefined, shippingZipCode: newServiceType === "sale" ? serviceShippingZipCode.trim() : undefined, shippingCity: newServiceType === "sale" ? serviceShippingCity.trim() : undefined, shippingState: newServiceType === "sale" ? serviceShippingState.trim() : undefined, saleStatus: newServiceType === "sale" ? (serviceNeedsConfection ? "awaiting_confection" : (serviceShippingEnabled ? "awaiting_shipping" : "approved")) : undefined, relatedCharges: [],
  };
  setConsultations(previous => [record, ...previous]);
  if (newServiceType === "consultation" && record.scheduledAt) upsertLinkedAgendaItem({ entityType: "consultation", entityId: record.id, scheduledAt: record.scheduledAt, title: `Atendimento · ${record.title}`, description: `Atendimento de ${record.clientName}`, clientId: record.clientId, priority: record.priority });
  if (newServiceType === "work" && record.scheduledAt) upsertLinkedAgendaItem({ entityType: "work", entityId: record.id, scheduledAt: record.scheduledAt, title: `Trabalho · ${record.title}`, description: `Trabalho de ${record.clientName}`, clientId: record.clientId, priority: record.priority });
  if (newServiceType === "sale" && record.shippingScheduledAt) upsertLinkedAgendaItem({ entityType: "sale", entityId: record.id, scheduledAt: record.shippingScheduledAt, title: `Envio · ${record.title}`, description: `Envio para ${record.clientName}`, clientId: record.clientId, priority: record.priority });
  if (servicePaymentMode === "free" && grossBRL > 0 && !isConsultation) setDesfalques(previous => [{ id: makeId(), clientId: client.id, clientName: client.name, consultationId: record.id, workId: newServiceType === "work" ? record.id : undefined, type: newServiceType === "work" ? "free_work" : "gift", description: `${title} grátis`, potentialValue: grossBRL, receivedValue: 0, amount: grossBRL, date: now, createdAt: now }, ...previous]);
  setShowNewConsultation(false); setShowIntakeModal(false); setShowScheduleModal(false);
  if (isConsultation && record.status === "active") { setActiveConsultation(record); setActiveQuestionId(record.questions[0]?.id || null); } else { setActiveConsultation(null); setActiveQuestionId(null); }
  const recordHasSchedule = !!(record.scheduledAt || record.shippingScheduledAt);
  if (recordHasSchedule) { setAgendaDate((record.scheduledAt || record.shippingScheduledAt || "").slice(0,10)); setAgendaFilterDate(""); }
  setHistoryClient(client); setScreen(recordHasSchedule ? "agenda" : (isConsultation && record.status === "active" ? "consultation" : "history"));
  setNewTitle(""); setNewValue(""); setNewPaid(true); setNewPaymentDate(""); setNewServiceType("consultation"); setSelectedWorkTypeId(""); setSelectedSaleItemId(""); setServiceValue(""); setServicePaymentMode("pending"); setServicePaymentMethod("pix"); setServiceCurrency("BRL"); setServiceForeignAmount(""); setServicePaymentDate(""); setServicePhotos([]); setServiceAudios([]); setServiceNotes(""); setServiceBudgetId(""); setServiceReceivedObjects([]); setServiceSentObjects([]); setServiceInstallmentCount("2"); setServiceInstallmentFirstDate(""); setServiceInstallmentEntry(false); setServiceEntryAmount("0"); setServiceInstallmentRows([]); setRelatedCharges([]); setRelatedReadingEnabled(false); setRelatedReadingWorkId(""); setPreWorkReadingEnabled(false); setPreWorkReadingWorkTypeId(""); setServiceShippingEnabled(false); setServiceShippingMethod("uber"); setServiceShippingScheduledAt(""); setServiceShippingRecipientName(""); setServiceShippingPhone(""); setServiceShippingAddress(""); setServiceShippingZipCode(""); setServiceShippingCity(""); setServiceShippingState(""); setServiceShippingUber(""); setServiceShippingUberSpent(false); setServiceShippingUberSpentAmount(""); setServiceShippingCorreios(""); setIntakeNotes(""); setIntakePhotos([]); setIntakeAudios([]); setIntakeEditingExisting(false); setNewScheduledDate(""); setNewScheduledTime(""); setNewServicePriority(3);
  setSelectedReadingTypeId((Array.isArray(readingTypes) ? readingTypes : initialReadingTypes).find(item => item.active)?.id || "simple"); setNewReadingCurrency("BRL");
  showToast(isConsultation ? "Nova consulta iniciada." : newServiceType === "work" ? "Trabalho cadastrado no histórico do consulente." : "Venda registrada no histórico do consulente.");
};
const deleteReadingType = (id:string) => { const item=readingTypes.find(x=>x.id===id); if(!item)return; if(!window.confirm(`Excluir o tipo de tiragem "${item.name}"? Os atendimentos antigos serão preservados.`))return; setReadingTypes(prev=>prev.filter(x=>x.id!==id)); if(selectedReadingTypeId===id)setSelectedReadingTypeId(""); showToast("Tipo de tiragem excluído."); };
const deleteWorkType = (id:string) => { const item=workTypes.find(x=>x.id===id); if(!item)return; if(!window.confirm(`Excluir o tipo de trabalho "${item.name}"? Os trabalhos antigos serão preservados.`))return; setWorkTypes(prev=>prev.filter(x=>x.id!==id)); if(selectedWorkTypeId===id)setSelectedWorkTypeId(""); showToast("Tipo de trabalho excluído."); };
const deleteSaleItem = (id:string) => { const item=saleItems.find(x=>x.id===id); if(!item)return; if(!window.confirm(`Excluir o item "${item.name}"? As vendas antigas serão preservadas.`))return; setSaleItems(prev=>prev.filter(x=>x.id!==id)); if(selectedSaleItemId===id)setSelectedSaleItemId(""); showToast("Item de venda excluído."); };
const deleteHouseholdCategory = (id:string) => { const item=householdCategories.find(x=>x.id===id); if(!item)return; if(!window.confirm(`Excluir a categoria "${item.name}"?`))return; setHouseholdCategories(prev=>prev.filter(x=>x.id!==id)); showToast("Categoria excluída."); };
const deleteHouseholdSector = (id:string) => { const item=householdSectors.find(x=>x.id===id); if(!item)return; if(!window.confirm(`Excluir o setor "${item.name}"? As categorias existentes serão preservadas.`))return; setHouseholdSectors(prev=>prev.filter(x=>x.id!==id)); showToast("Setor excluído."); };

const clientAddressText = (client?: Client | null) => {
  if (!client?.address) return "";
  const a=client.address;
  return [a.street && `${a.street}${a.number ? `, ${a.number}` : ""}`, a.complement, a.neighborhood, a.city && `${a.city}${a.state ? `/${a.state}` : ""}`].filter(Boolean).join(" · ");
};
const clientPostalCodeText = (client?: Client | null) => client?.address?.postalCode || "";
const prefillServiceShippingFromClient = (clientId:string) => {
  const client=clients.find(x=>x.id===clientId); if(!client) return;
  setServiceShippingRecipientName(client.name);
  setServiceShippingPhone(client.phone || "");
  setServiceShippingAddress(clientAddressText(client));
  setServiceShippingZipCode(clientPostalCodeText(client));
  setServiceShippingCity(client.address?.city || "");
  setServiceShippingState(client.address?.state || "");
};
const editClient = (client: Client) => {
  setEditingClientId(client.id);
  setNewClientName(client.name);
  setNewClientPhone(client.phone || "");
  setNewClientBirthDate(client.birthDate || "");
  setNewClientCPF(client.cpf || "");
  setNewClientStreet(client.address?.street || "");
  setNewClientNumber(client.address?.number || "");
  setNewClientComplement(client.address?.complement || "");
  setNewClientNeighborhood(client.address?.neighborhood || "");
  setNewClientCity(client.address?.city || "");
  setNewClientState(client.address?.state || "");
  setNewClientPostalCode(client.address?.postalCode || "");
  setNewClientCountry(client.country || detectCountryFromPhone(client.phone) || "");
  setNewClientNotes(client.notes || "");
  setNewClientSource(client.source || "instagram");
  setClientPhotoDraft(client.avatarPhoto || "");
  setNewClientReferrerId(client.sourceReferrerClientId || "");
  setNewClientSourceDetails(client.sourceDetails || "");
  setShowNewClient(true);
};

const deleteClient = (id: string) => {
  const client = clients.find(item => item.id === id);
  if (!client) return;
  const clientConsultations = consultations.filter(item => item.clientId === id);
  if (!window.confirm(clientConsultations.length ? `Mover ${client.name} e todo o histórico de atendimentos para a lixeira?` : `Mover o consulente ${client.name} para a lixeira?`)) return;
  sendToTrash("client_bundle", `Consulente: ${client.name}`, { client, consultations: clientConsultations });
  setClients(previous => previous.filter(item => item.id !== id));
  if (clientConsultations.length) setConsultations(previous => previous.filter(item => item.clientId !== id));
  if (selectedClientId === id) setSelectedClientId("");
  if (historyClient?.id === id) { setHistoryClient(null); setScreen("clients"); }
  showToast("Consulente enviado para a lixeira.");
};

const saveClient = () => {
if (!newClientName.trim()) {
showToast("Digite o nome do consulente.");
return;
}
if (editingClientId) {
  setClients(previous => previous.map(item => item.id === editingClientId
    ? { ...item, name: newClientName.trim(), phone: newClientPhone.trim(), birthDate: newClientBirthDate || undefined, cpf: newClientCPF.trim() || undefined, address: {street:newClientStreet.trim(),number:newClientNumber.trim(),complement:newClientComplement.trim(),neighborhood:newClientNeighborhood.trim(),city:newClientCity.trim(),state:newClientState.trim(),postalCode:newClientPostalCode.trim(),country:newClientCountry.trim() || detectCountryFromPhone(newClientPhone) || "Brasil"}, country: newClientCountry.trim() || detectCountryFromPhone(newClientPhone), notes: newClientNotes.trim(), source: newClientSource, sourceReferrerClientId: newClientSource === "indication" ? (newClientReferrerId || undefined) : undefined, sourceDetails: newClientSourceDetails.trim() || undefined, avatarPhoto: clientPhotoDraft || item.avatarPhoto, updatedAt: nowISO() }
    : item
  ));
  setEditingClientId(null);
  setNewClientName("");
  setNewClientPhone("");
  setNewClientBirthDate("");
  setNewClientCPF("");
  setNewClientStreet(""); setNewClientNumber(""); setNewClientComplement(""); setNewClientNeighborhood(""); setNewClientCity(""); setNewClientState(""); setNewClientPostalCode("");
  setNewClientCountry("");
  setNewClientNotes("");
  setNewClientSource("instagram"); setNewClientReferrerId(""); setNewClientSourceDetails("");
  setClientPhotoDraft("");
  setShowNewClient(false);
  showToast("Consulente atualizado.");
  return;
}
const client: Client = {
id: makeId(),
name: newClientName.trim(),
phone: newClientPhone.trim(),
birthDate: newClientBirthDate || undefined,
cpf: newClientCPF.trim() || undefined,
address: {street:newClientStreet.trim(),number:newClientNumber.trim(),complement:newClientComplement.trim(),neighborhood:newClientNeighborhood.trim(),city:newClientCity.trim(),state:newClientState.trim(),postalCode:newClientPostalCode.trim(),country:newClientCountry.trim() || detectCountryFromPhone(newClientPhone) || "Brasil"},
country: newClientCountry.trim() || detectCountryFromPhone(newClientPhone),
notes: newClientNotes.trim(),
source: newClientSource, sourceReferrerClientId: newClientSource === "indication" ? (newClientReferrerId || undefined) : undefined, sourceDetails: newClientSourceDetails.trim() || undefined, avatarPhoto: clientPhotoDraft || undefined,
createdAt: nowISO(),
};
setClients((previous) => [...previous, client]);
setSelectedClientId(client.id);
if (returnToAgendaClientContext === "composer") setAgendaClientId(client.id);
setNewClientName("");
setNewClientPhone("");
setNewClientBirthDate("");
setNewClientCPF("");
setNewClientStreet(""); setNewClientNumber(""); setNewClientComplement(""); setNewClientNeighborhood(""); setNewClientCity(""); setNewClientState(""); setNewClientPostalCode("");
setNewClientCountry("");
setNewClientNotes("");
setClientPhotoDraft("");
setShowNewClient(false);
if (returnToAgendaClientContext) setReturnToAgendaClientContext(null);
if (returnToNewConsultationAfterClient) { setReturnToNewConsultationAfterClient(false); setShowNewConsultation(true); }
showToast("Consulente cadastrado.");
};
const importContact = async () => {
try {
  const permission = await PermissionBridge.requestContacts();
  if (!permission?.granted) {
    showToast("O acesso aos contatos não foi autorizado. Você pode permitir Contatos nas configurações do aplicativo.");
    try { await PermissionBridge.openSettings(); } catch {}
    return;
  }

  // A versão 7.x do plugin retorna o contato no formato nativo:
  // { contactId, name: { display, given, family }, phones: [{ number }] }.
  // A opção correta é `projection`, não `fields`.
  const result = await Contacts.pickContact({
    projection: {
      name: true,
      phones: true,
    },
  } as any);

  const raw: any = (result as any)?.contact || result || {};
  const contact: any = Array.isArray(raw) ? raw[0] : raw;

  const name =
    contact?.name?.display ||
    contact?.displayName ||
    [contact?.name?.given, contact?.name?.middle, contact?.name?.family].filter(Boolean).join(" ").trim() ||
    [contact?.givenName, contact?.middleName, contact?.familyName].filter(Boolean).join(" ").trim() ||
    contact?.display ||
    "";

  const phoneEntries = [
    ...(Array.isArray(contact?.phones) ? contact.phones : []),
    ...(Array.isArray(contact?.phoneNumbers) ? contact.phoneNumbers : []),
  ];

  const phone = phoneEntries
    .map((item: any) => item?.number || item?.value || item?.phone || "")
    .find((value: string) => value.trim()) || "";

  if (!name && !phone) {
    console.error("Contato selecionado sem dados reconhecíveis:", result);
    showToast("O contato foi selecionado, mas o telefone/nome não foi retornado pelo sistema.");
    return;
  }

  setNewClientName(name || "Contato sem nome");
  setNewClientPhone(phone);
  setNewClientCountry(detectCountryFromPhone(phone));
  showToast("Contato importado. Confira os dados e toque em Salvar consulente.");
} catch (error: any) {
  const code = String(error?.code || error?.message || "");
  if (code.includes("OS-PLUG-CONT-0020") || code.includes("PERMISSION") || code.includes("permission")) {
    showToast("O acesso aos contatos foi negado. Você pode permitir Contatos nas configurações do aplicativo.");
    try { await PermissionBridge.openSettings(); } catch {}
  } else if (code.includes("OS-PLUG-CONT-0006") || code.toLowerCase().includes("cancel")) {
    showToast("Seleção de contato cancelada.");
  } else {
    console.error("Erro ao importar contato:", error);
    showToast("Não foi possível importar o contato.");
  }
}
};

const addPhoto = async (event: React.ChangeEvent<HTMLInputElement>) => {
if (!currentQuestion) return;
const files = Array.from(event.target.files || []);
if (!files.length) return;
const photos: PhotoItem[] = [];
for (const file of files) {
photos.push({ id: makeId(), name: file.name, data: await compressImageFile(file), createdAt: nowISO(), audios: [], note: "", updatedAt: nowISO() });
}
updateCurrentQuestion({ photos: [...currentQuestion.photos, ...photos] });
event.target.value = "";
showToast(`${photos.length} foto(s) adicionada(s).`);
};

const addResponsePhotosFromFiles = async (event: React.ChangeEvent<HTMLInputElement>) => {
  if (!currentQuestion) return;
  const files = Array.from(event.target.files || []);
  if (!files.length) return;
  const photos: PhotoItem[] = [];
  for (const file of files) photos.push({ id: makeId(), name: file.name, data: await compressImageFile(file), createdAt: nowISO(), audios: [], note: "", updatedAt: nowISO() });
  updateCurrentQuestion({ responsePhotos: [...(currentQuestion.responsePhotos || []), ...photos] });
  event.target.value = "";
  showToast(`${photos.length} foto(s) adicionada(s) à resposta da consulente.`);
};

const addResponseAudiosFromFiles = async (event: React.ChangeEvent<HTMLInputElement>) => {
  if (!currentQuestion) return;
  const files = Array.from(event.target.files || []);
  if (!files.length) return;
  const audios: AudioItem[] = [];
  for (const file of files) audios.push({ id: makeId(), name: file.name, data: await readFileAsDataUrl(file), duration: 0, createdAt: nowISO() });
  updateCurrentQuestion({ responseAudios: [...(currentQuestion.responseAudios || []), ...audios] });
  event.target.value = "";
  showToast(`${audios.length} áudio(s) adicionados à resposta da consulente.`);
};

const compressDataUrl = async (dataUrl: string, maxSize = 1280, quality = 0.62): Promise<string> => {
  if (!dataUrl) throw new Error("Imagem vazia.");
  const image = new Image();
  image.src = dataUrl;
  await new Promise<void>((resolve, reject) => { image.onload = () => resolve(); image.onerror = () => reject(new Error("Falha ao ler imagem.")); });
  const scale = Math.min(1, maxSize / Math.max(image.naturalWidth || image.width, image.naturalHeight || image.height));
  const width = Math.max(1, Math.round((image.naturalWidth || image.width) * scale));
  const height = Math.max(1, Math.round((image.naturalHeight || image.height) * scale));
  const canvas = document.createElement("canvas");
  canvas.width = width; canvas.height = height;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Canvas indisponível.");
  ctx.drawImage(image, 0, 0, width, height);
  return canvas.toDataURL("image/jpeg", quality);
};

const takeClientProfilePhoto = async () => {
  try {
    const result = await Camera.getPhoto({ quality: 70, width: 900, height: 900, correctOrientation: true, source: CameraSource.Camera, resultType: CameraResultType.DataUrl, allowEditing: true });
    if (!result.dataUrl) throw new Error("NO_PHOTO");
    setClientPhotoDraft(await compressDataUrl(result.dataUrl, 900, 0.72));
    showToast("Foto do consulente adicionada.");
  } catch { showToast("Não foi possível capturar a foto do consulente."); }
};
const chooseClientProfilePhoto = async (event?: React.ChangeEvent<HTMLInputElement>) => {
  try {
    if (event) { const file = event.target.files?.[0]; if (!file) return; setClientPhotoDraft(await compressImageFile(file, 900, 0.72)); event.target.value = ""; }
    showToast("Foto do consulente adicionada.");
  } catch { showToast("Não foi possível selecionar a foto do consulente."); }
};

const takeNativePhoto = async (target: "question" | "questionResponse" | "intake" | "service") => {
try {
  if (activeConsultation) {
    safeSetStorage(PHOTO_RETURN_KEY, { consultationId: activeConsultation.id, questionId: activeQuestionId, screen, target, createdAt: nowISO() });
  }
const result = await Camera.getPhoto({ quality: 55, width: 1280, correctOrientation: true, source: CameraSource.Camera, resultType: CameraResultType.DataUrl, allowEditing: false });
if (!result.dataUrl) throw new Error("A câmera não retornou a imagem.");
const compressed = await compressDataUrl(result.dataUrl, 1280, 0.60);
const photo: PhotoItem = { id: makeId(), name: `foto-${Date.now()}.jpg`, data: compressed, createdAt: nowISO(), updatedAt: nowISO(), note: "", audios: [] };
if (target === "question" && currentQuestion) updateCurrentQuestion({ photos: [...currentQuestion.photos, photo] });
if (target === "questionResponse" && currentQuestion) updateCurrentQuestion({ responsePhotos: [...(currentQuestion.responsePhotos || []), photo] });
if (target === "intake") {
  if (intakeEditingExisting && activeConsultation) {
    const nextPhotos = [...(activeConsultation.intakePhotos || []), photo];
    updateConsultation({ ...activeConsultation, intakePhotos: nextPhotos, updatedAt: nowISO() });
    setIntakePhotos(nextPhotos);
  } else setIntakePhotos(previous => [...previous, photo]);
}
if (target === "service") setServicePhotos(previous => [...previous, photo]);
try { if (Capacitor.isNativePlatform() && PermissionBridge.savePhotoToGallery) await PermissionBridge.savePhotoToGallery(base64FromDataUrl(compressed), photo.name); } catch {}
try { localStorage.removeItem(PHOTO_RETURN_KEY); } catch {}
showToast("Foto capturada e salva no aplicativo e, quando permitido, na galeria.");
} catch (error) {
  console.error("Camera V18:", error);
  showToast("Não foi possível usar a câmera. Verifique a permissão e tente novamente.");
}
};

const chooseNativePhoto = async (target: "question" | "questionResponse" | "intake" | "service") => {
try {
  if (activeConsultation) safeSetStorage(PHOTO_RETURN_KEY, { consultationId: activeConsultation.id, questionId: activeQuestionId, screen, target, createdAt: nowISO() });
const result = await Camera.getPhoto({ quality: 55, width: 1280, correctOrientation: true, source: CameraSource.Photos, resultType: CameraResultType.DataUrl, allowEditing: false });
if (!result.dataUrl) throw new Error("Imagem não selecionada.");
const compressed = await compressDataUrl(result.dataUrl, 1280, 0.60);
const photo: PhotoItem = { id: makeId(), name: `foto-${Date.now()}.jpg`, data: compressed, createdAt: nowISO(), updatedAt: nowISO(), note: "", audios: [] };
if (target === "question" && currentQuestion) updateCurrentQuestion({ photos: [...currentQuestion.photos, photo] });
if (target === "questionResponse" && currentQuestion) updateCurrentQuestion({ responsePhotos: [...(currentQuestion.responsePhotos || []), photo] });
if (target === "intake") {
  if (intakeEditingExisting && activeConsultation) {
    const nextPhotos = [...(activeConsultation.intakePhotos || []), photo];
    updateConsultation({ ...activeConsultation, intakePhotos: nextPhotos, updatedAt: nowISO() });
    setIntakePhotos(nextPhotos);
  } else setIntakePhotos(previous => [...previous, photo]);
}
if (target === "service") setServicePhotos(previous => [...previous, photo]);
try { localStorage.removeItem(PHOTO_RETURN_KEY); } catch {}
showToast("Foto adicionada.");
} catch {
showToast("Não foi possível selecionar a foto.");
}
};

const removePhoto = (photoId: string) => {
if (!currentQuestion || !activeConsultation) return;
const photo = currentQuestion.photos.find(x => x.id === photoId);
if (!photo) return;
if (!window.confirm("Mover esta foto para a lixeira? Os áudios e a observação dela serão preservados.")) return;
sendToTrash("photo", `Foto: ${photo.name}`, { consultationId: activeConsultation.id, questionId: currentQuestion.id, photo });
updateCurrentQuestion({ photos: currentQuestion.photos.filter(x => x.id !== photoId) });
if (selectedPhotoId === photoId) setSelectedPhotoId(null);
showToast("Foto enviada para a lixeira.");
};
const selectedIntakePhoto = activeConsultation?.intakePhotos?.find(photo=>photo.id===selectedIntakePhotoId) || null;
const deleteIntakePhoto = (photoId:string) => {
  if(!activeConsultation) return; const photo=activeConsultation.intakePhotos?.find(p=>p.id===photoId); if(!photo) return; if(!window.confirm("Excluir este print/foto das informações recebidas?")) return;
  updateConsultation({...activeConsultation,intakePhotos:(activeConsultation.intakePhotos||[]).filter(p=>p.id!==photoId)}); setSelectedIntakePhotoId(null); showToast("Foto removida das informações recebidas.");
};

const selectedPhoto = currentQuestion?.photos.find(photo => photo.id === selectedPhotoId) || null;
const openPhotoModal = (photo: PhotoItem) => { setSelectedPhotoId(photo.id); setPhotoNoteDraft(photo.note || ""); };
const savePhotoNote = () => {
  if (!currentQuestion || !selectedPhotoId) return;
  updateCurrentQuestion({ photos: currentQuestion.photos.map(photo => photo.id === selectedPhotoId ? { ...photo, note: photoNoteDraft.trim(), updatedAt: nowISO() } : photo) });
  showToast("Observação da foto salva.");
};

useEffect(() => {
  if (recording && !recordingPaused) {
    if (recordingIntervalRef.current) window.clearInterval(recordingIntervalRef.current);
    recordingIntervalRef.current = window.setInterval(() => setRecordingTime(time => { const next = time + 1; recordingElapsedRef.current = next; return next; }), 1000);
  } else if (recordingIntervalRef.current) {
    window.clearInterval(recordingIntervalRef.current);
    recordingIntervalRef.current = null;
  }
  return () => {
    if (recordingIntervalRef.current) {
      window.clearInterval(recordingIntervalRef.current);
      recordingIntervalRef.current = null;
    }
  };
}, [recording, recordingPaused]);

const attachRecordedAudio = (audio: AudioItem, target: RecordingTarget) => {
  if (target.kind === "client") {
    const client = clients.find(item => item.id === target.clientId);
    if (!client) {
      showToast("A consulente não está mais disponível para receber o áudio.");
      return;
    }
    setClients(previous => previous.map(item => item.id === target.clientId
      ? { ...item, audios: [...(item.audios || []), audio], updatedAt: nowISO() }
      : item
    ));
    setHistoryClient(previous => previous && previous.id === target.clientId
      ? { ...previous, audios: [...(previous.audios || []), audio], updatedAt: nowISO() }
      : previous
    );
    showToast("Áudio salvo automaticamente na ficha da consulente.");
  } else if (target.kind === "question" && currentQuestion && activeConsultation) {
    updateCurrentQuestion({ audios: [...(currentQuestion.audios || []), audio] });
    showToast("Áudio salvo automaticamente nesta pergunta e no histórico da consulente.");
  } else if (target.kind === "service") {
    setServiceAudios(previous => [...previous, audio]);
    showToast("Áudio do trabalho/venda salvo.");
  } else if (target.kind === "intake") {
    setIntakeAudios(previous => [...previous, audio]);
    showToast("Áudio recebido salvo no histórico.");
  } else if (target.kind === "questionResponse" && currentQuestion) {
    updateCurrentQuestion({ responseAudios: [...(currentQuestion.responseAudios || []), audio] });
    showToast("Áudio da resposta da consulente salvo.");
  } else if (target.kind === "photo" && currentQuestion) {
    const photos = currentQuestion.photos.map((photo) =>
      photo.id === target.photoId ? { ...photo, audios: [...(photo.audios || []), audio], updatedAt: nowISO() } : photo
    );
    updateConsultation({ ...activeConsultation!, questions: activeConsultation!.questions.map(q => q.id === currentQuestion.id ? { ...q, photos, updatedAt: nowISO() } : q), updatedAt: nowISO() });
    showToast("Áudio vinculado à foto e salvo no histórico.");
  }
};

const combineNativeRecordingSegments = async (segments: Array<{ data: string; duration: number }>) => {
  if (!segments.length) return null;
  if (segments.length === 1) return segments[0].data;
  const AudioContextClass = (window as any).AudioContext || (window as any).webkitAudioContext;
  if (!AudioContextClass) throw new Error("AUDIO_CONTEXT_UNAVAILABLE");
  const ctx = new AudioContextClass();
  try {
    const buffers: AudioBuffer[] = [];
    for (const segment of segments) {
      const response = await fetch(segment.data);
      const arrayBuffer = await response.arrayBuffer();
      buffers.push(await ctx.decodeAudioData(arrayBuffer));
    }
    const sampleRate = buffers[0].sampleRate;
    const channels = Math.max(1, ...buffers.map(buffer => buffer.numberOfChannels));
    const totalFrames = buffers.reduce((sum, buffer) => sum + buffer.length, 0);
    const wav = new ArrayBuffer(44 + totalFrames * channels * 2);
    const view = new DataView(wav);
    const writeString = (offset: number, value: string) => { for (let i = 0; i < value.length; i++) view.setUint8(offset + i, value.charCodeAt(i)); };
    writeString(0, "RIFF");
    view.setUint32(4, 36 + totalFrames * channels * 2, true);
    writeString(8, "WAVE");
    writeString(12, "fmt ");
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true);
    view.setUint16(22, channels, true);
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, sampleRate * channels * 2, true);
    view.setUint16(32, channels * 2, true);
    view.setUint16(34, 16, true);
    writeString(36, "data");
    view.setUint32(40, totalFrames * channels * 2, true);
    let offset = 44;
    for (const buffer of buffers) {
      const channelData = Array.from({ length: channels }, (_, channel) => buffer.getChannelData(Math.min(channel, buffer.numberOfChannels - 1)));
      for (let frame = 0; frame < buffer.length; frame++) {
        for (let channel = 0; channel < channels; channel++) {
          const sample = Math.max(-1, Math.min(1, channelData[channel][frame] || 0));
          view.setInt16(offset, sample < 0 ? sample * 0x8000 : sample * 0x7fff, true);
          offset += 2;
        }
      }
    }
    const bytes = new Uint8Array(wav);
    let binary = "";
    const chunk = 0x8000;
    for (let i = 0; i < bytes.length; i += chunk) binary += String.fromCharCode(...bytes.subarray(i, Math.min(i + chunk, bytes.length)));
    return `data:audio/wav;base64,${btoa(binary)}`;
  } finally {
    try { await ctx.close(); } catch {}
  }
};

const makeRecordedAudio = (target: RecordingTarget, data: string, duration: number): AudioItem => ({
  id: makeId(),
  name: target.kind === "photo" ? `Áudio da foto ${(currentQuestion?.photos.findIndex(photo => photo.id === target.photoId) ?? -1) + 1}` : target.kind === "question" ? `Áudio da pergunta ${(currentQuestion?.audios?.length || 0) + 1}` : target.kind === "questionResponse" ? `Áudio da resposta ${(currentQuestion?.responseAudios?.length || 0) + 1}` : target.kind === "service" ? `Áudio do trabalho/venda ${(serviceAudios.length || 0) + 1}` : target.kind === "client" ? `Áudio da ficha ${(clients.find(item => item.id === target.clientId)?.audios?.length || 0) + 1}` : `Áudio recebido ${(intakeAudios.length || 0) + 1}`,
  data,
  duration: Math.max(1, Math.round(duration)),
  createdAt: nowISO(),
});

const startNativeRecordingSegment = async () => {
  await VoiceRecorder.startRecording();
  nativeRecordingRef.current = true;
  mediaRecorderRef.current = null;
};

const openAudioRecorder = (target: RecordingTarget = { kind: "intake" }) => {
  // Esta função SOMENTE abre/prepara a janela. Ela nunca inicia o microfone.
  // Estados temporários de uma tentativa anterior não podem impedir a abertura.
  // O botão externo NUNCA deve ficar bloqueado por validações do microfone
  // ou por um estado transitório do atendimento. Primeiro abrimos a janela;
  // as validações do alvo acontecem quando o usuário realmente inicia a gravação.
  if (recording) {
    showToast("Já existe uma gravação em andamento.");
    return;
  }

  cancelRecordingRef.current = false;
  nativeRecordingRef.current = false;
  nativeSegmentPauseRef.current = false;
  recordingStartRef.current = false;
  mediaRecorderRef.current = null;
  audioChunksRef.current = [];
  nativeRecordedSegmentsRef.current = [];
  setRecordingTarget(target);
  setAudioRecorderOpen(true);
  setAudioRecorderSavedNotice(false);
  setAudioRecorderStarting(false);
  setRecording(false);
  setRecordingPaused(false);
  setRecordingTime(0);
  recordingElapsedRef.current = 0;
  setPendingRecordedAudio(null);
  setPendingRecordedTarget(null);
  if (recordingPreviewUrl) {
    try { URL.revokeObjectURL(recordingPreviewUrl); } catch {}
    setRecordingPreviewUrl(null);
  }
};

const handleOpenAudioRecorderClick = (target: RecordingTarget) => {
  // A abertura e o início são uma única ação do usuário. beginRecording()
  // recebe o alvo diretamente e não depende do estado audioRecorderOpen da
  // renderização anterior, evitando a corrida de estado que fazia o primeiro
  // clique não iniciar o gravador.
  openAudioRecorder(target);
  void beginRecording(target);
};

const closeIdleAudioRecorder = () => {
  if (recording) {
    showToast("Finalize ou descarte a gravação antes de fechar.");
    return;
  }
  setAudioRecorderOpen(false);
  setAudioRecorderSavedNotice(false);
  setRecordingPaused(false);
  setRecordingTime(0);
  recordingElapsedRef.current = 0;
  cancelRecordingRef.current = true;
};

const beginRecording = async (targetOverride?: RecordingTarget) => {
  // Pode ser chamado imediatamente após openAudioRecorder(). Por isso não
  // usamos audioRecorderOpen aqui: setState é assíncrono e o valor capturado
  // nesta função pode ainda ser false. O alvo explícito é a fonte de verdade.
  if (recording || recordingStartRef.current) {
    showToast("A gravação já está em andamento.");
    return;
  }
  if (audioRecorderStarting) {
    showToast("O gravador ainda está sendo preparado.");
    return;
  }
  // Uma prévia pendente não deve bloquear um modal já aberto; ela é descartada
  // antes de uma nova gravação, porque as gravações são salvas automaticamente.
  if (pendingRecordedAudio) {
    setPendingRecordedAudio(null);
    setPendingRecordedTarget(null);
  }
  const target = targetOverride || recordingTarget;
  if ((target.kind === "question" || target.kind === "questionResponse" || target.kind === "photo") && !activeConsultation) {
    showToast("O atendimento não está disponível. Permaneça no atendimento e tente novamente.");
    return;
  }
  if (target.kind === "photo" && !currentQuestion?.photos.some(photo => photo.id === target.photoId)) {
    showToast("Essa foto não está mais disponível para receber o áudio.");
    return;
  }
  recordingStartRef.current = true;
  cancelRecordingRef.current = false;
  setAudioRecorderStarting(true);
  setRecordingTime(0);
  recordingElapsedRef.current = 0;
  setRecordingPaused(false);
  nativeRecordedSegmentsRef.current = [];

  try {
    if (Capacitor.isNativePlatform()) {
      const canRecord = await VoiceRecorder.canDeviceVoiceRecord();
      if (cancelRecordingRef.current) { recordingStartRef.current = false; return; }
      if (canRecord?.value === false) throw new Error("VOICE_RECORDING_UNAVAILABLE");

      const permission = await PermissionBridge.requestMicrophone();
      if (cancelRecordingRef.current) { recordingStartRef.current = false; return; }
      if (!permission?.granted) throw new Error("MISSING_PERMISSION");

      // Android/WebView: use compressed Opus whenever MediaRecorder is available.
      // This avoids the very large PCM/WAV files and keeps long voice recordings small.
      const canUseCompactWebRecorder = typeof navigator !== "undefined" && !!navigator.mediaDevices?.getUserMedia && typeof MediaRecorder !== "undefined";
      if (canUseCompactWebRecorder) {
        let stream: MediaStream | null = null;
        try {
          stream = await navigator.mediaDevices.getUserMedia({ audio: { channelCount: 1, echoCancellation: true, noiseSuppression: true, autoGainControl: true } });
          if (cancelRecordingRef.current) { stream.getTracks().forEach(track => track.stop()); recordingStartRef.current = false; return; }
          const mimeCandidates = ["audio/webm;codecs=opus", "audio/ogg;codecs=opus", "audio/mp4", "audio/aac"];
          const mimeType = mimeCandidates.find(type => MediaRecorder.isTypeSupported(type)) || "";
          let recorder: MediaRecorder;
          try { recorder = new MediaRecorder(stream, { ...(mimeType ? { mimeType } : {}), audioBitsPerSecond: 32000 }); }
          catch { recorder = new MediaRecorder(stream, mimeType ? { mimeType } : undefined); }
          audioChunksRef.current = [];
          recorder.ondataavailable = event => { if (event.data?.size) audioChunksRef.current.push(event.data); };
          recorder.onstop = async () => {
            try {
              if (cancelRecordingRef.current) { stream?.getTracks().forEach(track => track.stop()); return; }
              const blob = new Blob(audioChunksRef.current, { type: recorder.mimeType || mimeType || "audio/webm" });
              stream?.getTracks().forEach(track => track.stop());
              if (!blob.size) throw new Error("EMPTY_RECORDING");
              const actualMime = blob.type || recorder.mimeType || mimeType || "audio/webm";
              const extension = actualMime.includes("ogg") ? "ogg" : actualMime.includes("mp4") ? "m4a" : actualMime.includes("aac") ? "aac" : "webm";
              const data = await readFileAsDataUrl(new File([blob], `gravacao-${Date.now()}.${extension}`, { type: actualMime }));
              const duration = Math.max(1, Math.round(recordingElapsedRef.current || recordingTime || 1));
              const audio = makeRecordedAudio(target, data, duration);
              attachRecordedAudio(audio, target);
              setPendingRecordedAudio(null); setPendingRecordedTarget(null); setAudioRecorderSavedNotice(true);
              showToast("Gravação finalizada e salva automaticamente.");
            } catch (error) { console.error(error); showToast("Não foi possível preparar a prévia do áudio."); }
            finally {
              nativeRecordingRef.current = false; setRecording(false); setRecordingPaused(false); setRecordingTime(0); recordingElapsedRef.current = 0; setAudioRecorderStarting(false); mediaRecorderRef.current = null;
              if (recordingPreviewUrl) { try { URL.revokeObjectURL(recordingPreviewUrl); } catch {} setRecordingPreviewUrl(null); }
            }
          };
          recorder.onerror = () => { stream?.getTracks().forEach(track => track.stop()); mediaRecorderRef.current = null; setRecording(false); setRecordingPaused(false); setAudioRecorderStarting(false); showToast("Não foi possível gravar o áudio."); };
          recorder.start(250);
          mediaRecorderRef.current = recorder; nativeRecordingRef.current = false; setRecording(true); setAudioRecorderStarting(false); recordingStartRef.current = false;
          return;
        } catch (compactError) {
          console.warn("MediaRecorder compacto indisponível; usando VoiceRecorder:", compactError);
          stream?.getTracks().forEach(track => track.stop()); mediaRecorderRef.current = null;
        }
      }

      if (cancelRecordingRef.current) { recordingStartRef.current = false; return; }
      await startNativeRecordingSegment();
      if (cancelRecordingRef.current) { try { await VoiceRecorder.stopRecording(); } catch {} nativeRecordingRef.current = false; recordingStartRef.current = false; return; }
      setRecording(true); setAudioRecorderStarting(false); recordingStartRef.current = false; return;
    }

    if (typeof navigator === "undefined" || !navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === "undefined") {
      throw new Error("RECORDING_UNAVAILABLE");
    }

    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    if (cancelRecordingRef.current) {
      stream.getTracks().forEach(track => track.stop());
      recordingStartRef.current = false;
      return;
    }

    const mimeCandidates = ["audio/webm;codecs=opus", "audio/webm", "audio/mp4", "audio/aac"];
    const mimeType = mimeCandidates.find(type => MediaRecorder.isTypeSupported(type)) || "";
    const recorder = new MediaRecorder(stream, mimeType ? { mimeType } : undefined);
    audioChunksRef.current = [];
    recorder.ondataavailable = event => { if (event.data?.size) audioChunksRef.current.push(event.data); };
    recorder.onstop = async () => {
      try {
        if (cancelRecordingRef.current) { stream.getTracks().forEach(track => track.stop()); return; }
        const blob = new Blob(audioChunksRef.current, { type: recorder.mimeType || mimeType || "audio/webm" });
        stream.getTracks().forEach(track => track.stop());
        if (!blob.size) throw new Error("EMPTY_RECORDING");
        const extension = (blob.type || "audio/webm").includes("mp4") ? "m4a" : "webm";
        const data = await readFileAsDataUrl(new File([blob], `gravacao-${Date.now()}.${extension}`, { type: blob.type }));
        const audio = makeRecordedAudio(target, data, recordingTime);
        attachRecordedAudio(audio, target);
        setPendingRecordedAudio(null);
        setPendingRecordedTarget(null);
        setAudioRecorderSavedNotice(true);
        showToast("Gravação finalizada e salva automaticamente.");
      } catch (error) {
        console.error(error);
        showToast("Não foi possível preparar a prévia do áudio.");
      } finally {
        nativeRecordingRef.current = false;
        setRecording(false);
        setRecordingPaused(false);
        setRecordingTime(0);
        recordingElapsedRef.current = 0;
        setAudioRecorderStarting(false);
        mediaRecorderRef.current = null;
        if (recordingPreviewUrl) { try { URL.revokeObjectURL(recordingPreviewUrl); } catch {} setRecordingPreviewUrl(null); }
      }
    };
    recorder.onerror = () => {
      stream.getTracks().forEach(track => track.stop());
      mediaRecorderRef.current = null;
      setRecording(false);
      setRecordingPaused(false);
      setAudioRecorderStarting(false);
      showToast("Não foi possível gravar o áudio.");
    };
    recorder.start(200);
    mediaRecorderRef.current = recorder;
    nativeRecordingRef.current = false;
    setRecording(true);
    setAudioRecorderStarting(false);
    recordingStartRef.current = false;
  } catch (error: any) {
    const message = String(error?.message || error?.code || "");
    console.error("Erro ao iniciar gravação:", error);
    if (cancelRecordingRef.current) return;
    setAudioRecorderStarting(false);
    setRecording(false);
    setRecordingPaused(false);
    recordingStartRef.current = false;
    if (message.includes("MISSING_PERMISSION") || message.includes("NotAllowedError")) {
      showToast("Permissão do microfone ausente. Ative Microfone nas permissões do aplicativo e tente novamente.");
      try { await PermissionBridge.openSettings(); } catch {}
      return;
    }
    if (message.includes("MICROPHONE_BEING_USED") || message.includes("NotReadableError")) {
      showToast("O microfone está sendo usado por outro aplicativo.");
      return;
    }
    if (message.includes("ALREADY_RECORDING")) {
      showToast("Já existe uma gravação em andamento.");
      return;
    }
    if (message.includes("VOICE_RECORDING_UNAVAILABLE") || message.includes("RECORDING_UNAVAILABLE")) {
      showToast("Este ambiente não disponibiliza gravação de áudio.");
      return;
    }
    showToast("Não foi possível acessar o microfone. Verifique a permissão do aplicativo.");
  }
};

const pauseRecording = async () => {
  if (!recording || recordingPaused) return;
  try {
    if (mediaRecorderRef.current) {
      mediaRecorderRef.current.pause();
      const mimeType = mediaRecorderRef.current.mimeType || "audio/webm";
      if (audioChunksRef.current.length) {
        const blob = new Blob(audioChunksRef.current, { type: mimeType });
        if (recordingPreviewUrl) try { URL.revokeObjectURL(recordingPreviewUrl); } catch {}
        setRecordingPreviewUrl(URL.createObjectURL(blob));
      }
      setRecordingPaused(true);
      return;
    }
    if (!nativeRecordingRef.current) return;
    // No Android usamos pausa por segmentos de propósito. O VoiceRecorder 7.0.6
    // documenta pause/resume, mas também informa que eles podem não ser
    // suportados em determinadas versões do sistema. Encerrar o segmento atual
    // nos dá uma prévia reproduzível imediatamente e torna o Retomar determinístico:
    // ele sempre inicia um novo segmento.
    const result = await VoiceRecorder.stopRecording();
    const value = (result as any)?.value || {};
    const base64 = value.recordDataBase64 || "";
    if (!base64) throw new Error("EMPTY_RECORDING");
    const segment = { data: `data:${value.mimeType || "audio/aac"};base64,${base64}`, duration: Math.max(1, Math.round((value.msDuration || recordingTime * 1000 || 0) / 1000)) };
    nativeRecordedSegmentsRef.current.push(segment);
    nativeRecordingRef.current = false;
    nativeSegmentPauseRef.current = true;
    try {
      const preview = await combineNativeRecordingSegments(nativeRecordedSegmentsRef.current);
      if (preview) setRecordingPreviewUrl(preview);
      else setRecordingPreviewUrl(segment.data);
    } catch (combineError) {
      console.error("Não foi possível montar a prévia contínua:", combineError);
      setRecordingPreviewUrl(segment.data);
    }
    setRecordingPaused(true);
  } catch (error:any) {
    const code = String(error?.message || error?.code || "");
    console.error("Erro ao pausar gravação:", error);
    showToast(code.includes("EMPTY_RECORDING") ? "Ainda não há áudio suficiente para pausar. Grave por alguns segundos." : "Não foi possível pausar a gravação.");
  }
};

const resumeRecording = async () => {
  if (!recording || !recordingPaused) return;
  try {
    if (mediaRecorderRef.current) {
      mediaRecorderRef.current.resume();
      if (recordingPreviewUrl) { try { URL.revokeObjectURL(recordingPreviewUrl); } catch {} setRecordingPreviewUrl(null); }
      setRecordingPaused(false);
      return;
    }
    // Se a pausa nativa foi feita por stopRecording(), não existe mais uma
    // gravação pausada para VoiceRecorder.resumeRecording() retomar. Iniciar um
    // novo segmento é a continuação correta e preserva tudo que já foi gravado.
    if (nativeSegmentPauseRef.current || nativeRecordedSegmentsRef.current.length > 0 || !nativeRecordingRef.current) {
      await startNativeRecordingSegment();
      nativeSegmentPauseRef.current = false;
    } else {
      const nativeResume = (VoiceRecorder as any).resumeRecording;
      if (typeof nativeResume === "function") await nativeResume();
      else await startNativeRecordingSegment();
    }
    if (recordingPreviewUrl) { try { URL.revokeObjectURL(recordingPreviewUrl); } catch {} setRecordingPreviewUrl(null); }
    setRecordingPaused(false);
  } catch (error) {
    console.error("Erro ao retomar gravação:", error);
    showToast("Não foi possível retomar a gravação.");
  }
};

const stopRecording = async () => {
  if (!recording) return;
  try {
    if (mediaRecorderRef.current) {
      mediaRecorderRef.current.stop();
      return;
    }
    if (!nativeRecordingRef.current && nativeRecordedSegmentsRef.current.length === 0) return;
    let segments = [...nativeRecordedSegmentsRef.current];
    if (nativeRecordingRef.current) {
      const result = await VoiceRecorder.stopRecording();
      const value = (result as any)?.value || {};
      const base64 = value.recordDataBase64 || "";
      if (!base64) throw new Error("EMPTY_RECORDING");
      segments.push({ data: `data:${value.mimeType || "audio/aac"};base64,${base64}`, duration: Math.max(1, Math.round((value.msDuration || recordingTime * 1000 || 0) / 1000)) });
    }
    const data = await combineNativeRecordingSegments(segments);
    if (!data) throw new Error("EMPTY_RECORDING");
    const duration = Math.max(1, segments.reduce((sum, segment) => sum + segment.duration, 0));
    const target = recordingTarget;
    const audio = makeRecordedAudio(target, data, duration);
    attachRecordedAudio(audio, target);
    setPendingRecordedAudio(null);
    setPendingRecordedTarget(null);
    setAudioRecorderSavedNotice(true);
    setRecording(false);
    setRecordingPaused(false);
    setRecordingTime(0);
    recordingElapsedRef.current = 0;
    nativeRecordingRef.current = false;
    nativeSegmentPauseRef.current = false;
    nativeRecordedSegmentsRef.current = [];
    if (recordingPreviewUrl) { try { URL.revokeObjectURL(recordingPreviewUrl); } catch {} setRecordingPreviewUrl(null); }
    showToast("Gravação finalizada e salva automaticamente.");
  } catch (error: any) {
    console.error("Erro ao parar gravação:", error);
    const message = String(error?.message || error?.code || "");
    showToast(message.includes("EMPTY_RECORDING") ? "A gravação ficou vazia. Grave por alguns segundos e tente novamente." : "Não foi possível preparar a prévia da gravação.");
  }
};

const cancelActiveRecording = async () => {
  cancelRecordingRef.current = true;
  try {
    if (mediaRecorderRef.current) {
      const recorder = mediaRecorderRef.current;
      if (recorder.state !== "inactive") recorder.stop();
      mediaRecorderRef.current = null;
    } else if (nativeRecordingRef.current) {
      try { await VoiceRecorder.stopRecording(); } catch {}
      nativeRecordingRef.current = false;
    }
  } finally {
    nativeRecordedSegmentsRef.current = [];
    nativeSegmentPauseRef.current = false;
    recordingStartRef.current = false;
    setRecording(false);
    setRecordingPaused(false);
    setRecordingTime(0);
    recordingElapsedRef.current = 0;
    if (recordingPreviewUrl) { try { URL.revokeObjectURL(recordingPreviewUrl); } catch {} setRecordingPreviewUrl(null); }
    setPendingRecordedAudio(null);
    setPendingRecordedTarget(null);
    setAudioRecorderSavedNotice(false);
    setAudioRecorderStarting(false);
    setAudioRecorderOpen(false);
    showToast("Gravação descartada.");
  }
};

const cancelRecordedAudioPreview = () => {
  setPendingRecordedAudio(null);
  setPendingRecordedTarget(null);
  setAudioRecorderSavedNotice(false);
  setAudioRecorderStarting(false);
  setAudioRecorderOpen(false);
  showToast("Gravação descartada.");
};

useEffect(() => {
  // O gravador não depende de uma tela artificial: ele acompanha o contexto
  // real que o abriu. Durante um atendimento ativo, activeConsultation é a
  // fonte de verdade; na ficha, historyClient é a fonte de verdade.
  // Isso impede que o próprio ciclo de renderização feche o modal imediatamente.
  if (!audioRecorderOpen) return;

  if (recordingTarget.kind === "client") {
    // A ficha pode ser aberta dentro de diferentes fluxos visuais. O alvo do
    // gravador já contém o clientId; não devemos exigir screen === "history" e
    // cancelar o modal durante uma troca de renderização. Basta confirmar que
    // a consulente ainda existe.
    const validClientContext = clients.some(item => item.id === recordingTarget.clientId);
    if (!validClientContext) void cancelActiveRecording();
    return;
  }

  if (recordingTarget.kind === "service") {
    if (screen !== "services") void cancelActiveRecording();
    return;
  }

  // intake, question, questionResponse e photo pertencem ao atendimento.
  // Não fechar por uma simples mudança de estado de renderização enquanto
  // activeConsultation continuar presente.
  if (!activeConsultation) void cancelActiveRecording();
}, [screen, audioRecorderOpen, recordingTarget, historyClient?.id, activeConsultation?.id, clients]);

const saveRecordedAudioPreview = () => {
  if (!pendingRecordedAudio || !pendingRecordedTarget) return;
  attachRecordedAudio(pendingRecordedAudio, pendingRecordedTarget);
  setPendingRecordedAudio(null);
  setPendingRecordedTarget(null);
  setAudioRecorderStarting(false);
  setAudioRecorderOpen(false);
};

const trimCurrentAudio = async () => {
  if (!trimAudio) return;
  const start = Math.max(0, Number(String(trimStart).replace(",", ".")) || 0);
  const end = Math.max(start, Number(String(trimEnd).replace(",", ".")) || trimAudio.duration);
  try {
    const AudioContextClass = (window as any).AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) throw new Error("AUDIO_CONTEXT_UNAVAILABLE");
    const ctx = new AudioContextClass();
    const response = await fetch(trimAudio.data);
    const arrayBuffer = await response.arrayBuffer();
    const decoded = await ctx.decodeAudioData(arrayBuffer);
    const safeStart = Math.min(start, decoded.duration);
    const safeEnd = Math.min(Math.max(safeStart, end), decoded.duration);
    const frameStart = Math.floor(safeStart * decoded.sampleRate);
    const frameEnd = Math.floor(safeEnd * decoded.sampleRate);
    const length = Math.max(1, frameEnd - frameStart);
    const trimmed = ctx.createBuffer(decoded.numberOfChannels, length, decoded.sampleRate);
    for (let channel = 0; channel < decoded.numberOfChannels; channel++) {
      trimmed.copyToChannel(decoded.getChannelData(channel).subarray(frameStart, frameEnd), channel, 0);
    }
    const wav = audioBufferToWav(trimmed);
    const data = await new Promise<string>((resolve, reject) => { const reader = new FileReader(); reader.onload=()=>resolve(String(reader.result)); reader.onerror=reject; reader.readAsDataURL(wav); });
    if (currentQuestion) {
      const updatedAudio = { ...trimAudio, data, duration: Math.max(1, Math.round(safeEnd-safeStart)), updatedAt: nowISO() };
      updateCurrentQuestion({ audios: currentQuestion.audios.map(a => a.id === trimAudio.id ? updatedAudio : a), photos: currentQuestion.photos.map(p => ({...p, audios:(p.audios||[]).map(a=>a.id===trimAudio.id?updatedAudio:a)})) });
    }
    setTrimAudio(null);
    showToast("Áudio cortado e salvo.");
    try { await ctx.close(); } catch {}
  } catch (error) {
    console.error("Erro ao cortar áudio:", error);
    showToast("Não foi possível cortar este áudio neste aparelho.");
  }
};

const deletePhotoAudio = (photoId: string, audioId: string) => {
if (!currentQuestion || !activeConsultation) return;
const photo = currentQuestion.photos.find(x => x.id === photoId);
const audio = photo?.audios?.find(x => x.id === audioId);
if (!photo || !audio) return;
if (!window.confirm("Mover este áudio para a lixeira?")) return;
sendToTrash("photo_audio", `Áudio da foto: ${photo.name}`, { consultationId: activeConsultation.id, questionId: currentQuestion.id, photoId, audio });
updateCurrentQuestion({ photos: currentQuestion.photos.map(x => x.id === photoId ? { ...x, audios: (x.audios || []).filter(a => a.id !== audioId), updatedAt: nowISO() } : x) });
if (playingAudio === audioId) setPlayingAudio(null);
showToast("Áudio enviado para a lixeira.");
};


const playAudio = (
audio: AudioItem
) => {
const element =
audioRefs.current[audio.id];
if (!element) return;
if (playingAudio === audio.id) {
element.pause();
setPlayingAudio(null);
return;
}
(Object.values(audioRefs.current) as Array<HTMLAudioElement | null>).forEach((item) => {
if (item) item.pause();
});
element.currentTime = 0;
element.play().catch(() => {
showToast(
"Não foi possível reproduzir o áudio."
);
});
setPlayingAudio(audio.id);
};
const shareAudio = async (audio: AudioItem) => {
const mime = String(audio.data || "").match(/^data:([^;,]+)[;,]/i)?.[1] || "audio/aac";
const extension = mime.includes("webm") ? "webm" : mime.includes("ogg") ? "ogg" : mime.includes("mp4") ? "m4a" : mime.includes("wav") ? "wav" : mime.includes("mpeg") ? "mp3" : mime.includes("aac") ? "aac" : "audio";
await shareDataFile(audio.data, `${audio.name || "audio"}.${extension}`, mime, "Áudio da tiragem");
};
const sharePhoto = async (photo: PhotoItem) => {
await shareDataFile(photo.data, `tiragem-${photo.id}.jpg`, "image/jpeg", "Foto da tiragem");
};
const sharePhotoAndAudio = async (photo: PhotoItem) => {
  const audios = photo.audios || [];
  if (!audios.length) { await sharePhoto(photo); return; }
  const entries = [{ data: photo.data, name: `tiragem-${photo.id}.jpg`, mime:"image/jpeg" }, ...audios.map((a,i)=>{const mime=a.data.match(/^data:([^;,]+)[;,]/i)?.[1]||"audio/aac";const extension=mime.includes("webm")?"webm":mime.includes("ogg")?"ogg":mime.includes("mp4")?"m4a":mime.includes("wav")?"wav":mime.includes("aac")?"aac":"audio";return {data:a.data,name:`audio-${i+1}-${a.id}.${extension}`,mime};})];
  try {
    const uris: string[] = [];
    for (const entry of entries) { const path=`gestao/share-${Date.now()}-${entry.name}`; const written=await Filesystem.writeFile({path,data:base64FromDataUrl(entry.data),directory:Directory.Cache,recursive:true}); const info=await Filesystem.getUri({path,directory:Directory.Cache}); uris.push(info.uri||written.uri); }
    await Share.share({title:"Foto + áudio da tiragem",text:"Foto + áudio da tiragem",files:uris});
    return;
  } catch {}
  try {
    const files: File[] = [];
    for (const entry of entries) { const blob=await (await fetch(entry.data)).blob(); files.push(new File([blob],entry.name,{type:entry.mime})); }
    const nav=navigator as Navigator & {canShare?: (data: ShareData)=>boolean};
    if (navigator.share && (!nav.canShare || nav.canShare({files}))) { await navigator.share({title:"Foto + áudio da tiragem",text:"Foto + áudio da tiragem",files}); return; }
  } catch {}
  showToast("O aparelho não permitiu compartilhar os arquivos juntos. Tente compartilhar a foto e os áudios separadamente.");
};
const savePhotoToDevice = async (photo: PhotoItem) => {
  try {
    const base64=base64FromDataUrl(photo.data);
    if (Capacitor.isNativePlatform() && PermissionBridge.savePhotoToGallery) { const result=await PermissionBridge.savePhotoToGallery(base64, photo.name || `foto-${photo.id}.jpg`); if(result?.granted){ showToast("Foto salva na galeria."); return; } }
    const path=`gestao/${photo.name || `foto-${photo.id}.jpg`}`; await Filesystem.writeFile({path,data:base64,directory:Directory.Documents,recursive:true}); showToast("Foto salva nos arquivos do aparelho.");
  } catch { showToast("Não foi possível salvar a foto no aparelho."); }
};

const openHistory = (
client: Client
) => {
setHistoryClient(client);
setHistorySearch("");
setScreen("history");
};

const openRelatedActivity = (work: Consultation) => {
  if (work.serviceType !== "work") { showToast("Selecione um trabalho para vincular a atividade."); return; }
  setRelatedWorkId(work.id);
  setRelatedActivityType("reading");
  setRelatedTitle("Tiragem sobre o trabalho");
  setRelatedValue("");
  setRelatedPotentialValue("");
  setRelatedPaid(true);
  setRelatedPaymentMethod("pix");
  setShowRelatedActivity(true);
};

const saveRelatedActivity = () => {
  const work = consultations.find(item => item.id === relatedWorkId);
  if (!work) { showToast("Trabalho não encontrado."); return; }
  if (!relatedTitle.trim()) { showToast("Informe o nome da atividade."); return; }
  const potential = Math.max(0, Number(String(relatedPotentialValue || relatedValue).replace(",", ".")) || 0);
  const value = relatedActivityType === "free_support" ? 0 : Math.max(0, Number(String(relatedValue).replace(",", ".")) || 0);
  if (relatedActivityType !== "free_support" && value <= 0) { showToast("Informe o valor da atividade."); return; }
  if (relatedActivityType === "free_support" && potential <= 0) { showToast("Informe quanto essa atividade valeria normalmente para registrar o desfalque."); return; }
  const now = nowISO();
  const activity: Consultation = {
    id: makeId(), clientId: work.clientId, clientName: work.clientName, title: relatedTitle.trim(),
    value, paid: relatedActivityType === "free_support" ? true : relatedPaid,
    paymentDate: relatedActivityType === "free_support" ? now : (relatedPaid ? now : ""),
    createdAt: now, status: relatedActivityType === "reading" ? "active" : "completed", questions: relatedActivityType === "reading" ? [createEmptyQuestion(1)] : [],
    intakeNotes: `Vinculado ao trabalho: ${work.title}`, serviceType: relatedActivityType === "work_done" ? "work" : "consultation",
    linkedWorkId: work.id, activityType: relatedActivityType, potentialValue: potential,
    shortfall: Math.max(0, potential - value), budgetId: work.budgetId,
    paymentPlan: value > 0 ? { id: makeId(), originalTotal: value, total: value, surcharge: 0, type: "full", installments: [{ id: makeId(), number: 1, amount: value, dueDate: now.slice(0,10), status: relatedPaid ? "received" : "pending", paymentMethod: relatedPaymentMethod, receivedAt: relatedPaid ? now : "" }] } : undefined
  };
  setConsultations(previous => [activity, ...previous]);
  if (relatedActivityType === "reading") {
    setActiveConsultation(activity);
    setActiveQuestionId(activity.questions[0]?.id || null);
    setShowRelatedActivity(false);
    setHistoryClient(clients.find(c => c.id === work.clientId) || null);
    showToast("Nova tiragem vinculada iniciada. As perguntas, fotos e áudios ficarão ligados a este trabalho.");
    return;
  }
  const shortfall = Math.max(0, potential - value);
  if (shortfall > 0) {
    setDesfalques(previous => [{ id: makeId(), clientId: work.clientId, clientName: work.clientName, consultationId: activity.id, workId: work.id, type: relatedActivityType === "free_support" ? "gift" : "other", description: relatedTitle.trim(), potentialValue: potential, receivedValue: value, amount: shortfall, date: now, createdAt: now }, ...previous]);
  }
  setShowRelatedActivity(false);
  setHistoryClient(clients.find(c => c.id === work.clientId) || null);
  showToast(relatedActivityType === "free_support" ? "Suporte grátis registrado e contabilizado como desfalque." : "Atividade vinculada ao trabalho registrada.");
};

const markWorkCompleted = (work: Consultation) => {
  const now = nowISO();
  setConsultations(previous => previous.map(item => item.id === work.id ? { ...item, status: "completed", updatedAt: now, activityType: item.activityType || "work_done" } : item));
  showToast("Trabalho marcado como realizado.");
};

const registerDesfalque = () => { setDesfalquePotential("0"); setDesfalqueReceived("0"); setDesfalqueDescription("Desconto / serviço não cobrado"); setDesfalqueDate(localDateKey()); setShowDesfalqueModal(true); };
const saveDesfalque = () => { const client=historyClient; const potential=Number(String(desfalquePotential).replace(",","."))||0; const received=Number(String(desfalqueReceived).replace(",","."))||0; if(potential<=received){showToast("O valor potencial precisa ser maior que o recebido.");return;} const date=desfalqueDate||localDateKey(); setDesfalques(prev=>[{id:makeId(),clientId:client?.id,clientName:client?.name,type:"other",description:desfalqueDescription.trim()||"Desfalque",potentialValue:potential,receivedValue:received,amount:Math.max(0,potential-received),date:`${date}T12:00:00`,createdAt:nowISO()},...prev]); setShowDesfalqueModal(false); showToast(`Desfalque de ${formatMoney(Math.max(0,potential-received))} registrado.`); };

const editQuickTransactionDirect = (transaction: QuickTransaction) => {
  const amount = Number(String(window.prompt("Valor:", String(transaction.amount)) || transaction.amount).replace(",", "."));
  if (!Number.isFinite(amount) || amount < 0) { showToast("Valor inválido."); return; }
  const source = window.prompt("Descrição / origem:", transaction.source);
  if (source === null) return;
  const description = window.prompt("Detalhes:", transaction.description || "");
  if (description === null) return;
  setQuickTransactions(previous => previous.map(item => item.id === transaction.id ? { ...item, amount, source: source.trim() || item.source, description: description.trim(), updatedAt: nowISO() } : item));
  showToast("Lançamento atualizado.");
};

const editInstallmentPaymentDirect = (movement:any) => {
  const consultation = consultations.find(c => c.id === movement.consultationId);
  if (!consultation || !movement.installmentId || !movement.sourceId) { showToast("Recebimento não encontrado."); return; }
  const rows = movement.questionId
    ? consultation.questions.find(q=>q.id===movement.questionId)?.paymentPlan?.installments
    : consultation.paymentPlan?.installments;
  const inst = rows?.find(i=>i.id===movement.installmentId);
  const payment = inst?.payments?.find(p=>p.id===movement.sourceId);
  if (!inst || !payment) { showToast("Este recebimento não está mais disponível para edição."); return; }
  const maxAmount = Math.max(0, inst.amount - (installmentReceivedAmount(inst) - payment.amount));
  const raw = window.prompt(`Valor do recebimento (máximo ${formatMoney(maxAmount)}):`, String(payment.amount));
  if (raw === null) return;
  const amount = Number(String(raw).replace(",", "."));
  if (!Number.isFinite(amount) || amount <= 0 || amount > maxAmount + 0.009) { showToast("Informe um valor válido dentro do restante permitido da parcela."); return; }
  const now = nowISO();
  const updateRows = (source: Installment[]) => source.map(row => {
    if (row.id !== inst.id) return row;
    const payments = (row.payments || []).map(p => p.id === payment.id ? {...p, amount} : p);
    const received = payments.reduce((sum,p)=>sum+Number(p.amount||0),0);
    const status: Installment["status"] = received >= row.amount - 0.01 ? "received" : "pending";
    return {...row, payments, receivedAmount: received, status, lastPaymentAt: payment.date, receivedAt: status === "received" ? (row.receivedAt || payment.date) : ""};
  });
  const updated:Consultation = movement.questionId
    ? {...consultation,questions:consultation.questions.map(q=>q.id===movement.questionId&&q.paymentPlan?{...q,paymentPlan:{...q.paymentPlan,installments:updateRows(q.paymentPlan.installments)}}:q),updatedAt:now}
    : {...consultation,paymentPlan:consultation.paymentPlan?{...consultation.paymentPlan,installments:updateRows(consultation.paymentPlan.installments)}:consultation.paymentPlan,updatedAt:now};
  const targetRows = movement.questionId ? (updated.questions.find(q=>q.id===movement.questionId)?.paymentPlan?.installments||[]) : (updated.paymentPlan?.installments||[]);
  if (!movement.questionId) {
    const all = targetRows.length>0 && targetRows.every(i=>installmentReceivedAmount(i)>=i.amount-0.01);
    updated.paid = all;
    if (!all) updated.paymentDate = "";
  }
  updateConsultationRecordOnly(updated);
  const updatedInst = targetRows.find(i=>i.id===inst.id);
  const existingDesfalque = desfalques.find(d=>d.consultationId===consultation.id && !d.deletedAt && d.installmentId===inst.id && (movement.questionId ? d.questionId===movement.questionId : !d.questionId));
  if (existingDesfalque && updatedInst) {
    const received = installmentReceivedAmount(updatedInst);
    setDesfalques(prev=>prev.map(d=>d.id===existingDesfalque.id?{...d,receivedValue:received,amount:Math.max(0,inst.amount-received),updatedAt:now}:d));
  }
  const marker = movement.questionId ? `[QUESTION:${consultation.id}:${movement.questionId}:INST:${inst.id}:PAY:${payment.id}]` : `[WORK:${consultation.id}:INST:${inst.id}:PAY:${payment.id}]`;
  setQuickTransactions(prev=>prev.map(t=>`${t.source||""} ${t.description||""}`.includes(marker)?{...t,amount,grossAmount:amount,fee:Number((amount*getFeePercent(payment.paymentMethod)/100).toFixed(2)),description:`${movement.questionId?"Pergunta":"Parcela"} ${inst.number} · ${amount.toFixed(2)} recebido · ${consultation.clientName}`,updatedAt:now}:t));
  showToast("Recebimento corrigido e sincronizado com a parcela, financeiro e histórico.");
};

const deleteInstallmentPaymentDirect = (movement:any) => {
  const consultation = consultations.find(c => c.id === movement.consultationId);
  if (!consultation || !movement.installmentId || !movement.sourceId) { showToast("Recebimento não encontrado."); return; }
  const rows = movement.questionId
    ? consultation.questions.find(q=>q.id===movement.questionId)?.paymentPlan?.installments
    : consultation.paymentPlan?.installments;
  const inst = rows?.find(i=>i.id===movement.installmentId);
  const payment = inst?.payments?.find(p=>p.id===movement.sourceId);
  if (!inst || !payment) { showToast("Este recebimento não está mais disponível."); return; }
  if (!window.confirm(`Excluir o recebimento de ${formatMoney(payment.amount)}? O valor será retirado da parcela e do financeiro.`)) return;
  const now=nowISO();
  const updateRows=(source:Installment[])=>source.map(row=>{
    if(row.id!==inst.id)return row;
    const payments=(row.payments||[]).filter(p=>p.id!==payment.id);
    const received=payments.reduce((sum,p)=>sum+Number(p.amount||0),0);
    return {...row,payments,receivedAmount:received,status:received>=row.amount-0.01?"received":"pending",receivedAt:received>=row.amount-0.01?(row.receivedAt||payments[payments.length-1]?.date||""):"",lastPaymentAt:payments[payments.length-1]?.date||""};
  });
  const updated:Consultation = movement.questionId
    ? {...consultation,questions:consultation.questions.map(q=>q.id===movement.questionId&&q.paymentPlan?{...q,paymentPlan:{...q.paymentPlan,installments:updateRows(q.paymentPlan.installments)}}:q),updatedAt:now}
    : {...consultation,paymentPlan:consultation.paymentPlan?{...consultation.paymentPlan,installments:updateRows(consultation.paymentPlan.installments)}:consultation.paymentPlan,updatedAt:now};
  const targetRows = movement.questionId ? (updated.questions.find(q=>q.id===movement.questionId)?.paymentPlan?.installments||[]) : (updated.paymentPlan?.installments||[]);
  if(!movement.questionId){const all=targetRows.length>0&&targetRows.every(i=>installmentReceivedAmount(i)>=i.amount-0.01);updated.paid=all;if(!all)updated.paymentDate="";}
  updateConsultationRecordOnly(updated);
  const updatedInst = targetRows.find(i=>i.id===inst.id);
  const existingDesfalque = desfalques.find(d=>d.consultationId===consultation.id && !d.deletedAt && d.installmentId===inst.id && (movement.questionId ? d.questionId===movement.questionId : !d.questionId));
  if (existingDesfalque && updatedInst) {
    const received = installmentReceivedAmount(updatedInst);
    setDesfalques(prev=>prev.map(d=>d.id===existingDesfalque.id?{...d,receivedValue:received,amount:Math.max(0,inst.amount-received),updatedAt:now}:d));
  }
  const marker=movement.questionId?`[QUESTION:${consultation.id}:${movement.questionId}:INST:${inst.id}:PAY:${payment.id}]`:`[WORK:${consultation.id}:INST:${inst.id}:PAY:${payment.id}]`;
  setQuickTransactions(prev=>prev.filter(t=>!`${t.source||""} ${t.description||""}`.includes(marker)));
  showToast("Recebimento excluído e parcela/financeiro recalculados.");
};

const deleteConsultationFinancialReceipt = (consultation: Consultation) => {
  if (!window.confirm(`Excluir o recebimento de ${formatMoney(consultationReceivedAmount(consultation))}? O atendimento será mantido, mas ficará novamente como não pago.`)) return;
  const updated:Consultation = {
    ...consultation,
    paid: false,
    paymentDate: "",
    billingMode: "pending",
    updatedAt: nowISO(),
  };
  updateConsultationRecordOnly(updated);
  showToast("Recebimento removido. O atendimento foi mantido e voltou para não pago.");
};

const editFinancialMovement = (movement:any) => {
  if (movement.sourceType === "quick") { const t=quickTransactions.find(x=>x.id===movement.sourceId); if(t) editQuickTransactionDirect(t); return; }
  if (movement.sourceType === "installmentPayment") { editInstallmentPaymentDirect(movement); return; }
  if (movement.sourceType === "consultation") { const c=consultations.find(x=>x.id===movement.sourceId); if(c) openEditConsultation(c); return; }
  if (movement.sourceType === "purchase") { const p=purchases.find(x=>x.id===movement.sourceId); if(p) editPurchase(p); return; }
  showToast("Este lançamento não possui edição direta.");
};
const deleteFinancialMovement = (movement:any) => {
  if (movement.sourceType === "quick") { const t=quickTransactions.find(x=>x.id===movement.sourceId); if(t && window.confirm("Mover este lançamento para a lixeira?")){sendToTrash("quick_transaction",`Lançamento: ${t.source}`,t);setQuickTransactions(prev=>prev.filter(x=>x.id!==t.id));showToast("Lançamento enviado para a lixeira.");} return; }
  if (movement.sourceType === "installmentPayment") { deleteInstallmentPaymentDirect(movement); return; }
  if (movement.sourceType === "consultation") { const c=consultations.find(x=>x.id===movement.sourceId); if(c) deleteConsultationFinancialReceipt(c); return; }
  if (movement.sourceType === "purchase") { deletePurchase(movement.sourceId); return; }
  showToast("Este lançamento não pode ser excluído diretamente.");
};

const convertBudgetToSale = (budget: Budget) => {
  const client = clients.find(c=>c.id===budget.clientId);
  const amount = Math.max(0, budget.value + budget.surcharge - budget.discount) + Number(budget.shippingUber||0) + Number(budget.shippingCorreios||0);
  if(amount<=0){ showToast("O orçamento não possui valor para converter."); return; }
  const now=nowISO();
  const sale: QuickTransaction = { id:makeId(), type:"sale", area:"work", amount, source:`Venda · ${budget.serviceName||budget.title}`, description:`Convertido do orçamento ${budget.title}`, clientId:client?.id||budget.clientId, clientName:client?.name||budget.clientName, paymentMethod:"pix", currency:budget.currency||"BRL", paymentStatus:"pending", date:now, createdAt:now, stockItemId:"", quantity:0 };
  setQuickTransactions(prev=>[sale,...prev]);
  setBudgets(prev=>prev.map(b=>b.id===budget.id?{...b,status:"approved",updatedAt:now}:b));
  showToast("Orçamento convertido em venda. Ficou registrado como venda a receber.");
};

const openBudgetApproval = (budget: Budget) => {
  if(budget.status === "approved" && budget.linkedWorkId && consultations.some(c=>c.id===budget.linkedWorkId)){showToast("Este orçamento já foi aprovado e já possui um trabalho na fila.");return;}
  const now=nowISO();
  setWorkSetupTarget(budget);
  setWorkSetupValue(String(Math.max(0,budget.value+budget.surcharge-budget.discount)));
  const existingDate = budget.installmentFirstDate || budget.paymentDate || "";
  setWorkSetupScheduleEnabled(false);
  setWorkSetupPriority(3);
  setWorkSetupDate(""); setWorkSetupTime("09:00"); setWorkSetupNotes(budget.description || ""); setWorkSetupReceivedObjects([]); setWorkSetupSentObjects([]);
  setWorkSetupPaymentMode((budget.paymentMode || "pending") as "paid"|"pending"|"installments");
  setWorkSetupPaymentMethod(budget.paymentMethod || "pix");
  setWorkSetupPaymentDate(budget.paymentDate || now.slice(0,10));
  const total=Math.max(0,budget.value+budget.surcharge-budget.discount);
  if((budget.paymentMode||"pending")==="installments"){
    const count=Math.max(2,budget.installmentCount||2);
    const first=existingDate||now.slice(0,10);
    const entry=budget.installmentEntry?Math.min(total,Math.max(0,budget.installmentEntryAmount||0)):0;
    const rest=Math.max(0,total-entry);
    setWorkSetupInstallmentRows(Array.from({length:count},(_,i)=>{const d=new Date(first+"T12:00:00");d.setMonth(d.getMonth()+i);return{id:makeId(),amount:String(Number(((i===0&&entry>0)?entry:(entry>0?rest/Math.max(1,count-1):total/count)).toFixed(2))),dueDate:d.toISOString().slice(0,10)};}));
  } else setWorkSetupInstallmentRows([{id:makeId(),amount:String(total),dueDate:budget.paymentDate||now.slice(0,10)}]);
  setScreen("services");
};
const confirmBudgetApproval = () => {
  const budget=workSetupTarget; if(!budget)return;
  const client=clients.find(c=>c.id===budget.clientId); if(!client){showToast("O orçamento precisa estar vinculado a um consulente.");return;}
  const now=nowISO(); const finalValue=Math.max(0,Number(String(workSetupValue).replace(",","."))||0); if(finalValue<=0){showToast("Informe o valor do trabalho.");return;}
  const setupFee = finalValue * getFeePercent(workSetupPaymentMethod) / 100;
  let paymentPlan:PaymentPlan|undefined;
  if(workSetupPaymentMode==="paid") paymentPlan={id:makeId(),originalTotal:finalValue,total:finalValue,surcharge:0,fee:setupFee,type:"full",installments:[{id:makeId(),number:1,amount:finalValue,dueDate:workSetupPaymentDate||now.slice(0,10),status:"received",paymentMethod:workSetupPaymentMethod,receivedAt:now}]};
  else if(workSetupPaymentMode==="pending") paymentPlan={id:makeId(),originalTotal:finalValue,total:finalValue,surcharge:0,fee:setupFee,type:"full",installments:[{id:makeId(),number:1,amount:finalValue,dueDate:workSetupPaymentDate||now.slice(0,10),status:"pending",paymentMethod:workSetupPaymentMethod,receivedAt:""}]};
  else { const rows=workSetupInstallmentRows.map((r,i)=>({id:r.id||makeId(),number:i+1,amount:Math.max(0,Number(String(r.amount).replace(",","."))||0),dueDate:r.dueDate,status:"pending" as const,paymentMethod:workSetupPaymentMethod,receivedAt:""})).filter(r=>r.amount>0&&r.dueDate); if(!rows.length || Math.abs(rows.reduce((a,b)=>a+b.amount,0)-finalValue)>0.01){showToast(`As parcelas devem somar ${formatMoney(finalValue)}.`);return;} paymentPlan={id:makeId(),originalTotal:finalValue,total:finalValue,surcharge:0,fee:setupFee,type:"installments",installments:rows}; }
  const scheduledAt=workSetupScheduleEnabled&&workSetupDate&&workSetupTime?`${workSetupDate}T${workSetupTime}`:"";
  const work:Consultation={id:makeId(),clientId:client.id,clientName:client.name,title:budget.serviceName||budget.title,value:finalValue,paid:paymentPlan?.installments.every(i=>i.status==="received")||false,paymentDate:paymentPlan?.installments.find(i=>i.status==="received")?.receivedAt||"",createdAt:now,updatedAt:now,status:"active",workStatus:scheduledAt?"scheduled":"approved",questions:[],intakeNotes:workSetupNotes.trim()||budget.description,serviceType:"work",activityType:"main",budgetId:budget.id,paymentPlan,paymentMethod:workSetupPaymentMethod,currency:budget.currency||"BRL",currencyRate:budget.currency==="BRL"?1:(currencyRates[budget.currency||"BRL"]||0),scheduledAt:scheduledAt||undefined,priority: Math.min(5, Math.max(1, Number(workSetupPriority) || 3)),shippingEnabled:!!budget.shippingEnabled,shippingMethod:budget.shippingEnabled?"outro":undefined,shippingScheduledAt:undefined,shippingUber:budget.shippingUber||0,shippingRecipientName:budget.shippingRecipientName,shippingPhone:budget.shippingPhone,shippingAddress:budget.shippingAddress,shippingZipCode:budget.shippingZipCode,shippingCity:budget.shippingCity,shippingState:budget.shippingState,receivedObjects:workSetupReceivedObjects,sentObjects:workSetupSentObjects};
  setConsultations(prev=>[work,...prev]); setBudgets(prev=>prev.map(b=>b.id===budget.id?{...b,status:"approved",linkedWorkId:work.id,updatedAt:now}:b));
  if(scheduledAt){const [date,time]=scheduledAt.split("T");setAgendaItems(prev=>[{id:makeId(),title:`Trabalho · ${work.title}`,description:`${client.name} · ${workSetupNotes.trim()||budget.description||"Trabalho agendado"}`,date,time,category:"work",notify:true,completed:false,createdAt:now,relatedEntityType:"work",relatedEntityId:work.id,priority:Math.min(5, Math.max(1, Number((work as any).priority) || 3))},...prev.filter(a=>a.relatedEntityId!==work.id)]);}
  if(paymentPlan){ paymentPlan.installments.filter(i=>i.status==="received").forEach(i=>{setQuickTransactions(prev=>{const marker=`[WORK:${work.id}:INST:${i.id}]`;if(prev.some(t=>`${t.source} ${t.description}`.includes(marker)))return prev;return [{id:makeId(),type:"income",area:"work",amount:i.amount,source:`Recebimento · ${work.title} ${marker}`,description:`Parcela ${i.number} recebida · ${client.name}`,clientId:client.id,clientName:client.name,stockItemId:"",quantity:0,paymentMethod:i.paymentMethod,currency:work.currency||"BRL",paymentStatus:"received",fee:Number((i.amount*getFeePercent(i.paymentMethod)/100).toFixed(2)),grossAmount:i.amount,date:i.receivedAt||now,createdAt:now},...prev];});});}
  setWorkSetupTarget(null); setHistoryClient(client); setServiceHubTab("works"); setServiceHubStatusFilter("waiting"); showToast(scheduledAt?"Orçamento aprovado. Trabalho criado e agendado; ele já aparece nos próximos agendamentos.":"Orçamento aprovado. Trabalho criado e enviado para a fila de execução.");
};
const approveBudget=openBudgetApproval;
const convertBudgetToWork=openBudgetApproval;
const rejectBudget=(budget:Budget)=>{if(budget.status==="approved"){showToast("Um orçamento já aprovado não pode ser reprovado sem antes cancelar o trabalho vinculado.");return;}const now=nowISO();setBudgets(prev=>prev.map(b=>b.id===budget.id?{...b,status:"rejected",updatedAt:now}:b));showToast("Orçamento reprovado.");};
const editPendingInstallment = (consultationId:string, installmentId:string) => { const c=consultations.find(x=>x.id===consultationId); const inst=c?.paymentPlan?.installments.find(i=>i.id===installmentId); if(!c||!inst||inst.status==="received")return; const date=window.prompt("Nova data de vencimento (AAAA-MM-DD):",inst.dueDate); if(!date||!/^[0-9]{4}-[0-9]{2}-[0-9]{2}$/.test(date))return; const method=window.prompt("Forma de pagamento (pix, credit, debit, cash, transfer, paypal, wise, other):",inst.paymentMethod||"pix") as PaymentMethod|null; if(!method)return; updateConsultation({...c,paymentPlan:{...c.paymentPlan!,installments:c.paymentPlan!.installments.map(i=>i.id===installmentId?{...i,dueDate:date,paymentMethod:method}:i)},paymentDate:date,updatedAt:nowISO()}); showToast("Parcela atualizada e nova data registrada na agenda financeira."); };

const editBudgetDirect = (budget: Budget) => {
  const value = Number(String(window.prompt("Valor do orçamento:", String(budget.value)) || budget.value).replace(",", "."));
  const discount = Number(String(window.prompt("Desconto:", String(budget.discount)) || budget.discount).replace(",", "."));
  if (!Number.isFinite(value) || value <= 0 || !Number.isFinite(discount) || discount < 0 || discount >= value + budget.surcharge) { showToast("Valores inválidos."); return; }
  const title = window.prompt("Título:", budget.title);
  if (title === null) return;
  setBudgets(previous => previous.map(item => item.id === budget.id ? { ...item, value, discount, title: title.trim() || item.title, updatedAt: nowISO() } : item));
  showToast("Orçamento atualizado.");
};

/* =========================================================
FINANCEIRO - CÁLCULOS
========================================================= */
const purchaseItemValue = (item: PurchaseItem) => {
  const stored = Number(item.total);
  if (Number.isFinite(stored) && stored > 0) return stored;
  const quantity = Number(item.quantity) || 0;
  const unitPrice = Number(item.unitPrice) || 0;
  return quantity * unitPrice;
};
const purchaseAreaValue = (purchase: Purchase, area: FinanceArea) => {
  const supplier = suppliers.find(item => item.id === purchase.supplierId);
  const items = Array.isArray(purchase.items) ? purchase.items : [];
  return items.reduce((sum, item) => {
    const destination = item.destination || supplier?.area || "home";
    return sum + (destination === area ? purchaseItemValue(item) : 0);
  }, 0);
};
const purchasesHome = purchases.reduce((sum, purchase) => sum + purchaseAreaValue(purchase, "home"), 0);
const purchasesWork = purchases.reduce((sum, purchase) => sum + purchaseAreaValue(purchase, "work"), 0);
const recurringHome = accountTemplates.filter(item => item.active && item.area === "home").reduce((sum,item)=>sum+Number(item.amount||0),0);
const recurringWork = accountTemplates.filter(item => item.active && item.area === "work").reduce((sum,item)=>sum+Number(item.amount||0),0);
const recurringTotal = recurringHome + recurringWork;
const consultationReceivedAmount = (item: Consultation) => {
  if (item.billingMode === "free") return 0;
  if (item.paymentPlan?.installments?.length) return item.paymentPlan.installments.reduce((s,i)=>s+installmentReceivedAmount(i),0);
  return item.paid ? Math.max(0, item.value - Number(item.paymentPlan?.fee || 0)) : 0;
};
const consultationHasPrimaryPaymentPlan = (item: Consultation) => Boolean(item.paymentPlan?.installments?.length);
const questionReceivedAmount = (question: Question) => {
  if (question.billingMode === "free" || question.billingMode === "desfalque") return 0;
  if (question.paymentPlan?.installments?.length) return question.paymentPlan.installments.reduce((s,i)=>s+installmentReceivedAmount(i),0);
  return question.billingMode === "paid" ? Number(question.value||0) : 0;
};
const consultationShortfallAmount = (item: Consultation) => item.billingMode === "free" ? 0 : Number(item.shortfall || 0);
const questionShortfallAmount = (question: Question) => (question.billingMode === "desfalque" ? Number(question.potentialValue ?? question.value ?? 0) : question.billingMode === "free" ? 0 : Number(question.shortfall || 0));
const receivedTotal = consultations.filter(item=>item.status === "completed").reduce((sum,item)=>sum + consultationReceivedAmount(item) + (consultationHasPrimaryPaymentPlan(item) ? 0 : (item.questions||[]).reduce((s,q)=>s+questionReceivedAmount(q),0)),0);
const todayKey = new Date().toISOString().slice(0, 10);
const consultationReceivables = consultations.filter(consultation=>consultation.status === "completed").flatMap((consultation) => {
if (consultation.paymentPlan?.installments?.length) {
return consultation.paymentPlan.installments
.filter((installment) => installmentOpenAmount(installment) > 0.009 && installment.status !== "defaulted")
.map((installment) => ({
id: `${consultation.id}-${installment.id}`,
consultationId: consultation.id,
installmentId: installment.id,
clientId: consultation.clientId,
clientName: consultation.clientName,
title: consultation.title,
amount: installmentOpenAmount(installment),
currency: consultation.currency || "BRL",
currencyRate: consultation.currencyRate || 1,
dueDate: installment.dueDate,
overdue: installment.status === "overdue" || installment.dueDate < todayKey,
}));
}
if (!consultation.paid && consultation.billingMode !== "free" && consultation.value > 0) {
return [{
id: consultation.id,
consultationId: consultation.id,
installmentId: "",
clientId: consultation.clientId,
clientName: consultation.clientName,
title: consultation.title,
amount: consultation.value,
currency: consultation.currency || "BRL",
currencyRate: consultation.currencyRate || 1,
dueDate: consultation.paymentDate || "",
overdue: Boolean(consultation.paymentDate && consultation.paymentDate < todayKey),
}];
}
return [];
});
const questionReceivables = consultations.filter(consultation=>consultation.status === "completed").flatMap(consultation => (consultation.questions || []).flatMap(question => {
  if (question.billingMode === "free" || question.billingMode === "desfalque") return [];
  if (question.paymentPlan?.installments?.length) return question.paymentPlan.installments.filter(i=>installmentOpenAmount(i)>0.009 && i.status!=="defaulted").map(i=>({ id:`${consultation.id}-${question.id}-${i.id}`, consultationId:consultation.id, installmentId:i.id, clientId:consultation.clientId, clientName:consultation.clientName, title:`${consultation.title} · Pergunta ${question.number}`, amount:installmentOpenAmount(i), currency:consultation.currency || "BRL", currencyRate:consultation.currencyRate || 1, dueDate:i.dueDate, overdue:i.status==="overdue"||i.dueDate<todayKey }));
  if (question.billingMode === "pending" && Number(question.value||0)>0) return [{ id:`${consultation.id}-${question.id}`, consultationId:consultation.id, installmentId:"", clientId:consultation.clientId, clientName:consultation.clientName, title:`${consultation.title} · Pergunta ${question.number}`, amount:Number(question.value||0), currency:consultation.currency || "BRL", currencyRate:consultation.currencyRate || 1, dueDate:question.paymentDate||"", overdue:Boolean(question.paymentDate && question.paymentDate<todayKey) }];
  return [];
}));
consultationReceivables.push(...questionReceivables);

const pendingConsultations = consultationReceivables.map((item) => ({
id: item.id,
value: item.amount,
title: item.title,
clientName: item.clientName,
clientId: item.clientId,
dueDate: item.dueDate,
overdue: item.overdue,
}));
const receivableTotal = consultationReceivables.reduce(
(sum, item) => sum + item.amount,
0
);
const quickSaleReceivableTotal = quickTransactions.filter(item=>item.type==="sale" && item.paymentStatus==="pending").reduce((sum,item)=>sum+item.amount,0);
const totalReceivableAll = receivableTotal + quickSaleReceivableTotal;
const overdueReceivable = consultationReceivables
.filter((item) => item.overdue)
.reduce((sum, item) => sum + item.amount, 0);
const consultationDefaultedTotal = consultations.filter(consultation=>consultation.status === "completed").reduce((sum, consultation) => sum + (consultation.paymentPlan?.installments || []).filter(item => item.status === "defaulted" && !desfalques.some(d=>d.consultationId===consultation.id && d.description.includes(`Parcela ${item.number}`) && !d.deletedAt)).reduce((s, item) => s + item.amount, 0), 0);
const payablePending =
payables
.filter(
(item) =>
item.status ===
"pending"
)
.reduce(
(sum, item) =>
sum + item.amount,
0
);
const payablePaid = payables.filter(item => item.status === "paid").reduce((sum,item) => sum + Number(item.paidAmount ?? item.amount ?? 0), 0);
const stockValueHome =
stockItems
.filter(
(item) =>
item.area === "home"
)
.reduce(
(sum, item) =>
sum +
item.quantity *
item.averageCost,
0
);
const stockValueWork =
stockItems
.filter(
(item) =>
item.area === "work"
)
.reduce(
(sum, item) =>
sum +
item.quantity *
item.averageCost,
0
);
const lowStockItems =
stockItems.filter(
(item) =>
item.active &&
item.quantity <=
item.minimumQuantity
);
const historyClientConsultations =
historyClient
? consultations.filter(item => item.clientId === historyClient.id && item.status === "completed" && !item.deletedAt)
: [];
const trashedConsultationIds = new Set(trash.filter(item => item.entityType === "consultation").map(item => item.payload?.id));
const standbyConsultations = consultations.filter(item => item.status === "standby" && !trashedConsultationIds.has(item.id) && !item.deletedAt);
const completedConsultations =
consultations.filter(
(item) =>
item.status === "completed"
);
const isInstallmentMirrorTransaction = (item: {source?:string;description?:string}) => {
  const text = `${item.source || ""} ${item.description || ""}`;
  return /\[WORK:[^\]]+:INST:[^\]]+\]/.test(text) || /\[QUESTION:[^\]]+:INST:[^\]]+\]/.test(text);
};
const quickIncomeTotal = quickTransactions
.filter((item) => !isInstallmentMirrorTransaction(item) && (item.type === "income" || (item.type === "sale" && item.paymentStatus !== "pending")))
.reduce((sum, item) => sum + item.amount, 0);
const quickExpenseTotal = quickTransactions
.filter((item) => item.type === "expense")
.reduce((sum, item) => sum + item.amount, 0);
const consultationReceivedTotal = consultations.filter(consultation=>consultation.status === "completed").reduce((sum, consultation) => {
  const primary = consultationReceivedAmountValue(consultation);
  // A question may carry the same receipt already represented by the atendimento-level
  // checkout. In that case it is an internal allocation, not a second cash entry.
  const questionTotal = consultationHasPrimaryPaymentPlan(consultation)
    ? 0
    : (consultation.questions || []).reduce((s,q)=>s+questionReceivedAmount(q),0);
  return sum + primary + questionTotal;
}, 0);
const moneyReceived = consultationReceivedTotal + quickIncomeTotal;
const reserveTotal = reserves.reduce((sum,r)=>sum+Number(r.balance||0),0);
const investmentTotal = investments.reduce((sum,i)=>sum+Number(i.balance||0),0);
const loanBalanceTotal = loans.reduce((sum,l)=>sum+Number(l.balanceDue ?? Math.max(0, (l.totalRepayable ?? l.principal) - ((l.installmentSchedule||[]).filter(x=>x.status==="paid").reduce((a,x)=>a+x.principalAmount,0)))),0);
const loanPaidOut = loans.reduce((sum,l)=>sum+(l.installmentSchedule||[]).filter(x=>x.status==="paid").reduce((a,x)=>a+Number(x.paidAmount||x.amount||0),0),0);
const reserveTransfersOut = reserves.reduce((sum,r)=>sum+0,0);
const shippingUberActualExpenses = consultations.filter(item=>item.status === "completed").reduce((sum, item) => sum + (item.shippingUberSpent ? Math.max(0, Number(item.shippingUberSpentAmount || item.shippingUber || 0)) : 0), 0) + consultations.filter(item=>item.status === "completed").reduce((sum, item) => sum + (item.relatedCharges || []).reduce((inner, charge) => inner + (charge.shippingUberSpent ? Math.max(0, Number(charge.shippingUberSpentAmount || charge.shippingUber || 0)) : 0), 0), 0);
const moneyOut = purchasesHome + purchasesWork + quickExpenseTotal + payablePaid + loanPaidOut + shippingUberActualExpenses;
const operationalBalance = moneyReceived - moneyOut - reserveTransfersOut;
const totalFinancialPatrimony = operationalBalance + reserveTotal + investmentTotal;
const overduePayables = payables.filter(p=>p.status!=="paid" && p.dueDate < todayKey);
const overduePayableTotal = overduePayables.reduce((sum,p)=>sum+Number(p.amount||0),0);
const upcomingPayables = payables.filter(p=>p.status!=="paid").sort((a,b)=>a.dueDate.localeCompare(b.dueDate));
const loanInstallmentRows = loans.flatMap(l=>(l.installmentSchedule||[]).filter(i=>i.status!=="paid").map(i=>({...i,loanId:l.id,loanName:l.name})));
const overdueLoanInstallments = loanInstallmentRows.filter(i=>i.dueDate<todayKey);
const upcomingLoanInstallments = loanInstallmentRows.filter(i=>i.dueDate>=todayKey).sort((a,b)=>a.dueDate.localeCompare(b.dueDate));
const totalOverdraftLimit = overdrafts.reduce((sum, item) => sum + item.limit, 0);
const overdraftUsed = Math.max(0, -operationalBalance);
const overdraftAvailable = Math.max(0, totalOverdraftLimit - overdraftUsed);
const recentTransactions = [
...quickTransactions.filter(item => !isInstallmentMirrorTransaction(item)).map((item) => ({
id: item.id,
sourceType: "quick",
sourceId: item.id,
date: item.date,
kind: item.type === "expense" ? "expense" : item.type === "sale" && item.paymentStatus === "pending" ? "receivable" : "income",
amount: item.amount,
grossAmount: item.grossAmount ?? item.amount,
currency: item.currency || "BRL",
currencyRate: item.currencyRate || 1,
fee: item.fee || 0,
title: item.type === "sale" ? `🛍️ ${item.source}` : item.source,
subtitle: `${item.area === "home" ? "Casa" : "Trabalho"}${item.clientName ? ` ·
${item.clientName}` : ""}`,
})),
...consultations.filter((item) => item.status === "completed" && item.paid && !(item.paymentPlan?.installments?.length)).map((item) => ({
id: `consult-${item.id}`,
sourceType: "consultation",
sourceId: item.id,
date: item.createdAt,
kind: "income",
amount: consultationReceivedAmount(item),
grossAmount: item.value,
currency: item.currency || "BRL",
currencyRate: item.currencyRate || 1,
fee: Number(item.paymentPlan?.fee || 0),
title: item.title,
subtitle: `Atendimento · ${item.clientName}`,
})),
...consultations.filter(item=>item.status === "completed").flatMap((item) => (item.paymentPlan?.installments || []).flatMap(inst => {
  const payments = Array.isArray(inst.payments) ? inst.payments : [];
  if (payments.length) return payments.map((payment, index) => ({
    id: `installment-payment-${item.id}-${inst.id}-${payment.id}`,
    sourceType: "installmentPayment",
    sourceId: payment.id,
    consultationId: item.id,
    installmentId: inst.id,
    date: payment.date || inst.receivedAt || item.updatedAt || item.createdAt,
    kind: "income",
    amount: payment.amount,
    grossAmount: payment.amount,
    currency: item.currency || "BRL",
    currencyRate: 1,
    fee: 0,
    title: `💳 ${inst.number === 0 ? "Entrada" : `Parcela ${inst.number}`} · ${item.clientName}${payments.length > 1 ? ` · recebimento ${index + 1}` : ""}`,
    subtitle: item.title,
  }));
  // Compatibilidade com parcelas antigas que não possuem payments[].
  if (inst.status === "received") return [{
    id: `installment-legacy-${item.id}-${inst.id}`,
    date: inst.receivedAt || item.updatedAt || item.createdAt,
    kind: "income",
    amount: installmentReceivedAmount(inst),
    grossAmount: installmentReceivedAmount(inst),
    currency: item.currency || "BRL",
    currencyRate: 1,
    fee: 0,
    title: `💳 ${inst.number === 0 ? "Entrada" : `Parcela ${inst.number}`} · ${item.clientName}`,
    subtitle: item.title,
  }];
  return [];
})),
...consultations.filter(item=>item.status === "completed").flatMap((item) => (item.questions || []).flatMap(question => (question.paymentPlan?.installments || []).flatMap(inst => {
  const payments = Array.isArray(inst.payments) ? inst.payments : [];
  return payments.map((payment, index) => ({
    id: `question-installment-payment-${item.id}-${question.id}-${inst.id}-${payment.id}`,
    sourceType: "installmentPayment",
    sourceId: payment.id,
    consultationId: item.id,
    installmentId: inst.id,
    questionId: question.id,
    date: payment.date || inst.receivedAt || item.updatedAt || item.createdAt,
    kind: "income",
    amount: payment.amount,
    grossAmount: payment.amount,
    currency: question.currency || item.currency || "BRL",
    currencyRate: 1,
    fee: 0,
    title: `💳 Pergunta ${question.number} · Parcela ${inst.number} · ${item.clientName}${payments.length > 1 ? ` · recebimento ${index + 1}` : ""}`,
    subtitle: item.title,
  }));
}))),
...purchases.slice(0, 20).map((item) => ({
id: `purchase-${item.id}`,
sourceType: "purchase",
sourceId: item.id,
date: item.createdAt,
kind: "expense",
amount: item.total,
title: item.supplierName,
subtitle: "Compra",
})),
...consultationReceivables.map((item) => ({
id: `receivable-${item.id}`,
date: item.dueDate || nowISO(),
kind: "receivable",
amount: item.amount,
title: `A receber · ${item.clientName}`,
subtitle: `${item.title}${item.overdue ? " · vencido" : ""}`,
})),
].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).slice(0, 12);
const monthlyIncome =
consultations
.filter((item) => {
const date =
new Date(
item.createdAt
);
const current =
new Date();
return (
date.getMonth() === current.getMonth() &&
date.getFullYear() === current.getFullYear()
);
})
.reduce(
(sum, item) =>
sum + consultationReceivedAmount(item) + (item.questions || []).reduce((s,q)=>s+questionReceivedAmount(q),0),
0
);
/* =========================================================
FINANCEIRO - FORNECEDOR
========================================================= */
const addBankAccountByPrompt = () => {
const bank = window.prompt("Nome do banco / conta:");
if (!bank?.trim()) return;
const areaAnswer = window.prompt(
"Destino da conta: digite CASA ou TRABALHO",
"TRABALHO"
);
const area: FinanceArea =
areaAnswer?.trim().toLowerCase() === "casa" ? "home" : "work";
const balance = Number(
String(window.prompt("Saldo atual:", "0") || "0").replace(",", ".")
) || 0;
const overdraftLimit = Number(
String(window.prompt("Limite do cheque especial:", "0") || "0").replace(",", ".")
) || 0;
const overdraftInterestRate = Number(
String(window.prompt("Juros do cheque especial (% ao mês):", "0") || "0").replace(",", ".")
) || 0;
setBankAccounts((previous) => [
...previous,
{
id: makeId(),
bank: bank.trim(),
area,
balance,
overdraftLimit,
overdraftInterestRate,
active: true,
},
]);
showToast("Conta bancária cadastrada.");
};
const updateBankBalance = (id: string, balance: number) => {
setBankAccounts((previous) =>
previous.map((account) =>
account.id === id ? { ...account, balance } : account
)
);
};
const saveSupplier = () => {
if (!supplierName.trim()) {
showToast(
"Digite o nome do estabelecimento."
);
return;
}
const supplier: Supplier = {
id: makeId(),
name: supplierName.trim(),
type: supplierType,
phone: supplierPhone.trim(),
document:
supplierDocument.trim(),
notes: supplierNotes.trim(),
area: supplierArea,
sectorId: supplierArea === "home" ? supplierSectorId : "",
categoryIds: supplierArea === "home" ? supplierCategoryIds : [],
active: true,
};
setSuppliers((previous) => [
...previous,
supplier,
]);
setPurchaseSupplierId(supplier.id);
setQuickSupplierId(supplier.id);
setQuickSource(supplier.name);
setQuickArea(supplier.area);
setQuickSectorId(supplier.sectorId || "");
setQuickCategoryId(supplier.categoryIds?.[0] || "");
setSupplierName("");
setSupplierPhone("");
setSupplierDocument("");
setSupplierNotes("");
setSupplierType("market");
setSupplierArea("home");
setSupplierSectorId("");
setSupplierCategoryIds([]);
setShowSupplierModal(false);
showToast(
"Estabelecimento cadastrado."
);
};
/* =========================================================
FINANCEIRO - COMPRA
========================================================= */
const editPurchase = (purchase: Purchase) => {
  setEditingPurchaseId(purchase.id);
  setPurchaseSupplierId(purchase.supplierId);
  setPurchaseDate(purchase.date);
  setPurchaseSource(purchase.source);
  setPurchaseQrCode(purchase.qrCode || "");
  setPurchaseAccessKey(purchase.accessKey || "");
  setPurchaseNotes(purchase.notes || "");
  setPurchaseItems((purchase.items || []).map(item => ({ ...item })));
  setShowPurchaseModal(true);
};

const deletePurchase = (id: string) => {
  const purchase = purchases.find(item => item.id === id);
  if (!purchase) return;
  const movements = stockMovements.filter(item => item.referenceType === "purchase" && item.referenceId === id);
  if (!window.confirm(`Mover a compra de ${purchase.supplierName} para a lixeira?`)) return;
  sendToTrash("purchase_bundle", `Compra: ${purchase.supplierName} · ${formatMoney(purchase.total)}`, { purchase, movements });
  setPurchases(previous => previous.filter(item => item.id !== id));
  setStockMovements(previous => previous.filter(item => item.referenceType !== "purchase" || item.referenceId !== id));
  showToast("Compra enviada para a lixeira.");
};

const addPurchaseItem = () => {
const firstSector =
householdSectors.find(
(sector) => sector.active
);
const firstCategory =
householdCategories.find(
(category) =>
category.active
);
const item: PurchaseItem = {
id: makeId(),
name: "",
quantity: 1,
unit: "un",
unitPrice: 0,
total: 0,
destination: "home",
sectorId:
firstSector?.id || "",
categoryId:
firstCategory?.id || "",
stockItem: false,
notes: "",
};
setPurchaseItems(
(previous) => [
...previous,
item,
]
);
};
const updatePurchaseItem = (
id: string,
changes: Partial<PurchaseItem>
) => {
setPurchaseItems(
(previous) =>
previous.map((item) => {
if (item.id !== id) {
return item;
}
const updated = {
...item,
...changes,
};
if (
changes.quantity !==
undefined ||
changes.unitPrice !==
undefined
) {
updated.total =
Number(
updated.quantity
) *
Number(
updated.unitPrice
);
}
return updated;
})
);
};
const removePurchaseItem = (
id: string
) => {
setPurchaseItems(
(previous) =>
previous.filter(
(item) =>
item.id !== id
)
);
};
const purchaseTotal =
purchaseItems.reduce(
(sum, item) =>
sum + purchaseItemValue(item),
0
);
const savePurchase = () => {
if (!purchaseSupplierId) {
showToast(
"Selecione o estabelecimento."
);
return;
}
if (!purchaseItems.length) {
showToast(
"Adicione pelo menos um item."
);
return;
}
const supplier =
suppliers.find(
(item) =>
item.id ===
purchaseSupplierId
);
const purchase: Purchase = {
id: editingPurchaseId || makeId(),
supplierId:
purchaseSupplierId,
supplierName:
supplier?.name ||
"Estabelecimento",
date: purchaseDate,
total: purchaseTotal,
source: purchaseSource,
qrCode: purchaseQrCode,
accessKey: purchaseAccessKey || extractNfeAccessKey(purchaseQrCode),
items: purchaseItems,
notes: purchaseNotes,
createdAt: editingPurchaseId ? (purchases.find(item => item.id === editingPurchaseId)?.createdAt || nowISO()) : nowISO(),
};
if (editingPurchaseId) {
  setPurchases(previous => previous.map(item => item.id === editingPurchaseId ? purchase : item));
  setEditingPurchaseId(null);
  setPurchaseItems([]);
  setPurchaseQrCode("");
  setPurchaseAccessKey("");
  setPurchaseNotes("");
  setPurchaseSource("manual");
  setPurchaseSupplierId("");
  setShowPurchaseModal(false);
  showToast(`Compra de ${formatMoney(purchaseTotal)} atualizada.`);
  return;
}
setPurchases((previous) => [purchase, ...previous]);
/* -----------------------------------------------
INTEGRAÇÃO COM ESTOQUE
------------------------------------------------ */
purchaseItems
.filter(
(item) =>
item.stockItem &&
item.name.trim()
)
.forEach((purchaseItem) => {
const existing =
stockItems.find(
(stock) =>
stock.name
.toLowerCase()
.trim() ===
purchaseItem.name
.toLowerCase()
.trim() &&
stock.area ===
purchaseItem.destination
);
if (existing) {
const oldValue =
existing.quantity *
existing.averageCost;
const newValue =
purchaseItem.quantity *
purchaseItem.unitPrice;
const newQuantity =
existing.quantity +
purchaseItem.quantity;
const averageCost =
newQuantity > 0
? (oldValue +
newValue) /
newQuantity
: purchaseItem.unitPrice;
setStockItems(
(previous) =>
previous.map(
(stock) =>
stock.id ===
existing.id
? {
...stock,
quantity:
newQuantity,
averageCost,
}
: stock
)
);
setStockMovements(
(previous) => [
...previous,
{
id: makeId(),
stockItemId:
existing.id,
type: "entry",
quantity:
purchaseItem.quantity,
unitCost:
purchaseItem.unitPrice,
date:
purchaseDate,
referenceType:
"purchase",
referenceId:
purchase.id,
notes:
`Entrada da compra ${supplier?.name || ""}`,
},
]
);
} else {
const newStock: StockItem = {
id: makeId(),
name:
purchaseItem.name.trim(),
area:
purchaseItem.destination,
quantity:
purchaseItem.quantity,
unit:
purchaseItem.unit,
minimumQuantity: 1,
averageCost:
purchaseItem.unitPrice,
category:
purchaseItem.categoryId,
active: true,
notes: "",
};
setStockItems(
(previous) => [
...previous,
newStock,
]
);
setStockMovements(
(previous) => [
...previous,
{
id: makeId(),
stockItemId:
newStock.id,
type: "entry",
quantity:
purchaseItem.quantity,
unitCost:
purchaseItem.unitPrice,
date:
purchaseDate,
referenceType:
"purchase",
referenceId:
purchase.id,
notes:
`Entrada da compra ${supplier?.name || ""}`,
},
]
);
}
});
setPurchaseItems([]);
setPurchaseQrCode("");
setPurchaseNotes("");
setPurchaseSource("manual");
setPurchaseSupplierId("");
setShowPurchaseModal(false);
showToast(
`Compra de ${formatMoney(
purchaseTotal
)} registrada.`
);
};
/* =========================================================
ESTOQUE
========================================================= */
const saveStockItem = () => {
  if (!stockName.trim()) { showToast("Digite o nome do item."); return; }
  const quantity = Math.max(0, Number(stockQuantity) || 0);
  const minimum = Math.max(0, Number(stockMinimum) || 0);
  const cost = Math.max(0, Number(String(stockCost).replace(",", ".")) || 0);
  if (editingStockItemId) {
    setStockItems(previous => previous.map(item => item.id === editingStockItemId ? {...item,name:stockName.trim(),area:stockArea,quantity,unit:stockUnit,minimumQuantity:minimum,averageCost:cost,category:stockCategory.trim(),updatedAt:nowISO()} : item));
    setEditingStockItemId(null); setShowStockModal(false); showToast("Item de estoque atualizado."); return;
  }
  const item: StockItem = {id: makeId(),name: stockName.trim(),area: stockArea,quantity,unit: stockUnit,minimumQuantity: minimum,averageCost: cost,category: stockCategory.trim(),active:true,notes:""};
  setStockItems(previous => [...previous,item]);
  if (quantity > 0) setStockMovements(previous => [...previous,{id:makeId(),stockItemId:item.id,type:"entry",quantity,unitCost:cost,date:nowISO(),referenceType:"manual",notes:"Cadastro inicial de estoque"}]);
  setStockName(""); setStockQuantity(""); setStockMinimum(""); setStockCost(""); setStockCategory(""); setStockUnit("un"); setShowStockModal(false);
  showToast("Item de estoque cadastrado.");
};
const editStockItem = (item: StockItem) => { setEditingStockItemId(item.id); setStockName(item.name); setStockArea(item.area); setStockQuantity(String(item.quantity)); setStockUnit(item.unit); setStockMinimum(String(item.minimumQuantity)); setStockCost(String(item.averageCost)); setStockCategory(item.category || ""); setShowStockModal(true); };
const deleteStockItem = (id:string) => { const item=stockItems.find(x=>x.id===id); if(!item)return; if(!window.confirm(`Excluir o item ${item.name} e suas movimentações?`))return; setStockItems(prev=>prev.filter(x=>x.id!==id)); setStockMovements(prev=>prev.filter(x=>x.stockItemId!==id)); showToast("Item de estoque excluído."); };
const [consumeStockId, setConsumeStockId] = useState<string | null>(null);
const [consumeStockQuantity, setConsumeStockQuantity] = useState("1");
const confirmConsumeStock = () => {
  const item=stockItems.find(x=>x.id===consumeStockId); if(!item)return;
  const amount=Number(String(consumeStockQuantity).replace(",","."))||0;
  if(amount<=0){showToast("Quantidade inválida.");return;}
  if(amount>item.quantity){showToast("Não há quantidade suficiente em estoque.");return;}
  setStockItems(prev=>prev.map(stock=>stock.id===item.id?{...stock,quantity:stock.quantity-amount,updatedAt:nowISO()}:stock));
  setStockMovements(prev=>[...prev,{id:makeId(),stockItemId:item.id,type:"consumption",quantity:amount,unitCost:item.averageCost,date:nowISO(),referenceType:"manual",notes:"Consumo manual"}]);
  setConsumeStockId(null); setShowLoanForm(false); setConsumeStockQuantity("1"); showToast(`${amount} ${item.unit} de ${item.name} consumido.`);
};
const consumeStock = (item: StockItem) => { setConsumeStockId(item.id); setConsumeStockQuantity("1"); };
const transferStock = () => {
const item =
stockItems.find(
(stock) =>
stock.id ===
transferStockId
);
if (!item) {
showToast(
"Selecione o item."
);
return;
}
const quantity =
Number(
transferQuantity.replace(
",",
"."
)
) || 0;
if (quantity <= 0) {
showToast(
"Digite uma quantidade válida."
);
return;
}
if (
quantity > item.quantity
) {
showToast(
"Quantidade maior que o estoque disponível."
);
return;
}
if (
item.area ===
transferDestination
) {
showToast(
"Origem e destino não podem ser iguais."
);
return;
}
const destinationExisting =
stockItems.find(
(stock) =>
stock.name
.toLowerCase() ===
item.name
.toLowerCase() &&
stock.area ===
transferDestination
);
setStockItems(
(previous) => {
let result =
previous.map(
(stock) =>
stock.id ===
item.id
? {
...stock,
quantity:
stock.quantity -
quantity,
}
: stock
);
if (
destinationExisting
) {
result =
result.map(
(stock) =>
stock.id ===
destinationExisting.id
? {
...stock,
quantity:
stock.quantity +
quantity,
}
: stock
);
} else {
result.push({
...item,
id: makeId(),
area:
transferDestination,
quantity,
});
}
return result;
}
);
setStockMovements(
(previous) => [
...previous,
{
id: makeId(),
stockItemId:
item.id,
type:
"transfer_out",
quantity,
unitCost:
item.averageCost,
date: nowISO(),
areaFrom:
item.area,
areaTo:
transferDestination,
referenceType:
"transfer",
notes:
`Transferência para ${
transferDestination ===
"home"
? "Casa"
: "Trabalho"
}`,
},
]
);
setTransferStockId("");
setTransferQuantity("");
setShowTransferModal(false);
showToast(
"Transferência realizada."
);
};
/* =========================================================
CONTAS A PAGAR
========================================================= */
const savePayable = () => {
if (!payableDescription.trim()) {
showToast(
"Digite a descrição da conta."
);
return;
}
const amount =
Number(
payableAmount.replace(
",",
"."
)
) || 0;
if (amount <= 0) {
showToast(
"Digite um valor válido."
);
return;
}
if (!payableDueDate) {
showToast(
"Informe o vencimento."
);
return;
}
const recurrenceCount=payableRecurrenceType==="fixed"?Math.max(1,Math.floor(Number(payableRecurrenceCount)||1)):1;
const recurrenceGroupId=makeId();
const accounts:PayableAccount[]=Array.from({length:recurrenceCount},(_,i)=>{const d=new Date(`${payableDueDate}T12:00:00`);if(payableRecurrenceType!=="none")d.setMonth(d.getMonth()+i);return {id:makeId(),description:payableDescription.trim(),area:payableArea,supplierId:payableSupplierId,amount,originalAmount:amount,dueDate:d.toISOString().slice(0,10),status:"pending",paymentMethod:payableMethod,notes:"",recurrenceType:payableRecurrenceType,recurrenceCount:payableRecurrenceType==="fixed"?recurrenceCount:undefined,recurrenceNumber:payableRecurrenceType!=="none"?i+1:undefined,recurrenceGroupId,recurrenceKey:payableRecurrenceType==="recurring"&&i===0?`${recurrenceGroupId}-${payableDueDate.slice(0,7)}`:undefined};});
if(payableRecurrenceType==="recurring") {
  const template:AccountTemplate={id:recurrenceGroupId,name:payableDescription.trim(),description:"Criada pelo cadastro de conta recorrente",area:payableArea,dueDay:Number(payableDueDate.slice(8,10))||1,amount,supplierId:payableSupplierId,active:true,recurrenceType:"fixed",createdAt:nowISO(),updatedAt:nowISO()};
  setAccountTemplates(prev=>[...prev,template]);
}
setPayables(previous=>[...accounts,...previous]);
setPayableDescription("");
setPayableAmount("");
setPayableDueDate("");
setPayableSupplierId("");
setPayableMethod("pix"); setPayableRecurrenceType("none"); setPayableRecurrenceCount("1");
setShowPayableModal(false);
showToast(
"Conta cadastrada."
);
};
const informPayableAmount = (id:string) => { const item=payables.find(x=>x.id===id); if(!item)return; const value=Math.max(0,Number(String(window.prompt("Informe o valor da conta:",String(item.amount||0))||"0").replace(",","."))||0); if(value<=0){showToast("Informe um valor válido.");return;} setPayables(prev=>prev.map(x=>x.id===id?{...x,amount:value,originalAmount:value,updatedAt:nowISO()}:x)); showToast("Valor da conta informado."); };
const openPayableAction = (kind:"pay"|"postpone", id:string) => {
 const item=payables.find(x=>x.id===id); if(!item) return;
 setPayableActionDate(item.dueDate||"");
 setPayableActionInterest(String(item.interestAmount||0));
 setPayableActionFine(String(item.fineAmount||0));
 setPayableActionAmount(String(item.paidAmount ?? (Number(item.originalAmount ?? item.amount ?? 0))));
 setShowPayableActionModal({kind,id});
};
const markPayablePaid = (id: string) => openPayableAction("pay", id);
const postponePayable = (id:string) => openPayableAction("postpone", id);
const confirmPayableAction = () => {
 const action=showPayableActionModal; if(!action) return;
 const item=payables.find(x=>x.id===action.id); if(!item) return;
 if(action.kind==="postpone") {
   if(!/^\d{4}-\d{2}-\d{2}$/.test(payableActionDate)) { showToast("Escolha uma data de vencimento válida."); return; }
   setPayables(prev=>prev.map(x=>x.id===action.id?{...x,dueDate:payableActionDate,status:"pending",postponedFrom:x.dueDate,updatedAt:nowISO()}:x));
   setShowPayableActionModal(null); showToast("Conta adiada e vencimento atualizado."); return;
 }
 const base=Number(item.originalAmount ?? item.amount ?? 0);
 const interest=Math.max(0,Number(String(payableActionInterest).replace(",","."))||0);
 const fine=Math.max(0,Number(String(payableActionFine).replace(",","."))||0);
 const paidAmount=Math.max(0,Number(String(payableActionAmount).replace(",","."))||0);
 if(paidAmount<=0){showToast("Informe o valor efetivamente pago.");return;}
 const now=nowISO();
 setPayables(prev=>prev.map(x=>x.id===action.id?{...x,status:"paid",originalAmount:base,interestAmount:interest,fineAmount:fine,paidAmount,paidAt:now,updatedAt:now}:x));
 const marker=`[PAYABLE:${action.id}]`;
 setQuickTransactions(prev=>prev.some(t=>`${t.source} ${t.description}`.includes(marker))?prev:[{id:makeId(),type:"expense",area:item.area,amount:paidAmount,source:`Pagamento · ${item.description} ${marker}`,description:`Conta paga · ${item.description}`,clientId:"",clientName:"",stockItemId:"",quantity:0,paymentMethod:item.paymentMethod,currency:"BRL",paymentStatus:"received",date:now,createdAt:now},...prev]);
 setShowPayableActionModal(null); showToast(`${item.description} marcada como paga e lançada no caixa: ${formatMoney(paidAmount)}.`);
};
const createLoan = () => { setLoanFormName("Empréstimo"); setLoanFormArea("home"); setLoanFormPrincipal(""); setLoanFormRate("0"); setLoanFormCount("12"); setLoanFormFirstDate(new Date(Date.now()+30*86400000).toISOString().slice(0,10)); setLoanFormNotes(""); setShowLoanForm(true); setShowLoanManager(true); };
const saveLoan = () => { const name=loanFormName.trim(); const principal=Math.max(0,Number(String(loanFormPrincipal).replace(",","."))||0); const rate=Math.max(0,Number(String(loanFormRate).replace(",","."))||0); const count=Math.max(1,Math.floor(Number(loanFormCount)||1)); const first=loanFormFirstDate; if(!name||principal<=0||!first){showToast("Preencha nome, valor e primeiro vencimento.");return;} const totalInterest=principal*(rate/100)*count; const total=principal+totalInterest; const installment=total/count; const schedule:LoanInstallment[]=Array.from({length:count},(_,i)=>{const d=new Date(first+"T12:00:00");d.setMonth(d.getMonth()+i);return {id:makeId(),number:i+1,dueDate:d.toISOString().slice(0,10),amount:Number(installment.toFixed(2)),principalAmount:Number((principal/count).toFixed(2)),interestAmount:Number((totalInterest/count).toFixed(2)),status:"pending"};}); const loan:Loan={id:makeId(),name,area:loanFormArea,principal,interestRate:rate,installments:count,paidInstallments:0,nextDueDate:first,notes:loanFormNotes.trim(),totalRepayable:total,balanceDue:principal,installmentAmount:installment,installmentSchedule:schedule,createdAt:nowISO()}; setLoans(prev=>[loan,...prev]); setSelectedLoanId(loan.id); setShowLoanForm(false); setQuickTransactions(prev=>[{id:makeId(),type:"income",area:loanFormArea,amount:principal,source:`Empréstimo · ${name}`,description:"Entrada de empréstimo — não é lucro",clientId:"",clientName:"",stockItemId:"",quantity:0,paymentMethod:"transfer",currency:"BRL",paymentStatus:"received",date:nowISO(),createdAt:nowISO()},...prev]); showToast(`Empréstimo de ${formatMoney(principal)} registrado. As parcelas foram criadas.`); };
const payLoanInstallment = (loanId:string, installmentId:string) => {
 const loan=loans.find(l=>l.id===loanId); const inst=loan?.installmentSchedule?.find(i=>i.id===installmentId); if(!loan||!inst||inst.status==="paid")return;
 const extraInterest=Math.max(0,Number(String(window.prompt("Juros por atraso (R$):","0")||"0").replace(",","."))||0); const fine=Math.max(0,Number(String(window.prompt("Multa (R$):","0")||"0").replace(",","."))||0); const paidAmount=inst.amount+extraInterest+fine; const now=nowISO();
 setLoans(prev=>prev.map(l=>{if(l.id!==loanId)return l; const schedule=(l.installmentSchedule||[]).map(i=>i.id===installmentId?{...i,status:"paid",paidAt:now,paidAmount,lateInterest:extraInterest,lateFine:fine}:i); const paid=schedule.filter(i=>i.status==="paid").length; const balance=Math.max(0,Number(l.principal)-schedule.filter(i=>i.status==="paid").reduce((a,i)=>a+i.principalAmount,0)); const next=schedule.find(i=>i.status!=="paid"); return {...l,installmentSchedule:schedule,paidInstallments:paid,balanceDue:balance,nextDueDate:next?.dueDate||"",updatedAt:now};}));
 showToast(`Parcela ${inst.number} paga: ${formatMoney(paidAmount)}.`);
};
const createReserve = () => { const name=window.prompt("Nome da caixinha:","Reserva"); if(!name?.trim())return; const amount=Math.max(0,Number(String(window.prompt("Valor inicial:","0")||"0").replace(",","."))||0); if(amount>operationalBalance){showToast("O valor inicial é maior que o dinheiro disponível.");return;} const cdi=Math.max(0,Number(String(window.prompt("Rendimento da caixinha (% do CDI):","115")||"115").replace(",","."))||0); const reserve:Reserve={id:makeId(),name:name.trim(),balance:amount,area:"home",cdiPercent:cdi,createdAt:nowISO()}; setReserves(prev=>[reserve,...prev]); setSelectedReserveId(reserve.id); setShowReserveManager(true); if(amount>0) setQuickTransactions(prev=>[{id:makeId(),type:"expense",area:"home",amount,source:`Guardar · ${name.trim()}`,description:"Transferência para caixinha — não é despesa real",clientId:"",clientName:"",stockItemId:"",quantity:0,paymentMethod:"transfer",currency:"BRL",paymentStatus:"received",date:nowISO(),createdAt:nowISO()},...prev]); showToast("Caixinha criada."); };
const openReserveManager = () => { if(reserves.length===0){ createReserve(); return; } setSelectedReserveId(reserves[0].id); setShowReserveManager(true); };
const openLoanManager = () => { if(loans.length===0){ createLoan(); return; } setSelectedLoanId(loans[0].id); setShowLoanManager(true); };
const addRoutineItem = () => { if(!routineTitle.trim()) return; const item={id:makeId(),title:routineTitle.trim(),category:routineCategory,done:false,date:localDateKey()}; setRoutineItems(prev=>[item,...prev]); setRoutineTitle(""); showToast("Tarefa adicionada à Organização."); };
const addRoutineTemplate = () => {
  if (!routineFormTitle.trim()) { showToast("Informe o nome da rotina."); return; }
  const days = routineFormDays.length ? routineFormDays : [1,2,3,4,5];
  const item: RoutineTemplate = {
    id: makeId(), title:routineFormTitle.trim(), area:routineConfigArea, category:routineConfigArea === "home" ? "Casa" : "Trabalho", responsibleId:routineFormResponsible, participantIds:routineFormParticipants, days, time:routineFormTime, priority:routineFormPriority, kind:routineFormKind, durationMinutes:0, checklist:routineFormChecklist.map((title)=>({id:makeId(),title})), notify:routineFormNotify, notifyBeforeMinutes:Math.max(0,Number(routineFormNotifyBefore)||0), active:true, createdAt:nowISO()
  };
  setRoutineTemplates(prev=>[item,...prev]);
  setRoutineFormTitle(""); setRoutineFormChecklist([]); setRoutineChecklistDraft("");
  showToast("Rotina recorrente criada.");
};
const routineOccurrenceKey = (routineId:string,date:string) => `${routineId}__${date}`;
const getRoutineLog = (routineId:string,date:string) => routineLogs.find(l=>l.routineId===routineId && l.date===date);
const getRoutineOccurrences = (date:string) => {
  const d=new Date(`${date}T12:00:00`); const weekday=d.getDay();
  return routineTemplates.filter(r=>r.active && r.days.includes(weekday)).sort((a,b)=>a.time.localeCompare(b.time)).map(r=>({routine:r,log:getRoutineLog(r.id,date)}));
};
const updateRoutineLog = (routine:RoutineTemplate, action:"start"|"complete"|"skip") => {
  const date=localDateKey(); const now=nowISO();
  setRoutineLogs(prev=>{
    const existing=prev.find(x=>x.routineId===routine.id && x.date===date);
    const nextStatus=action==="start"?"started":action==="complete"?"completed":"skipped";
    const next:RoutineLog={id:existing?.id||makeId(),routineId:routine.id,date,status:nextStatus,startedAt:action==="start"?(existing?.startedAt||now):existing?.startedAt,completedAt:action==="complete"?now:existing?.completedAt,checklistDoneIds:existing?.checklistDoneIds||[],updatedAt:now};
    return existing?prev.map(x=>x.id===existing.id?next: x):[next,...prev];
  });
  showToast(action==="start"?`${routine.title} iniciada.`:action==="complete"?`${routine.title} concluída.`:`${routine.title} marcada como não realizada.`);
};
const toggleRoutineChecklist = (routineId:string, date:string, itemId:string) => {
  const now=nowISO(); setRoutineLogs(prev=>{ const existing=prev.find(x=>x.routineId===routineId&&x.date===date); const done=existing?.checklistDoneIds||[]; const nextDone=done.includes(itemId)?done.filter(x=>x!==itemId):[...done,itemId]; const next:RoutineLog={id:existing?.id||makeId(),routineId,date,status:existing?.status||"pending",startedAt:existing?.startedAt,completedAt:existing?.completedAt,checklistDoneIds:nextDone,updatedAt:now}; return existing?prev.map(x=>x.id===existing.id?next:x):[next,...prev]; });
};
const addHealthEntry = () => { setHealthEntries(prev=>[{id:makeId(),memberId:healthMemberId,date:localDateKey(),time:localTimeKey(),mood:healthMood,event:healthEvent,note:healthNote.trim(),createdAt:nowISO()},...prev]); setHealthNote(""); showToast("Registro de bem-estar salvo."); };
const addCycleEntry = () => { if(!cycleStartDate) return; setCycleEntries(prev=>[{id:makeId(),memberId:healthMemberId,startDate:cycleStartDate,endDate:cycleEndDate||undefined,cramps:cycleCramps,notes:cycleNotes.trim(),createdAt:nowISO()},...prev]); setCycleNotes(""); showToast("Ciclo registrado."); };
const addMedication = () => { if(!medicationFormName.trim()) {showToast("Informe o medicamento.");return;} const times=medicationFormTimes.split(",").map(x=>x.trim()).filter(Boolean); const med:Medication={id:makeId(),memberId:medicationFormMember,name:medicationFormName.trim(),unit:medicationFormUnit.trim()||"unidade",quantity:Math.max(0,Number(medicationFormQuantity)||0),doseAmount:Math.max(0,Number(medicationFormDose)||0),dosesPerDay:Math.max(1,Number(medicationFormDosesPerDay)||1),times,stockAlertAt:Math.max(0,Number(medicationFormAlert)||0),notes:"",active:true,createdAt:nowISO()}; setMedications(prev=>[med,...prev]); setMedicationFormName(""); showToast("Medicamento cadastrado."); };
const registerMedicationDose = (med:Medication) => { const now=new Date(); const log:MedicationLog={id:makeId(),medicationId:med.id,memberId:med.memberId,date:localDateKey(now),time:localTimeKey(now),quantityTaken:med.doseAmount,createdAt:nowISO()}; setMedicationLogs(prev=>[log,...prev]); setMedications(prev=>prev.map(x=>x.id===med.id?{...x,quantity:Math.max(0,x.quantity-med.doseAmount),updatedAt:nowISO()}:x)); showToast(`${med.name} registrado às ${log.time}.`); };
const toggleRoutineTemplate = (id:string) => { setRoutineTemplates(prev=>prev.map(x=>x.id===id?{...x,active:!x.active,updatedAt:nowISO()}:x)); };

const requestRoutineNotifications = async () => {
  try {
    if (Capacitor.isNativePlatform()) {
      const result = await LocalNotifications.requestPermissions();
      const granted = result.display === "granted";
      setRoutineSettings(prev=>({...prev,notificationEnabled:granted,updatedAt:nowISO()}));
      showToast(granted?"Alarmes do celular ativados.":"Permissão de notificações não concedida.");
      return;
    }
    if(typeof Notification === "undefined"){showToast("Este ambiente não oferece notificações.");return;}
    const permission=await Notification.requestPermission();
    setRoutineSettings(prev=>({...prev,notificationEnabled:permission==="granted",updatedAt:nowISO()}));
    showToast(permission==="granted"?"Notificações ativadas.":"Permissão não concedida.");
  } catch { showToast("Não foi possível solicitar a permissão."); }
};
const moveToReserve = (id:string) => { const r=reserves.find(x=>x.id===id); if(!r)return; const amount=Math.max(0,Number(String(window.prompt("Quanto guardar?","0")||"0").replace(",","."))||0); if(amount<=0||amount>Math.max(0,operationalBalance)){showToast("Valor maior que o disponível.");return;} setReserves(prev=>prev.map(x=>x.id===id?{...x,balance:x.balance+amount,updatedAt:nowISO()}:x)); setQuickTransactions(prev=>[{id:makeId(),type:"expense",area:"home",amount,source:`Guardar · ${r.name}`,description:"Transferência para reserva",clientId:"",clientName:"",stockItemId:"",quantity:0,paymentMethod:"transfer",currency:"BRL",paymentStatus:"received",date:nowISO(),createdAt:nowISO()},...prev]); showToast(`${formatMoney(amount)} guardados em ${r.name}.`); };
const redeemReserve = (id:string) => { const r=reserves.find(x=>x.id===id); if(!r)return; const amount=Math.max(0,Number(String(window.prompt("Quanto resgatar?",String(r.balance))||"0").replace(",","."))||0); if(amount<=0||amount>r.balance){showToast("Valor de resgate inválido.");return;} setReserves(prev=>prev.map(x=>x.id===id?{...x,balance:x.balance-amount,updatedAt:nowISO()}:x)); setQuickTransactions(prev=>[{id:makeId(),type:"income",area:"home",amount,source:`Resgate · ${r.name}`,description:"Transferência de reserva para caixa",clientId:"",clientName:"",stockItemId:"",quantity:0,paymentMethod:"transfer",currency:"BRL",paymentStatus:"received",date:nowISO(),createdAt:nowISO()},...prev]); showToast(`${formatMoney(amount)} resgatados para o caixa.`); };
const createInvestment = () => { const name=window.prompt("Nome da aplicação:","Caixinha / Investimento"); if(!name?.trim())return; const amount=Math.max(0,Number(String(window.prompt("Valor aplicado:","0")||"0").replace(",","."))||0); const cdi=Math.max(0,Number(String(window.prompt("Percentual do CDI (%):","115")||"115").replace(",","."))||0); const inv:Investment={id:makeId(),name:name.trim(),principal:amount,balance:amount,cdiPercent:cdi,estimatedMonthlyRate:0,createdAt:nowISO()}; setInvestments(prev=>[inv,...prev]); if(amount>0)setQuickTransactions(prev=>[{id:makeId(),type:"expense",area:"home",amount,source:`Aplicação · ${name.trim()}`,description:"Transferência para investimento — não é despesa",clientId:"",clientName:"",stockItemId:"",quantity:0,paymentMethod:"transfer",currency:"BRL",paymentStatus:"received",date:nowISO(),createdAt:nowISO()},...prev]); showToast("Aplicação cadastrada."); };
const redeemInvestment = (id:string) => { const inv=investments.find(x=>x.id===id); if(!inv)return; const amount=Math.max(0,Number(String(window.prompt("Quanto resgatar?",String(inv.balance))||"0").replace(",","."))||0); if(amount<=0||amount>inv.balance){showToast("Valor inválido.");return;} setInvestments(prev=>prev.map(x=>x.id===id?{...x,balance:x.balance-amount,updatedAt:nowISO()}:x)); setQuickTransactions(prev=>[{id:makeId(),type:"income",area:"home",amount,source:`Resgate · ${inv.name}`,description:"Resgate de investimento",clientId:"",clientName:"",stockItemId:"",quantity:0,paymentMethod:"transfer",currency:"BRL",paymentStatus:"received",date:nowISO(),createdAt:nowISO()},...prev]); showToast("Resgate registrado no caixa."); };

/* =========================================================
   NOVAS FUNÇÕES - COMPRAS FUTURAS / NOTAS / DIA
========================================================= */
const getFutureTargetDate = (timeframe: FuturePurchaseTimeframe) => {
 const base = new Date();
 const days = timeframe === "today" ? 0 : timeframe === "7days" ? 7 : timeframe === "30days" ? 30 : timeframe === "90days" ? 90 : -1;
 if (days < 0) return "";
 base.setDate(base.getDate() + days);
 return base.toISOString().slice(0, 10);
};
 
const saveFuturePurchase = () => {
 if (!futureTitle.trim()) {
   showToast("Digite o nome do item que pretende comprar.");
   return;
 }
 const item: FuturePurchase = {
   id: makeId(),
   title: futureTitle.trim(),
   description: futureDescription.trim(),
   link: futureLink.trim(),
   area: futureArea,
   sectorId: futureArea === "home" ? futureSectorId : "",
   priority: futurePriority,
   timeframe: futureTimeframe,
   targetDate: futureTargetDate || getFutureTargetDate(futureTimeframe),
   completed: false,
   createdAt: nowISO(),
 };
 setFuturePurchases(previous => [item, ...previous]);
 setFutureTitle("");
 setFutureDescription("");
 setFutureLink("");
 setFutureArea("home");
 setFutureSectorId("");
 setFuturePriority("medium");
 setFutureTimeframe("30days");
 setFutureTargetDate("");
 showToast("Compra futura cadastrada.");
};
 
const toggleFuturePurchase = (id: string) => {
 setFuturePurchases(previous => previous.map(item => item.id === id ? { ...item, completed: !item.completed } : item));
};
 
const deleteFuturePurchase = (id: string) => {
 const item = futurePurchases.find(x => x.id === id);
 if (!item) return;
 if (!window.confirm("Mover esta compra futura para a lixeira?")) return;
 sendToTrash("future_purchase", `Compra futura: ${item.title}`, item);
 setFuturePurchases(previous => previous.filter(x => x.id !== id));
 showToast("Compra futura enviada para a lixeira.");
};
 
const saveNote = () => {
 if (!noteTitle.trim() && !noteContent.trim()) {
   showToast("Escreva algo antes de salvar a anotação.");
   return;
 }
 const now = nowISO();
 if (editingNoteId) {
   setNotes(previous => previous.map(note => note.id === editingNoteId ? { ...note, title: noteTitle.trim() || "Sem título", content: noteContent.trim(), updatedAt: now } : note));
   showToast("Anotação atualizada.");
 } else {
   setNotes(previous => [{ id: makeId(), title: noteTitle.trim() || "Sem título", content: noteContent.trim(), createdAt: now, updatedAt: now }, ...previous]);
   showToast("Anotação salva.");
 }
 setNoteTitle("");
 setNoteContent("");
 setEditingNoteId(null);
};
 
const editNote = (note: NoteItem) => {
 setEditingNoteId(note.id);
 setNoteTitle(note.title);
 setNoteContent(note.content);
};
 
const deleteNote = (id: string) => {
 const note = notes.find(x => x.id === id);
 if (!note) return;
 if (!window.confirm("Mover esta anotação para a lixeira?")) return;
 sendToTrash("note", `Anotação: ${note.title}`, note);
 setNotes(previous => previous.filter(x => x.id !== id));
 if (editingNoteId === id) { setEditingNoteId(null); setNoteTitle(""); setNoteContent(""); }
 showToast("Anotação enviada para a lixeira.");
};
 
const moodOptions: Array<{value:HealthEntry["mood"]; icon:string; label:string}> = [
 {value:"very-good",icon:"😄",label:"Muito bem"},
 {value:"good",icon:"🙂",label:"Bem"},
 {value:"neutral",icon:"😐",label:"Normal"},
 {value:"low",icon:"😞",label:"Baixa"},
 {value:"bad",icon:"😣",label:"Mal"},
 {value:"tired",icon:"😴",label:"Cansada"},
 {value:"unwell",icon:"🤒",label:"Passei mal"},
];
const exportOrganizationBackup = async () => {
 const keys = [FAMILY_MEMBERS_KEY, ROUTINE_TEMPLATES_KEY, ROUTINE_LOGS_KEY, ROUTINE_SETTINGS_KEY, HEALTH_ENTRIES_KEY, CYCLE_ENTRIES_KEY, MEDICATIONS_KEY, MEDICATION_LOGS_KEY, ROUTINE_ITEMS_KEY, FUTURE_PURCHASES_KEY, NOTES_KEY, SECTORS_KEY, CATEGORIES_KEY];
 const payload: Record<string, unknown> = {};
 keys.forEach(key => payload[key] = readStorage(key, []));
 const bundle = {version:1, exportedAt:nowISO(), app:"Gestão Sacerdotisa Aimê", type:"organization-config", keys, payload};
 const text = JSON.stringify(bundle, null, 2);
 try {
   if (Capacitor.isNativePlatform()) {
     const path = `gestao-aime-organizacao-${localDateKey()}.json`;
     const result = await Filesystem.writeFile({path, data:text, directory:Directory.Documents, recursive:true});
     try { await Share.share({title:"Backup da Organização", text:"Backup das configurações de Organização da Gestão Sacerdotisa Aimê", url:result.uri, dialogTitle:"Compartilhar backup"}); } catch {}
     showToast("Backup salvo nos documentos do aparelho.");
   } else {
     const blob = new Blob([text], {type:"application/json;charset=utf-8"});
     const url = URL.createObjectURL(blob); const a=document.createElement("a"); a.href=url; a.download=`gestao-aime-organizacao-${localDateKey()}.json`; a.click(); URL.revokeObjectURL(url); showToast("Backup de organização exportado.");
   }
 } catch { showToast("Não foi possível exportar o backup."); }
};
const importOrganizationBackup = async (file: File) => {
 try {
   const raw = JSON.parse(await file.text());
   if (!raw || raw.type !== "organization-config" || !raw.payload) throw new Error("Arquivo inválido");
   const payload = raw.payload as Record<string, unknown>;
   const keys = [FAMILY_MEMBERS_KEY, ROUTINE_TEMPLATES_KEY, ROUTINE_LOGS_KEY, ROUTINE_SETTINGS_KEY, HEALTH_ENTRIES_KEY, CYCLE_ENTRIES_KEY, MEDICATIONS_KEY, MEDICATION_LOGS_KEY, ROUTINE_ITEMS_KEY, FUTURE_PURCHASES_KEY, NOTES_KEY, SECTORS_KEY, CATEGORIES_KEY];
   keys.forEach(key => { if (key in payload) safeSetStorage(key, payload[key]); });
   const defaultMembers: FamilyMember[] = [
     {id:"member-aime",name:"Aimê",role:"adult",active:true,createdAt:nowISO()}, {id:"member-eme",name:"Emê",role:"adult",active:true,createdAt:nowISO()}, {id:"member-tuco",name:"Tuco",role:"child",active:true,createdAt:nowISO()}, {id:"member-taiguara",name:"Taiguara",role:"child",active:true,createdAt:nowISO()},
   ];
   setFamilyMembers((payload[FAMILY_MEMBERS_KEY] as FamilyMember[]) || defaultMembers);
   setRoutineTemplates((payload[ROUTINE_TEMPLATES_KEY] as RoutineTemplate[]) || []);
   setRoutineLogs((payload[ROUTINE_LOGS_KEY] as RoutineLog[]) || []);
   const rs=payload[ROUTINE_SETTINGS_KEY]; setRoutineSettings((Array.isArray(rs)?rs[0]:rs) || routineSettings);
   setHealthEntries((payload[HEALTH_ENTRIES_KEY] as HealthEntry[]) || []); setCycleEntries((payload[CYCLE_ENTRIES_KEY] as CycleEntry[]) || []); setMedications((payload[MEDICATIONS_KEY] as Medication[]) || []); setMedicationLogs((payload[MEDICATION_LOGS_KEY] as MedicationLog[]) || []); setRoutineItems((payload[ROUTINE_ITEMS_KEY] as any[]) || []); setFuturePurchases((payload[FUTURE_PURCHASES_KEY] as FuturePurchase[]) || []); setNotes((payload[NOTES_KEY] as NoteItem[]) || []); setHouseholdSectors((payload[SECTORS_KEY] as any[]) || []); setHouseholdCategories((payload[CATEGORIES_KEY] as any[]) || []);
   showToast("Backup de organização importado.");
 } catch { showToast("Arquivo de backup inválido ou incompatível."); }
};


// V112: backup completo independente do Supabase. O ZIP guarda todos os dados
// persistidos no localStorage do aplicativo, inclusive fotos/áudios que estejam
// armazenados como dados dentro desses registros. Credenciais/tokens do Supabase
// nunca entram no arquivo.
const FULL_BACKUP_EXCLUDED_KEYS = [
  /supabase/i,
  /auth[-_]?token/i,
  /^sb-/i,
];
const isBackupSafeKey = (key: string) => !FULL_BACKUP_EXCLUDED_KEYS.some(pattern => pattern.test(key));

const collectFullBackupEntries = () => {
  const entries: Record<string, string> = {};
  for (let i = 0; i < localStorage.length; i += 1) {
    const key = localStorage.key(i);
    if (!key || !isBackupSafeKey(key)) continue;
    const value = localStorage.getItem(key);
    if (value !== null) entries[key] = value;
  }
  return entries;
};

const bytesToBase64 = (bytes: Uint8Array) => {
  let binary = "";
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
  }
  return btoa(binary);
};

const base64ToBytes = (value: string) => {
  const binary = atob(value);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
  return bytes;
};

const exportFullBackup = async () => {
  try {
    const entries = collectFullBackupEntries();
    const manifest = {
      format: "gestao-sacerdotista-aime-backup",
      version: 1,
      appVersion: "1.12.0",
      exportedAt: nowISO(),
      app: "Gestão Sacerdotista Aimê",
      note: "Backup completo dos dados persistidos localmente. Credenciais do Supabase não são incluídas.",
      entriesCount: Object.keys(entries).length,
    };
    const data = { manifest, entries };
    const zip = zipSync({
      "manifest.json": strToU8(JSON.stringify(manifest, null, 2)),
      "data.json": strToU8(JSON.stringify(data)),
    }, { level: 6 });
    const filename = `gestao-sacerdotista-aime-backup-${localDateKey()}.zip`;

    if (Capacitor.isNativePlatform()) {
      const base64 = bytesToBase64(zip);
      const result = await Filesystem.writeFile({
        path: filename,
        data: base64,
        directory: Directory.Documents,
        recursive: true,
      });
      try {
        await Share.share({
          title: "Backup completo da Gestão Sacerdotista Aimê",
          text: "Backup completo dos dados do aplicativo.",
          url: result.uri,
          dialogTitle: "Salvar ou compartilhar backup",
        });
      } catch {}
      showToast(`Backup completo criado com ${Object.keys(entries).length} itens.`);
      return;
    }

    const blob = new Blob([zip], { type: "application/zip" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
    showToast(`Backup completo criado com ${Object.keys(entries).length} itens.`);
  } catch (error) {
    console.error("V112 export full backup", error);
    showToast("Não foi possível criar o backup completo.");
  }
};

const importFullBackup = async (file: File) => {
  if (!file.name.toLowerCase().endsWith(".zip")) {
    showToast("Selecione um arquivo .zip de backup da Gestão Sacerdotista Aimê.");
    return;
  }
  if (!window.confirm("Importar este backup substituirá os dados locais atuais pelos dados do arquivo. Continuar?")) return;

  backupOperationRef.current = true;
  try {
    const bytes = new Uint8Array(await file.arrayBuffer());
    const files = unzipSync(bytes);
    const dataFile = files["data.json"];
    if (!dataFile) throw new Error("data.json ausente");

    const parsed = JSON.parse(strFromU8(dataFile));
    if (parsed?.manifest?.format !== "gestao-sacerdotista-aime-backup" || !parsed?.entries || typeof parsed.entries !== "object") {
      throw new Error("Formato incompatível");
    }

    const entries = parsed.entries as Record<string, unknown>;
    for (const [key, value] of Object.entries(entries)) {
      if (!isBackupSafeKey(key) || typeof value !== "string") continue;
      localStorage.setItem(key, value);
    }

    // A restauração local passa a ser também a nova referência remota, sem
    // depender do merge automático do Supabase para recuperar o estado antigo.
    if (authUser && navigator.onLine) {
      await pushFullSupabaseSnapshot(authUser.id);
    }

    showToast("Backup completo importado. O aplicativo será recarregado.");
    window.setTimeout(() => window.location.reload(), 700);
  } catch (error) {
    console.error("V112 import full backup", error);
    showToast("Arquivo de backup inválido ou incompatível.");
  } finally {
    backupOperationRef.current = false;
  }
};

const dailyActivities: DailyActivity[] = [
 ...budgets.filter(item => item.createdAt.slice(0, 10) === dailyDate).map(item => ({
   id: `budget-${item.id}`, date: item.createdAt, kind: "budget", title: item.serviceName,
   subtitle: `Orçamento · ${item.clientName}`, amount: Math.max(0, item.value + item.surcharge - item.discount) + Number(item.shippingUber||0) + Number(item.shippingCorreios||0),
   details: [`Serviço: ${item.serviceName}`, `Título: ${item.title}`, `Status: ${item.status === "draft" ? "Rascunho" : item.status === "sent" ? "Enviado" : item.status === "approved" ? "Aprovado" : item.status === "rejected" ? "Recusado" : "Expirado"}`, item.validUntil ? `Validade: ${formatDate(item.validUntil)}` : "Sem validade definida"],
 })),
 ...consultations.filter(item => item.status === "completed" && item.createdAt.slice(0, 10) === dailyDate).map(item => ({
   id: `consult-${item.id}`, date: item.createdAt, kind: "consultation", title: item.title,
   subtitle: `Atendimento · ${item.clientName}`, amount: item.value, clientId: item.clientId,
   details: [`Consulente: ${item.clientName}`, `Telefone: ${clients.find(c=>c.id===item.clientId)?.phone || "não informado"}`, `País: ${clients.find(c=>c.id===item.clientId) ? clientCountry(clients.find(c=>c.id===item.clientId)!) : "Não identificado"}`, `Status: ${item.status === "completed" ? "Concluído" : item.status === "standby" ? "Standby" : "Ativo"}`, `Pagamento: ${item.paid ? "Pago" : "Pendente"}`, `Moeda: ${item.currency || "BRL"}`, `${item.currency && item.currency !== "BRL" && item.currencyRate ? `Pago: ${currencySymbol(item.currency)} ${(item.value/item.currencyRate).toFixed(2)} · equivalente ${formatMoney(item.value)}` : ""}`, `${item.paymentPlan?.fee ? `Taxa: ${formatMoney(item.paymentPlan.fee)} · líquido ${formatMoney(Math.max(0,item.value-item.paymentPlan.fee))}` : ""}`, `${item.questions.filter(q=>q.text.trim() || q.completed).length} pergunta(s)`].filter(Boolean),
 })),
 ...consultations.filter(item=>item.status === "completed").flatMap(item => (item.relatedCharges || []).filter(charge => (charge.createdAt || item.createdAt || "").slice(0, 10) === dailyDate).map(charge => ({
   id: `charge-${item.id}-${charge.id}`, date: charge.createdAt || item.createdAt, kind: charge.kind === "sale" ? "sale" : "work", title: charge.title || (charge.kind === "sale" ? "Venda" : "Trabalho"),
   subtitle: `${charge.kind === "sale" ? "Venda" : "Trabalho"} · ${item.clientName}`, amount: Number(charge.originalAmount ?? charge.amountBRL ?? 0), clientId: item.clientId,
   details: [`Consulente: ${item.clientName}`, `Status: ${charge.saleStatus || charge.status || "Registrado"}`, charge.scheduledAt ? `Agendado: ${formatDateTime(charge.scheduledAt)}` : "Sem agendamento"]
 }))),
 ...quickTransactions.filter(item => !isInstallmentMirrorTransaction(item) && item.date.slice(0, 10) === dailyDate).map(item => ({
   id: `quick-${item.id}`, date: item.date, kind: item.type === "expense" ? "expense" : "income",
   title: item.source, subtitle: `${item.type === "expense" ? "Saída rápida" : item.type === "sale" ? "Venda" : "Entrada rápida"} · ${item.area === "home" ? "Casa" : "Trabalho"}`,
   amount: item.amount, details: [item.description || "Sem descrição", `Forma: ${item.paymentMethod}`, item.type === "sale" ? `Status: ${item.paymentStatus === "pending" ? "A receber" : "Recebida"}` : "", item.clientName ? `Consulente: ${item.clientName}` : "Sem consulente"].filter(Boolean),
 })),
 ...purchases.filter(item => item.date === dailyDate).map(item => ({
   id: `purchase-${item.id}`, date: item.date, kind: "purchase", title: item.supplierName,
   subtitle: "Compra registrada", amount: item.total,
   details: item.items.map(product => `${product.name || "Item"}: ${product.quantity} ${product.unit} · ${formatMoney(product.total)} · ${product.destination === "home" ? "Casa" : "Trabalho"}`),
 })),
 ...payables.filter(item => item.dueDate === dailyDate).map(item => ({
   id: `payable-${item.id}`, date: item.dueDate, kind: "payable", title: item.description,
   subtitle: `Vencimento · ${item.area === "home" ? "Casa" : "Trabalho"}`, amount: item.amount,
   details: [`Status: ${item.status === "paid" ? "Pago" : item.status === "overdue" ? "Vencido" : "Pendente"}`, `Forma: ${item.paymentMethod}`],
 })),
 ...stockMovements.filter(item => item.date.slice(0, 10) === dailyDate).map(item => {
   const stock = stockItems.find(stockItem => stockItem.id === item.stockItemId);
   const label = item.type === "entry" ? "Entrada de estoque" : item.type === "consumption" ? "Consumo de estoque" : item.type === "transfer_out" ? "Transferência de estoque" : item.type === "loss" ? "Perda de estoque" : "Movimentação de estoque";
   return { id: `stock-${item.id}`, date: item.date, kind: "stock", title: stock?.name || "Item de estoque", subtitle: label, details: [`Quantidade: ${item.quantity} ${stock?.unit || "un"}`, `Custo unitário: ${formatMoney(item.unitCost)}`, item.areaFrom && item.areaTo ? `${item.areaFrom === "home" ? "Casa" : "Trabalho"} → ${item.areaTo === "home" ? "Casa" : "Trabalho"}` : item.notes || "Sem observações"] };
 }),
 ...futurePurchases.filter(item => item.createdAt.slice(0, 10) === dailyDate).map(item => ({
   id: `future-${item.id}`, date: item.createdAt, kind: "future", title: item.title,
   subtitle: `Compra futura · ${item.area === "home" ? "Casa" : "Trabalho"}`,
   details: [`Prioridade: ${item.priority === "urgent" ? "Urgente" : item.priority === "high" ? "Alta" : item.priority === "medium" ? "Média" : "Baixa"}`, item.targetDate ? `Pretendida para: ${formatDate(item.targetDate)}` : "Sem prazo definido", item.description || "Sem descrição"],
 })),
 ...agendaItems.filter(item => item.date === dailyDate).map(item => ({
   id: `agenda-${item.id}`, date: `${item.date}T${item.time}`, kind: "agenda", title: item.title,
   subtitle: `Agenda · ${item.category === "family" ? "Família" : item.category === "work" ? "Trabalho" : "Casa"} · ${item.time}`,
   details: [item.description || "Sem descrição", item.notify ? "Alarme/notificação ativado" : "Sem alarme", item.completed ? "Concluído" : "Pendente"],
 })),
].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
 
const filteredDailyActivities = dailyActivities.filter(item => {
 const matchesFilter = dailyFilter === "all" || item.kind === dailyFilter;
 const haystack = `${item.title} ${item.subtitle} ${item.details.join(" ")}`.toLocaleLowerCase("pt-BR");
 const term = dailySearch.trim().toLocaleLowerCase("pt-BR");
 return matchesFilter && (!term || haystack.includes(term));
});
const monthStart = new Date(`${agendaDate}T00:00:00`);
const agendaYear = monthStart.getFullYear();
const agendaMonth = monthStart.getMonth();
const daysInAgendaMonth = new Date(agendaYear, agendaMonth + 1, 0).getDate();
const agendaAccountOccurrences = accountTemplates.filter(item => item.active).map(item => {
 const day = Math.min(item.dueDay, daysInAgendaMonth);
 const date = `${agendaYear}-${String(agendaMonth + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
 const supplier = suppliers.find(supplierItem => supplierItem.id === item.supplierId);
 return {
  id: `account-template-${item.id}-${date}`,
  date,
  time: "08:00",
  title: item.name,
  description: item.description || "Conta cadastrada nas configurações.",
  category: item.area === "home" ? "home" as AgendaCategory : "work" as AgendaCategory,
  amount: item.amount,
  supplierName: supplier?.name || "",
 };
});
const scheduledConsultations = consultations.filter(item => {
 const scheduled = !!(item.scheduledAt || item.shippingScheduledAt);
 // Um trabalho/venda pode existir no registro principal e também em relatedCharges.
 // Se ambos representam exatamente o mesmo título e horário, a charge é a fonte operacional
 // e o registro-pai não deve gerar um segundo compromisso visual.
 const parentWhen = item.serviceType === "sale" ? (item.shippingScheduledAt || item.scheduledAt) : item.scheduledAt;
 const hasEquivalentLinkedCharge = !!parentWhen && (item.relatedCharges || []).some(ch => {
   const chargeWhen = ch.kind === "sale" ? (ch.shippingScheduledAt || ch.scheduledAt) : ch.scheduledAt;
   return !ch.deletedAt && ch.kind === (item.serviceType === "sale" ? "sale" : "work") && !!chargeWhen && chargeWhen === parentWhen && String(ch.title || "").trim().toLowerCase() === String(item.title || "").trim().toLowerCase() && (ch.kind === "sale" ? !["delivered","cancelled"].includes(ch.saleStatus || "") : !["completed","cancelled"].includes(ch.status || ""));
 });
 if (hasEquivalentLinkedCharge && (item.serviceType === "work" || item.serviceType === "sale")) return false;
 if (!scheduled) return false;
 // A sale created directly from Novo atendimento can be stored as `completed`
 // because its commercial record is complete while its shipment is still scheduled.
 // It must remain visible in Agenda until delivered/cancelled.
 if (item.serviceType === "sale") {
   if (["delivered","cancelled"].includes((item as any).saleStatus || "")) return false;
   return true;
 }
 if (item.status === "completed" || item.status === "cancelled") return false;
 if (item.serviceType === "work" && ["completed","cancelled"].includes(item.workStatus || "")) return false;
 return true;
}).map(item => {
 const serviceType = item.serviceType || "consultation";
 const when = serviceType === "sale" ? (item.shippingScheduledAt || item.scheduledAt)! : item.scheduledAt!;
 const date = when.slice(0, 10);
 const time = when.slice(11, 16) || "00:00";
 return {
  id: `consultation-${item.id}`,
  date, time, title: item.title,
  description: `${serviceType === "work" ? "Trabalho de" : serviceType === "sale" ? "Envio/venda de" : "Atendimento de"} ${item.clientName}`,
  category: "work" as AgendaCategory, amount: item.value, consultationId: item.id, isWork: serviceType === "work", serviceType, workStatus: item.workStatus, chargeId: undefined as string|undefined, priority: Math.min(5, Math.max(1, Number((item as any).priority) || 3)),
 };
});
const scheduledRelatedCharges = consultations.flatMap(parent => (parent.relatedCharges || []).filter(ch => !ch.deletedAt && (ch.scheduledAt || ch.shippingScheduledAt)).map(ch => {
 const when = ch.kind === "sale" ? (ch.shippingScheduledAt || ch.scheduledAt)! : ch.scheduledAt!;
 return { id:`charge-${parent.id}-${ch.id}`, date:when.slice(0,10), time:when.slice(11,16)||"00:00", title:ch.title || (ch.kind === "sale" ? "Venda" : "Trabalho"), description:`${ch.kind === "sale" ? "Envio/venda de" : "Trabalho de"} ${parent.clientName}`, category:"work" as AgendaCategory, amount:ch.originalAmount, consultationId:parent.id, chargeId:ch.id, isWork:ch.kind === "work", serviceType:ch.kind === "sale" ? "sale" : "work", workStatus:ch.status, priority: Math.min(5, Math.max(1, Number((ch as any).priority || parent.priority || 3))) };
}));

const consultantPaymentAgenda = consultations.filter(consultation=>consultation.status === "completed").flatMap(consultation => {
 const currency = (consultation.currency || "BRL") as CurrencyCode;
 const today = new Date().toISOString().slice(0,10);
 const consultationRows = (consultation.paymentPlan?.installments || []).map(installment => {
   const displayStatus = installment.status === "pending" && installment.dueDate < today ? "overdue" : installment.status;
   return { id: `${consultation.id}-${installment.id}`, consultationId: consultation.id, installmentId: installment.id, questionId: undefined as string|undefined, clientId: consultation.clientId, clientName: consultation.clientName, title: consultation.title, number: installment.number, amountBRL: installmentOpenAmount(installment), originalAmountBRL: installment.amount, receivedAmountBRL: installmentReceivedAmount(installment), amountCurrency: convertFromBRL(installmentOpenAmount(installment), currency), currency, dueDate: installment.dueDate, status: displayStatus, archived: installment.status === "received" || installment.status === "defaulted", paymentMethod: installment.paymentMethod, postponedFrom: installment.postponedFrom, paymentDates: installmentPaymentDateLines(installment) };
 });
 const questionRows = (consultation.questions || []).flatMap(question => (question.paymentPlan?.installments || []).map(installment => {
   const qCurrency=(question.currency || currency) as CurrencyCode;
   const displayStatus = installment.status === "pending" && installment.dueDate < today ? "overdue" : installment.status;
   return { id: `${consultation.id}-${question.id}-${installment.id}`, consultationId: consultation.id, installmentId: installment.id, questionId: question.id, clientId: consultation.clientId, clientName: consultation.clientName, title: `Pergunta ${question.number}: ${question.text || "Sem título"}`, number: installment.number, amountBRL: installmentOpenAmount(installment), originalAmountBRL: installment.amount, receivedAmountBRL: installmentReceivedAmount(installment), amountCurrency: convertFromBRL(installmentOpenAmount(installment), qCurrency), currency:qCurrency, dueDate:installment.dueDate, status:displayStatus, archived:installment.status === "received" || installment.status === "defaulted", paymentMethod:installment.paymentMethod, postponedFrom: installment.postponedFrom, paymentDates: installmentPaymentDateLines(installment) };
 }));
 return [...consultationRows,...questionRows];
});
const consultantOpenPayments = consultantPaymentAgenda.filter(item => !item.archived);
const consultantArchivedPayments = consultantPaymentAgenda.filter(item => item.archived);
const groupConsultantPayments = (items: typeof consultantPaymentAgenda) => Object.values(items.reduce((groups: Record<string, typeof consultantPaymentAgenda>, item) => {
 const key = item.clientId || item.clientName;
 (groups[key] ||= []).push(item);
 return groups;
}, {})).sort((a,b) => (a[0]?.clientName || "").localeCompare(b[0]?.clientName || "", "pt-BR"));
const pendingCount = consultantPaymentAgenda.filter(item => item.status === "pending" || item.status === "overdue").length;
const receivedCount = consultantPaymentAgenda.filter(item => item.status === "received").length;
const defaultedCount = consultantPaymentAgenda.filter(item => item.status === "defaulted").length;
const agendaDateMatches = (date: string) => !agendaFilterDate || date === agendaFilterDate;
const agendaManualForDate = agendaItems.filter(item => agendaDateMatches(item.date));
const centralAgendaServiceRows = agendaItems.filter(item => !!item.relatedEntityType && !!item.relatedEntityId && agendaDateMatches(item.date)).map(item => {
  const parent = item.relatedEntityType === "consultation" ? consultations.find(c => c.id === item.relatedEntityId) : consultations.find(c => (c.relatedCharges || []).some(ch => ch.id === item.relatedEntityId));
  const charge = parent && item.relatedEntityType !== "consultation" ? (parent.relatedCharges || []).find(ch => ch.id === item.relatedEntityId) : undefined;
  if (!parent || parent.deletedAt) return null;
  if (item.relatedEntityType === "consultation" && (parent.status === "cancelled" || parent.status === "completed")) return null;
  if (item.relatedEntityType === "work" && (charge ? ["completed","cancelled"].includes(charge.status || "") : ["completed","cancelled"].includes(parent.workStatus || ""))) return null;
  if (item.relatedEntityType === "sale" && (charge ? ["delivered","cancelled"].includes(charge.saleStatus || "") : ["delivered","cancelled"].includes(parent.saleStatus || ""))) return null;
  return {
    id: item.id,
    date: item.date,
    time: item.time,
    title: item.title,
    description: item.description,
    category: item.category,
    amount: charge?.originalAmount ?? parent.value,
    consultationId: parent.id,
    chargeId: charge?.id,
    isWork: item.relatedEntityType === "work",
    serviceType: item.relatedEntityType === "sale" ? "sale" : item.relatedEntityType === "work" ? "work" : "consultation",
    workStatus: charge?.status || parent.workStatus,
    priority: Math.min(5, Math.max(1, Number(item.priority || parent.priority || 3))),
    clientId: item.clientId || parent.clientId,
    completed: item.completed,
  };
}).filter(Boolean).sort((a:any,b:any)=>Number(b.priority || 3) - Number(a.priority || 3) || `${a.date}T${a.time}`.localeCompare(`${b.date}T${b.time}`));
const agendaConsultationsForDate = (() => {
  const seen = new Set<string>();
  return centralAgendaServiceRows.filter((row:any) => {
    const key = `${row.date}|${row.time}|${row.serviceType}|${row.title}|${row.clientId || row.consultationId || ""}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
})();
const agendaAccountsForDate = agendaAccountOccurrences.filter(item => item.date === agendaDate);

// Agenda central: os registros de serviço mantêm seus campos de data para a aba Serviços,
// mas cada compromisso agendado possui um único registro correspondente em AGENDA_KEY.
// Este efeito apenas reconcilia/migra registros antigos e mantém a Agenda sincronizada;
// a interface da Agenda lê os itens centrais, evitando uma segunda lista paralela.
useEffect(() => {
  const derived = [...scheduledConsultations, ...scheduledRelatedCharges].map((item:any) => {
    const relatedEntityType = item.serviceType as AgendaItem["relatedEntityType"];
    const relatedEntityId = item.chargeId || item.consultationId;
    const existing = agendaItems.find(a => a.relatedEntityId === relatedEntityId && a.relatedEntityType === relatedEntityType);
    return {
      id: existing?.id || `auto-${relatedEntityType}-${relatedEntityId}`,
      title: item.title,
      description: item.description,
      date: item.date,
      time: item.time,
      category: "work" as AgendaCategory,
      notify: existing?.notify !== false,
      completed: existing?.completed || false,
      createdAt: existing?.createdAt || nowISO(),
      updatedAt: existing?.updatedAt || nowISO(),
      relatedEntityType,
      relatedEntityId,
      clientId: existing?.clientId || (item.consultationId ? consultations.find(c => c.id === item.consultationId)?.clientId : undefined),
      priority: Math.min(5, Math.max(1, Number(item.priority || existing?.priority || 3))),
    } as AgendaItem;
  });
  setAgendaItems(previous => {
    const linkedKeys = new Set(derived.map(a => `${a.relatedEntityType}:${a.relatedEntityId}`));
    const manual = previous.filter(a => !a.relatedEntityType || !a.relatedEntityId);
    const next = [...derived, ...manual];
    const same = next.length === previous.length && next.every((a, i) => {
      const b = previous[i];
      return a.id === b.id && a.title === b.title && a.description === b.description && a.date === b.date && a.time === b.time && a.completed === b.completed && a.relatedEntityType === b.relatedEntityType && a.relatedEntityId === b.relatedEntityId && Number(a.priority || 3) === Number(b.priority || 3);
    });
    // linkedKeys is intentionally materialized so stale linked service entries are not retained.
    void linkedKeys;
    return same ? previous : next;
  });
  // eslint-disable-next-line react-hooks/exhaustive-deps
}, [consultations]);

const periodStartKey = (period: "today"|"week"|"month"|"all") => {
 const now = new Date();
 if (period === "all") return "0000-00-00";
 if (period === "today") return now.toISOString().slice(0,10);
 if (period === "week") { const d = new Date(now); d.setDate(now.getDate()-6); return d.toISOString().slice(0,10); }
 return new Date(now.getFullYear(), now.getMonth(), 1).toISOString().slice(0,10);
};
const inDashboardPeriod = (dateValue: string, period: "today"|"week"|"month"|"all") => {
 const key = (dateValue || "").slice(0,10);
 if (period === "all") return true;
 const start = periodStartKey(period);
 return key >= start && key <= new Date().toISOString().slice(0,10);
};

const todayRoutineOccurrences = getRoutineOccurrences(localDateKey());
const organizationAgendaOccurrences = getRoutineOccurrences(organizationAgendaDate);
const routineDurationRows = routineLogs.filter(l=>l.status==="completed" && l.startedAt && l.completedAt).map(l=>{ const r=routineTemplates.find(x=>x.id===l.routineId); const ms=new Date(l.completedAt!).getTime()-new Date(l.startedAt!).getTime(); return {...l,routine:r,durationMinutes:Math.max(0,Math.round(ms/60000))}; }).filter(x=>x.routine);
const todayRoutineDone = todayRoutineOccurrences.filter(x=>x.log?.status==="completed").length;
const todayRoutinePending = todayRoutineOccurrences.filter(x=>x.log?.status!=="completed" && x.log?.status!=="skipped").length;
const medicationLowStock = medications.filter(m=>m.active && m.quantity<=m.stockAlertAt);
const medicationTodayLogs = medicationLogs.filter(l=>l.date===localDateKey());
const currentCycle = cycleEntries.filter(c=>c.memberId===healthMemberId).sort((a,b)=>b.startDate.localeCompare(a.startDate))[0];

const liveSelectedServiceRecord = (() => {
  if (!selectedServiceRecord) return null;
  const consultationId = selectedServiceRecord.consultationId || selectedServiceRecord.consultation?.id;
  const live = consultationId ? consultations.find(c => c.id === consultationId) : null;
  if (!live) return selectedServiceRecord;
  return { ...selectedServiceRecord, consultation: live, clientId: live.clientId, clientName: live.clientName, value: live.value, amount: selectedServiceRecord.recordType === "reading" ? selectedServiceRecord.amount : live.value, currency: live.currency || selectedServiceRecord.currency || "BRL", paymentStatus: getPaymentStatus(live), status: selectedServiceRecord.recordType === "work" ? live.workStatus : selectedServiceRecord.recordType === "sale" ? live.saleStatus : live.status };
})();

/* =========================================================
RENDER - AUTENTICAÇÃO
========================================================= */
if (!authReady) {
return <div style={{ minHeight: "100vh", display: "grid", placeItems: "center", padding: 24, background: "#f7f3fb", color: "#241b2f", fontFamily: "system-ui, sans-serif" }}>Carregando...</div>;
}

if (!authUser) {
return (
<div style={{ minHeight: "100vh", display: "grid", placeItems: "center", padding: 24, background: "linear-gradient(160deg,#f7f1ff,#fff9f2)", fontFamily: "system-ui, sans-serif" }}>
<div style={{ width: "100%", maxWidth: 420, background: "white", borderRadius: 24, padding: 24, boxShadow: "0 18px 50px rgba(0,0,0,.10)" }}>
<div style={{ fontSize: 13, fontWeight: 800, letterSpacing: 1, opacity: .65, textTransform: "uppercase" }}>Gestão Sacerdotisa Aimê</div>
<h1 style={{ margin: "8px 0 6px", fontSize: 28 }}>Entrar</h1>
<p style={{ marginTop: 0, opacity: .7, lineHeight: 1.5 }}>Entre com a única conta do aplicativo para acessar seus dados sincronizados.</p>
<label style={{ display: "block", marginTop: 18, fontWeight: 700 }}>E-mail</label>
<input value={authEmail} onChange={(e) => setAuthEmail(e.target.value)} type="email" autoComplete="email" placeholder="seu@email.com" style={{ width: "100%", boxSizing: "border-box", marginTop: 8, padding: 13, borderRadius: 12, border: "1px solid #ddd" }} />
<label style={{ display: "block", marginTop: 14, fontWeight: 700 }}>Senha</label>
<input value={authPassword} onChange={(e) => setAuthPassword(e.target.value)} type="password" autoComplete="current-password" placeholder="Sua senha" onKeyDown={(e) => { if (e.key === "Enter") void handleSupabaseLogin(); }} style={{ width: "100%", boxSizing: "border-box", marginTop: 8, padding: 13, borderRadius: 12, border: "1px solid #ddd" }} />
{authError && <div style={{ marginTop: 14, padding: 12, borderRadius: 12, background: "#fff0f0", color: "#9d1c1c", fontSize: 14 }}>{authError}</div>}
<button onClick={() => void handleSupabaseLogin()} disabled={authLoading} style={{ width: "100%", marginTop: 18, padding: 14, border: 0, borderRadius: 14, background: "#3f2758", color: "white", fontWeight: 800, fontSize: 16, opacity: authLoading ? .6 : 1 }}>
{authLoading ? "Entrando..." : "Entrar no aplicativo"}
</button>
</div>
</div>
);
}

/* =========================================================
RENDER - CARREGAMENTO PÓS-LOGIN
========================================================= */
if (authUser && !appReady) {
return <div style={{ minHeight: "100vh", display: "grid", placeItems: "center", padding: 24, background: "#fff7fb", color: "#4a2340", fontFamily: "system-ui, sans-serif" }}>
  <div style={{ width: "100%", maxWidth: 360, textAlign: "center", background: "white", borderRadius: 22, padding: 24, boxShadow: "0 14px 40px rgba(80,30,60,.10)" }}>
    <div style={{ fontSize: 30, marginBottom: 10 }}>✨</div>
    <div style={{ fontWeight: 800, fontSize: 18 }}>Abrindo seu aplicativo</div>
    <div style={{ marginTop: 8, opacity: .7, lineHeight: 1.45 }}>{syncMessage || "Restaurando seus dados..."}</div>
  </div>
</div>;
}

/* =========================================================
V74 · IDENTIFICAÇÃO PADRONIZADA DA CONSULENTE
========================================================= */
const normalizeClientLookupName = (value?: string) => (value || "").trim().toLocaleLowerCase("pt-BR").replace(/\s+/g, " ");
const resolveClientForDisplay = (clientId?: string, clientName?: string) => {
  if (clientId) {
    const byId = clients.find(item => item.id === clientId);
    if (byId) return byId;
  }
  const needle = normalizeClientLookupName(clientName);
  if (!needle) return undefined;
  return clients.find(item => normalizeClientLookupName(item.name) === needle);
};
const openClientPhoto = (clientId?: string, clientName?: string) => {
  const client = resolveClientForDisplay(clientId, clientName);
  if (!client?.avatarPhoto) return;
  setSelectedClientPhoto({ id: client.id, name: client.name, data: client.avatarPhoto });
};
const ClientIdentity = ({ clientId, clientName, size = 42, showName = true, className = "" }: { clientId?: string; clientName?: string; size?: number; showName?: boolean; className?: string }) => {
  const client = resolveClientForDisplay(clientId, clientName);
  const name = client?.name || clientName || "Consulente";
  const photo = client?.avatarPhoto;
  return <span className={`v74-client-identity ${className}`.trim()} style={{display:"inline-flex",alignItems:"center",gap:9,minWidth:0,maxWidth:"100%",flex:"0 1 auto"}}>
    {photo ? <button type="button" aria-label={`Abrir foto de ${name}`} onClick={(event)=>{event.stopPropagation();openClientPhoto(client?.id, name);}} style={{width:size,height:size,minWidth:size,border:"none",padding:0,borderRadius:"50%",overflow:"hidden",background:"#f0e8f1",cursor:"pointer",display:"inline-flex",alignItems:"center",justifyContent:"center",flexShrink:0,boxShadow:"0 0 0 2px #fff, 0 0 0 3px #ead9e2"}}><img src={photo} alt={`Foto de ${name}`} style={{width:"100%",height:"100%",objectFit:"cover",display:"block"}} /></button> : <span aria-hidden="true" style={{width:size,height:size,minWidth:size,borderRadius:"50%",background:"#eee7f0",color:"#7b6488",display:"inline-flex",alignItems:"center",justifyContent:"center",fontWeight:900,fontSize:Math.max(14,Math.round(size*.38)),flexShrink:0,boxShadow:"inset 0 0 0 1px #e1d6e3"}}>{name.charAt(0).toUpperCase()}</span>}
    {showName && <span className="v74-client-name" style={{minWidth:0,display:"inline-flex",flexDirection:"column",gap:1}}><strong>{name}</strong></span>}
  </span>;
}


const audioRecorderPortal = audioRecorderOpen && typeof document !== "undefined" && createPortal(<div
    className="audio-recorder-overlay"
    style={{
      position:"fixed", inset:0, zIndex:2147483647,
      background:"rgba(20,12,18,.62)",
      display:"flex", alignItems:"center", justifyContent:"center",
      padding:"max(14px, env(safe-area-inset-top, 0px)) max(14px, env(safe-area-inset-right, 0px)) max(14px, env(safe-area-inset-bottom, 0px)) max(14px, env(safe-area-inset-left, 0px))",
      boxSizing:"border-box"
    }}
    onMouseDown={event=>event.stopPropagation()}
    onTouchStart={event=>event.stopPropagation()}
    onClick={event=>event.stopPropagation()}
  >
    <div
      role="dialog"
      aria-modal="true"
      aria-label={pendingRecordedAudio ? "Prévia da gravação" : "Gravação de áudio"}
      style={{
        width:"100%", maxWidth:560, maxHeight:"calc(100dvh - 28px)",
        background:"#fff", color:"#241b22", borderRadius:24,
        boxShadow:"0 24px 80px rgba(0,0,0,.35)", overflow:"hidden",
        display:"flex", flexDirection:"column"
      }}
    >
      <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",gap:10,padding:"16px 18px",borderBottom:"1px solid #eadfe6"}}>
        <div style={{minWidth:0}}>
          <div style={{fontSize:12,fontWeight:850,letterSpacing:".08em",textTransform:"uppercase",color:"#8a647b"}}>ÁUDIO</div>
          <h2 style={{margin:"3px 0 0",fontSize:21,lineHeight:1.2}}>{pendingRecordedAudio ? "🎧 Prévia da gravação" : audioRecorderSavedNotice ? "🎧 Áudios salvos" : "🎙️ Gravar áudio"}</h2>
        </div>
        <button
          type="button"
          aria-label="Cancelar e fechar gravação"
          style={{...styles.modalClose,flexShrink:0}}
          onClick={recording || audioRecorderStarting ? cancelActiveRecording : pendingRecordedAudio ? cancelRecordedAudioPreview : closeIdleAudioRecorder}
        >×</button>
      </div>

      <div style={{padding:18,display:"grid",gap:14,overflowY:"auto",overscrollBehavior:"contain",WebkitOverflowScrolling:"touch"}}>
        {!audioRecorderStarting && !recording && !pendingRecordedAudio && !audioRecorderSavedNotice ? <>
          <div style={{fontSize:54,fontWeight:900,textAlign:"center",lineHeight:1}}>🎙️</div>
          <div style={{...styles.infoBox,textAlign:"center"}}>
            <strong>Pronto para gravar</strong>
            <div style={styles.muted}>A gravação será iniciada automaticamente assim que esta janela abrir.</div>
          </div>
          <button type="button" style={styles.primaryButtonLarge} onClick={() => void beginRecording(recordingTarget)}>🔴 Iniciar gravação</button>
          <button type="button" style={styles.secondaryButtonLarge} onClick={closeIdleAudioRecorder}>Cancelar</button>
        </> : audioRecorderStarting ? <>
          <div style={{fontSize:52,fontWeight:900,textAlign:"center",lineHeight:1}}>🎙️</div>
          <div style={{...styles.infoBox,textAlign:"center"}}>
            <strong>Preparando o gravador...</strong>
            <div style={styles.muted}>O modal permanece aberto enquanto o microfone é ativado.</div>
          </div>
          <button type="button" style={styles.secondaryButtonLarge} onClick={cancelActiveRecording}>✕ Cancelar</button>
        </> : recording ? <>
          <div style={{textAlign:"center",padding:"6px 0 0"}}>
            <div style={{fontSize:50,fontWeight:950,fontVariantNumeric:"tabular-nums",lineHeight:1.05}}>{formatDuration(recordingTime)}</div>
            <div style={{marginTop:8,fontWeight:850,color:recordingPaused?"#8a647b":"#b42318"}}>{recordingPaused ? "⏸️ Gravação pausada" : "🔴 Gravando agora"}</div>
          </div>
          <div style={styles.infoBox}>
            <strong>{recordingPaused ? "Você pode ouvir o que já foi gravado." : "Fale normalmente."}</strong>
            <div style={styles.muted}>{recordingPaused ? "Retome para continuar, ou finalize para revisar e decidir se deseja salvar." : "A janela permanece aberta durante toda a gravação. Você pode pausar, retomar, finalizar ou cancelar."}</div>
          </div>
          {recordingPaused && recordingPreviewUrl && <div style={{...styles.card,display:"grid",gap:8}}><strong>▶ Ouvir o trecho gravado</strong><audio controls src={recordingPreviewUrl} style={{width:"100%"}} /></div>}
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:9}}>
            <button type="button" style={styles.smallButton} onClick={recordingPaused ? resumeRecording : pauseRecording}>{recordingPaused ? "▶ Retomar" : "⏸ Pausar"}</button>
            <button type="button" style={styles.primaryButtonLarge} onClick={stopRecording}>⏹ Finalizar</button>
          </div>
          <button type="button" style={styles.secondaryButtonLarge} onClick={cancelActiveRecording}>✕ Cancelar e descartar</button>
        </> : <>
          <div style={{fontSize:44,textAlign:"center",lineHeight:1}}>🎧</div>
          <div style={{...styles.infoBox,textAlign:"center"}}>
            <strong>Áudios salvos automaticamente</strong>
            <div style={styles.muted}>Ao finalizar uma gravação, ela é salva imediatamente e permanece vinculada à pergunta e ao histórico da consulente.</div>
          </div>
          {pendingRecordedAudio && <div style={{...styles.card,display:"grid",gap:8}}><AudioPlayer audio={pendingRecordedAudio}/></div>}
          {currentQuestion && recordingTarget.kind === "question" && <div style={{display:"grid",gap:8}}>{currentQuestion.audios.map((audio,index)=><div key={audio.id} style={{display:"grid",gap:7,padding:9,border:"1px solid #eadfe6",borderRadius:14,background:"#fff"}}><div style={{display:"flex",justifyContent:"space-between",gap:8}}><strong>🎧 Áudio {index+1}</strong><span style={styles.muted}>{formatDuration(audio.duration)}</span></div><AudioPlayer audio={audio}/><button type="button" style={styles.smallButton} onClick={()=>shareAudio(audio)}>↗ Compartilhar áudio</button></div>)}</div>}
          {recordingTarget.kind === "client" && historyClient && <div style={{display:"grid",gap:8}}>{(historyClient.audios || []).map((audio,index)=><div key={audio.id} style={{display:"grid",gap:7,padding:9,border:"1px solid #eadfe6",borderRadius:14,background:"#fff"}}><div style={{display:"flex",justifyContent:"space-between",gap:8}}><strong>🎧 Áudio {index+1}</strong><span style={styles.muted}>{formatDuration(audio.duration)}</span></div><AudioPlayer audio={audio}/><button type="button" style={styles.smallButton} onClick={()=>shareAudio(audio)}>↗ Compartilhar áudio</button></div>)}</div>}
          <button type="button" style={styles.primaryButtonLarge} onClick={() => void beginRecording()}>🎙️ Gravar mais áudio</button>
          <button type="button" style={styles.secondaryButtonLarge} onClick={closeIdleAudioRecorder}>✓ Fechar</button>
        </>}
      </div>
    </div>
  </div>, document.body);

/* =========================================================
RENDER - TAROT ATIVO
========================================================= */
if (activeConsultation) {
return (
<div style={styles.app}>
{audioRecorderPortal}
<header style={styles.topbar}>
<button
style={styles.iconButton}
onClick={putOnStandby}
>
←
</button>
<div>
<div style={styles.eyebrow}>
ATENDIMENTO
</div>
<div style={{display:"flex",alignItems:"center",gap:10}}><ClientIdentity clientId={activeConsultation.clientId} clientName={activeConsultation.clientName} size={44} /></div>
</div>
<div style={{display:"flex",alignItems:"center",gap:10}}><AppDateTime compact /></div>
</header>
<main style={styles.main}>
<div
style={
styles.sessionHeader
}
>
<div>
<div style={styles.muted}>
Tiragem
</div>
<h2
style={
styles.pageTitle
}
>
{
activeConsultation.title
}
</h2>
</div>

</div>
<label style={{display:"flex",alignItems:"center",gap:8,margin:"10px 0",fontWeight:700}}><input type="checkbox" checked={relatedReadingEnabled} onChange={e=>setRelatedReadingEnabled(e.target.checked)} /> Tiragem relacionada a um trabalho</label>{relatedReadingEnabled && <div style={styles.infoBox}><label style={styles.label}>Trabalho deste consulente</label><select value={relatedReadingWorkId} onChange={e=>setRelatedReadingWorkId(e.target.value)} style={styles.input}><option value="">Selecione...</option>{consultations.filter(c=>c.clientId===activeConsultation.clientId && c.serviceType==="work" && c.id!==activeConsultation.id).map(w=><option key={w.id} value={w.id}>{w.workTypeName || w.title} · {formatDate(w.createdAt)}</option>)}</select>{relatedReadingWorkId && <div style={styles.muted}>A tiragem ficará marcada como relacionada a esse trabalho no histórico.</div>}</div>}
<div
style={
styles.questionTabs
}
>
{activeConsultation.questions.map(
(question) => (
<div key={question.id} style={{position:"relative",display:"inline-flex"}}>
<button
style={{...styles.questionTab,...(question.id === currentQuestion?.id ? styles.questionTabActive : {})}}
onClick={() => setActiveQuestionId(question.id)}
>
{question.number}{question.completed ? " ✓" : ""}
</button>
{activeConsultation.questions.length > 1 && <button type="button" aria-label={`Excluir pergunta ${question.number}`} onClick={(e)=>{e.stopPropagation();deleteQuestion(question.id);}} style={{position:"absolute",top:-7,right:-7,width:20,height:20,borderRadius:"50%",border:"1px solid #fff",background:"#b42318",color:"#fff",fontWeight:900,fontSize:12,lineHeight:"18px",padding:0,cursor:"pointer",boxShadow:"0 1px 4px rgba(0,0,0,.25)"}}>×</button>}
</div>
)
)}
{(activeConsultation.relatedCharges || []).map((charge,index)=><div key={charge.id} style={styles.relatedChargeTabWrap}><button type="button" style={styles.relatedChargeTab} onClick={()=>openRelatedChargeEditor(charge)} title={`Abrir ${charge.kind === "work" ? "trabalho" : "venda"}`}><span>{charge.kind === "work" ? "✨" : "🛍️"}</span><small>{index+1}</small></button><button type="button" aria-label={`Excluir ${charge.kind === "work" ? "trabalho" : "venda"}`} onClick={e=>{e.stopPropagation();deleteRelatedCharge(charge.id)}} style={styles.relatedChargeDelete}>×</button></div>)}
</div>
<div style={styles.consultationQuickActions}>
<button style={styles.compactSecondaryAction} onClick={newQuestion}>＋ Pergunta extra</button>
<button style={styles.compactSecondaryAction} onClick={()=>startNewRelatedCharge("work")}>✨ Trabalho</button>
<button style={styles.compactSecondaryAction} onClick={()=>startNewRelatedCharge("sale")}>🛍️ Venda</button>
<button style={styles.compactSecondaryAction} onClick={()=>openQuickBudgetForClient(activeConsultation.clientId)}>💼 Orçamento</button>
{activeConsultation.preWorkReading && <button style={styles.compactSecondaryAction} onClick={()=>openPreWorkBudget(activeConsultation)}>🔥 Vender trabalho</button>}
</div>
<section style={styles.card}>
<div style={styles.cardHeader}><div><div style={styles.eyebrow}>INFORMAÇÕES RECEBIDAS</div><h2 style={styles.cardTitle}>Material enviado pelo consulente</h2></div><button type="button" style={styles.smallButton} onClick={openIntakeEditorForActiveConsultation}>✏️ Editar</button></div>
{activeConsultation.intakeNotes && (
<div style={{ ...styles.noteBox, marginTop: 12 }}>
{activeConsultation.intakeNotes}
</div>
)}
{(activeConsultation.intakePhotos?.length || 0) > 0 && (
<div style={styles.photoGrid}>
{activeConsultation.intakePhotos?.map((photo,index) => (<div key={photo.id} style={styles.photoThumbCard} onClick={()=>setSelectedIntakePhotoId(photo.id)}><img src={photo.data} alt={photo.name} style={styles.photoThumb}/><div style={styles.photoThumbFooter}><strong>Arquivo {index+1}</strong><span>🔎 Abrir</span></div></div>))}
</div>
)}
{(activeConsultation.intakeAudios?.length || 0) > 0 && (
<div style={styles.list}>
{activeConsultation.intakeAudios?.map((audio) => (
<AudioPlayer audio={audio} />
))}
</div>
)}
</section>
{currentQuestion && (
<>
<section
style={styles.card}
>
<div
style={
styles.cardHeader
}
>
<div>
<div
style={
styles.eyebrow
}
>
PERGUNTA{" "}
{
currentQuestion.number
}
</div>
<h2
style={
styles.cardTitle
}
>
Pergunta da consulente
</h2>
</div>
{currentQuestion.completed && (
<span
style={
styles.successBadge
}
>
Salva
</span>
)}
</div>
{currentQuestion.relatedWorkId && (()=>{ const work=getClientWorkOptions(activeConsultation.clientId).find(x=>x.id===currentQuestion.relatedWorkId); const stats=getWorkQuestionStats(currentQuestion.relatedWorkId); return <div style={{...styles.infoBox,marginBottom:12,border:"1px solid #e4bfd5"}}>
  <strong>🔮 Pergunta relacionada ao trabalho</strong>
  <div>{work?.title || currentQuestion.relatedWorkTitle || "Trabalho"}</div>
  <div style={styles.muted}>Pergunta nº {currentQuestion.workQuestionNumber || "—"} deste trabalho · {stats.total} registrada(s) · {stats.paid} paga(s) · {stats.courtesy} cortesia(s)</div>
  <div style={{marginTop:6,fontWeight:850}}>{currentQuestion.workQuestionKind === "benefit" ? "🎁 Benefício do trabalho · pergunta gratuita utilizada" : currentQuestion.workQuestionKind === "courtesy" ? "🎁 Cortesia extra · não é o benefício do trabalho" : "💰 Pergunta paga relacionada ao trabalho"}</div>
</div>; })()}
<label
style={styles.label}
>
O que a pessoa perguntou?
</label>
<textarea
value={
currentQuestion.text
}
onChange={(event) =>
updateCurrentQuestion(
{
text:
event.target
.value,
}
)
}
placeholder="Digite a pergunta da consulente..."
style={
styles.textarea
}
/>
<div style={{...styles.muted,marginTop:6}}>✓ A pergunta fica salva dentro deste atendimento e só entra no Histórico quando o atendimento for finalizado.</div>
<label
style={styles.label}
>
Notas da leitura
</label>
<textarea
value={
currentQuestion.notes
}
onChange={(event) =>
updateCurrentQuestion(
{
notes:
event.target
.value,
}
)
}
placeholder="Anote cartas, interpretação, observações..."
style={
styles.textarea
}
/>
</section>
<section style={styles.card}>
<div style={styles.cardHeader}>
<div>
<div style={styles.eyebrow}>REGISTRO VISUAL</div>
<h2 style={styles.cardTitle}>Fotos e áudios da pergunta</h2>
</div>
<div style={{display:"grid",gridTemplateColumns:"repeat(2,minmax(0,1fr))",gap:8,width:"100%"}}>
  <button type="button" style={styles.primaryButton} onClick={() => takeNativePhoto("question")}>📷 Tirar foto</button>
  <button type="button" style={styles.primaryButton} onClick={() => handleOpenAudioRecorderClick({kind:"question"})}>🎙️ Gravar áudio</button>
  <label style={styles.primaryButton}>🖼️ Galeria<input type="file" accept="image/*" multiple onChange={addPhoto} style={{display:"none"}} /></label>
  <label style={styles.primaryButton}>🎵 Importar áudio<input type="file" accept="audio/*,.m4a,.aac,.mp3,.wav,.ogg" multiple onChange={e=>void addQuestionAudiosFromFiles(e)} style={{display:"none"}} /></label>
</div>
</div>

<div style={{display:"grid",gap:14,marginTop:12}}>
  <div>
    <div style={{fontWeight:850,marginBottom:8}}>📷 Fotos adicionadas {currentQuestion.photos.length ? `(${currentQuestion.photos.length})` : ""}</div>
    {currentQuestion.photos.length === 0 ? <div style={styles.emptyBox}>Nenhuma foto adicionada.</div> : <div style={styles.photoGrid}>
      {currentQuestion.photos.map((photo, photoIndex) => <div key={photo.id} style={{...styles.photoThumbCard,position:"relative"}}>
        <button type="button" onClick={() => openPhotoModal(photo)} style={{display:"grid",gap:6,width:"100%",border:0,background:"transparent",padding:0,textAlign:"left",cursor:"pointer"}} aria-label={`Abrir Carta ${photoIndex + 1}`}>
          <img src={photo.data} alt={`Carta ${photoIndex + 1}`} style={styles.photoThumb} />
          <div style={styles.photoThumbFooter}><strong>Carta {photoIndex + 1}</strong><span>🔎 Abrir</span></div>
        </button>
        <div style={{display:"flex",gap:6,flexWrap:"wrap",padding:"0 8px 8px"}}>
          <button type="button" style={styles.smallButton} onClick={() => sharePhoto(photo)}>↗ Compartilhar foto</button>
          {photo.audios?.length > 0 && <button type="button" style={styles.smallButton} onClick={() => sharePhotoAndAudio(photo)}>📤 Foto + áudio</button>}
          <button type="button" style={styles.deleteButton} onClick={() => removePhoto(photo.id)}>🗑️ Excluir</button>
        </div>
        {photo.note ? <div style={styles.photoThumbNote}>📝 Observação salva</div> : null}
      </div>)}
    </div>}
  </div>

  <div>
    <div style={{fontWeight:850,marginBottom:8}}>🎙️ Áudios gravados/importados {currentQuestion.audios.length ? `(${currentQuestion.audios.length})` : ""}</div>
    {currentQuestion.audios.length === 0 ? <div style={styles.emptyBox}>Nenhum áudio salvo nesta pergunta.</div> : <div style={{display:"grid",gap:9}}>
      {currentQuestion.audios.map((audio,index)=><div key={audio.id} style={{display:"grid",gap:7,padding:10,border:"1px solid #eadfe6",borderRadius:14,background:"#fff"}}>
        <div style={{display:"flex",justifyContent:"space-between",gap:8,alignItems:"center"}}><strong>🎧 Áudio {index+1}</strong><span style={styles.muted}>{formatDuration(audio.duration)}</span></div>
        <AudioPlayer audio={audio} />
        <div style={{display:"flex",gap:7,flexWrap:"wrap"}}>
          <button type="button" style={styles.smallButton} onClick={()=>shareAudio(audio)}>↗ Compartilhar áudio</button>
          <button type="button" style={styles.deleteButton} onClick={()=>{ if(window.confirm("Mover este áudio para a lixeira?")){ sendToTrash("question_audio", `Áudio da pergunta ${currentQuestion.number}`, { consultationId: activeConsultation.id, questionId: currentQuestion.id, audio }); updateCurrentQuestion({audios: currentQuestion.audios.filter(x=>x.id!==audio.id)}); showToast("Áudio enviado para a lixeira."); }}}>🗑️ Excluir</button>
        </div>
      </div>)}
    </div>}
    {currentQuestion.audios.length > 0 && <button type="button" style={{...styles.secondaryButtonLarge,marginTop:9}} onClick={() => handleOpenAudioRecorderClick({kind:"question"})}>🎙️ Gravar mais áudio</button>}
  </div>
</div>
</section>
<section style={{...styles.card,display:"grid",gap:10}}>
  <button type="button" className="execution-accordion" onClick={()=>setQuestionResponseExpanded(v=>!v)}><span>💬 Resposta da consulente</span><strong>{questionResponseExpanded?"−":"+"}</strong></button>
  {questionResponseExpanded && <div className="execution-accordion-panel" style={{display:"grid",gap:12}}>
    <div style={styles.muted}>Registre aqui a resposta desta pergunta. Ela fica vinculada à pergunta e acompanha o atendimento quando ele for retomado.</div>
    <label style={styles.label}>Texto da resposta</label>
    <textarea value={currentQuestion.responseText || ""} onChange={e=>updateCurrentQuestion({responseText:e.target.value})} placeholder="Digite a resposta da consulente..." style={{...styles.textarea,minHeight:120}} />
    <div style={styles.compactActionGrid}>
      <button type="button" style={styles.compactActionCard} onClick={()=>takeNativePhoto("questionResponse")}><span style={styles.compactActionIcon}>📷</span><strong>Tirar foto</strong><span>{currentQuestion.responsePhotos?.length || 0} foto(s)</span></button>
      <label style={styles.compactActionCard}><span style={styles.compactActionIcon}>🖼️</span><strong>Galeria</strong><span>Adicionar foto(s)</span><input type="file" accept="image/*" multiple hidden onChange={addResponsePhotosFromFiles}/></label>
      <div style={styles.compactActionCard}><span style={styles.compactActionIcon}>🎙️</span><strong>Gravar áudio</strong><span>{currentQuestion.responseAudios?.length || 0} áudio(s)</span><button type="button" style={styles.smallButton} onClick={() => handleOpenAudioRecorderClick({kind:"questionResponse"})}>🎙️ Abrir gravador</button></div>
      <label style={styles.compactActionCard}><span style={styles.compactActionIcon}>📎</span><strong>Importar áudio</strong><span>Do aparelho</span><input type="file" accept="audio/*,.m4a,.aac,.mp3,.wav,.ogg" multiple hidden onChange={addResponseAudiosFromFiles}/></label>
    </div>
    {(currentQuestion.responsePhotos?.length || 0) > 0 && <div style={styles.photoGrid}>{(currentQuestion.responsePhotos || []).map((photo,index)=><button type="button" key={photo.id} onClick={()=>setSelectedResponsePhotoId(photo.id)} style={{border:0,background:"transparent",padding:0,textAlign:"left",cursor:"pointer"}}><div style={styles.photoThumbCard}><img src={photo.data} alt={`Resposta ${index+1}`} style={styles.photoThumb}/><div style={styles.photoThumbFooter}><strong>Foto {index+1}</strong><span>🔎 Abrir</span></div></div></button>)}</div>}
    {(currentQuestion.responseAudios?.length || 0) > 0 && <div style={{display:"grid",gap:8}}>{(currentQuestion.responseAudios || []).map(audio=><div key={audio.id} style={styles.listItem}><AudioPlayer audio={audio} /><button type="button" style={styles.deleteButton} onClick={()=>updateCurrentQuestion({responseAudios:(currentQuestion.responseAudios || []).filter(x=>x.id!==audio.id)})}>Excluir</button></div>)}</div>}
  </div>}
</section>
<section style={styles.card}>
  {currentQuestion.packageId ? <div style={styles.infoBox}>🏷️ <strong>Pacote {currentQuestion.packageQuestionCount || activeConsultation.questions.length} perguntas</strong><br/>Valor total configurado: <strong>{formatForeign(currentQuestion.packageTotal || 0, (currentQuestion.currency || activeConsultation.currency || "BRL") as CurrencyCode)}</strong> · valor individual de referência: <strong>{formatForeign(currentQuestion.value || 0, (currentQuestion.currency || activeConsultation.currency || "BRL") as CurrencyCode)}</strong>.<br/>A situação de pagamento e o recebimento são definidos somente no checkout.</div> : <div style={styles.infoBox}>💰 O preço e a situação de pagamento desta pergunta são definidos somente no checkout final do atendimento.</div>}
</section>
</>
)}
</main>
<div style={styles.consultationEndBar}><button type="button" style={styles.consultationEndButton} onClick={() => { setFinishPaymentMode("paid"); setFinishPaymentMethod("pix"); const c = (activeConsultation?.currency || activeConsultation?.questions?.find(q=>q.currency)?.currency || activeConsultation?.relatedCharges?.find(x=>x.currency)?.currency || "BRL") as CurrencyCode; setFinishCurrency(c); setCheckoutCurrency(c); setFinishForeignAmount(""); setFinishPaymentDate(""); setShowFinishConsultation(true); }}>✓ Encerrar atendimento · Ir para o checkout</button></div>
{showRelatedChargeModal && activeConsultation && (<Modal title={editingRelatedChargeId ? (relatedChargeKind === "work" ? "Editar trabalho" : "Editar venda") : (relatedChargeKind === "work" ? "Novo trabalho na tiragem" : "Nova venda na tiragem")} onClose={()=>{setShowRelatedChargeModal(false);setEditingRelatedChargeId(null);}}>
<div style={styles.infoBox}>Consulente: <strong>{activeConsultation.clientName}</strong><br/>Este registro será somado ao checkout final da tiragem.</div>
{relatedChargeKind === "work" ? (
  <>
    <label style={styles.label}>Tipo de trabalho</label>
    <div style={{display:"grid",gap:6}}>
      <select value={relatedChargeWorkTypeId} onChange={e=>{setRelatedChargeWorkTypeId(e.target.value);const w=workTypes.find(x=>x.id===e.target.value);if(w){setRelatedChargeTitle(w.name);const price=workPrice(w,relatedChargeCurrency);if(relatedChargeCurrency==="BRL")setRelatedChargeAmount(String(price));else setRelatedChargeForeignAmount(String(price));}}} style={styles.input}>
        <option value="">Selecione...</option>
        {workTypes.filter(x=>x.active).map(x=><option key={x.id} value={x.id}>{x.name}</option>)}
      </select>
      <button type="button" style={styles.smallButton} onClick={()=>openQuickCatalog("work")}>＋ Novo tipo de trabalho</button>
    </div>
  </>
) : (
  <>
    <label style={styles.label}>Item para vender</label>
    <div style={{display:"grid",gap:6}}>
      <select value={relatedChargeSaleItemId} onChange={e=>{setRelatedChargeSaleItemId(e.target.value);const x=saleItems.find(i=>i.id===e.target.value);if(x){setRelatedChargeTitle(x.name);const price=salePrice(x,relatedChargeCurrency);if(relatedChargeCurrency==="BRL")setRelatedChargeAmount(String(price));else setRelatedChargeForeignAmount(String(price));}}} style={styles.input}>
        <option value="">Selecione...</option>
        {saleItems.filter(x=>x.active).map(x=><option key={x.id} value={x.id}>{x.name} · {formatMoney(x.price)}</option>)}
      </select>
      <button type="button" style={styles.smallButton} onClick={()=>openQuickCatalog("sale")}>＋ Novo item para venda</button>
    </div>
    {saleItems.filter(x=>x.active).length===0&&<div style={styles.muted}>Cadastre itens em Configurações → Itens para venda.</div>}
  </>
)}
<label style={styles.label}>Descrição / identificação</label><input value={relatedChargeTitle} onChange={e=>setRelatedChargeTitle(e.target.value)} style={styles.input}/><label style={styles.label}>Moeda</label><select value={relatedChargeCurrency} onChange={e=>{const c=e.target.value as CurrencyCode; setRelatedChargeCurrency(c); if(relatedChargeKind === "work"){const w=workTypes.find(x=>x.id===relatedChargeWorkTypeId);const price=workPrice(w,c); if(c==="BRL") setRelatedChargeAmount(String(price)); else setRelatedChargeForeignAmount(String(price));} else {const x=saleItems.find(i=>i.id===relatedChargeSaleItemId);const price=salePrice(x,c); if(c==="BRL") setRelatedChargeAmount(String(price)); else setRelatedChargeForeignAmount(String(price));}}} style={styles.input}>{(["BRL","EUR","USD","GBP"] as CurrencyCode[]).map(c=><option key={c} value={c}>{c}</option>)}</select><label style={styles.label}>Valor {relatedChargeCurrency === "BRL" ? "(R$)" : `(${currencySymbol(relatedChargeCurrency)})`}</label><input type="number" min="0" step="0.01" value={relatedChargeCurrency === "BRL" ? relatedChargeAmount : relatedChargeForeignAmount} onChange={e=>relatedChargeCurrency === "BRL" ? setRelatedChargeAmount(e.target.value) : setRelatedChargeForeignAmount(e.target.value)} style={styles.input}/>{relatedChargeCurrency!=="BRL"&&<div style={styles.infoBox}>{relatedChargeForeignAmount?`${currencySymbol(relatedChargeCurrency)} ${relatedChargeForeignAmount} ≈ ${formatMoney((Number(String(relatedChargeForeignAmount).replace(",","."))||0)*(currencyRates[relatedChargeCurrency]||0))}`:"Aguardando valor."}</div>}<label style={styles.label}>Pagamento do trabalho</label><select value={relatedChargeBillingMode} onChange={e=>setRelatedChargeBillingMode(e.target.value as any)} style={styles.input}><option value="paid">✓ Pago</option><option value="pending">🕐 Não pago</option><option value="installments">📆 Parcelado</option><option value="free">🎁 Grátis / cortesia</option><option value="desfalque">⚠️ Desfalque</option></select>{relatedChargeBillingMode === "installments" && <div style={styles.infoBox}>O trabalho ficará marcado como parcelado. Os valores e vencimentos das parcelas serão configurados no checkout final.</div>}{relatedChargeBillingMode === "free" && <div style={styles.infoBox}>O trabalho não será incluído no valor a cobrar do checkout.</div>}{relatedChargeBillingMode === "desfalque" && <div style={{...styles.infoBox,border:"1px solid #e7b6c8"}}>O trabalho não será cobrado e o valor potencial será registrado como desfalque.</div>}<label style={styles.label}>Prioridade (1 = menor · 5 = máxima)</label><select value={relatedChargePriority} onChange={e=>setRelatedChargePriority(Math.min(5,Math.max(1,Number(e.target.value)||3)))} style={styles.input}>{[5,4,3,2,1].map(n=><option key={n} value={n}>{n}{n===5?" · Máxima":n>=4?" · Alta":n===3?" · Média":" · Baixa"}</option>)}</select><label style={styles.label}>Orçamento relacionado</label><select value={relatedChargeBudgetId} onChange={e=>setRelatedChargeBudgetId(e.target.value)} style={styles.input}><option value="">Nenhum</option>{budgets.filter(b=>b.clientId===activeConsultation.clientId).map(b=><option key={b.id} value={b.id}>{b.title}</option>)}</select>{relatedChargeKind === "work" && <section style={{...styles.card,display:"grid",gap:8,marginTop:10}}><div className="checkoutSectionTitle" style={styles.eyebrow}>📦 OBJETOS / MATERIAIS DO TRABALHO</div><button type="button" className="checkboxItem object-checkbox-card" onClick={()=>{setObjectDraftName("");setObjectDraftValue("");setObjectDraftNotes("");const c=clients.find(x=>x.id===activeConsultation.clientId);setObjectAddress("");setObjectPostalCode("");setObjectCountry("Brasil");setObjectModalContext("relatedCharge");setObjectModalKind("received");}}><span className="fake-checkbox">{relatedChargeReceivedObjects.length?"✓":""}</span><span>A cliente enviou algo para o trabalho</span></button>{relatedChargeReceivedObjects.length>0&&<div style={styles.list}>{relatedChargeReceivedObjects.map(x=><div key={x.id} style={styles.listItem}><div><strong>📥 {x.name}</strong>{x.referenceValue?<div style={styles.muted}>Valor de referência: {formatMoney(x.referenceValue)}</div>:null}{x.notes?<div style={styles.muted}>{x.notes}</div>:null}</div><button type="button" style={styles.deleteButton} onClick={()=>removeRelatedChargeObject("received",x.id)}>×</button></div>)}</div>}<button type="button" className="checkboxItem object-checkbox-card" onClick={()=>{setObjectDraftName("");setObjectDraftValue("");setObjectDraftNotes("");const c=clients.find(x=>x.id===activeConsultation.clientId);setObjectAddress(clientAddressText(c));setObjectPostalCode(clientPostalCodeText(c));setObjectCountry(c?.address?.country || c?.country || "Brasil");setObjectModalContext("relatedCharge");setObjectModalKind("sent");}}><span className="fake-checkbox">{relatedChargeSentObjects.length?"✓":""}</span><span>Eu enviei alguma coisa para a cliente</span></button>{relatedChargeSentObjects.length>0&&<div style={styles.list}>{relatedChargeSentObjects.map(x=><div key={x.id} style={styles.listItem}><div><strong>📤 {x.name}</strong>{x.referenceValue?<div style={styles.muted}>Valor de referência: {formatMoney(x.referenceValue)} · não é cobrança separada</div>:null}{x.notes?<div style={styles.muted}>{x.notes}</div>:null}</div><button type="button" style={styles.deleteButton} onClick={()=>removeRelatedChargeObject("sent",x.id)}>×</button></div>)}</div>}</section>}{relatedChargeKind === "sale" && <section style={{...styles.paymentBox,marginTop:10}}><div style={styles.eyebrow}>📦 ENVIO DA VENDA</div><label className="checkboxItem"><input type="checkbox" checked={relatedChargeNeedsConfection} onChange={e=>setRelatedChargeNeedsConfection(e.target.checked)}/> Esta venda precisa de confecção?</label>{relatedChargeNeedsConfection && <div style={styles.infoBox}>A venda ficará em <strong>Aguardando confecção</strong> na Central de Serviços.</div>}<label className="checkboxItem"><input type="checkbox" checked={relatedChargeShippingEnabled} onChange={e=>setRelatedChargeShippingEnabled(e.target.checked)}/> Esta venda precisa de envio/entrega</label>{relatedChargeShippingEnabled && <div style={{display:"grid",gap:8,marginTop:8}}><label style={styles.label}>Data/hora do envio</label><input type="datetime-local" value={relatedChargeShippingScheduledAt} onChange={e=>setRelatedChargeShippingScheduledAt(e.target.value)} style={styles.input}/><label style={styles.label}>Endereço</label><input value={relatedChargeShippingAddress} onChange={e=>setRelatedChargeShippingAddress(e.target.value)} placeholder="Rua, número, complemento" style={styles.input}/><label style={styles.label}>Telefone</label><input value={relatedChargeShippingPhone} onChange={e=>setRelatedChargeShippingPhone(e.target.value)} style={styles.input}/><label style={styles.label}>Frete Uber cobrado</label><input type="number" min="0" step="0.01" value={relatedChargeShippingUber} onChange={e=>setRelatedChargeShippingUber(e.target.value)} style={styles.input}/><label className="checkboxItem"><input type="checkbox" checked={relatedChargeShippingUberSpent} onChange={e=>{setRelatedChargeShippingUberSpent(e.target.checked);if(e.target.checked&&!relatedChargeShippingUberSpentAmount)setRelatedChargeShippingUberSpentAmount(relatedChargeShippingUber);}}/> Eu realmente gastei com Uber</label>{relatedChargeShippingUberSpent && <input type="number" min="0" step="0.01" value={relatedChargeShippingUberSpentAmount} onChange={e=>setRelatedChargeShippingUberSpentAmount(e.target.value)} placeholder="Valor realmente gasto" style={styles.input}/>}<div style={styles.muted}>O frete cobrado entra na venda. Só o Uber realmente gasto entra como saída.</div></div>}</section>}<label style={styles.label}>Agendar este trabalho (opcional)</label><input type="datetime-local" value={relatedChargeScheduledAt} onChange={e=>setRelatedChargeScheduledAt(e.target.value)} style={styles.input}/><label style={styles.label}>Observações</label><textarea value={relatedChargeNotes} onChange={e=>setRelatedChargeNotes(e.target.value)} style={{...styles.input,minHeight:80}}/><div style={{display:"flex",gap:8,flexWrap:"wrap"}}><button style={styles.primaryButtonLarge} onClick={addRelatedCharge}>{editingRelatedChargeId ? "✓ Salvar alterações" : "+ Adicionar ao checkout"}</button><button style={styles.ghostButton} onClick={()=>setShowRelatedChargeModal(false)}>Cancelar</button></div></Modal>)}
{showFinishConsultation && (
<Modal title="Checkout final do atendimento" onClose={() => setShowFinishConsultation(false)}>
<div style={styles.infoBox}><strong>{activeConsultation?.clientName}</strong><br/>Confira a tiragem, os trabalhos e as vendas antes de registrar a cobrança.</div>
<section style={styles.paymentBox}>
<div style={styles.eyebrow}>1 · O QUE FOI FEITO</div>
<div style={{display:"grid",gap:8}}>
<div className="checkoutLine" style={styles.listItem}><div><strong>🔮 Tiragem</strong><div style={styles.muted}>{checkoutQuestions.length} pergunta(s)</div></div><strong>{formatForeign(checkoutQuestionTotal(finishCurrency), finishCurrency)}</strong></div>
{checkoutQuestions.map(q=>{ const mode=q.billingMode||"included"; const qCurrency=(q.currency||finishCurrency) as CurrencyCode; const raw=Math.max(0,Number(q.value||0)); const discount=Math.min(raw,Math.max(0,Number(q.discount||0))); const net=Math.max(0,raw-discount); const displayNet=convertCurrency(net,qCurrency,finishCurrency); const potential=convertCurrency(questionPotentialAmount(q),qCurrency,finishCurrency); const editing=editingCheckoutQuestionId===q.id; return <div key={q.id} style={{...styles.listItem,display:"grid",gap:8,marginLeft:8}}>
<div style={{display:"flex",justifyContent:"space-between",gap:8,alignItems:"flex-start"}}><div><strong>Pergunta {q.number}</strong><div style={styles.muted}>{q.text.trim()||"Sem pergunta registrada."}</div></div><button type="button" style={styles.smallButton} onClick={()=>setEditingCheckoutQuestionId(editing?null:q.id)}>{editing?"Fechar":"Editar"}</button></div>
{editing ? <div style={{display:"grid",gap:6}}><div style={{display:"grid",gridTemplateColumns:"1fr 110px",gap:6}}><input type="number" min="0" step="0.01" value={q.value??0} onChange={e=>{const value=Math.max(0,Number(String(e.target.value).replace(",","."))||0);updateFinalQuestionBilling(q.id,{value,currency:qCurrency,potentialValue:Math.max(Number(q.potentialValue||0),value),billingMode:value>0?"paid":q.billingMode});}} placeholder="Valor" style={styles.input}/><select value={qCurrency} onChange={e=>updateFinalQuestionBilling(q.id,{currency:e.target.value as CurrencyCode})} style={styles.input}>{currencyList.map(c=><option key={c} value={c}>{c}</option>)}</select></div><select value={mode} onChange={e=>updateFinalQuestionBilling(q.id,{billingMode:e.target.value as QuestionBillingMode,shortfall:(e.target.value==="free"||e.target.value==="desfalque")?Number(q.potentialValue||q.value||0):0})} style={styles.input}><option value="included">Incluída no valor</option><option value="paid">Paga</option><option value="pending">A pagar</option><option value="installments">Parcelada</option><option value="free">🎁 Grátis / cortesia</option><option value="desfalque">⚠ Desfalque · não cobrado</option></select>{mode!=="free"&&<input type="number" min="0" step="0.01" value={q.discount??0} onChange={e=>updateFinalQuestionBilling(q.id,{discount:Math.max(0,Number(String(e.target.value).replace(",","."))||0)})} placeholder={`Desconto (${currencySymbol(qCurrency)})`} style={styles.input}/>}</div> : <div style={styles.muted}>Valor cadastrado: <strong>{formatForeign(raw,qCurrency)}</strong> · {mode==="included"?"incluído":mode==="free"?"grátis":mode}</div>}
{mode==="free"&&<div style={styles.infoBox}><div><span style={{textDecoration:"line-through"}}>{formatForeign(potential,qCurrency)}</span> <strong>{q.workQuestionKind ? "🎁 GRÁTIS / CORTESIA" : "⚠ GRÁTIS → DESFALQUE"}</strong></div><div style={styles.muted}>Em pergunta comum, “Grátis” com valor potencial registra automaticamente o desfalque. Benefício/cortesia de trabalho não gera desfalque.</div></div>}{mode==="desfalque"&&<div style={{...styles.infoBox,border:"1px solid #e7b6c8"}}><div><span style={{textDecoration:"line-through"}}>{formatForeign(potential,qCurrency)}</span> <strong>⚠ DESFALQUE</strong></div><div style={styles.muted}>Valor não cobrado e registrado automaticamente como desfalque.</div></div>}
{mode!=="included"&&mode!=="free"&&<div style={styles.muted}>Cobrado nesta pergunta: <strong>{formatForeign(displayNet,finishCurrency)}</strong>{discount>0?` · desconto ${formatForeign(convertCurrency(discount,qCurrency,finishCurrency),finishCurrency)}`:""}</div>}
</div>})}
{(activeConsultation?.relatedCharges || []).map(c => {
  const amount = convertCurrency(Number(c.originalAmount || 0), c.currency || "BRL", finishCurrency);
  const editing = editingCheckoutChargeId === c.id;
  const workMode = c.billingMode || "pending";
  return (
    <div key={c.id} style={styles.listItem}>
      <div style={{display:"flex",justifyContent:"space-between",gap:8,alignItems:"flex-start"}}>
        <div>
          <strong>{c.kind === "work" ? "✨ Trabalho" : "🛍️ Venda"}</strong>
          <div style={styles.muted}>{c.title}{c.workTypeName || c.saleItemName ? ` · ${c.workTypeName || c.saleItemName}` : ""}{c.budgetId ? " · 🔗 Orçamento" : ""}</div>
        </div>
        <button type="button" style={styles.smallButton} onClick={() => setEditingCheckoutChargeId(editing ? null : c.id)}>{editing ? "Fechar" : "Editar"}</button>
      </div>
      {editing ? (
        <div style={{display:"grid",gap:8,marginTop:8,padding:10,borderRadius:12,background:"#faf8fb",border:"1px solid #ead9e2"}}>
          <div style={styles.twoColumns}>
            <div>
              <label style={styles.label}>Valor</label>
              <input type="number" min="0" step="0.01" value={c.originalAmount ?? 0} onChange={e => updateRelatedCharge(c.id,{originalAmount:Math.max(0,Number(String(e.target.value).replace(",",".")) || 0)})} style={{...styles.input,width:"100%",boxSizing:"border-box"}} />
            </div>
            <div>
              <label style={styles.label}>Moeda</label>
              <select value={c.currency || "BRL"} onChange={e => { const next=e.target.value as CurrencyCode; const converted=convertCurrency(Number(c.originalAmount || 0),(c.currency || "BRL") as CurrencyCode,next); updateRelatedCharge(c.id,{currency:next,originalAmount:Number(converted.toFixed(2))}); }} style={{...styles.input,width:"100%",boxSizing:"border-box"}}>
                {currencyList.map(x => <option key={x} value={x}>{x}</option>)}
              </select>
            </div>
          </div>
          <div style={styles.muted}>Valor no checkout: <strong>{formatForeign(convertCurrency(Number(c.originalAmount || 0),c.currency || "BRL",finishCurrency),finishCurrency)}</strong></div>
          {c.kind === "work" && (
            <div style={{display:"grid",gap:6,marginTop:6}}>
              <label style={styles.label}>Situação do pagamento</label>
              <select value={workMode} onChange={e => updateRelatedCharge(c.id,{billingMode:e.target.value as any,potentialAmount:Number(c.potentialAmount ?? c.originalAmount ?? 0)})} style={styles.input}>
                <option value="paid">✓ Pago</option>
                <option value="pending">🕐 Não pago</option>
                <option value="installments">📆 Parcelado</option>
                <option value="free">🎁 Grátis / cortesia</option>
                <option value="desfalque">⚠️ Desfalque</option>
              </select>
              {workMode === "installments" && <div style={styles.muted}>As parcelas e vencimentos serão definidos no fechamento do checkout.</div>}
              {(workMode === "free" || workMode === "desfalque") && <div style={styles.infoBox}>{workMode === "desfalque" ? "O valor não será cobrado e será registrado como desfalque." : "O trabalho será tratado como grátis/cortesia e não será cobrado."}</div>}
            </div>
          )}
        </div>
      ) : (
        <div>
          <strong>{formatForeign(amount,finishCurrency)}</strong>
          {c.kind === "work" && <div style={styles.muted}>{workMode === "paid" ? "✓ Pago" : workMode === "installments" ? "📆 Parcelado" : workMode === "free" ? "🎁 Grátis / cortesia" : workMode === "desfalque" ? "⚠️ Desfalque" : "🕐 Não pago"}</div>}
        </div>
      )}
    </div>
  );
})}
</div>
</section>
<section style={styles.paymentBox}>
<div className="checkoutSectionTitle" style={styles.eyebrow}>2 · MOEDA E RECEBIMENTO</div>
<label style={styles.label}>Moeda do checkout (todo o atendimento será calculado nesta moeda)</label>
<select value={finishCurrency} onChange={e=>{const c=e.target.value as CurrencyCode; setFinishCurrency(c); setCheckoutCurrency(c);}} style={styles.input}>{(["BRL","EUR","USD","GBP"] as CurrencyCode[]).map(c=><option key={c} value={c}>{c}</option>)}</select>
<div style={{...styles.infoBox,display:"grid",gap:4}}>
<div style={{fontSize:12,fontWeight:800,opacity:.7}}>RESUMO DO CHECKOUT</div>
<div style={styles.checkoutSummaryRow}><span>Perguntas</span><strong>{formatForeign(checkoutQuestionTotal(finishCurrency),finishCurrency)}</strong></div>
<div style={styles.checkoutSummaryRow}><span>Trabalhos e vendas</span><strong>{formatForeign(checkoutRelatedTotal(finishCurrency),finishCurrency)}</strong></div>{checkoutDesfalqueTotal > 0 && <div style={styles.checkoutSummaryRow}><span>⚠️ Desfalques</span><strong>{formatForeign(checkoutDesfalqueTotal,finishCurrency)}</strong></div>}
<div style={styles.checkoutTotalProfessional}><div><span style={styles.muted}>TOTAL A COBRAR</span><div style={{fontSize:29,fontWeight:900}}>R$ {convertToBRL(checkoutTotal,finishCurrency).toFixed(2)}</div>{finishCurrency!=="BRL"&&<div style={{fontSize:13,fontWeight:800,opacity:.7}}>{formatForeign(checkoutTotal,finishCurrency)} · moeda escolhida</div>}</div><div style={{textAlign:"right"}}><span style={styles.muted}>Cotação</span><br/><strong>{finishCurrency === "BRL" ? "1,0000" : `1 ${currencySymbol(finishCurrency)} = ${formatMoney(finishSelectedRate)}`}</strong></div></div>
</div>
<div style={styles.eyebrow}>3 · COBRANÇA</div>
<div style={styles.segmented}>{(["paid","pending","installments","free"] as const).filter(mode => mode !== "free" || !checkoutQuestions.some(q => !!q.relatedWorkId)).map(mode=><button key={mode} type="button" style={{...styles.segmentButton,...(finishPaymentMode===mode?styles.segmentActive:{})}} onClick={()=>setFinishPaymentMode(mode)}>{mode==="paid"?"✓ Pago":mode==="pending"?"🕐 Não pago":mode==="installments"?"📆 Parcelado":"🎁 Grátis"}</button>)}</div>
{finishPaymentMode!=="free"&&<><label style={styles.label}>Forma de recebimento</label><select value={finishPaymentMethod} onChange={e=>setFinishPaymentMethod(e.target.value as PaymentMethod)} style={styles.input}>{(["pix","credit","debit","cash","transfer","paypal","wise","other"] as PaymentMethod[]).map(m=><option key={m} value={m}>{m==="paypal"?"PayPal":m==="wise"?"Wise":m==="pix"?"Pix":m==="credit"?"Cartão de crédito":m==="debit"?"Cartão de débito":m==="cash"?"Dinheiro":m==="transfer"?"Transferência":"Outro"}</option>)}</select></>}
{finishPaymentMode==="pending"&&<><label style={styles.label}>Vencimento</label><input type="date" value={finishPaymentDate} onChange={e=>setFinishPaymentDate(e.target.value)} style={styles.input}/></>}
{finishPaymentMode==="installments"&&<div style={{display:"grid",gap:10}}><label style={styles.label}>Número de parcelas</label><input type="number" min="2" value={finishInstallmentCount} onChange={e=>setFinishInstallmentCount(e.target.value)} style={styles.input}/><label style={styles.checkboxItem}><input type="checkbox" checked={finishInstallmentEntry} onChange={e=>{const enabled=e.target.checked;setFinishInstallmentEntry(enabled);setFinishInstallmentRows(prev=>prev.map((row,i)=>{const d=new Date();d.setDate(1);d.setMonth(d.getMonth()+i+1);return {...row,dueDate:d.toISOString().slice(0,10),status:"pending" as "pending"};}));}}/> Dar entrada agora</label><div style={{...styles.infoBox,display:"grid",gap:8}}><strong>Entrada e parcelas — ajuste valor e vencimento</strong>{finishInstallmentEntry&&<div style={{display:"grid",gridTemplateColumns:"52px 1fr 1fr",gap:6,alignItems:"center",background:"#f1ebf5",padding:7,borderRadius:10}}><strong>ENT.</strong><input type="number" min="0" step="0.01" value={finishEntryAmount} onChange={e=>setFinishEntryAmount(e.target.value)} style={styles.input}/><div style={{...styles.input,display:"flex",alignItems:"center",boxSizing:"border-box"}}>Hoje · {new Date().toLocaleDateString("pt-BR")}</div></div>}{finishInstallmentRows.map(row=><div key={row.id} style={{display:"grid",gridTemplateColumns:"52px 1fr 1fr",gap:6,alignItems:"center"}}><strong>#{row.number}</strong><input type="number" min="0" step="0.01" value={row.amount} onChange={e=>setFinishInstallmentRows(prev=>prev.map(x=>x.id===row.id?{...x,amount:e.target.value}:x))} style={styles.input}/><input type="date" value={row.dueDate} onChange={e=>setFinishInstallmentRows(prev=>prev.map(x=>x.id===row.id?{...x,dueDate:e.target.value}:x))} style={styles.input}/></div>)}<div style={styles.muted}>Os valores acima estão em {finishCurrency}. {finishInstallmentEntry?"A entrada é registrada hoje como paga; a parcela #1 vence no próximo mês.":"Sem entrada: a parcela #1 vence no próximo mês."}</div></div></div>}
{(finishPaymentMethod === "paypal" || finishPaymentMethod === "wise" || finishPaymentMethod === "other") && finishPaymentMode!=="free" && <div style={styles.infoBox}><div><strong>Taxa {finishPaymentMethod === "paypal" ? "PayPal" : finishPaymentMethod === "wise" ? "Wise" : "da forma selecionada"}:</strong> {finishFeePercentPreview.toFixed(2)}%</div><div><strong>Taxa estimada:</strong> {formatMoney(finishFeeBRLPreview)}</div><div><strong>Líquido estimado:</strong> {formatForeign(finishNetForeignPreview,finishCurrency)} · {formatMoney(finishNetBRLPreview)}</div></div>}
</section>
<div style={{display:"flex",gap:8,flexWrap:"wrap"}}><button style={styles.primaryButtonLarge} onClick={finalizeConsultationPayment}>{finishPaymentMode==="paid" ? (checkoutTotal <= 0 && checkoutDesfalqueTotalBRL > 0 ? "✓ Encerrar e registrar desfalques" : "✓ Encerrar e registrar pagamento") : finishPaymentMode==="free" ? "✓ Encerrar como grátis" : finishPaymentMode==="installments" ? "✓ Encerrar com parcelamento" : "✓ Encerrar e registrar pendência"}</button>{activeConsultation?.status === "active" && <button style={styles.secondaryButtonLarge} onClick={()=>{setShowFinishConsultation(false);putOnStandby();}}>Salvar em standby</button>}</div>
</Modal>
)}

{selectedIntakePhoto && activeConsultation && (<Modal title="Foto recebida" onClose={()=>setSelectedIntakePhotoId(null)}><div style={styles.photoModalContent}><img src={selectedIntakePhoto.data} alt={selectedIntakePhoto.name} style={styles.photoLarge}/><div style={styles.photoModalActions}><button style={styles.smallButton} onClick={()=>sharePhoto(selectedIntakePhoto)}>Compartilhar foto</button><button style={styles.smallButton} onClick={()=>savePhotoToDevice(selectedIntakePhoto)}>💾 Salvar foto</button><button style={styles.deleteButton} onClick={()=>deleteIntakePhoto(selectedIntakePhoto.id)}>🗑️ Excluir</button></div>{selectedIntakePhoto.note && <div style={styles.noteBox}>{selectedIntakePhoto.note}</div>}</div></Modal>)}
{selectedResponsePhotoId && currentQuestion && (() => { const photo = (currentQuestion.responsePhotos || []).find(p => p.id === selectedResponsePhotoId); if (!photo) return null; return <Modal title="Foto · resposta da consulente" onClose={()=>setSelectedResponsePhotoId(null)}><div style={styles.photoModalContent}><img src={photo.data} alt="Foto da resposta da consulente" style={styles.photoLarge}/><button type="button" style={styles.secondaryButtonLarge} onClick={()=>setSelectedResponsePhotoId(null)}>Fechar</button></div></Modal>; })()}
{selectedPhoto && currentQuestion && (
<Modal title={`Carta ${currentQuestion.photos.findIndex(p => p.id === selectedPhoto.id) + 1}`} onClose={() => { setSelectedPhotoId(null); setPhotoNoteDraft(""); }}>
  <div style={styles.photoModalContent}>
    <img src={selectedPhoto.data} alt="Carta ampliada" style={styles.photoLarge} />
    <div style={styles.photoModalActions}>
      <button style={styles.smallButton} onClick={() => sharePhoto(selectedPhoto)}>Compartilhar foto</button>
      <button style={styles.smallButton} onClick={() => sharePhotoAndAudio(selectedPhoto)}>📤 Compartilhar foto + áudio</button>
      <button style={styles.smallButton} onClick={() => savePhotoToDevice(selectedPhoto)}>💾 Salvar foto</button>
      <button style={styles.deleteButton} onClick={() => removePhoto(selectedPhoto.id)}>🗑️ Mover foto para lixeira</button>
    </div>
    <label style={styles.label}>Observação desta foto</label>
    <textarea value={photoNoteDraft} onChange={e => setPhotoNoteDraft(e.target.value)} placeholder="Escreva a interpretação ou observação desta carta..." style={styles.textarea} />
    <button style={styles.primaryButtonLarge} onClick={savePhotoNote}>✓ Salvar observação</button>
    <div style={styles.photoModalSectionTitle}>Áudios desta foto ({(selectedPhoto.audios || []).length})</div>
    {(selectedPhoto.audios || []).map((audio, index) => (
      <div key={audio.id} style={styles.photoAudioItem}>
        <div style={styles.photoAudioTitle}><strong>🎧 Áudio {index + 1}</strong><span style={styles.muted}>{formatDuration(audio.duration)}</span></div>
        <div style={{...styles.audioWave,marginBottom:7}}>{[0,1,2,3,4,5,6,7,8,9].map(i=><span key={i} style={{...styles.audioWaveBar,height:[9,16,22,13,19,11,21,15,18,10][i]}} />)}</div>
        <AudioPlayer audio={audio} />
        <div style={styles.photoAudioActions}>
          
          <button style={styles.smallButton} onClick={() => { setTrimAudio(audio); setTrimStart("0"); setTrimEnd(String(Math.round(audio.duration))); }}>Cortar</button>
          <button style={styles.smallButton} onClick={() => shareAudio(audio)}>Compartilhar</button>
          <button style={styles.deleteButton} onClick={() => deletePhotoAudio(selectedPhoto.id, audio.id)}>Excluir</button>
        </div>
      </div>
    ))}
  </div>
</Modal>
)}
{trimAudio && (
<Modal
title="Cortar áudio"
onClose={() =>
setTrimAudio(null)
}
>
<p
style={
styles.modalText
}
>
Informe o trecho que deseja
manter.
</p>
<div
style={
styles.twoColumns
}
>
<div>
<label
style={
styles.label
}
>
Início (segundos)
</label>
<input
type="number"
min="0"
value={trimStart}
onChange={(event) =>
setTrimStart(
event.target.value
)
}
style={
styles.input
}
/>
</div>
<div>
<label
style={
styles.label
}
>
Fim (segundos)
</label>
<input
type="number"
min="0"
value={trimEnd}
onChange={(event) =>
setTrimEnd(
event.target.value
)
}
style={
styles.input
}
/>
</div>
</div>
<button
style={
styles.primaryButtonLarge
}
onClick={
trimCurrentAudio
}
>
✓ Salvar áudio cortado
</button>
<button
style={
styles.secondaryButtonLarge
}
onClick={() =>
setTrimAudio(null)
}
>
Cancelar
</button>
</Modal>
)}
{objectModalKind && <Modal title={objectModalKind === "received" ? "Objeto recebido para o trabalho" : "Objeto enviado para a cliente"} onClose={()=>setObjectModalKind(null)}><div style={styles.infoBox}>{objectModalContext === "relatedCharge" ? "Este objeto ficará vinculado ao trabalho criado dentro da tiragem e não altera o valor do checkout." : objectModalKind === "received" ? "Registre o que a cliente enviou. Isso fica vinculado ao trabalho e não cria cobrança." : "Registre o que você enviou para a cliente. O endereço abaixo é usado para identificar o destino do envio; não será criada uma venda separada."}</div><label style={styles.label}>O que é?</label><input value={objectDraftName} onChange={e=>setObjectDraftName(e.target.value)} placeholder="Ex.: Colar de pirita" style={styles.input}/><label style={styles.label}>Valor de referência (opcional)</label><input type="number" min="0" step="0.01" value={objectDraftValue} onChange={e=>setObjectDraftValue(e.target.value)} style={styles.input}/><label style={styles.label}>Observação</label><textarea value={objectDraftNotes} onChange={e=>setObjectDraftNotes(e.target.value)} style={{...styles.input,minHeight:90}}/>{objectModalKind === "sent" && <section style={{...styles.infoBox,display:"grid",gap:8}}><strong>📍 Endereço da cliente para envio</strong><input value={objectAddress} onChange={e=>setObjectAddress(e.target.value)} placeholder="Endereço completo" style={styles.input}/><div className="twoColumns"><input value={objectPostalCode} onChange={e=>setObjectPostalCode(e.target.value)} placeholder="CEP / código postal" style={styles.input}/><input value={objectCountry} onChange={e=>setObjectCountry(e.target.value)} placeholder="País" style={styles.input}/></div><div style={styles.muted}>Se a consulente já tiver endereço cadastrado, ele é preenchido automaticamente.</div></section>}<button type="button" style={styles.primaryButtonLarge} onClick={objectModalContext === "relatedCharge" ? saveRelatedChargeObject : objectModalContext === "workSetup" ? saveWorkSetupObject : saveServiceObject}>✓ Salvar registro</button><button type="button" style={styles.secondaryButtonLarge} onClick={()=>setObjectModalKind(null)}>Cancelar</button></Modal>}
{selectedServicePhotoId && <Modal title="Foto selecionada" onClose={()=>setSelectedServicePhotoId(null)}>{(()=>{const photo=servicePhotos.find(p=>p.id===selectedServicePhotoId); if(!photo)return null; return <div style={styles.photoModalContent}><img src={photo.data} alt={photo.name} style={styles.photoLarge}/><div style={styles.photoModalActions}><button type="button" style={styles.deleteButton} onClick={()=>deleteDraftServicePhoto(photo.id)}>🗑️ Excluir foto</button><button type="button" style={styles.secondaryButtonLarge} onClick={()=>setSelectedServicePhotoId(null)}>Fechar</button></div></div>;})()}</Modal>}
{showIntakeModal && (
  <Modal title="Editar informações recebidas" onClose={() => { setShowIntakeModal(false); setIntakeEditingExisting(false); }}>
    <div style={styles.infoBox}>Edite o material recebido sem sair do atendimento. As alterações ficam guardadas no atendimento atual e só entram no Histórico quando ele for finalizado.</div>
    <label style={styles.label}>Texto / contexto recebido</label>
    <textarea value={intakeNotes} onChange={event => setIntakeNotes(event.target.value)} placeholder="Textos, contexto do WhatsApp e observações importantes..." style={{ ...styles.input, minHeight: 170 }} />
    <div className="compactActionGrid">
      <button type="button" style={styles.compactActionCard} onClick={() => takeNativePhoto("intake")}><span style={styles.compactActionIcon}>📷</span><strong>Tirar foto</strong><span>Usar a câmera</span></button>
      <label style={styles.compactActionCard}><span style={styles.compactActionIcon}>🖼️</span><strong>Adicionar print/foto</strong><span>{intakePhotos.length} arquivo(s)</span><input type="file" accept="image/*" multiple hidden onChange={addIntakePhotos} /></label>
      <div style={styles.compactActionCard}><span style={styles.compactActionIcon}>🎙️</span><strong>Gravar áudio</strong><span>{intakeAudios.length} áudio(s) anexado(s)</span><button type="button" style={styles.smallButton} onClick={() => handleOpenAudioRecorderClick({kind:"intake"})}>🎙️ Abrir gravador</button></div>
      <label style={styles.compactActionCard}><span style={styles.compactActionIcon}>🎧</span><strong>Adicionar áudio</strong><span>{intakeAudios.length} arquivo(s)</span><input type="file" accept="audio/*" multiple hidden onChange={addIntakeAudios} /></label>
    </div>
    {recording && <div style={{display:"flex",gap:8,flexWrap:"wrap"}}><button type="button" style={styles.smallButton} onClick={recordingPaused?resumeRecording:pauseRecording}>{recordingPaused?"▶ Retomar":"⏸ Pausar"}</button><button type="button" style={styles.primaryButtonLarge} onClick={stopRecording}>⏹ Finalizar e salvar</button></div>}
    {intakePhotos.length>0&&<div style={styles.photoGrid}>{intakePhotos.map((photo,index)=><button type="button" key={photo.id} onClick={()=>setSelectedIntakePhotoId(photo.id)} style={{border:0,background:"transparent",padding:0,textAlign:"left",cursor:"pointer"}}><div style={styles.photoThumbCard}><img src={photo.data} alt={photo.name} style={styles.photoThumb}/><div style={styles.photoThumbFooter}><strong>Foto {index+1}</strong><span>🔎 Abrir</span></div></div></button>)}</div>}
    {intakeAudios.length>0&&<div style={{display:"grid",gap:8}}>{intakeAudios.map(audio=><div key={audio.id} style={styles.listItem}><AudioPlayer audio={audio} /><button type="button" style={styles.deleteButton} onClick={()=>setIntakeAudios(prev=>prev.filter(x=>x.id!==audio.id))}>Excluir</button></div>)}</div>}
    <button style={styles.primaryButtonLarge} onClick={saveIntakeModal}>✓ Salvar informações</button>
  </Modal>
)}
{quickCatalogKind && (
  <div className="quick-catalog-layer" role="dialog" aria-modal="true" aria-label={quickCatalogKind==="stock"?"Novo item de estoque":quickCatalogKind==="work"?"Novo tipo de trabalho":quickCatalogKind==="category"?"Nova categoria":quickCatalogKind==="sale"?"Novo item para venda":"Nova tiragem"}>
    <div className="quick-catalog-sheet">
      <div className="modal-header" style={styles.modalHeader}>
        <div style={{minWidth:0}}>
          <h2 className="modal-title" style={styles.modalTitle}>{quickCatalogKind==="stock"?"Novo item de estoque":quickCatalogKind==="work"?"Novo tipo de trabalho":quickCatalogKind==="category"?"Nova categoria":quickCatalogKind==="sale"?"Novo item para venda":"Nova tiragem"}</h2>
          <AppDateTime compact />
        </div>
        <button type="button" aria-label="Fechar cadastro rápido" style={styles.modalClose} onClick={()=>{setQuickCatalogKind(null);setQuickCatalogReturnContext(null);}}>×</button>
      </div>
      <div className="modal-body-scroll" style={styles.modalBodyScroll}>
        <div style={styles.infoBox}>Cadastre sem sair da tela atual. Depois de salvar, o novo item ficará disponível no campo que você estava preenchendo.</div>
        <label style={styles.label}>Nome</label><input autoFocus value={quickCatalogName} onChange={e=>setQuickCatalogName(e.target.value)} style={styles.input}/>
        {quickCatalogKind!=="category" && <label style={styles.label}>Preço padrão em BRL</label>}{quickCatalogKind!=="category" && <input type="number" min="0" step="0.01" value={quickCatalogPrice} onChange={e=>setQuickCatalogPrice(e.target.value)} style={styles.input}/>}
        {quickCatalogKind==="reading" && <><label style={styles.label}>Quantidade de perguntas</label><input type="number" min="1" value={quickCatalogQuestions} onChange={e=>setQuickCatalogQuestions(e.target.value)} style={styles.input}/></>}
        {quickCatalogKind==="category" && <><label style={styles.label}>Setor</label><select value={quickCatalogSectorId} onChange={e=>setQuickCatalogSectorId(e.target.value)} style={styles.input}>{householdSectors.filter(x=>x.active).map(x=><option key={x.id} value={x.id}>{x.name}</option>)}</select></>}
        <button style={styles.primaryButtonLarge} onClick={saveQuickCatalog}>✓ Salvar cadastro</button>
        <button style={styles.secondaryButtonLarge} onClick={()=>{setQuickCatalogKind(null);setQuickCatalogReturnContext(null);}}>Cancelar</button>
      </div>
    </div>
  </div>
)}
{selectedClientPhoto && (
  <Modal title={`Foto · ${selectedClientPhoto.name}`} onClose={()=>setSelectedClientPhoto(null)}>
    <div style={styles.photoModalContent}>
      <img
        src={selectedClientPhoto.data}
        alt={`Foto de ${selectedClientPhoto.name}`}
        style={{...styles.photoLarge,maxHeight:"58vh",objectFit:"contain",borderRadius:18}}
      />
      <div style={{display:"grid",gap:8,width:"100%"}}>
        {selectedClientPhoto.id && (
          <button
            type="button"
            style={{...styles.primaryButtonLarge,minHeight:52,padding:"12px 16px",fontSize:16}}
            onClick={()=>{
              const client=clients.find(x=>x.id===selectedClientPhoto.id);
              if(client) editClient(client);
              setSelectedClientPhoto(null);
            }}
          >
            ✏️ Editar foto do consulente
          </button>
        )}
        <button
          type="button"
          style={{...styles.secondaryButtonLarge,minHeight:48,padding:"11px 16px",fontSize:15}}
          onClick={()=>setSelectedClientPhoto(null)}
        >
          Fechar
        </button>
      </div>
    </div>
  </Modal>
)}
{toast && (
<Toast message={toast} />
)}
</div>
);
}
/* =========================================================
RENDER PRINCIPAL
========================================================= */
return (
<div style={styles.app}>
{audioRecorderPortal}
{permissionSetupOpen && <Modal title="Preparar permissões" onClose={()=>setPermissionSetupOpen(false)}><div style={{display:"grid",gap:10}}><div style={styles.infoBox}><strong>🔐 Permissões do aplicativo</strong><div style={styles.muted}>Você continua no Início do aplicativo. Para Sobreposição e Alarmes, toque em <strong>Configurar</strong> somente quando quiser abrir a tela do Android. O aplicativo não abre essas configurações sozinho.</div></div>{[{key:"notifications",label:"🔔 Notificações"},{key:"camera",label:"📷 Câmera"},{key:"microphone",label:"🎙️ Microfone"},{key:"contacts",label:"👥 Contatos"},{key:"overlay",label:"🪟 Sobreposição sobre outros aplicativos"},{key:"exactAlarm",label:"⏰ Alarmes e lembretes"}].map((item:any)=><div key={item.key} className="permission-row"><div><strong>{item.label}</strong><div className="muted">{permissionSetupStatus[item.key as keyof typeof permissionSetupStatus]?"Permitido":"Pendente"}</div></div><button style={permissionSetupStatus[item.key as keyof typeof permissionSetupStatus]?styles.smallButton:styles.primaryButton} onClick={async()=>{try{if(item.key==="notifications"){const r=await LocalNotifications.requestPermissions();setPermissionSetupStatus(p=>({...p,notifications:r.display==="granted"}));}else if(item.key==="camera"){const r=await Camera.requestPermissions({permissions:["camera"]});setPermissionSetupStatus(p=>({...p,camera:r.camera==="granted"}));}else if(item.key==="microphone"){const r=await PermissionBridge.requestMicrophone();setPermissionSetupStatus(p=>({...p,microphone:r.granted}));}else if(item.key==="contacts"){const r=await PermissionBridge.requestContacts();setPermissionSetupStatus(p=>({...p,contacts:r.granted}));}else if(item.key==="overlay"){await PermissionBridge.openOverlaySettings?.();}else if(item.key==="exactAlarm"){await PermissionBridge.openAlarmSettings?.();}}catch{showToast("Não foi possível abrir essa configuração agora.");}}}>{permissionSetupStatus[item.key as keyof typeof permissionSetupStatus]?"✓ Permitido":"Configurar"}</button></div>)}<div style={styles.muted}>Você pode revisar essas permissões depois nas configurações do Android. Para testar um trabalho agendado, deixe pelo menos Notificações e Alarmes autorizados.</div><button style={styles.primaryButtonLarge} onClick={()=>setPermissionSetupOpen(false)}>✓ Continuar</button></div></Modal>}

<header style={styles.topbar}>
<div style={styles.topbarLeft}>
<button style={styles.menuButton} aria-label="Abrir menu" onClick={() => setMenuOpen(true)}>☰</button>
</div>
<div className="top-mode-tabs">
 <button className={screen!=="organization"&&screen!=="routine"&&screen!=="tools"?"active":""} onClick={()=>setScreen("dashboard")}>🔮 Trabalho & Financeiro</button>
 <button className={screen==="organization"||screen==="routine"?"active":""} onClick={()=>{setOrganizationSection("index");setScreen("organization");}}>🏠 Organização</button>
 <button className={screen==="tools"?"active":""} onClick={()=>setScreen("tools")}>🧰 Ferramentas</button>
</div>

</header>
<main style={styles.main}>
{/* =================================================
DASHBOARD
================================================= */}
<OrganizationWorkspace ctx={{
      addCycleEntry,
      addHealthEntry,
      addMedication,
      addRoutineTemplate,
      agendaClientId,
      agendaDate,
      agendaDescription,
      agendaItems,
      agendaNotify,
      agendaPriority,
      agendaTime,
      agendaTitle,
      clients,
      cycleCramps,
      cycleEndDate,
      cycleNotes,
      cycleStartDate,
      exportOrganizationBackup,
      familyMembers,
      formatDate,
      futurePurchases,
      healthEntries,
      healthEvent,
      healthMemberId,
      healthMood,
      importOrganizationBackup,
      localDateKey,
      localTimeKey,
      medicationFormAlert,
      medicationFormDose,
      medicationFormDosesPerDay,
      medicationFormMember,
      medicationFormName,
      medicationFormQuantity,
      medicationFormTimes,
      medicationFormUnit,
      medicationLowStock,
      medicationTodayLogs,
      medications,
      moodOptions,
      nowISO,
      organizationAgendaDate,
      organizationAgendaOccurrences,
      organizationAgendaTab,
      organizationAppointmentComposerOpen,
      organizationBackupInputRef,
      organizationSection,
      registerMedicationDose,
      requestRoutineNotifications,
      routineChecklistDraft,
      routineConfigArea,
      routineDurationRows,
      routineFormChecklist,
      routineFormDays,
      routineFormKind,
      routineFormNotify,
      routineFormNotifyBefore,
      routineFormParticipants,
      routineFormPriority,
      routineFormResponsible,
      routineFormTime,
      routineFormTitle,
      routineLogs,
      routineSettings,
      routineTemplates,
      saveAgendaItem,
      screen,
      setAgendaCategory,
      setAgendaClientId,
      setAgendaDate,
      setAgendaDescription,
      setAgendaEditingId,
      setAgendaNotify,
      setAgendaPriority,
      setAgendaTime,
      setAgendaTitle,
      setCycleCramps,
      setCycleEndDate,
      setCycleNotes,
      setCycleStartDate,
      setEditingClientId,
      setFamilyMembers,
      setFutureArea,
      setHealthEvent,
      setHealthMemberId,
      setHealthMood,
      setMedicationFormAlert,
      setMedicationFormDose,
      setMedicationFormDosesPerDay,
      setMedicationFormMember,
      setMedicationFormName,
      setMedicationFormQuantity,
      setMedicationFormTimes,
      setMedicationFormUnit,
      setNewClientBirthDate,
      setNewClientCPF,
      setNewClientCity,
      setNewClientComplement,
      setNewClientCountry,
      setNewClientName,
      setNewClientNeighborhood,
      setNewClientNotes,
      setNewClientNumber,
      setNewClientPhone,
      setNewClientPostalCode,
      setNewClientReferrerId,
      setNewClientSource,
      setNewClientSourceDetails,
      setNewClientState,
      setNewClientStreet,
      setOrganizationAgendaDate,
      setOrganizationAgendaTab,
      setOrganizationAppointmentComposerOpen,
      setOrganizationSection,
      setReturnToAgendaClientContext,
      setRoutineChecklistDraft,
      setRoutineConfigArea,
      setRoutineFormChecklist,
      setRoutineFormDays,
      setRoutineFormKind,
      setRoutineFormNotify,
      setRoutineFormNotifyBefore,
      setRoutineFormParticipants,
      setRoutineFormPriority,
      setRoutineFormResponsible,
      setRoutineFormTime,
      setRoutineFormTitle,
      setRoutineSettings,
      setScreen,
      setSelectedClientPhoto,
      setShowHealthNoteModal,
      setShowNewClient,
      styles,
      todayRoutineDone,
      todayRoutineOccurrences,
      todayRoutinePending,
      toggleRoutineChecklist,
      toggleRoutineTemplate,
      updateRoutineLog,
      StatCard,
    }} />
{screen === "tools" && (
 <section style={styles.card}><div style={styles.eyebrow}>FERRAMENTAS</div><h2 style={styles.pageTitle}>Ferramentas</h2><div className="organization-tabs"><button className="active" onClick={()=>setToolsSection("notes")}>📝 Bloco de notas</button></div><div style={{marginTop:14}}><button style={styles.primaryButtonLarge} onClick={()=>{setScreen("notes");setToolsSection("notes");}}>Abrir bloco de notas →</button></div></section>
)}
{screen === "dashboard" && (
 <div className="dashboard-compact">
  <section style={styles.hero}>
   <div style={{...styles.eyebrow,display:"flex",alignItems:"center",justifyContent:"center",gap:8,flexWrap:"wrap",textAlign:"center"}}>
    {(() => {
      const now = new Date();
      const weekday = new Intl.DateTimeFormat("pt-BR", {weekday:"long"}).format(now);
      const date = new Intl.DateTimeFormat("pt-BR", {day:"2-digit",month:"long",year:"numeric"}).format(now);
      const time = now.toLocaleTimeString("pt-BR", {hour:"2-digit",minute:"2-digit"});
      return <span>{weekday.charAt(0).toUpperCase()+weekday.slice(1)}, {date} · {time}</span>;
    })()}
   </div>
   {(() => {
     const now = new Date();
     const nowKey = localDateKey(now);
     const priorityCandidates = [
       ...agendaItems.filter(a=>!a.completed && !a.deletedAt && a.date>=nowKey).map(a=>({id:`agenda:${a.id}`,priority:Math.min(5,Math.max(1,Number(a.priority)||3)),date:a.date,time:a.time,title:a.title,subtitle:a.description||"Agendamento",clientId:a.clientId,icon:a.category==="work"?"🔥":a.category==="family"?"🏠":"📌",source:"agenda" as const})),
       ...scheduledConsultations.filter(a=>{const c=consultations.find(x=>x.id===a.consultationId);return !!c && c.status!=="standby" && a.date>=nowKey && !agendaItems.some(ai=>ai.relatedEntityId===a.consultationId && ai.date===a.date && !ai.deletedAt);}).map(a=>{const c=consultations.find(x=>x.id===a.consultationId)!;return {id:`consult:${c.id}`,priority:Math.min(5,Math.max(1,Number((c as any).priority)||3)),date:a.date,time:a.time,title:a.title,subtitle:a.description,clientId:c.clientId,icon:c.serviceType==="work"?"🔥":c.serviceType==="sale"?"🛍️":"🔮",source:"consultation" as const};}),
     ];
     const prioritySeen = new Set<string>();
     const priorities = priorityCandidates.filter(item=>{
       const key=`${item.date}|${item.time}|${item.title.trim().toLowerCase()}|${item.clientId || ""}`;
       if(prioritySeen.has(key)) return false;
       prioritySeen.add(key);
       return true;
     }).sort((a,b)=>b.priority-a.priority || `${a.date}T${a.time}`.localeCompare(`${b.date}T${b.time}`)).slice(0,5);
     return <section style={{...styles.card,marginTop:12}}>
       <div className="dashboard-section-head"><div><div style={styles.eyebrow}>⭐ PRIORIDADES</div><h2 style={styles.cardTitle}>O que merece atenção primeiro</h2></div><span className="count-badge-small">1–5</span></div>
       <div className="dashboard-scroll-list">{priorities.length===0?<div className="compact-empty">Nenhum agendamento pendente com prioridade definida.</div>:priorities.map(item=>{
         const client=item.clientId ? clients.find(c=>c.id===item.clientId) : undefined;
         return <div key={item.id} className="dashboard-list-row priority-dashboard-row">
           <div className="priority-person-avatar" aria-hidden="true">{client?.avatarPhoto ? <img src={client.avatarPhoto} alt=""/> : <span>{(client?.name || item.subtitle || "?").trim().charAt(0).toUpperCase()}</span>}</div>
           <span className="priority-dashboard-main"><strong>{item.icon} {item.title}</strong><small>{client?.name || item.subtitle} · {formatDate(item.date)} {item.time}</small></span>
           <span className="priority-label">PRIORIDADE {item.priority}</span>
         </div>;
       })}</div>
       <div style={{...styles.muted,marginTop:8}}>A prioridade de 5 é a máxima. Em caso de empate, o compromisso mais próximo aparece primeiro.</div>
     </section>;
   })()}
   {(() => {
     const base = new Date();
     base.setDate(1);
     base.setMonth(base.getMonth()+dashboardMonthOffset);
     const monthKey = `${base.getFullYear()}-${String(base.getMonth()+1).padStart(2,"0")}`;
     const monthLabel = new Intl.DateTimeFormat("pt-BR", {month:"long",year:"numeric"}).format(base);
     const monthTitle = monthLabel.charAt(0).toUpperCase()+monthLabel.slice(1);
     const inMonth = (value?:string) => !!value && value.slice(0,7)===monthKey;
     const monthConsultations = consultations.filter(c=>c.status!=="standby" && !c.deletedAt && ((c.scheduledAt && inMonth(c.scheduledAt)) || inMonth(c.createdAt)));
     const monthReadings = monthConsultations.filter(c=>c.serviceType==="consultation");
     const monthWorks = monthConsultations.filter(c=>c.serviceType==="work" || (c.relatedCharges||[]).some(ch=>ch.kind==="work" && inMonth(ch.scheduledAt||c.createdAt)));
     const monthAgendaKeys = new Set<string>();
     agendaItems.filter(a=>!a.deletedAt && inMonth(a.date)).forEach(a=>monthAgendaKeys.add(`agenda:${a.relatedEntityId||a.id}`));
     scheduledConsultations.filter(a=>inMonth(`${a.date}T${a.time}`)).forEach(a=>monthAgendaKeys.add(`consult:${a.consultationId}`));
     return <section className="dashboard-month-overview">
       <div className="dashboard-section-head">
        <div><div style={styles.eyebrow}>VISÃO GERAL DO MÊS</div><h2 style={styles.cardTitle}>{monthTitle}</h2></div>
        <div style={{display:"flex",gap:4}}><button className="compact-chevron" onClick={()=>setDashboardMonthOffset(v=>v-1)}>‹</button><button className="compact-chevron" onClick={()=>setDashboardMonthOffset(v=>v+1)}>›</button></div>
       </div>
       <div className="dashboard-month-grid">
        {[
          ["📅","Agendamentos",String(monthAgendaKeys.size)],
          ["🔮","Atendimentos",String(monthReadings.length)],
          ["🔥","Trabalhos",String(monthWorks.length)],
        ].map(([icon,label,value])=><div key={label} className="dashboard-month-stat"><span className="dashboard-month-icon">{icon}</span><strong>{value}</strong><small>{label}</small></div>)}
       </div>
     </section>;
   })()}
   <section className="dashboard-collapsible" style={{marginTop:12}}>
    <button className="dashboard-collapse-head" onClick={()=>setDashboardActionsCollapsed(v=>!v)}><span>⚡ <b>Ações rápidas</b><small>Atendimento, orçamento, agenda e financeiro</small></span><span>{dashboardActionsCollapsed?"⌄":"⌃"}</span></button>
    {!dashboardActionsCollapsed && <div className="dashboard-collapse-body">
     <div className="dashboard-action-grid">
      <button className="dashboard-action" onClick={()=>setShowNewConsultation(true)}><b>＋ Novo</b><span>Atendimento</span></button>
      <button className="dashboard-action" onClick={()=>{setBudgetClientId("");setBudgetItems([]);setShowQuickBudgetModal(true);}}><b>📋 Orçamento</b><span>Novo orçamento</span></button>
      <button className="dashboard-action" onClick={()=>{setOrganizationAppointmentComposerOpen(false);setAgendaCategory("work");setAgendaDate(localDateKey());setAgendaFilterDate("");setAgendaPriority(3);setAgendaComposerOpen(true);setScreen("agenda");}}><b>📅 Agendar</b><span>Compromisso</span></button>
      <button className="dashboard-action" onClick={()=>{setDailyDate(localDateKey());setDailyFilter("all");setScreen("daily");}}><b>🗓️ Feito hoje</b><span>Tudo que foi feito</span></button>
      <button className="dashboard-action" onClick={openQuickIncome}><b>🟢 Entrada</b><span>Registrar</span></button>
      <button className="dashboard-action" onClick={openQuickExpense}><b>🔴 Saída</b><span>Registrar</span></button>
      <button className="dashboard-action" onClick={()=>setScreen("accounts")}><b>🧾 Contas</b><span>Central de contas</span></button>
      <button className="dashboard-action" onClick={openLoanManager}><b>🏦 Empréstimo</b><span>Ver / criar</span></button>
      <button className="dashboard-action" onClick={openReserveManager}><b>🐷 Caixinha</b><span>Guardar / resgatar</span></button>
     </div>
    </div>}
   </section>
  </section>
  {(() => {
   const today = new Date(); const todayKey = localDateKey(); const nowHm = `${String(today.getHours()).padStart(2,"0")}:${String(today.getMinutes()).padStart(2,"0")}`;
   const isScheduledOverdue = (date:string,time:string) => `${date}T${time}` < `${todayKey}T${nowHm}`;
   const upcomingServices:any[] = agendaItems.filter(a => !!a.relatedEntityType && !!a.relatedEntityId && !a.completed && !a.deletedAt).map(a => {
     const c = a.relatedEntityType === "consultation" ? consultations.find(x=>x.id===a.relatedEntityId) : consultations.find(x=>(x.relatedCharges||[]).some(ch=>ch.id===a.relatedEntityId));
     const charge = c && a.relatedEntityType !== "consultation" ? (c.relatedCharges||[]).find(ch=>ch.id===a.relatedEntityId) : undefined;
     if (!c || c.deletedAt) return null;
     return {id:a.id,date:a.date,time:a.time,title:a.title,description:a.description,kind:"consultation" as const,consultationId:c.id,chargeId:charge?.id,serviceType:a.relatedEntityType === "sale" ? "sale" : a.relatedEntityType === "work" ? "work" : "consultation",amount:charge?.originalAmount ?? c.value,overdue:isScheduledOverdue(a.date,a.time)};
   }).filter(Boolean);
   const upcoming = [...agendaItems.filter(a=>!a.completed && !a.deletedAt && a.category!=="family" && !a.relatedEntityId).map(a=>({id:a.id,date:a.date,time:a.time,title:a.title,description:a.description,kind:"manual" as const,consultationId:"",chargeId:undefined,serviceType:"manual" as const,overdue:isScheduledOverdue(a.date,a.time)})), ...upcomingServices].sort((a,b)=>{if(a.overdue!==b.overdue)return a.overdue?-1:1;return `${a.date}T${a.time}`.localeCompare(`${b.date}T${b.time}`)}).slice(0,3);
   return <section className="dashboard-alert-card" style={upcoming.length?styles.card:styles.card}>
    <div className={"dashboard-section-head"}>
     <div><div style={styles.eyebrow}>PRÓXIMOS AGENDAMENTOS</div><h2 style={styles.cardTitle}>{upcoming.length ? "Não perca o próximo atendimento" : "Agenda livre por enquanto"}</h2></div>
     <button className="compact-chevron" onClick={()=>setScreen("agenda")}>Agenda →</button>
    </div>
    {upcoming.length ? <div className="dashboard-list">{upcoming.map(item=>{
      const c=item.kind==="consultation"?consultations.find(x=>x.id===item.consultationId):undefined;
      const clientDisplayName=c?.clientName || "";
      const displayItemTitle=clientDisplayName && normalizeClientLookupName(item.title)===normalizeClientLookupName(clientDisplayName)
        ? (item.serviceType==="work"?"Trabalho":item.serviceType==="sale"?"Venda":"Atendimento")
        : item.title;
      const actionLabel=item.kind==="manual"?"📌 Abrir agenda":item.serviceType==="work"?"▶ Executar trabalho":item.serviceType==="sale"?"🛍️ Abrir venda":"▶ Iniciar atendimento";
      const openAction=()=>{
        if(!c){setScreen("agenda");return;}
        if(item.serviceType==="consultation"){resumeConsultation(c);return;}
        if(item.serviceType==="work"){const charge=item.chargeId?(c.relatedCharges||[]).find(x=>x.id===item.chargeId):undefined;openWorkExecution({id:item.chargeId||c.id,consultationId:c.id,chargeId:item.chargeId,workTypeId:charge?.workTypeId||c.workTypeId,title:item.title,clientName:c.clientName,amount:item.amount||c.value});return;}
        const charge=item.chargeId?(c.relatedCharges||[]).find(x=>x.id===item.chargeId):undefined;
        setSelectedServiceRecord({id:item.chargeId||c.id,recordType:"sale",consultationId:c.id,chargeId:item.chargeId,workTypeId:charge?.workTypeId,title:item.title,clientName:c.clientName,scheduledAt:item.date+"T"+item.time,amount:item.amount||c.value,currency:charge?.currency||c.currency||"BRL",execution:undefined,status:charge?.saleStatus||(c as any).saleStatus||"approved",consultation:c,createdAt:c.createdAt});
        setServiceHubTab("sales"); setServiceHubStatusFilter("waiting"); setScreen("services"); setShowServiceDetail(true);
      };
      const rescheduleAction=()=>{ if(c) rescheduleWork({id:item.chargeId||c.id,consultationId:c.id,chargeId:item.chargeId,scheduledAt:item.date+"T"+item.time,title:item.title,clientName:c.clientName}); else rescheduleWork({id:item.id,scheduledAt:item.date+"T"+item.time,title:item.title,clientName:"",serviceType:"manual"}); };
      const cancelAction=()=>{ if(!c){deleteAgendaItem(item.id);return;} if(item.serviceType==="consultation"&&!item.chargeId) cancelScheduledConsultation(c); else if(item.serviceType==="work") updateWorkLifecycle({id:item.chargeId||c.id,consultationId:c.id,chargeId:item.chargeId,title:item.title,clientName:c.clientName,fromAgendaAction:true},"cancelled"); else updateSaleLifecycle({id:item.chargeId||c.id,consultationId:c.id,chargeId:item.chargeId,title:item.title,clientName:c.clientName,fromAgendaAction:true},"cancelled"); };
      return <div key={item.id} className="agenda-compact-row" style={{display:"grid",gap:6}}>
        <div className="dashboard-list-row" style={{alignItems:"flex-start"}}>
          <span className="dashboard-time" style={{display:"flex",flexDirection:"column",alignItems:"flex-end",lineHeight:1.15}}><strong>{formatDate(item.date)}</strong><small>{item.time}</small></span>
          <span style={{display:"flex",alignItems:"center",gap:9,minWidth:0,flex:1}}>{(() => { const manual= item.kind==="manual" ? agendaItems.find(a=>a.id===item.id) : undefined; const clientId=c?.clientId || manual?.clientId; const clientName=c?.clientName || (manual?.clientId ? clients.find(x=>x.id===manual.clientId)?.name : undefined); return clientName ? <ClientIdentity clientId={clientId} clientName={clientName} size={42} /> : null; })()}<span style={{minWidth:0}}><strong>{item.overdue?"🔴 ":item.kind==="consultation"?(c?.serviceType==="work"?"🔥 ":c?.serviceType==="sale"?"🛍️ ":"🔮 "):"📌 "}{displayItemTitle}</strong><small>{item.description}</small>{item.overdue&&<span className="notice-status notice-status-danger" style={{display:"inline-block",marginTop:4}}>ATRASADO</span>}</span></span>
        </div>
        <div className="dashboard-row-actions" style={{padding:"0 4px 6px",display:"flex",gap:6,flexWrap:"wrap"}}>
          <button type="button" style={styles.primaryButton} onClick={openAction}>{actionLabel}</button>
          <button type="button" style={styles.smallButton} onClick={rescheduleAction}>📅 Reagendar</button>{item.kind!=="manual"&&<button type="button" style={styles.deleteButton} onClick={cancelAction}>✕ Cancelar</button>}
        </div>
      </div>;
    })}</div> : <div className="compact-empty">Nenhum atendimento/compromisso próximo.</div>}
   </section>;
  })()}
  {(() => {
   const now = new Date();
   const todayKey = localDateKey(now);
   const todayStart = new Date(`${todayKey}T00:00:00`);
   const isLate = (scheduledAt?: string) => !!scheduledAt && scheduledAt.slice(0,16) < `${todayKey}T${String(now.getHours()).padStart(2,"0")}:${String(now.getMinutes()).padStart(2,"0")}`;
   const operational:any[] = [];
   const add = (item:any) => { if(!item || operational.some(x=>x.id===item.id && x.type===item.type)) return; operational.push(item); };

   consultations.filter(c=>!c.deletedAt && c.serviceType==="consultation" && c.status!=="completed" && c.status!=="standby" && !!c.scheduledAt).forEach(c=>add({id:c.id,type:"consultation",consultation:c,title:c.title,clientName:c.clientName,scheduledAt:c.scheduledAt,createdAt:c.createdAt,late:isLate(c.scheduledAt),label:"🔮 Atendimento agendado",action:"start"}));
   consultations.filter(c=>!c.deletedAt && c.serviceType==="work" && c.status!=="standby" && !["completed","cancelled"].includes(c.workStatus||"")).forEach(c=>add({id:c.id,type:"work",consultation:c,title:c.workTypeName||c.title,clientName:c.clientName,scheduledAt:c.scheduledAt,createdAt:c.createdAt,late:isLate(c.scheduledAt),label:c.scheduledAt?"🔥 Trabalho agendado":"🔥 Trabalho aguardando execução",action:"execute"}));
   consultations.flatMap(c=>(c.relatedCharges||[]).filter(ch=>ch.kind==="work"&&!ch.deletedAt&&c.status!=="standby"&&!['completed','cancelled'].includes(ch.status||'')).map(ch=>({c,ch}))).forEach(({c,ch})=>add({id:ch.id,type:"work",charge:ch,consultation:c,title:ch.title,clientName:c.clientName,scheduledAt:ch.scheduledAt,createdAt:ch.scheduledAt||c.createdAt,late:isLate(ch.scheduledAt),label:ch.scheduledAt?"🔥 Trabalho agendado":"🔥 Trabalho aguardando execução",action:"execute"}));
   consultations.filter(c=>!c.deletedAt && c.serviceType==="sale" && c.status!=="standby" && !["delivered","cancelled"].includes(c.saleStatus||"")).forEach(c=>{const status=c.saleStatus||"approved"; const action=status==="awaiting_confection"?"start_confection":status==="in_confection"?"finish_confection":status==="awaiting_shipping"?"ship":c.shippingEnabled?"prepare_shipping":"complete_sale"; add({id:c.id,type:"sale",consultation:c,title:c.saleItemName||c.title,clientName:c.clientName,scheduledAt:c.scheduledAt,createdAt:c.createdAt,late:isLate(c.scheduledAt),label:status==="awaiting_confection"?"🛍️ Venda aguardando confecção":status==="in_confection"?"🛠️ Venda em confecção":status==="awaiting_shipping"?"📦 Venda aguardando envio":"🛍️ Venda aguardando fazer",action});});
   consultations.flatMap(c=>(c.relatedCharges||[]).filter(ch=>ch.kind==="sale"&&!ch.deletedAt&&c.status!=="standby"&&!['delivered','cancelled'].includes(ch.saleStatus||'')).map(ch=>({c,ch}))).forEach(({c,ch})=>{const status=ch.saleStatus||"approved"; const action=status==="awaiting_confection"?"start_confection":status==="in_confection"?"finish_confection":status==="awaiting_shipping"?"ship":ch.shippingEnabled?"prepare_shipping":"complete_sale"; add({id:ch.id,type:"sale",charge:ch,consultation:c,title:ch.title,clientName:c.clientName,scheduledAt:ch.scheduledAt,createdAt:ch.scheduledAt||c.createdAt,late:isLate(ch.scheduledAt),label:status==="awaiting_confection"?"🛍️ Venda aguardando confecção":status==="in_confection"?"🛠️ Venda em confecção":status==="awaiting_shipping"?"📦 Venda aguardando envio":"🛍️ Venda aguardando fazer",action});});

   const inOperationalPeriod=(item:any)=>{
     if(dashboardOperationalPeriod==="overdue") return item.late;
     if(!item.scheduledAt) return true;
     const d=new Date(item.scheduledAt); const diff=Math.floor((d.getTime()-todayStart.getTime())/86400000);
     const max=dashboardOperationalPeriod==="today"?0:dashboardOperationalPeriod==="3days"?3:dashboardOperationalPeriod==="5days"?5:7;
     return !item.late && diff>=0 && diff<=max;
   };
   const filtered=operational.filter(inOperationalPeriod).sort((a,b)=>{
     if(a.late!==b.late) return a.late?-1:1;
     const av=Date.parse(a.scheduledAt||a.createdAt||"")||0; const bv=Date.parse(b.scheduledAt||b.createdAt||"")||0;
     return dashboardOperationalSort==="recent"?bv-av:av-bv;
   });
   const actionFor=(item:any)=>{
     if(item.type==="consultation") return ()=>startScheduledConsultation(item.consultation);
     if(item.type==="work") return ()=>openWorkExecution({id:item.id,consultationId:item.consultation.id,chargeId:item.charge?.id,workTypeId:item.charge?.workTypeId||item.consultation.workTypeId,title:item.title,clientName:item.clientName,amount:item.charge?.originalAmount||item.consultation.value});
     const c=item.consultation; const status=item.charge?.saleStatus||c.saleStatus||"approved"; const record={id:item.id,recordType:"sale",consultationId:c.id,chargeId:item.charge?.id,title:item.title,clientName:c.clientName,scheduledAt:item.charge?.scheduledAt||c.scheduledAt,shippingScheduledAt:item.charge?.shippingScheduledAt||c.shippingScheduledAt,amount:item.charge?.originalAmount||c.value,currency:item.charge?.currency||c.currency||"BRL",saleStatus:status,needsConfection:["awaiting_confection","in_confection"].includes(status),shippingEnabled:!!(item.charge?.shippingEnabled||c.shippingEnabled),consultation:c};
     const next=status==="awaiting_confection"?"in_confection":status==="in_confection"?"awaiting_shipping":status==="awaiting_shipping"?"shipped":status==="approved"?(record.shippingEnabled?"awaiting_shipping":"delivered"):null;
     return ()=>{if(next) updateSaleLifecycle(record,next);};
   };
   const actionLabel=(item:any)=>item.type==="consultation"?"▶ Iniciar atendimento":item.type==="work"?"▶ Executar trabalho":item.action==="start_confection"?"🛠️ Iniciar confecção":item.action==="finish_confection"?"✓ Concluir confecção":item.action==="prepare_shipping"?"📦 Preparar envio":item.action==="ship"?"🚚 Marcar enviado":"✓ Concluir venda";
   return <section className="dashboard-alert-card dashboard-collapsible" style={styles.card}>
    <button className="dashboard-collapse-head" onClick={()=>setDashboardOperationalCollapsed(v=>!v)}><span>🧭 <b>TRABALHOS E VENDAS · HOJE</b><small>{filtered.length} item(ns) no filtro · ações diretas</small></span><span>{dashboardOperationalCollapsed?"⌄":"⌃"}</span></button>
    {!dashboardOperationalCollapsed&&<div className="dashboard-collapse-body operational-dashboard-body">
      <div className="dashboard-tab-row operational-filter-row">{([['today','Hoje'],['3days','Próximos 3 dias'],['5days','Próximos 5 dias'],['7days','Próximos 7 dias'],['overdue','Atrasados']] as const).map(([key,text])=><button key={key} className={dashboardOperationalPeriod===key?"dashboard-tab active":"dashboard-tab"} onClick={()=>setDashboardOperationalPeriod(key)}>{text}</button>)}</div>
      <div className="dashboard-operational-toolbar"><span className="count-badge-small">Mostrando até 3 por vez</span><select value={dashboardOperationalSort} onChange={e=>setDashboardOperationalSort(e.target.value as "recent"|"oldest")} style={{...styles.input,margin:0,maxWidth:210}}><option value="recent">Mais recentes primeiro</option><option value="oldest">Mais antigos primeiro</option></select></div>
      {filtered.length===0?<div className="compact-empty">Nenhum trabalho, venda ou atendimento para este filtro.</div>:<div className="dashboard-scroll-list dashboard-operational-list">{filtered.map(item=><div key={`${item.type}-${item.id}`} className="agenda-compact-row" style={{display:"grid",gap:6}}><div className="dashboard-list-row" style={{alignItems:"flex-start"}}><span className="dashboard-time">{item.scheduledAt?(item.scheduledAt.slice(0,10)===todayKey?item.scheduledAt.slice(11,16):formatDate(item.scheduledAt.slice(0,10))):"—"}</span><span style={{minWidth:0,flex:1}}><ClientIdentity clientId={item.consultation?.clientId} clientName={item.clientName} size={40} /></span><span style={{minWidth:0,flex:1}}><strong>{item.late?"🔴 ":""}{normalizeClientLookupName(item.title)===normalizeClientLookupName(item.clientName)?(item.type==="work"?"Trabalho":item.type==="sale"?"Venda":"Atendimento"):item.title}</strong><small>{item.label}</small>{item.late&&<span className="notice-status notice-status-danger" style={{display:"inline-block",marginTop:4}}>ATRASADO</span>}</span></div><div className="dashboard-row-actions" style={{padding:"0 4px 6px"}}><button type="button" style={styles.primaryButton} onClick={actionFor(item)}>{actionLabel(item)}</button>{item.scheduledAt&&<button type="button" style={styles.smallButton} onClick={()=>rescheduleWork({id:item.id,consultationId:item.consultation.id,chargeId:item.charge?.id,scheduledAt:item.scheduledAt,title:item.title,clientName:item.clientName})}>📅 Reagendar</button>}</div></div>)}</div>}
    </div>}
   </section>;
  })()}
  {(() => {
    const periodDays = dashboardNoticePeriod === "today" ? 0 : dashboardNoticePeriod === "3days" ? 3 : dashboardNoticePeriod === "7days" ? 7 : 15;
    const baseToday = new Date(); baseToday.setHours(0,0,0,0);
    const limit = new Date(baseToday); limit.setDate(limit.getDate()+periodDays);
    const daysUntil = (date:string) => { const d=new Date(`${date}T00:00:00`); return Math.round((d.getTime()-baseToday.getTime())/86400000); };
    const noticeItems:any[] = [];
    payables.filter(p=>p.status!=="paid").forEach(p=>{ const delta=daysUntil(p.dueDate); const overdue=p.dueDate<todayKey || p.status==="overdue"; if((dashboardNoticePeriod==="overdue"&&overdue) || (dashboardNoticePeriod!=="overdue"&&!overdue&&delta>=0&&delta<=periodDays)) noticeItems.push({id:`payable:${p.id}`,kind:"payable",date:p.dueDate,title:p.description,clientName:"",amount:p.amount,currency:"BRL",overdue,categoryLabel:"CONTA A PAGAR",categoryTone:"danger",statusLabel:p.postponedFrom?"PRORROGADA":overdue?"ATRASADA":p.dueDate===todayKey?"VENCE HOJE":"PENDENTE",subtitle:p.postponedFrom?`Novo vencimento ${formatDate(p.dueDate)}`:overdue?`Vencida em ${formatDate(p.dueDate)}`:p.dueDate===todayKey?"Vence hoje":`Vence em ${formatDate(p.dueDate)}`,source:p}); });
    accountTemplates.filter(t=>t.active).forEach(t=>{
      for (const monthOffset of [0,1]) {
        const d=new Date(baseToday.getFullYear(),baseToday.getMonth()+monthOffset,1); const lastDay=new Date(d.getFullYear(),d.getMonth()+1,0).getDate(); const day=Math.min(Math.max(1,t.dueDay),lastDay); const due=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(day).padStart(2,"0")}`;
        if (payables.some(p=>p.recurrenceId===t.id && p.dueDate===due && p.status!=="paid")) continue;
        const delta=daysUntil(due); if(dashboardNoticePeriod!=="overdue" && delta>=0 && delta<=periodDays) noticeItems.push({id:`template:${t.id}:${due}`,kind:"payable",date:due,title:t.name,clientName:"",amount:Number(t.amount||0),currency:"BRL",overdue:false,categoryLabel:"CONTA A PAGAR",categoryTone:"danger",statusLabel:due===todayKey?"VENCE HOJE":"PENDENTE",subtitle:due===todayKey?"Conta recorrente vence hoje":`Vence em ${formatDate(due)}`,source:{id:"",description:t.name,area:t.area,amount:Number(t.amount||0),dueDate:due,paymentMethod:"pix"}});
      }
    });
    consultantPaymentAgenda.filter(i=>i.status!=="received"&&i.status!=="defaulted").forEach(i=>{ const delta=daysUntil(i.dueDate); const overdue=i.status==="overdue"||i.dueDate<todayKey; if((dashboardNoticePeriod==="overdue"&&overdue) || (dashboardNoticePeriod!=="overdue"&&!overdue&&delta>=0&&delta<=periodDays)) noticeItems.push({id:`installment:${i.id}`,kind:"installment",date:i.dueDate,title:i.title,clientName:i.clientName,amount:i.amountCurrency,currency:i.currency,overdue,categoryLabel:i.title.toLowerCase().startsWith("pergunta") ? "ATENDIMENTO A RECEBER" : (i.title.toLowerCase().includes("venda") || consultations.find(c=>c.id===i.consultationId)?.serviceType==="sale" ? "VENDA A RECEBER" : "PARCELA A RECEBER"),categoryTone:"success",statusLabel:i.postponedFrom?"PRORROGADA":overdue?"ATRASADA":i.dueDate===todayKey?"VENCE HOJE":"PENDENTE",subtitle:i.postponedFrom?`Novo vencimento ${formatDate(i.dueDate)}`:overdue?`Vencida em ${formatDate(i.dueDate)}`:i.dueDate===todayKey?"Vence hoje":`Vence em ${formatDate(i.dueDate)}`,source:i}); });
    consultations.filter(c=>c.serviceType==="sale"&&c.paymentPlan?.installments?.some(i=>i.status!=="received"&&i.status!=="defaulted")).forEach(c=>{ /* paymentPlan is already represented in consultantPaymentAgenda; kept as a guard for future sale-specific filters */ });
    noticeItems.sort((a,b)=>{ if(a.overdue!==b.overdue)return a.overdue?-1:1; return a.date.localeCompare(b.date); });
    const label = dashboardNoticePeriod==="overdue"?"ATRASADOS":dashboardNoticePeriod==="today"?"VENCENDO HOJE":`PRÓXIMOS ${periodDays} DIAS`;
    return <section className="dashboard-alert-card" style={styles.card}>
      <div className="dashboard-section-head"><div><div style={styles.eyebrow}>🔔 AVISOS · {label}</div><h2 style={styles.cardTitle}>{noticeItems.length?`${noticeItems.length} item(ns) exigem atenção`:`Nenhum aviso neste período`}</h2></div><button className="compact-chevron" onClick={()=>setScreen("finance")}>Financeiro →</button></div>
      <div className="dashboard-tab-row" style={{marginBottom:10}}>{([['3days','3 dias'],['today','Hoje'],['7days','7 dias'],['15days','15 dias'],['overdue','Atrasados']] as const).map(([key,text])=><button key={key} className={dashboardNoticePeriod===key?"dashboard-tab active":"dashboard-tab"} onClick={()=>setDashboardNoticePeriod(key)}>{text}</button>)}</div>
      {noticeItems.length===0?<div className="compact-empty">Nada vencendo ou atrasado neste período.</div>:<div className="dashboard-scroll-list notice-scroll-list">{noticeItems.map(item=><div key={item.id} className="notice-item-row"><div className="notice-item-icon">{item.overdue?"🔴":item.kind==="installment"?"👤":"🧾"}</div><div className="notice-item-main"><div className="notice-item-top"><span className={`notice-category ${item.categoryTone==="success"?"notice-category-success":"notice-category-danger"}`}>{item.categoryLabel}</span><span className={`notice-status ${item.overdue?"notice-status-danger":""}`}>{item.statusLabel}</span></div><strong>{item.kind==="installment"?`${item.clientName} · ${item.title}`:item.title}</strong><small>{item.subtitle}</small></div><div className="notice-item-side"><b>{formatForeign(item.amount,item.currency)}</b><div className="dashboard-row-actions">{item.kind==="installment"?<><button style={styles.smallButton} onClick={()=>setAnyInstallmentStatus(item.source.consultationId,item.source.installmentId,"received",item.source.questionId)}>✓ Recebeu</button><button style={styles.smallButton} onClick={()=>postponeDashboardPayment(item.source)}>Prorrogar</button><button style={styles.deleteButton} onClick={()=>setAnyInstallmentStatus(item.source.consultationId,item.source.installmentId,"defaulted",item.source.questionId)}>Não vai pagar</button></>:<><button style={styles.smallButton} onClick={()=>markPayablePaid(item.source.id)}>Pagar</button><button style={styles.smallButton} onClick={()=>postponePayable(item.source.id)}>Prorrogar</button></>}</div></div></div>)}</div>}
      {noticeItems.length>3&&<div style={styles.muted}>Deslize para ver os demais avisos.</div>}
    </section>;
  })()}
  <section className="dashboard-collapsible">
   <button className="dashboard-collapse-head" onClick={()=>setExpandedDashboardAccounts(v=>!v)}><span>🧾 <b>Central de contas</b><small>{overduePayables.length} atrasada(s) · {upcomingPayables.length} pendente(s)</small></span><span>{expandedDashboardAccounts?"⌃":"⌄"}</span></button>
   {expandedDashboardAccounts && <div className="dashboard-collapse-body"><div className="dashboard-scroll-list">{upcomingPayables.slice(0,4).map(a=><div key={a.id} className="dashboard-list-row"><span>{a.dueDate<todayKey?"🔴":"🧾"}</span><span><strong>{a.description}</strong><small>{a.dueDate<todayKey?"Atrasada":"Vence em "+formatDate(a.dueDate)}</small></span><b>{formatMoney(a.amount)}</b></div>)}</div><button className="compact-chevron" onClick={()=>setScreen("accounts")}>Abrir Central de Contas →</button></div>}
  </section>
  <section className="dashboard-collapsible">
   <button className="dashboard-collapse-head" onClick={()=>setExpandedDashboardSection(expandedDashboardSection==="standby"?null:"standby")}><span>🔮 <b>Atendimentos em standby</b><small>{standbyConsultations.length ? `${standbyConsultations.length} pendente(s) · apenas sessões pausadas` : "Nenhum atendimento pausado"}</small></span><span>{expandedDashboardSection==="standby"?"⌃":"⌄"}</span></button>
   {expandedDashboardSection==="standby" && <div className="dashboard-collapse-body">{standbyConsultations.length===0 ? <div className="compact-empty">Nenhum atendimento em standby. Esta área guarda somente atendimentos iniciados e pausados temporariamente.</div> : <>{standbyConsultations.slice(0,3).map(c=><div key={c.id} className="dashboard-list-row standby-client-row"><ClientIdentity clientId={c.clientId} clientName={c.clientName} size={42} showName={false} /><div className="standby-client-main"><strong>{c.clientName}</strong><small>{c.title} · 🔮 Não finalizado</small></div><div className="dashboard-row-actions"><button style={styles.smallButton} onClick={()=>resumeConsultation(c)}>Retomar</button><button style={styles.deleteButton} onClick={()=>deleteConsultation(c.id)}>Lixeira</button></div></div>)}{standbyConsultations.length>3&&<button className="compact-chevron" onClick={()=>setScreen("clients")}>Ver todos →</button>}</>}</div>}
  </section>
  <section className="dashboard-collapsible">
   <button className="dashboard-collapse-head" onClick={()=>setExpandedDashboardSection(expandedDashboardSection==="finance"?null:"finance")}><span>💰 <b>Resumo financeiro</b><small>{formatMoney(operationalBalance)} disponível</small></span><span>{expandedDashboardSection==="finance"?"⌃":"⌄"}</span></button>
   {expandedDashboardSection==="finance" && <div className="dashboard-collapse-body"><div className="dashboard-mini-grid"><FinanceMini title="Entrada" value={formatMoney(moneyReceived)} subtitle="Recebido" onClick={()=>{setReportTab("work");setScreen("reports");}}/><FinanceMini title="Saída" value={formatMoney(moneyOut)} subtitle="Pago" onClick={()=>{setReportTab("work");setScreen("reports");}}/><FinanceMini title="A receber" value={formatMoney(receivableTotal)} subtitle="Pendente"/><FinanceMini title="Saldo" value={formatMoney(operationalBalance)} subtitle={operationalBalance<0?"No vermelho":"Disponível"}/></div></div>}
  </section>
  <section className="dashboard-collapsible">
   <button className="dashboard-collapse-head" onClick={()=>setExpandedDashboardSection(expandedDashboardSection==="installments"?null:"installments")}><span>💳 <b>Acompanhamento de parcelas</b><small>{pendingCount} pendente(s) · {receivedCount} paga(s)</small></span><span>{expandedDashboardSection==="installments"?"⌃":"⌄"}</span></button>
   {expandedDashboardSection==="installments" && <div className="dashboard-collapse-body"><div className="dashboard-tab-row">{([['pending','⏳ Pendentes'],['paid','✓ Pagas'],['defaulted','⚠ Não pagas']] as const).map(([key,label])=><button key={key} className={dashboardInstallmentTab===key?"dashboard-tab active":"dashboard-tab"} onClick={()=>setDashboardInstallmentTab(key)}>{label}</button>)}</div><div className="dashboard-scroll-list">{groupConsultantPayments(consultantPaymentAgenda.filter(item=>{const status=item.status==="received"?"paid":item.status==="defaulted"?"defaulted":"pending";return status===dashboardInstallmentTab;})).slice(0,3).map(group=>{const first=group[0];return <button key={first.id} className="dashboard-list-row dashboard-installment-client-row" onClick={()=>setSelectedDashboardPayment(first)}><ClientIdentity clientId={first.clientId} clientName={first.clientName} size={42} className="dashboard-installment-client"/><span className="dashboard-installment-summary"><strong>{first.title}</strong><small>{group.length} registro(s) · parcela(s) em acompanhamento</small></span><span>›</span></button>})}</div></div>}
  </section>
  <section className="dashboard-collapsible">
   <button className="dashboard-collapse-head" onClick={()=>setExpandedDashboardSection(expandedDashboardSection==="movements"?null:"movements")}><span>↕️ <b>Movimentações</b><small>{recentTransactions.filter(item=>item.kind!=="receivable").length} registro(s)</small></span><span style={{display:"flex",alignItems:"center",gap:8}}><button type="button" className="compact-chevron" onClick={e=>{e.stopPropagation();setShowFinancialMovements(true);}}>Ver todas</button><span>{expandedDashboardSection==="movements"?"⌃":"⌄"}</span></span></button>
   {expandedDashboardSection==="movements" && <div className="dashboard-collapse-body"><div className="dashboard-scroll-list">{recentTransactions.filter(item=>item.kind!=="receivable").slice(0,5).map(item=><div key={item.id} className="dashboard-list-row"><span>{item.kind==="income"?"🟢":"🔴"}</span><span><strong>{item.title}</strong><small>{item.subtitle} · {formatDateTime(item.date)}</small></span><b>{item.kind==="income"?"+":"-"}{formatMoney(item.amount)}</b></div>)}</div></div>}
  </section>
  {lowStockItems.length>0 && <section className="dashboard-collapsible"><button className="dashboard-collapse-head" onClick={()=>setExpandedDashboardSection(expandedDashboardSection==="stock"?null:"stock")}><span>📦 <b>Atenção ao estoque</b><small>{lowStockItems.length} item(ns) abaixo do mínimo</small></span><span>{expandedDashboardSection==="stock"?"⌃":"⌄"}</span></button>{expandedDashboardSection==="stock"&&<div className="dashboard-collapse-body">{lowStockItems.slice(0,5).map(item=><div key={item.id} className="dashboard-list-row"><span>📦</span><span><strong>{item.name}</strong><small>{item.quantity} {item.unit} restantes</small></span><span>⚠</span></div>)}</div>}</section>}
 </div>
)}
{screen === "trash" && (
<section style={styles.card}>
<div style={styles.cardHeader}>
<div><div style={styles.eyebrow}>RECUPERAÇÃO</div><h2 style={styles.cardTitle}>Lixeira</h2></div>
<button style={styles.deleteButton} onClick={emptyTrash} disabled={!trash.length}>Esvaziar</button>
</div>
<p style={styles.heroText}>Registros excluídos ficam aqui antes da exclusão definitiva. Restaurar devolve o item ao local original.</p>
{trash.length === 0 ? <div style={styles.emptyBox}>A lixeira está vazia.</div> : (
<div style={styles.list}>
{trash.map(item => (
<div key={item.id} style={styles.trashCard}>
<div style={styles.trashIcon}>🗑️</div>
<div style={styles.dailyInfo}>
<strong>{item.label}</strong>
<span style={styles.muted}>{formatDateTime(item.deletedAt)}</span>
<span style={styles.muted}>Tipo: {item.entityType}</span>
<div style={styles.futureActions}>
<button style={styles.smallButton} onClick={() => restoreTrashItem(item)}>↩ Restaurar</button>
<button style={styles.deleteButton} onClick={() => permanentlyDeleteTrashItem(item.id)}>Excluir definitivamente</button>
</div>
</div>
</div>
))}
</div>
)}
</section>
)}
{screen === "agenda" && (
 <>
  <button style={styles.backButton} onClick={() => setScreen("dashboard")}>← Início</button>
  <section style={styles.hero}>
   <div style={styles.eyebrow}>TRABALHO</div><h2 style={styles.pageTitle}>Agenda</h2><p style={styles.heroText}>Agendamentos de atendimentos, trabalhos e compromissos profissionais.</p>
   <button className="agenda-open-button" onClick={()=>{setOrganizationAppointmentComposerOpen(false);setAgendaComposerOpen(v=>!v);setAgendaEditingId(null);setAgendaCategory("work");setAgendaPriority(5);}}>{agendaComposerOpen?"× Fechar agendamento":"＋ Agendar"}</button>
  </section>
  <section style={styles.card}>
   <label style={styles.label}>Filtrar por dia (opcional)</label><div style={{display:"flex",gap:8,alignItems:"center"}}><input type="date" value={agendaFilterDate} onChange={event=>setAgendaFilterDate(event.target.value)} style={{...styles.input,flex:1}}/><button type="button" style={styles.smallButton} onClick={()=>setAgendaFilterDate("")}>Todos</button></div>
   <div style={styles.agendaTabs}>
    <button style={{...styles.agendaTab,...(agendaTab==="work"?styles.agendaTabActive:{})}} onClick={()=>setAgendaTab("work")}>💼 Trabalho</button>
    
    <button style={{...styles.agendaTab,...(agendaTab==="accounts"?styles.agendaTabActive:{})}} onClick={()=>setAgendaTab("accounts")}>💳 Contas</button>
   </div>
  </section>
  {agendaComposerOpen && <section className="agenda-composer" style={styles.card}>
   <div className="dashboard-section-head"><div><div style={styles.eyebrow}>{agendaEditingId?"EDITANDO":"NOVO AGENDAMENTO"}</div><h2 style={styles.cardTitle}>{agendaEditingId?"Editar compromisso":"O que deseja agendar?"}</h2></div></div>
   <div className="agenda-type-grid"><button className={agendaCategory==="work" && agendaTitle!=="Atendimento"?"selected":""} onClick={()=>{setOrganizationAppointmentComposerOpen(false);setAgendaCategory("work");setAgendaTitle("Trabalho");}}>🔥 Trabalho</button><button className={agendaCategory==="work" && agendaTitle==="Atendimento"?"selected":""} onClick={()=>{setOrganizationAppointmentComposerOpen(false);setAgendaCategory("work");setAgendaTitle("Atendimento");}}>🔮 Atendimento</button></div>
   <label style={styles.label}>Título</label><input value={agendaTitle} onChange={event=>setAgendaTitle(event.target.value)} placeholder="Ex.: Trabalho de prosperidade · Letícia" style={styles.input}/>
   <label style={styles.label}>Consulente (opcional)</label><div className="twoColumns"><select value={agendaClientId} onChange={event=>setAgendaClientId(event.target.value)} style={styles.input}><option value="">Nenhuma consulente vinculada</option>{clients.map(client => <option key={client.id} value={client.id}>{client.name}</option>)}</select><button type="button" style={styles.smallButton} onClick={()=>{setEditingClientId(null);setNewClientName("");setNewClientPhone("");setNewClientBirthDate("");setNewClientCPF("");setNewClientStreet("");setNewClientNumber("");setNewClientComplement("");setNewClientNeighborhood("");setNewClientCity("");setNewClientState("");setNewClientPostalCode("");setNewClientCountry("");setNewClientNotes("");setNewClientSource("instagram");setNewClientReferrerId("");setNewClientSourceDetails("");setReturnToAgendaClientContext("composer");setShowNewClient(true);}}>＋ Novo contato</button></div>
   <label style={styles.label}>Descrição</label><textarea value={agendaDescription} onChange={event=>setAgendaDescription(event.target.value)} placeholder="Detalhes, o que levar, observações..." style={styles.textarea}/>
   <div style={styles.twoColumns}><div><label style={styles.label}>Data</label><input type="date" value={agendaDate} onChange={event=>setAgendaDate(event.target.value)} style={styles.input}/></div><div><label style={styles.label}>Hora</label><input type="time" value={agendaTime} onChange={event=>setAgendaTime(event.target.value)} style={styles.input}/></div></div>
   <label style={styles.label}>Prioridade (1 = menor · 5 = máxima)</label><select value={agendaPriority} onChange={event=>setAgendaPriority(Math.min(5, Math.max(1, Number(event.target.value)||3)))} style={styles.input}>{[5,4,3,2,1].map(n=><option key={n} value={n}>{n}{n===5?" · Máxima":n>=4?" · Alta":n===3?" · Média":" · Baixa"}</option>)}</select>
   <label style={styles.checkboxItem}><input type="checkbox" checked={agendaNotify} onChange={event=>setAgendaNotify(event.target.checked)}/> Lembrar neste horário</label>
   <div className="agenda-composer-actions"><button style={styles.primaryButtonLarge} onClick={()=>{if(!agendaTitle.trim()||!agendaDate||!agendaTime){saveAgendaItem();return;}saveAgendaItem();setAgendaComposerOpen(false);}}>✓ Salvar agendamento</button><button style={styles.secondaryButtonLarge} onClick={()=>{setAgendaComposerOpen(false);setAgendaEditingId(null);}}>Cancelar</button></div>
  </section>}
  {agendaTab === "consultants" ? (
   <section style={styles.card}><div className="dashboard-section-head"><div><div style={styles.eyebrow}>PAGAMENTOS</div><h2 style={styles.cardTitle}>Agenda financeira</h2></div></div><div style={styles.agendaTabs}><button style={{...styles.agendaTab,...(consultantAgendaView==="open"?styles.agendaTabActive:{})}} onClick={()=>setConsultantAgendaView("open")}>⏳ Pendências</button><button style={{...styles.agendaTab,...(consultantAgendaView==="archived"?styles.agendaTabActive:{})}} onClick={()=>setConsultantAgendaView("archived")}>🗂️ Arquivadas</button></div><input value={consultantAgendaSearch} onChange={e=>setConsultantAgendaSearch(e.target.value)} placeholder="Pesquisar consulente..." style={{...styles.input,marginTop:10}}/><div style={styles.list}>{(consultantAgendaView==="open"?consultantOpenPayments:consultantArchivedPayments).filter(item=>{const q=consultantAgendaSearch.trim().toLowerCase();return !q||`${item.clientName} ${item.title}`.toLowerCase().includes(q);}).length===0?<div style={styles.emptyBox}>Nenhum registro.</div>:groupConsultantPayments((consultantAgendaView==="open"?consultantOpenPayments:consultantArchivedPayments).filter(item=>{const q=consultantAgendaSearch.trim().toLowerCase();return !q||`${item.clientName} ${item.title}`.toLowerCase().includes(q);})).slice(0,3).map(group=>{const clientId=group[0]?.clientId||group[0]?.clientName||"";const key=`${consultantAgendaView}:${clientId}`;const expanded=expandedConsultantPaymentClientId===key;return <div key={key} className="dashboard-collapsible"><button className="dashboard-collapse-head" onClick={()=>setExpandedConsultantPaymentClientId(expanded?null:key)}><span>👤 <b>{group[0]?.clientName}</b><small>{group.length} parcela(s) · {group[0]?.title}</small></span><span>{expanded?"⌃":"⌄"}</span></button>{expanded&&<div className="dashboard-collapse-body">{group.map(item=><div key={item.id} style={styles.paymentBox}><strong>{item.number===0?"Entrada":`Parcela ${item.number}`}</strong><div style={styles.muted}>{formatDate(item.dueDate)} · Em aberto: {formatForeign(item.amountCurrency,item.currency)}</div>{item.receivedAmountBRL>0&&item.originalAmountBRL>item.receivedAmountBRL&&<div style={styles.muted}>Recebido: {formatForeign(convertFromBRL(item.receivedAmountBRL,item.currency),item.currency)} · Original: {formatForeign(convertFromBRL(item.originalAmountBRL,item.currency),item.currency)}</div>}<div style={{fontWeight:800,marginTop:4}}>{item.receivedAmountBRL>=item.originalAmountBRL-0.01?"✓ Paga":item.receivedAmountBRL>0?"🟠 Pago parcialmente":item.status==="defaulted"?"⚠ Não paga":item.status==="overdue"?"🔴 Vencida":"⏳ Pendente"}</div>{item.paymentDates?.length>0&&<div style={{...styles.muted,marginTop:4,display:"grid",gap:2}}>{item.paymentDates.map((payment:any)=><div key={payment.id}>📅 {item.receivedAmountBRL>=item.originalAmountBRL-0.01?"Pago integralmente":"Pagamento parcial"}: {formatMoney(payment.amount)} · {formatDateTime(payment.date)}</div>)}</div>}<div className="dashboard-row-actions">{item.status!=="received"&&<button style={styles.smallButton} onClick={()=>promptInstallmentPartialPayment(item)}>💰 Receber valor</button>}{item.status!=="received"&&<button style={styles.smallButton} onClick={()=>setAnyInstallmentStatus(item.consultationId,item.installmentId,"received",item.questionId)}>✓ Pagou</button>}{item.status!=="received"&&<button style={styles.smallButton} onClick={()=>setAnyInstallmentStatus(item.consultationId,item.installmentId,"defaulted",item.questionId)}>Não pagar</button>}</div></div>)}</div>}</div>})}</div></section>
  ) : agendaTab === "accounts" ? (
   <section style={styles.card}><div className="dashboard-section-head"><div><div style={styles.eyebrow}>CONTAS</div><h2 style={styles.cardTitle}>Contas do dia</h2></div></div><div style={styles.list}>{[...agendaAccountsForDate.map(item=>({id:item.id,time:item.time,title:item.title,description:item.description,amount:item.amount})),...payables.filter(item=>item.dueDate===agendaDate).map(item=>({id:`payable-${item.id}`,time:"08:00",title:`💳 ${item.description}`,description:item.status,amount:item.amount}))].slice(0,3).map(item=><div key={item.id} className="dashboard-list-row"><span>{item.time}</span><span><strong>{item.title}</strong><small>{item.description}</small></span><b>{formatMoney(item.amount)}</b></div>)}{agendaAccountsForDate.length===0&&payables.filter(item=>item.dueDate===agendaDate).length===0&&<div className="compact-empty">Nenhuma conta para este dia.</div>}</div></section>
  ) : (
   <section style={styles.card}><div className="dashboard-section-head"><div><div style={styles.eyebrow}>AGENDADOS</div><h2 style={styles.cardTitle}>Trabalhos, vendas e atendimentos</h2></div><span className="count-badge-small">{agendaFilterDate ? "Do dia" : "Todos"}</span></div>
    <div className="dashboard-list">
     {(() => {
      const manual=agendaManualForDate.filter(item=>item.category==="work" && !item.relatedEntityType && !item.relatedEntityId).sort((a,b)=>Number(b.priority||3)-Number(a.priority||3) || a.time.localeCompare(b.time));
      const auto=agendaTab==="work"?agendaConsultationsForDate:[];
      const rows:any[]=[...auto.map(item=>({id:item.id,time:item.time,title:item.title,description:item.description,auto:true,isWork:item.isWork,serviceType:item.serviceType,consultationId:item.consultationId,chargeId:(item as any).chargeId,date:item.date,amount:item.amount,priority:Number((item as any).priority||3)})),...manual.map(item=>({id:item.id,time:item.time,title:item.title,description:item.description,auto:false,completed:item.completed,date:item.date,priority:Number(item.priority||3)}))].sort((a,b)=>b.priority-a.priority || `${a.date}T${a.time}`.localeCompare(`${b.date}T${b.time}`));
      return rows.length ? rows.map(item=>{
        const expanded=expandedAgendaItemId===item.id;
        const c=item.auto?consultations.find(x=>x.id===item.consultationId):undefined;
        const overdue=!!item.auto && !item.completed && `${item.date}T${item.time}` < `${localDateKey()}T${new Date().toTimeString().slice(0,5)}`;
        return <div key={item.id} className="agenda-compact-row">
          <button className="dashboard-list-row" onClick={()=>setExpandedAgendaItemId(expanded?null:item.id)}>
            <span className="dashboard-time">{item.time}</span>
            <span style={{display:"flex",alignItems:"center",gap:9,minWidth:0,flex:1}}>{(() => { const clientId=c?.clientId || (!item.auto ? agendaItems.find(a=>a.id===item.id)?.clientId : undefined); const client=clientId?clients.find(x=>x.id===clientId):undefined; return client?.avatarPhoto ? <button type="button" aria-label={`Abrir foto de ${client.name}`} onClick={(event)=>{event.stopPropagation();setSelectedClientPhoto({id:client.id,name:client.name,data:client.avatarPhoto!})}} style={{...styles.clientAvatar,width:42,height:42,border:"none",padding:0,overflow:"hidden",cursor:"pointer",flexShrink:0}}><img src={client.avatarPhoto} alt={`Foto de ${client.name}`} style={{width:"100%",height:"100%",objectFit:"cover"}}/></button> : null; })()}<span className="agenda-row-main" style={{minWidth:0}}><strong>{overdue?"🔴 ":item.auto?(item.serviceType==="work"?"🔥 ":item.serviceType==="sale"?"🛍️ ":"🔮 "):"📌 "}{item.title}</strong><small>{c?.clientName || (!item.auto ? (agendaItems.find(a=>a.id===item.id)?.clientId ? clients.find(x=>x.id===agendaItems.find(a=>a.id===item.id)?.clientId)?.name : undefined) : undefined) || item.description}</small><span className="priority-label priority-label-small">PRIORIDADE {Number(item.priority || 3)}</span>{overdue&&<span className="notice-status notice-status-danger" style={{display:"inline-block",marginTop:4}}>ATRASADO</span>}</span></span>
            <span>{expanded?"⌃":"⌄"}</span>
          </button>
          {expanded&&item.auto&&c&&<div className="agenda-expanded-details">
            <div style={styles.muted}>{item.serviceType==="work"?"Trabalho":item.serviceType==="sale"?"Venda/envio":"Atendimento"} agendado · {item.time}{overdue?" · ATRASADO":""}</div>
            <div className="dashboard-row-actions">
              {!item.completed && item.serviceType==="consultation"&&!item.chargeId&&<button style={styles.primaryButton} onClick={()=>resumeConsultation(c)}>▶ Iniciar atendimento</button>}
              {!item.completed && item.serviceType==="work"&&<button style={styles.primaryButton} onClick={()=>openWorkExecution({id:item.chargeId||c.id,consultationId:c.id,chargeId:item.chargeId,workTypeId:item.chargeId?(c.relatedCharges||[]).find(x=>x.id===item.chargeId)?.workTypeId:c.workTypeId,title:item.title,clientName:c.clientName,amount:item.amount})}>▶ Executar trabalho</button>}
              {!item.completed && item.serviceType==="sale"&&<button style={styles.primaryButton} onClick={()=>{setSelectedServiceRecord({id:item.chargeId||c.id,recordType:"sale",consultationId:c.id,chargeId:item.chargeId,title:item.title,clientName:c.clientName,scheduledAt:c.shippingScheduledAt||c.scheduledAt,amount:item.amount,currency:c.currency||"BRL",execution:undefined,status:(c as any).saleStatus||"approved",consultation:c,createdAt:c.createdAt});setServiceHubTab("sales");setScreen("services");setShowServiceDetail(true);}}>🛍️ Abrir venda</button>}
              {!item.completed && <button type="button" style={styles.smallButton} onClick={(event)=>{event.stopPropagation();rescheduleWork({id:item.chargeId||c.id,consultationId:c.id,chargeId:item.chargeId,serviceType:item.serviceType,scheduledAt:item.date+"T"+item.time,title:item.title,clientName:c.clientName});}}>📅 Reagendar</button>}
              {!item.completed && item.serviceType==="consultation"&&!item.chargeId&&<button type="button" style={styles.deleteButton} onClick={(event)=>{event.stopPropagation();cancelScheduledConsultation(c);}}>✕ Cancelar atendimento</button>}
              {!item.completed && item.serviceType==="work"&&<button type="button" style={styles.deleteButton} onClick={(event)=>{event.stopPropagation();updateWorkLifecycle({id:item.chargeId||c.id,consultationId:c.id,chargeId:item.chargeId,title:item.title,clientName:c.clientName,fromAgendaAction:true},"cancelled");}}>✕ Cancelar trabalho</button>}
              {!item.completed && item.serviceType==="sale"&&<button type="button" style={styles.deleteButton} onClick={(event)=>{event.stopPropagation();updateSaleLifecycle({id:item.chargeId||c.id,consultationId:c.id,chargeId:item.chargeId,title:item.title,clientName:c.clientName,fromAgendaAction:true},"cancelled");}}>✕ Cancelar venda/envio</button>}
              {item.completed&&<span style={styles.muted}>✓ Compromisso já iniciado/concluído</span>}
            </div>
          </div>}
          {expanded&&!item.auto&&<div className="agenda-expanded-details"><div style={styles.muted}>{item.completed?"Concluído":"Agendado"}</div><div className="dashboard-row-actions"><button style={styles.smallButton} onClick={()=>{const a=agendaItems.find(x=>x.id===item.id);if(a)editAgendaItem(a);setAgendaComposerOpen(true);}}>✏️ Editar</button>{!item.completed&&<button style={styles.smallButton} onClick={()=>rescheduleWork({id:item.id,scheduledAt:item.date+"T"+item.time,title:item.title,serviceType:"manual"})}>📅 Reagendar</button>}<button style={styles.deleteButton} onClick={()=>deleteAgendaItem(item.id)}>✕ Cancelar</button></div></div>}
        </div>;
      }) : <div className="compact-empty">Nenhum compromisso para este dia.</div>;
    })()}
    </div>
    {(((agendaManualForDate.filter(item=>!item.relatedEntityType && !item.relatedEntityId && (item.category===agendaTab || (agendaTab==="family" && item.category==="home"))).length)+(agendaTab==="work"?agendaConsultationsForDate.length:0))>3)&&<button className="compact-chevron">Ver todos os agendamentos →</button>}
   </section>
  )}
 </>
)}
{/* =================================================
   COMPRAS FUTURAS
================================================= */}
{screen === "futurePurchases" && (
 <>
  <button style={styles.backButton} onClick={() => setScreen("dashboard")}>← Início</button>
  <section style={styles.hero}>
   <div style={styles.eyebrow}>PLANEJAMENTO</div>
   <h2 style={styles.pageTitle}>Compras futuras · {futureArea === "home" ? "Casa" : "Trabalho"}</h2>
   <p style={styles.heroText}>Planejamento de itens que ainda serão comprados. Não é estoque e não gera uma saída financeira até a compra acontecer.</p>
   <div className="organization-tabs"><button className={futureArea==="home"?"active":""} onClick={()=>setFutureArea("home")}>🏠 Casa</button><button className={futureArea==="work"?"active":""} onClick={()=>setFutureArea("work")}>🔮 Trabalho</button></div>
  </section>
  <section style={styles.card}>
   <div style={styles.cardHeader}><div><div style={styles.eyebrow}>NOVA COMPRA</div><h2 style={styles.cardTitle}>Adicionar item</h2></div></div>
   <label style={styles.label}>Item</label>
   <input value={futureTitle} onChange={e => setFutureTitle(e.target.value)} placeholder="Ex.: cadeira nova para o escritório" style={styles.input}/>
   <label style={styles.label}>Descrição</label>
   <textarea value={futureDescription} onChange={e => setFutureDescription(e.target.value)} placeholder="Detalhes, modelo, tamanho, observações..." style={styles.textarea}/>
   <label style={styles.label}>Link de compra</label>
   <input type="url" value={futureLink} onChange={e => setFutureLink(e.target.value)} placeholder="https://..." style={styles.input}/>
   <label style={styles.label}>Destino</label>
   <div style={styles.segmented}>
    <button style={{...styles.segmentButton, ...(futureArea === "home" ? styles.segmentActive : {})}} onClick={() => setFutureArea("home")}>🏠 Casa</button>
    <button style={{...styles.segmentButton, ...(futureArea === "work" ? styles.segmentActive : {})}} onClick={() => setFutureArea("work")}>🔮 Trabalho</button>
   </div>
   {futureArea === "home" && <>
    <label style={styles.label}>Setor da casa</label>
    <select value={futureSectorId} onChange={e => setFutureSectorId(e.target.value)} style={styles.input}>
     <option value="">Selecione o setor</option>
     {householdSectors.filter(sector => sector.active).map(sector => <option key={sector.id} value={sector.id}>{sector.name}</option>)}
    </select>
   </>}
   <label style={styles.label}>Prioridade</label>
   <div style={styles.priorityGrid}>
    {[['low','Baixa'],['medium','Média'],['high','Alta'],['urgent','Urgente']].map(([value,label]) => <button key={value} style={{...styles.priorityButton, ...(futurePriority === value ? styles.priorityActive : {})}} onClick={() => setFuturePriority(value as FuturePurchasePriority)}>{label}</button>)}
   </div>
   <label style={styles.label}>Quando pretende comprar?</label>
   <select value={futureTimeframe} onChange={e => { const value = e.target.value as FuturePurchaseTimeframe; setFutureTimeframe(value); if (!futureTargetDate) setFutureTargetDate(getFutureTargetDate(value)); }} style={styles.input}>
    <option value="today">Hoje</option><option value="7days">Nos próximos 7 dias</option><option value="30days">Nos próximos 30 dias</option><option value="90days">Nos próximos 90 dias</option><option value="later">Mais para frente / sem prazo</option>
   </select>
   <label style={styles.label}>Data pretendida (opcional)</label>
   <input type="date" value={futureTargetDate} onChange={e => setFutureTargetDate(e.target.value)} style={styles.input}/>
   <button style={styles.primaryButtonLarge} onClick={saveFuturePurchase}>✓ Salvar compra futura</button>
  </section>
  <section style={styles.card}>
   <div style={styles.cardHeader}><div><div style={styles.eyebrow}>LISTA</div><h2 style={styles.cardTitle}>Itens planejados</h2></div><span style={styles.countBadge}>{futurePurchases.filter(item => !item.completed).length}</span></div>
   {futurePurchases.length === 0 ? <div style={styles.emptyBox}>Nenhuma compra futura cadastrada.</div> : <div style={styles.list}>{futurePurchases.map(item => {
    const sector = householdSectors.find(s => s.id === item.sectorId);
    return <div key={item.id} style={{...styles.futurePurchaseCard, ...(item.completed ? styles.futureCompleted : {})}}>
     <div style={styles.cardHeader}><div><strong>{item.title}</strong><div style={styles.muted}>{item.area === "home" ? "Casa" : "Trabalho"}{sector ? ` · ${sector.name}` : ""}</div></div><span style={item.priority === "urgent" ? styles.urgentBadge : item.priority === "high" ? styles.warningBadge : styles.countBadge}>{item.priority === "urgent" ? "Urgente" : item.priority === "high" ? "Alta" : item.priority === "medium" ? "Média" : "Baixa"}</span></div>
     {item.description && <div style={styles.noteBox}>{item.description}</div>}
     <div style={styles.muted}>{item.targetDate ? `Pretendida para ${formatDate(item.targetDate)}` : "Sem prazo definido"}</div>
     {item.link && <a href={item.link} target="_blank" rel="noreferrer" style={styles.linkButton}>Abrir link de compra ↗</a>}
     <div style={styles.futureActions}><button style={styles.smallButton} onClick={() => toggleFuturePurchase(item.id)}>{item.completed ? "Reabrir" : "Marcar comprada"}</button><button style={styles.deleteButton} onClick={() => deleteFuturePurchase(item.id)}>Excluir</button></div>
    </div>;
   })}</div>}
  </section>
 </>
)}
 
{/* =================================================
   DIA
================================================= */}
{screen === "daily" && (
 <>
  <button style={styles.backButton} onClick={() => setScreen("dashboard")}>← Início</button>
  <section style={styles.hero}>
   <div style={styles.eyebrow}>REGISTRO DO DIA</div>
   <h2 style={styles.pageTitle}>Tudo que aconteceu</h2>
   <p style={styles.heroText}>Uma linha do tempo reunindo atendimentos, dinheiro, compras, contas, estoque e planejamentos.</p>
   <label style={styles.label}>Dia</label>
   <input type="date" value={dailyDate} onChange={e => { setDailyDate(e.target.value); setExpandedDailyId(null); }} style={styles.input}/>
   <label style={styles.label}>Filtrar por tipo</label>
   <select value={dailyFilter} onChange={e => setDailyFilter(e.target.value)} style={styles.input}>
    <option value="all">Tudo</option><option value="consultation">Atendimentos</option><option value="work">Trabalhos</option><option value="sale">Vendas</option><option value="budget">Orçamentos</option><option value="income">Entradas</option><option value="expense">Saídas</option><option value="purchase">Compras</option><option value="payable">Contas / vencimentos</option><option value="stock">Estoque</option><option value="agenda">Agenda</option><option value="future">Compras futuras cadastradas</option>
   </select>
   <label style={styles.label}>Buscar</label>
   <input value={dailySearch} onChange={e => setDailySearch(e.target.value)} placeholder="Digite nome, cliente, compra, descrição..." style={styles.input}/>
  </section>
  <section style={styles.card}>
   <div style={styles.cardHeader}><div><div style={styles.eyebrow}>ATIVIDADES</div><h2 style={styles.cardTitle}>{filteredDailyActivities.length} registro(s)</h2></div></div>
   {filteredDailyActivities.length === 0 ? (
    <div style={styles.emptyBox}>Nenhum registro encontrado para esse dia e filtro.</div>
   ) : (
    <div style={styles.list}>
     {filteredDailyActivities.map(item => (
      <div key={item.id} style={styles.dailyActivity} onClick={() => { if(item.kind === "consultation" && item.clientId){ const client=clients.find(c=>c.id===item.clientId); if(client){ openHistory(client); return; } } setExpandedDailyId(expandedDailyId === item.id ? null : item.id); }}>
       <div style={styles.dailyIcon}>{item.kind === "budget" ? "💼" : item.kind === "consultation" ? "🔮" : item.kind === "income" ? "🟢" : item.kind === "expense" ? "🔴" : item.kind === "purchase" ? "🛒" : item.kind === "stock" ? "📦" : item.kind === "payable" ? "💳" : item.kind === "work" ? "🔥" : item.kind === "sale" ? "🛍️" : item.kind === "agenda" ? "📅" : "📋"}</div>
       <div style={styles.dailyInfo}>
        <strong>{item.title}</strong>
        <span style={styles.muted}>{item.subtitle} · {formatDateTime(item.date)}</span>
        {item.amount !== undefined && <strong>{formatMoney(item.amount)}</strong>}
        {expandedDailyId === item.id && <div style={styles.dailyDetails}>{item.details.map((detail, index) => <div key={index}>• {detail}</div>)}</div>}
        {["consultation", "purchase", "agenda", "budget", "income", "expense"].includes(item.kind) && <div style={styles.futureActions} onClick={event => event.stopPropagation()}>{item.clientId && <button type="button" style={styles.smallButton} onClick={() => { const client = clients.find(c => c.id === item.clientId); if (client) openHistory(client); }}>👤 Histórico</button>}<button type="button" style={styles.smallButton} onClick={() => editDailyActivity(item)}>✏️ Editar</button><button type="button" style={styles.deleteButton} onClick={() => deleteDailyActivity(item)}>🗑️ Excluir</button></div>}
       </div>
       <span>{expandedDailyId === item.id ? "⌃" : "⌄"}</span>
      </div>
     ))}
    </div>
   )}
  </section>
 </>
)}
 
{/* =================================================
NOTAS
================================================= */}
{screen === "notes" && (
 <>
  <button style={styles.backButton} onClick={() => setScreen("dashboard")}>← Início</button>
  <section style={styles.hero}>
   <div style={styles.eyebrow}>ANOTAÇÕES</div>
   <h2 style={styles.pageTitle}>Bloco de notas</h2>
   <p style={styles.heroText}>Anotações gerais da casa, trabalho, ideias, lembretes e qualquer coisa que vocês precisem guardar.</p>
  </section>
  <section style={styles.card}>
   <div style={styles.cardHeader}>
    <div><div style={styles.eyebrow}>{editingNoteId ? "EDITANDO" : "NOVA ANOTAÇÃO"}</div><h2 style={styles.cardTitle}>{editingNoteId ? "Editar anotação" : "Escrever anotação"}</h2></div>
   </div>
   <label style={styles.label}>Título</label>
   <input value={noteTitle} onChange={e => setNoteTitle(e.target.value)} placeholder="Ex.: ideias para vídeos" style={styles.input}/>
   <label style={styles.label}>Anotação</label>
   <textarea value={noteContent} onChange={e => setNoteContent(e.target.value)} placeholder="Escreva aqui..." style={{...styles.textarea,minHeight:180}}/>
   <button style={styles.primaryButtonLarge} onClick={saveNote}>{editingNoteId ? "✓ Atualizar anotação" : "✓ Salvar anotação"}</button>
   {editingNoteId && (
    <button style={styles.secondaryButtonLarge} onClick={() => { setEditingNoteId(null); setNoteTitle(""); setNoteContent(""); }}>Cancelar edição</button>
   )}
  </section>
  <section style={styles.card}>
   <div style={styles.cardHeader}><div><div style={styles.eyebrow}>ARQUIVO</div><h2 style={styles.cardTitle}>Anotações salvas</h2></div><span style={styles.countBadge}>{notes.length}</span></div>
   {notes.length === 0 && <div style={styles.emptyBox}>Nenhuma anotação salva.</div>}
   {notes.length > 0 && (
    <div style={styles.list}>
     {notes.map(note => (
      <div key={note.id} style={styles.noteCard}>
       <div style={styles.cardHeader}><div><strong>{note.title}</strong><div style={styles.muted}>{formatDateTime(note.updatedAt)}</div></div></div>
       <div style={styles.noteBox}>{note.content || "Sem conteúdo."}</div>
       <div style={styles.futureActions}>
        <button style={styles.smallButton} onClick={() => editNote(note)}>Editar</button>
        <button style={styles.deleteButton} onClick={() => deleteNote(note.id)}>Excluir</button>
       </div>
      </div>
     ))}
    </div>
   )}
  </section>
 </>
)}
 
{/* =================================================
ORÇAMENTOS
================================================= */}
{screen === "budgets" && (
<>
<button style={styles.backButton} onClick={() => setScreen("dashboard")}>← Início</button>
<section style={styles.hero}>
<div style={styles.eyebrow}>ORÇAMENTOS</div>
<h2 style={styles.pageTitle}>Novo orçamento</h2>
<p style={styles.heroText}>Cadastre exatamente o que está sendo orçado e deixe o orçamento vinculado ao consulente, ao histórico e às atividades do dia.</p>
</section>
<section style={styles.card}>
<label style={styles.label}>Consulente</label>
<select value={budgetClientId} onChange={e => {const id=e.target.value; setBudgetClientId(id); const c=clients.find(x=>x.id===id); if(c){setBudgetShippingRecipientName(c.name);setBudgetShippingPhone(c.phone||"");setBudgetShippingAddress(clientAddressText(c));setBudgetShippingZipCode(clientPostalCodeText(c));setBudgetShippingCity(c.address?.city||"");setBudgetShippingState(c.address?.state||"");}}} style={styles.input}>
<option value="">Selecione o consulente</option>
{clients.map(client => <option key={client.id} value={client.id}>{client.name}</option>)}
</select>
<button style={styles.smallOutlineButton} onClick={() => setShowNewClient(true)}>+ Cadastrar consulente</button>

<label style={styles.label}>O orçamento é de quê?</label>
<select value={budgetServiceType} onChange={e => setBudgetServiceType(e.target.value as Budget["serviceType"])} style={styles.input}>
<option value="reading">🔮 Tiragem / consulta de tarô</option>
<option value="spell">🕯️ Feitiço</option>
<option value="work">✨ Trabalho espiritual</option>
<option value="sale">🛍️ Serviço / atendimento</option>
<option value="product">📦 Produto</option>
<option value="other">📋 Outro</option>
</select>

<label style={styles.label}>Nome específico do serviço</label>
<input value={budgetServiceName} onChange={e => setBudgetServiceName(e.target.value)} placeholder="Ex.: Tiragem completa, Feitiço de proteção, Trabalho de prosperidade..." style={styles.input}/>

<label style={styles.label}>Título do orçamento</label>
<input value={budgetTitle} onChange={e => setBudgetTitle(e.target.value)} placeholder="Ex.: Orçamento para proteção" style={styles.input}/>

<section style={{...styles.infoBox,display:"grid",gap:8}}><strong>🧾 Itens do orçamento</strong>{budgetItems.map((item,idx)=><div key={item.id} style={styles.listItem}><div style={{minWidth:0,flex:1}}><strong>{item.description}</strong><div style={styles.muted}>{item.quantity||1} × {formatMoney(item.unitPrice)} · {item.kind||"outro"}</div></div><button style={styles.deleteButton} onClick={()=>setBudgetItems(prev=>prev.filter((_,i)=>i!==idx))}>×</button></div>)}<div style={styles.twoColumns}><input value={budgetItemDescription} onChange={e=>setBudgetItemDescription(e.target.value)} placeholder="Ex.: Pergunta 1 / pedra / tiragem" style={styles.input}/><input type="number" min="0" step="0.01" value={budgetItemUnitPrice} onChange={e=>setBudgetItemUnitPrice(e.target.value)} placeholder="Valor unitário" style={styles.input}/></div><div style={styles.twoColumns}><select value={budgetItemKind} onChange={e=>setBudgetItemKind(e.target.value as BudgetItem["kind"])} style={styles.input}><option value="question">Pergunta</option><option value="reading">Tiragem</option><option value="work">Trabalho</option><option value="sale">Venda</option><option value="material">Material</option><option value="other">Outro</option></select><input type="number" min="1" step="1" value={budgetItemQuantity} onChange={e=>setBudgetItemQuantity(e.target.value)} placeholder="Qtd." style={styles.input}/></div><button style={styles.smallButton} onClick={()=>{const d=budgetItemDescription.trim();const price=Number(String(budgetItemUnitPrice).replace(",","."))||0;const qty=Math.max(1,Number(budgetItemQuantity)||1);if(!d||price<=0){showToast("Informe descrição e valor do item.");return;}setBudgetItems(prev=>[...prev,{id:makeId(),description:d,kind:budgetItemKind,quantity:qty,unitPrice:price,currency:budgetCurrency}]);setBudgetItemDescription("");setBudgetItemUnitPrice("");setBudgetItemQuantity("1");}}>+ Adicionar item</button><div><strong>Total dos itens: {formatForeign(budgetItems.reduce((sum,i)=>sum+(i.quantity||1)*i.unitPrice,0),budgetCurrency)}</strong></div></section><label style={styles.label}>Descrição / o que será entregue</label>
<textarea value={budgetDescription} onChange={e => setBudgetDescription(e.target.value)} placeholder="Detalhe o serviço, materiais, quantidade, prazo, condições..." style={{...styles.textarea,minHeight:130}}/>

<div style={styles.twoColumns}>
<div><label style={styles.label}>Valor</label><input type="number" min="0" step="0.01" value={budgetValue} onChange={e => setBudgetValue(e.target.value)} placeholder="0,00" style={styles.input}/></div>
<div><label style={styles.label}>Acréscimo</label><input type="number" min="0" step="0.01" value={budgetSurcharge} onChange={e => setBudgetSurcharge(e.target.value)} placeholder="0,00" style={styles.input}/></div>
</div>
<label style={styles.label}>Desconto</label>
<input type="number" min="0" step="0.01" value={budgetDiscount} onChange={e => setBudgetDiscount(e.target.value)} placeholder="0,00" style={styles.input}/>
<label style={styles.label}>Validade do orçamento</label>
<input type="date" value={budgetValidUntil} onChange={e => setBudgetValidUntil(e.target.value)} style={styles.input}/>
<label style={styles.label}>Moeda</label><select value={budgetCurrency} onChange={e=>setBudgetCurrency(e.target.value as CurrencyCode)} style={styles.input}><option value="BRL">Real (R$)</option><option value="EUR">Euro (€)</option><option value="USD">Dólar ($)</option><option value="GBP">Libra (£)</option></select><section style={{...styles.infoBox,display:"grid",gap:8,marginTop:10}}><strong>💳 Condições de pagamento</strong><label style={styles.label}>Forma</label><select value={budgetPaymentMode} onChange={e=>setBudgetPaymentMode(e.target.value as any)} style={styles.input}><option value="paid">Pago na confirmação</option><option value="pending">Pendente / uma parcela</option><option value="installments">Parcelado</option></select><label style={styles.label}>Método</label><select value={budgetPaymentMethod} onChange={e=>setBudgetPaymentMethod(e.target.value as PaymentMethod)} style={styles.input}>{(["pix","credit","debit","cash","transfer","paypal","wise","other"] as PaymentMethod[]).map(m=><option key={m} value={m}>{m}</option>)}</select>{budgetPaymentMode==="pending"&&<><label style={styles.label}>Vencimento</label><input type="date" value={budgetPaymentDate} onChange={e=>setBudgetPaymentDate(e.target.value)} style={styles.input}/></>}{budgetPaymentMode==="installments"&&<><label style={styles.label}>Número de parcelas</label><input type="number" min="2" value={budgetInstallmentCount} onChange={e=>setBudgetInstallmentCount(e.target.value)} style={styles.input}/><label style={styles.label}>Primeiro vencimento</label><input type="date" value={budgetInstallmentFirstDate} onChange={e=>setBudgetInstallmentFirstDate(e.target.value)} style={styles.input}/><label style={styles.checkboxItem}><input type="checkbox" checked={budgetInstallmentEntry} onChange={e=>setBudgetInstallmentEntry(e.target.checked)}/> Entrada paga agora</label>{budgetInstallmentEntry&&<input type="number" min="0" step="0.01" value={budgetInstallmentEntryAmount} onChange={e=>setBudgetInstallmentEntryAmount(e.target.value)} placeholder="Valor da entrada" style={styles.input}/>}</>}</section>
<label style={styles.checkboxItem}><input type="checkbox" checked={budgetShippingEnabled} onChange={e=>setBudgetShippingEnabled(e.target.checked)}/> Envio necessário</label>
{budgetShippingEnabled && <div style={styles.paymentBox}><label style={styles.label}>Nome para envio</label><input value={budgetShippingRecipientName} onChange={e=>setBudgetShippingRecipientName(e.target.value)} style={styles.input}/><label style={styles.label}>Telefone</label><input value={budgetShippingPhone} onChange={e=>setBudgetShippingPhone(e.target.value)} style={styles.input}/><label style={styles.label}>Endereço</label><input value={budgetShippingAddress} onChange={e=>setBudgetShippingAddress(e.target.value)} style={styles.input}/><div style={styles.twoColumns}><input value={budgetShippingZipCode} onChange={e=>setBudgetShippingZipCode(e.target.value)} placeholder="CEP" style={styles.input}/><input value={budgetShippingCity} onChange={e=>setBudgetShippingCity(e.target.value)} placeholder="Cidade" style={styles.input}/></div><input value={budgetShippingState} onChange={e=>setBudgetShippingState(e.target.value)} placeholder="Estado" style={styles.input}/><div style={styles.twoColumns}><input type="number" min="0" step="0.01" value={budgetShippingUber} onChange={e=>setBudgetShippingUber(e.target.value)} placeholder="Valor Uber" style={styles.input}/><input type="number" min="0" step="0.01" value={budgetShippingCorreios} disabled={budgetShippingCorreiosPending} onChange={e=>setBudgetShippingCorreios(e.target.value)} placeholder="Valor Correios" style={styles.input}/></div><label style={styles.checkboxItem}><input type="checkbox" checked={budgetShippingCorreiosPending} onChange={e=>setBudgetShippingCorreiosPending(e.target.checked)}/> Correios ainda não informado</label></div>}
<div style={styles.infoBox}><strong>Valor final:</strong> {formatMoney(Math.max(0, (Number(String(budgetValue).replace(",", ".")) || 0) + (Number(String(budgetSurcharge).replace(",", ".")) || 0) - (Number(String(budgetDiscount).replace(",", ".")) || 0)))}</div>
<button style={styles.primaryButtonLarge} onClick={saveBudget}>✓ Cadastrar orçamento</button>
</section>
<section style={styles.card}>
<div style={styles.cardHeader}><div><div style={styles.eyebrow}>HISTÓRICO DE ORÇAMENTOS</div><h2 style={styles.cardTitle}>{budgets.length} orçamento(s)</h2></div></div>
{budgets.length === 0 ? <div style={styles.emptyBox}>Nenhum orçamento cadastrado ainda.</div> : (
<div style={styles.list}>
{budgets.map(item => {
const finalValue = Math.max(0, item.value + item.surcharge - item.discount);
return <div key={item.id} style={styles.listItem}>
<div style={{flex:1}}>
<strong>{item.serviceName}</strong>
<div style={styles.muted}>{item.clientName} · {item.title}</div>
<div style={styles.muted}>Valor final: {formatMoney(finalValue)} · Criado em {formatDate(item.createdAt)}</div>
{item.validUntil && <div style={styles.muted}>Válido até {formatDate(item.validUntil)}</div>}
{item.description && <div style={{...styles.noteBox,marginTop:8}}>{item.description}</div>}<div style={styles.muted}>Pagamento: {item.paymentMode==="paid"?"Pago":item.paymentMode==="installments"?`${item.installmentCount||2} parcelas`:`Pendente · ${item.paymentDate?formatDate(item.paymentDate):"sem vencimento"}`}{item.linkedWorkId?" · ✓ convertido em trabalho":""}</div>
</div>
<div style={styles.futureActions}>
<select value={item.status} onChange={e => updateBudgetStatus(item.id, e.target.value as Budget["status"])} style={styles.input}>
<option value="draft">Rascunho</option><option value="sent">Enviado</option><option value="approved">Aprovado</option><option value="rejected">Recusado</option><option value="expired">Expirado</option>
</select>
<button style={styles.smallButton} onClick={() => editBudgetDirect(item)}>✏️ Editar</button><button style={styles.smallButton} onClick={() => { const client = clients.find(c => c.id === item.clientId); if (client) { setHistoryClient(client); setScreen("history"); } }}>Histórico</button><button style={styles.primaryButton} onClick={()=>openBudgetApproval(item)}>✨ Configurar e criar trabalho</button>
<button style={styles.deleteButton} onClick={() => deleteBudget(item.id)}>Excluir</button>
</div>
</div>;
})}
</div>)}
</section>
</>
)}

{/* =================================================
CLIENTES
================================================= */}
{screen === "clients" && (
<>
<section
style={styles.hero}
>
<div
style={
styles.eyebrow
}
>
CONSULENTES
</div>
<h2
style={
styles.pageTitle
}
>
Clientes
</h2>
<p
style={
styles.heroText
}
>
Cadastre e consulte o
histórico de cada pessoa
atendida.
</p>
<button
style={
styles.primaryButtonLarge
}
onClick={() =>
setShowNewClient(
true
)
}
>
+ Novo consulente
</button>
</section>
<div style={styles.card}><label style={styles.label}>Pesquisar consulente</label><input value={clientSearch} onChange={e=>setClientSearch(e.target.value)} placeholder="🔎 Nome, telefone ou país..." style={styles.input}/></div>
<div
style={styles.list}
>
{clients.filter(client => { const q=clientSearch.trim().toLocaleLowerCase("pt-BR"); if(!q) return true; return `${client.name} ${client.phone} ${clientCountry(client)}`.toLocaleLowerCase("pt-BR").includes(q); }).map(
(client) => (
<div
key={client.id}
style={
styles.clientCard
}
>
<button
  type="button"
  aria-label={`Abrir foto de ${client.name}`}
  style={{...styles.clientAvatar,border:"none",padding:0,overflow:"hidden",cursor:client.avatarPhoto?"pointer":"default"}}
  onClick={() => client.avatarPhoto && setSelectedClientPhoto({id:client.id,name:client.name,data:client.avatarPhoto})}
>
  {client.avatarPhoto ? <img src={client.avatarPhoto} alt={`Foto de ${client.name}`} style={{width:"100%",height:"100%",objectFit:"cover",display:"block"}} /> : client.name.charAt(0).toUpperCase()}
</button>
<div
style={
styles.clientInfo
}
>
<strong>
{
client.name
}
</strong>
<span
style={
styles.muted
}
>
{client.phone ||
"Telefone não cadastrado"}
</span>
<span style={styles.muted}>🌍 {clientCountry(client)}</span>{client.birthDate && <span style={styles.muted}>🎂 {formatDate(client.birthDate)}</span>}
</div>
<div style={{ display: "flex", gap: 6, flexWrap: "wrap", justifyContent: "flex-end" }}>
<button style={styles.smallButton} onClick={() => openHistory(client)}>Histórico</button>
<button style={styles.smallButton} onClick={() => editClient(client)}>Editar</button>
<button style={styles.deleteButton} onClick={() => deleteClient(client.id)}>Excluir</button>
</div>
</div>
)
)}
</div>
</>
)}
{/* =================================================
HISTÓRICO
================================================= */}
{screen ===
"history" &&
historyClient && (
<>
<button
style={
styles.backButton
}
onClick={() => {
setHistoryClient(
null
);
setScreen(
"clients"
);
}}
>
← Clientes
</button>
<section
style={styles.hero}
>
<div
style={
styles.eyebrow
}
>
HISTÓRICO DO CONSULENTE
</div>
<h2
style={
styles.pageTitle
}
>
{
historyClient.name
}
</h2>
<p style={styles.heroText}>
Ficha do consulente e histórico completo.
</p>
<div style={styles.infoBox}>
<strong>Ficha do consulente</strong>
<div style={{ marginTop: 6 }}>
WhatsApp: {historyClient.phone || "não informado"}
</div>
<div>País do consulente: 🌍 {clientCountry(historyClient)}</div>{historyClient.birthDate && <div>🎂 Data de nascimento: {formatDate(historyClient.birthDate)}</div>}
{historyClient.cpf && <div>CPF / documento: {historyClient.cpf}</div>}
{historyClient.address && <div style={{marginTop:6}}>📍 Endereço: {clientAddressText(historyClient)}{historyClient.address.postalCode ? ` · ${historyClient.address.postalCode}` : ""}{historyClient.address.country ? ` · ${historyClient.address.country}` : ""}</div>}
{historyClient.createdAt && (
<div>Cadastro: {formatDate(historyClient.createdAt)}</div>
)}
{historyClient.notes && (
<div style={{ marginTop: 8, whiteSpace: "pre-wrap" }}>
{historyClient.notes}
</div>
)}
</div>
</section>
<section style={{...styles.card,display:"grid",gap:10}}>
  <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",gap:10,flexWrap:"wrap"}}>
    <div>
      <div style={styles.eyebrow}>ÁUDIOS DA FICHA</div>
      <h2 style={styles.cardTitle}>Áudios da consulente</h2>
      <div style={styles.muted}>Grave um áudio diretamente nesta ficha. Ele fica salvo no cadastro e no histórico.</div>
    </div>
    <button type="button" style={styles.primaryButtonLarge} onClick={() => handleOpenAudioRecorderClick({kind:"client", clientId:historyClient.id})}>🎙️ Gravar áudio</button>
  </div>
  {(historyClient.audios || []).length > 0 ? <div style={{display:"grid",gap:8}}>
    {(historyClient.audios || []).map((audio,index) => <div key={audio.id} style={{display:"grid",gap:7,padding:10,border:"1px solid #eadfe6",borderRadius:14,background:"#fff"}}>
      <div style={{display:"flex",justifyContent:"space-between",gap:8}}><strong>🎧 Áudio {index+1}</strong><span style={styles.muted}>{formatDuration(audio.duration)}</span></div>
      <AudioPlayer audio={audio}/>
      <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
        <button type="button" style={styles.smallButton} onClick={() => shareAudio(audio)}>↗ Compartilhar áudio</button>
        <button type="button" style={styles.smallButton} onClick={() => { if (!window.confirm("Excluir este áudio da ficha da consulente?")) return; setClients(previous => previous.map(item => item.id === historyClient.id ? {...item, audios:(item.audios || []).filter(x => x.id !== audio.id), updatedAt:nowISO()} : item)); setHistoryClient(previous => previous && previous.id === historyClient.id ? {...previous, audios:(previous.audios || []).filter(x => x.id !== audio.id), updatedAt:nowISO()} : previous); showToast("Áudio excluído da ficha."); }}>🗑️ Excluir</button>
      </div>
    </div>)}
  </div> : <div className={"emptyBox"}>Nenhum áudio salvo diretamente na ficha ainda.</div>}
</section>
<section style={styles.card}>
  <label style={styles.label}>Pesquisar no histórico</label>
  <input value={historySearch} onChange={e => setHistorySearch(e.target.value)} placeholder="🔎 Atendimento, pergunta ou palavra..." style={styles.input} />
</section>
{budgets.filter(item => item.clientId === historyClient.id).length > 0 && (
<section style={styles.card}>
<div style={styles.eyebrow}>ORÇAMENTOS</div>
<h2 style={styles.cardTitle}>Orçamentos desta consulente</h2>
<div style={styles.list}>
{budgets.filter(item => item.clientId === historyClient.id).map(item => (
<div key={item.id} style={styles.listItem}>
<div style={{flex:1}}><button type="button" style={{background:"none",border:0,padding:0,textAlign:"left",fontWeight:800,cursor:"pointer"}} onClick={()=>setExpandedBudgetId(expandedBudgetId===item.id?null:item.id)}><strong>{item.serviceName}</strong><div style={styles.muted}>{item.title} · {formatMoney(Math.max(0, item.value + item.surcharge - item.discount))}</div></button>{expandedBudgetId===item.id && <div style={{marginTop:10}}><div className="noteBox" style={styles.noteBox}>{item.description || "Sem descrição."}</div><div style={styles.muted}>Status: {item.status} · Moeda: {item.currency || "BRL"}</div>{item.shippingEnabled && <div style={styles.infoBox}>📦 Envio · Uber {formatMoney(item.shippingUber||0)} · Correios {item.shippingCorreiosPending?"a informar":formatMoney(item.shippingCorreios||0)}<br/>{item.shippingRecipientName} · {item.shippingPhone}<br/>{item.shippingAddress} · {item.shippingZipCode} · {item.shippingCity}/{item.shippingState}</div>}<div style={styles.infoBox}>📌 O histórico é somente informativo. A aprovação ou reprovação deste orçamento é feita na Central de Serviços.</div></div>}</div>
</div>
))}
</div>
</section>
)}
{historyClientConsultations.length ===
0 ? (
<div
style={
styles.emptyBox
}
>
Nenhum atendimento
registrado.
</div>
) : (
<div
style={
styles.historyList
}
>
{historyClientConsultations.filter(c=>{ const q=historySearch.trim().toLowerCase(); if(!q) return true; return `${c.title} ${c.clientName} ${c.currency || "BRL"} ${c.paymentMethod || ""} ${c.questions.map(x=>`${x.text} ${x.notes}`).join(" ")}`.toLowerCase().includes(q); }).map(
(
consultation
) => (
<div key={consultation.id}>
<HistoryItem
consultation={consultation}
execution={consultation.serviceType === "work" ? workExecutions.find(execution => execution.consultationId === consultation.id) : undefined}
onResume={() => resumeConsultation(consultation)}
onEdit={() => openEditConsultation(consultation)}
onDelete={() => deleteConsultation(consultation.id, true)}
onPhotoDelete={(photoId)=>deleteHistoryPhoto(consultation.id,photoId)}
/>
{consultation.serviceType === "work" && consultations.filter(activity => activity.linkedWorkId === consultation.id && activity.status === "completed").length > 0 && (
<div style={{...styles.card, marginTop: -4, paddingTop: 12}}>
<div style={styles.muted}>✨ Atividades vinculadas</div>
{consultations.filter(activity => activity.linkedWorkId === consultation.id && activity.status === "completed").map(activity => <div key={activity.id} style={{...styles.listItem, marginTop:6}}>
<div><strong>{activity.title}</strong><div style={styles.muted}>{activity.activityType === "free_support" ? "🎁 Suporte grátis" : activity.activityType === "work_done" ? "✨ Trabalho realizado" : "🔮 Tiragem vinculada"} · {formatDateTime(activity.createdAt)}</div></div>
<strong>{activity.value > 0 ? formatMoney(activity.value) : "Grátis"}</strong>
</div>)}
</div>
)}
</div>
)
)}
</div>
)}
<section style={styles.card}>
<div style={styles.cardHeader}><div><div style={styles.eyebrow}>DESFALQUES AUTOMÁTICOS</div><h2 style={styles.cardTitle}>O que deixou de entrar</h2><div style={styles.muted}>Gerados a partir do checkout e de parcelas marcadas como não pagas.</div></div></div>
{desfalques.filter(item => item.clientId === historyClient.id).length === 0 ? <div style={styles.emptyBox}>Nenhum desfalque registrado para este consulente.</div> : <div style={styles.list}>{desfalques.filter(item => item.clientId === historyClient.id).map(item => <div key={item.id} style={styles.listItem}><div><strong>{item.description}</strong><div style={styles.muted}>{formatDateTime(item.date)} · Potencial {formatMoney(item.potentialValue)} · Recebido {formatMoney(item.receivedValue)}</div></div><strong>{formatMoney(item.amount)}</strong></div>)}</div>}
</section>
</>
)}
{/* =================================================
FINANCEIRO
================================================= */}
{screen ===
"finance" && (
<>
<button
style={
styles.backButton
}
onClick={() =>
setScreen(
"dashboard"
)
}
>
← Início
</button>
<section
style={styles.hero}
>
<div
style={
styles.eyebrow
}
>
FINANCEIRO
</div>
<h2
style={
styles.pageTitle
}
>
Casa e Trabalho
</h2>
<p
style={
styles.heroText
}
>
O financeiro é integrado,
mas os valores da casa e
do trabalho continuam
separados.
</p>
</section>
<section style={styles.card}>
 <div style={styles.cardHeader}><div><div style={styles.eyebrow}>CENTRAL DE CONTAS</div><h2 style={styles.cardTitle}>O que precisa ser pago</h2></div><button style={styles.smallButton} onClick={()=>setScreen("accounts")}>Abrir central →</button></div>
 <div className="dashboard-mini-grid"><FinanceMini title="Atrasadas" value={formatMoney(overduePayableTotal + overdueLoanInstallments.reduce((s,i)=>s+i.amount,0))} subtitle={`${overduePayables.length + overdueLoanInstallments.length} obrigação(ões)`}/><FinanceMini title="Próximas" value={formatMoney(payablePending)} subtitle="A pagar"/><FinanceMini title="Empréstimos" value={formatMoney(loanBalanceTotal)} subtitle="Saldo devedor"/><FinanceMini title="Patrimônio" value={formatMoney(totalFinancialPatrimony)} subtitle="Caixa + reservas + aplicações"/></div>
</section>
<div
style={
styles.statsGrid
}
>
<StatCard
title="Compras Casa"
value={formatMoney(
purchasesHome
)}
/>
<StatCard
title="Compras Trabalho"
value={formatMoney(
purchasesWork
)}
/>
<StatCard
title="A pagar"
value={formatMoney(payablePending)}
/>
<StatCard title="Recorrentes" value={formatMoney(recurringTotal)} />
<StatCard
title="Pago em contas"
value={formatMoney(
payablePaid
)}
/>
<StatCard title="Desfalques" value={formatMoney(consultationDefaultedTotal + desfalques.reduce((sum, item) => sum + item.amount, 0))} onClick={()=>{setScreen("finance");setConsultantAgendaView("archived");}} />
</div>
<section style={styles.card}>
<div style={styles.cardHeader}><div><div style={styles.eyebrow}>RECEBIMENTOS</div><h2 style={styles.cardTitle}>Valores a receber</h2></div></div>
{consultationReceivables.length === 0 ? <div style={styles.emptyBox}>Nenhum valor pendente de atendimento.</div> : (
<div style={styles.list}>{consultationReceivables.map(item => {
const consultation = consultations.find(c => c.id === item.consultationId);
return <div key={item.id} style={styles.listItem}>
<div><strong>{item.clientName}</strong><div style={styles.muted}>{item.title} · Vencimento: {item.dueDate ? formatDate(item.dueDate) : "sem data"}{item.overdue ? " · vencido" : ""}</div>{item.currency && item.currency !== "BRL" ? <div style={styles.muted}>💱 Cobrança: {currencySymbol(item.currency)} {(item.amount / (item.currencyRate || 1)).toFixed(2)} · equivalente: {formatMoney(item.amount)}</div> : <div style={styles.muted}>💵 Valor: {formatMoney(item.amount)}</div>}</div>
<div style={styles.rightStack}><strong>{formatMoney(item.amount)}</strong>{item.installmentId && consultation ? <div style={{display:"flex", gap:6, flexWrap:"wrap", justifyContent:"flex-end"}}><button style={styles.smallButton} onClick={() => receiveConsultationInstallment(consultation.id, item.installmentId)}>Recebida</button><button style={styles.smallButton} onClick={() => setConsultationInstallmentStatus(consultation.id, item.installmentId, "defaulted")}>Não recebida</button></div> : null}</div>
</div>;
})}</div>
)}
</section>
<section
style={styles.card}
>
<div
style={
styles.cardHeader
}
>
<div>
<div
style={
styles.eyebrow
}
>
CASA
</div>
<h2
style={
styles.cardTitle
}
>
Financeiro da casa
</h2>
</div>
</div>
<div
style={
styles.financeBigNumber
}
>
{formatMoney(
purchasesHome
)}
</div>
<div
style={
styles.muted
}
>
Total de itens destinados à
casa nas compras registradas.
</div>
</section>
<section
style={styles.card}
>
<div
style={
styles.cardHeader
}
>
<div>
<div
style={
styles.eyebrow
}
>
TRABALHO
</div>
<h2
style={
styles.cardTitle
}
>
Financeiro do trabalho
</h2>
</div>
</div>
<div
style={
styles.financeBigNumber
}
>
{formatMoney(
purchasesWork
)}
</div>
<div
style={
styles.muted
}
>
Materiais e itens destinados
ao trabalho.
</div>
</section>
<section style={styles.card}>
<div style={styles.cardHeader}><div><div style={styles.eyebrow}>CONTAS RECORRENTES</div><h2 style={styles.cardTitle}>Próximas contas recorrentes</h2></div></div>
{accountTemplates.filter(item=>item.active).length===0 ? <div style={styles.emptyBox}>Nenhuma conta recorrente ativa.</div> : <div style={styles.list}>{accountTemplates.filter(item=>item.active).map(item => <div key={item.id} style={styles.listItem}><div><strong>{item.name}</strong><div style={styles.muted}>{item.area === "home" ? "Casa" : "Trabalho"} · Todo dia {item.dueDay}{item.description ? ` · ${item.description}` : ""}</div></div><strong>{formatMoney(Number(item.amount||0))}</strong></div>)}</div>}
<div style={{...styles.infoBox, marginTop: 10}}>Projeção mensal das contas recorrentes ativas: <strong>{formatMoney(recurringTotal)}</strong>.</div>
</section>
<div
style={
styles.actionGrid
}
>
<button
style={
styles.actionCard
}
onClick={() =>
setScreen(
"purchases"
)
}
>
🛒
<strong>
Compras
</strong>
<span>
Mercado, lojas e
restaurantes
</span>
</button>
<button
style={
styles.actionCard
}
onClick={() =>
setScreen(
"stock"
)
}
>
📦
<strong>
Estoque
</strong>
<span>
Casa e trabalho
</span>
</button>
<button
style={
styles.actionCard
}
onClick={() =>
setScreen(
"accounts"
)
}
>
💳
<strong>
Contas
</strong>
<span>
A pagar e
vencimentos
</span>
</button>
<button
style={
styles.actionCard
}
onClick={() =>
setShowSupplierModal(
true
)
}
>
🏪
<strong>
Fornecedores
</strong>
<span>
Mercados e
estabelecimentos
</span>
</button>
<button style={styles.actionCard} onClick={openLoanManager}>🏦<strong>Empréstimo</strong><span>Ver / criar</span></button>
<button style={styles.actionCard} onClick={openReserveManager}>🐷<strong>Caixinha</strong><span>Guardar / resgatar</span></button>
</div>
</>
)}
{/* =================================================
COMPRAS
================================================= */}
{screen ===
"purchases" && (
<>
<button
style={
styles.backButton
}
onClick={() =>
setScreen(
"finance"
)
}
>
← Financeiro
</button>
<section
style={styles.hero}
>
<div
style={
styles.eyebrow
}
>
COMPRAS
</div>
<h2
style={
styles.pageTitle
}
>
Compras e notas
</h2>
<p
style={
styles.heroText
}
>
Uma mesma compra pode ter
produtos destinados à casa
e ao trabalho.
</p>
<button
style={
styles.primaryButtonLarge
}
onClick={() =>
setShowPurchaseModal(
true
)
}
>
+ Registrar compra
</button>
</section>
{purchases.length ===
0 ? (
<div
style={
styles.emptyBox
}
>
Nenhuma compra registrada.
</div>
) : (
<div
style={
styles.list
}
>
{purchases.map(
(purchase) => {
const home =
purchase.items
.filter(
(item) =>
item.destination ===
"home"
)
.reduce(
(
sum,
item
) =>
sum +
item.total,
0
);
const work =
purchase.items
.filter(
(item) =>
item.destination ===
"work"
)
.reduce(
(
sum,
item
) =>
sum +
item.total,
0
);
return (
<div
key={
purchase.id
}
style={
styles.purchaseCard
}
>
<div
style={
styles.cardHeader
}
>
<div>
<strong>
{
purchase.supplierName
}
</strong>
<div
style={
styles.muted
}
>
{formatDate(
purchase.date
)}{" "}
·{" "}
{purchase.source ===
"nfe_qr"
? "NF-e / QR Code"
: "Manual"}
</div>
</div>
<strong>
{formatMoney(
purchase.total
)}
</strong>
</div>
<div
style={
styles.financeSummary
}
>
<FinanceMini
title="Casa"
value={formatMoney(
home
)}
subtitle="Itens"
/>
<FinanceMini
title="Trabalho"
value={formatMoney(
work
)}
subtitle="Itens"
/>
</div>
<div
style={
styles.itemList
}
>
{purchase.items.map(
(
item
) => (
<div
key={
item.id
}
style={
styles.purchaseItem
}
>
<div>
<strong>
{
item.name
}
</strong>
<div
style={
styles.muted
}
>
{
item.quantity
}{" "}
{
item.unit
}{" "}
×{" "}
{formatMoney(
item.unitPrice
)}
</div>
</div>
<div
style={
styles.purchaseItemRight
}
>
<span
style={
item.destination ===
"home"
? styles.homeBadge
: styles.workBadge
}
>
{item.destination ===
"home"
? "Casa"
: "Trabalho"}
</span>
<strong>
{formatMoney(
item.total
)}
</strong>
</div>
</div>
)
)}
<div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 12 }}>
<button style={styles.smallButton} onClick={() => editPurchase(purchase)}>Editar compra</button>
<button style={styles.deleteButton} onClick={() => deletePurchase(purchase.id)}>Excluir compra</button>
</div>
</div>
</div>
);
}
)}
</div>
)}
</>
)}
{/* =================================================
INVENTÁRIO FIXO — módulo independente
================================================= */}
{screen ===
"inventory" && (<InventoryModule
  items={inventoryItems}
  onItemsChange={setInventoryItems}
  onDelete={(item)=>{ if(window.confirm(`Mover \"${item.name}\" para a lixeira?`)){ sendToTrash("inventory", `Inventário: ${item.name}`, item); setInventoryItems(previous=>previous.filter(x=>x.id!==item.id)); showToast("Item do inventário enviado para a lixeira."); } }}
  onBack={()=>setScreen("dashboard")}
  showToast={showToast}
  styles={styles}
  compressImageFile={compressImageFile}
  compressDataUrl={compressDataUrl}
  formatMoney={formatMoney}
/>)}
{screen ===
"stock" && (
<>
<button
style={
styles.backButton
}
onClick={() =>
setScreen(
"finance"
)
}
>
← Financeiro
</button>
<section
style={styles.hero}
>
<div
style={
styles.eyebrow
}
>
ESTOQUE
</div>
<h2
style={
styles.pageTitle
}
>
Estoque Casa / Trabalho
</h2>
<p
style={
styles.heroText
}
>
Registre entradas, consumo,
perdas e transferências entre
casa e trabalho.
</p>
<div
style={
styles.actionGrid
}
>
<button
style={
styles.primaryButtonLarge
}
onClick={() =>
setShowStockModal(
true
)
}
>
+ Novo item
</button>
<button
style={
styles.secondaryButtonLarge
}
onClick={() =>
setShowTransferModal(
true
)
}
>
🔄Transferir
</button>
</div>
</section>
<div
style={
styles.statsGrid
}
>
<StatCard
title="Valor Casa"
value={formatMoney(
stockValueHome
)}
/>
<StatCard
title="Valor Trabalho"
value={formatMoney(
stockValueWork
)}
/>
<StatCard
title="Itens baixos"
value={String(
lowStockItems.length
)}
/>
<StatCard
title="Itens cadastrados"
value={String(
stockItems.length
)}
/>
</div>
{stockItems.length ===
0 ? (
<div
style={
styles.emptyBox
}
>
Nenhum item no estoque.
</div>
) : (
<div
style={styles.list}
>
{stockItems.map(
(item) => (
<div
key={item.id}
style={
styles.stockCard
}
>
<div
style={
styles.stockIcon
}
>
📦
</div>
<div
style={
styles.stockInfo
}
>
<strong>
{item.name}
</strong>
<span
style={
styles.muted
}
>
{item.area ===
"home"
? "Casa"
: "Trabalho"}
{" · "}
{
item.quantity
}{" "}
{item.unit}
</span>
<span
style={
styles.muted
}
>
Custo médio:{" "}
{formatMoney(
item.averageCost
)}
</span>
</div>
<div
style={
styles.stockActions
}
>
{item.quantity <=
item.minimumQuantity && (
<span
style={
styles.warningBadge
}
>
Baixo
</span>
)}
<button style={styles.smallButton} onClick={()=>consumeStock(item)}>Consumir</button><button style={styles.smallButton} onClick={()=>editStockItem(item)}>Editar</button><button style={styles.deleteButton} onClick={()=>deleteStockItem(item.id)}>Excluir</button>
</div>
</div>
)
)}
</div>
)}
</>
)}
{/* =================================================
CONTAS
================================================= */}
{screen ===
"accounts" && (
<>
<button style={styles.backButton} onClick={()=>setScreen("finance")}>← Financeiro</button>
<section style={styles.hero}><div style={styles.eyebrow}>CENTRAL DE CONTAS</div><h2 style={styles.pageTitle}>Contas, parcelas e vencimentos</h2><p style={styles.heroText}>Aqui ficam contas recorrentes, contas variáveis, parcelas de empréstimos e tudo que precisa ser pago.</p><div style={styles.actionGrid}><button style={styles.primaryButtonLarge} onClick={()=>setShowPayableModal(true)}>+ Nova conta</button><button style={styles.secondaryButtonLarge} onClick={openLoanManager}>🏦 Empréstimos</button></div></section>
<div style={styles.statsGrid}><StatCard title="Atrasadas" value={formatMoney(overduePayableTotal)}/><StatCard title="A pagar" value={formatMoney(payablePending)}/><StatCard title="Dívida" value={formatMoney(loanBalanceTotal)}/><StatCard title="Guardado" value={formatMoney(reserveTotal+investmentTotal)}/></div>
<section style={styles.card}><div style={styles.cardHeader}><div><div style={styles.eyebrow}>CONTAS A PAGAR</div><h2 style={styles.cardTitle}>Próximos pagamentos</h2></div></div>{upcomingPayables.length===0?<div style={styles.emptyBox}>Nenhuma conta pendente.</div>:<div style={styles.list}>{upcomingPayables.map(account=>{const late=account.dueDate<todayKey;return <div key={account.id} style={styles.listItem}><div style={{flex:1}}><strong>{late?"🔴 ":"🧾 "}{account.description}</strong><div style={styles.muted}>{account.area==="home"?"Casa":"Trabalho"} · Vencimento: {formatDate(account.dueDate)}{account.isVariable?" · Variável":" · Fixa"}</div>{late&&<span style={styles.statusPillDanger}>Atrasada</span>}</div><div style={styles.rightStack}><strong>{formatMoney(account.amount)}</strong><div style={{display:"flex",gap:6,flexWrap:"wrap",justifyContent:"flex-end"}}>{account.isVariable && account.amount<=0 && <button style={styles.smallButton} onClick={()=>informPayableAmount(account.id)}>Informar valor</button>}<button style={styles.smallButton} onClick={()=>markPayablePaid(account.id)}>Pagar</button><button style={styles.smallButton} onClick={()=>postponePayable(account.id)}>Adiar</button></div></div></div>})}</div>}</section>
<section style={styles.card}><div style={styles.cardHeader}><div><div style={styles.eyebrow}>HISTÓRICO DE CONTAS PAGAS</div><h2 style={styles.cardTitle}>O que já foi pago</h2></div></div>{payables.filter(x=>x.status==="paid").length===0?<div style={styles.emptyBox}>Nenhuma conta paga registrada.</div>:<div style={styles.list}>{payables.filter(x=>x.status==="paid").sort((a,b)=>b.dueDate.localeCompare(a.dueDate)).map(x=><div key={x.id} style={styles.listItem}><div><strong>✓ {x.description}</strong><div style={styles.muted}>{x.area==="home"?"Casa":"Trabalho"} · Pago em {x.paidAt?formatDate(x.paidAt):formatDate(x.dueDate)} · {x.paymentMethod}</div></div><strong>{formatMoney(x.paidAmount??x.amount)}</strong></div>)}</div>}</section>
<section style={styles.card}><div style={styles.cardHeader}><div><div style={styles.eyebrow}>EMPRÉSTIMOS</div><h2 style={styles.cardTitle}>Parcelas e saldo devedor</h2></div></div>{loans.length===0?<div style={styles.emptyBox}>Nenhum empréstimo cadastrado.</div>:<div style={styles.list}>{loans.map(loan=><div key={loan.id} style={{...styles.listItem,display:"block"}}><div style={styles.cardHeader}><div><strong>🏦 {loan.name}</strong><div style={styles.muted}>Saldo devedor: {formatMoney(loan.balanceDue??loan.principal)} · {loan.paidInstallments}/{loan.installments} parcelas pagas</div></div><strong>{formatMoney(loan.installmentAmount||0)}</strong></div>{(loan.installmentSchedule||[]).filter(i=>i.status!=="paid").slice(0,3).map(i=><div key={i.id} style={{...styles.listItem,marginTop:7}}><div><strong>Parcela {i.number}</strong><div style={styles.muted}>{formatDate(i.dueDate)} · {formatMoney(i.amount)}</div></div><button style={styles.smallButton} onClick={()=>payLoanInstallment(loan.id,i.id)}>Pagar parcela</button></div>)}</div>)}</div>}</section>


</>
)}
{/* =================================================
RELATÓRIOS
================================================= */}
{screen === "services" && (() => {
 const workRecords = consultations.flatMap(c => (c.relatedCharges||[]).filter(x=>x.kind==="work" && !x.deletedAt && c.status!=="standby").map(x=>({id:x.id, recordType:"work", consultationId:c.id, chargeId:x.id, workTypeId:x.workTypeId, title:x.title, clientName:c.clientName, scheduledAt:x.scheduledAt, amount:x.originalAmount, currency:x.currency, execution:workExecutions.find(e=>e.id===x.id), status:x.status || (x.scheduledAt?"scheduled":"approved"), consultation:c, paymentStatus:getPaymentStatus(c), createdAt:x.scheduledAt || c.createdAt})));
 const directWorks = consultations.filter(c=>c.serviceType==="work" && !c.deletedAt).map(c=>({id:c.id, recordType:"work", consultationId:c.id, workTypeId:c.workTypeId, title:c.workTypeName||c.title, clientName:c.clientName, scheduledAt:c.scheduledAt, amount:c.value, currency:c.currency||"BRL", execution:workExecutions.find(e=>e.id===c.id), status:c.workStatus || (c.scheduledAt?"scheduled":"approved"), consultation:c, paymentStatus:getPaymentStatus(c), createdAt:c.createdAt}));
 const allWorks = [...workRecords, ...directWorks.filter(d=>!workRecords.some(w=>w.id===d.id))];
 const relatedSales=consultations.flatMap(c=>(c.relatedCharges||[]).filter(x=>x.kind==="sale"&&!x.deletedAt&&c.status!=="standby").map(x=>({id:x.id,recordType:"sale",consultationId:c.id,chargeId:x.id,clientName:c.clientName,title:x.title,amount:x.originalAmount,currency:x.currency,scheduledAt:x.scheduledAt,shippingScheduledAt:x.shippingScheduledAt,createdAt:x.scheduledAt||c.createdAt,status:x.saleStatus||"approved",paymentStatus:getPaymentStatus(c),saleStatus:x.saleStatus||"approved",needsConfection:["awaiting_confection","in_confection"].includes(x.saleStatus||""),shippingEnabled:!!x.shippingEnabled,consultation:c})));
 const directSales=consultations.filter(c=>c.serviceType==="sale"&&!c.deletedAt).map(c=>({id:c.id,recordType:"sale",consultationId:c.id,clientName:c.clientName,title:c.saleItemName||c.title,amount:c.value,currency:c.currency||"BRL",scheduledAt:c.scheduledAt,shippingScheduledAt:c.shippingScheduledAt,createdAt:c.createdAt,status:c.saleStatus||(c.shippingEnabled?"awaiting_shipping":"approved"),paymentStatus:getPaymentStatus(c),saleStatus:c.saleStatus||"approved",needsConfection:["awaiting_confection","in_confection"].includes(c.saleStatus||""),shippingEnabled:!!c.shippingEnabled,consultation:c}));
 const sales=[...relatedSales,...directSales.filter(d=>!relatedSales.some(r=>r.id===d.id))];
 const readings = consultations.filter(c=>!c.deletedAt && c.questions?.length).map(c=>({id:c.id,recordType:"reading",clientName:c.clientName,title:c.title,questions:c.questions.length,amount:c.value,currency:c.currency||"BRL",status:c.status,createdAt:c.createdAt,consultation:c}));
 const budgetsList = budgets.filter(b=>!b.deletedAt).map(b=>({...b,recordType:"budget" as const,linkedWorkId:b.linkedWorkId || consultations.find(c=>c.budgetId===b.id && c.serviceType==="work")?.id,clientName:b.clientName || clients.find(c=>c.id===b.clientId)?.name || "Sem consulente",createdAt:b.createdAt}));
 const statusLabel=(status:string)=>({approved:"🟢 Aguardando execução",scheduled:"🟡 Agendado",in_progress:"🟢 Aguardando execução",completed:"✅ Executado",cancelled:"❌ Cancelado",postponed:"⏸️ Prorrogado",pending:"🕐 Não pago",partial:"🟠 Pago parcialmente",paid:"✓ Pago",draft:"📝 Rascunho",sent:"📤 Enviado",rejected:"❌ Rejeitado",expired:"⌛ Expirado",standby:"🔵 Standby",active:"🔮 Em atendimento",awaiting_confection:"🧵 Aguardando confecção",in_confection:"🛠️ Em confecção",awaiting_shipping:"📦 Aguardando envio",shipped:"🚚 Enviado",delivered:"✅ Entregue"}[status]||"🟢 Aprovado");
 const openWorkDetail=(w:any)=>{setSelectedServiceRecord(w);setShowServiceDetail(true);};
 const searchNeedle=serviceHubSearch.trim().toLowerCase();
 const bySearch=(x:any)=>`${x.clientName||""} ${x.title||""} ${x.serviceName||""}`.toLowerCase().includes(searchNeedle);
 const bySort=(a:any,b:any)=>{const av=Date.parse(a.createdAt||a.scheduledAt||"")||0;const bv=Date.parse(b.createdAt||b.scheduledAt||"")||0;return serviceHubSort==="recent"?bv-av:av-bv;};
 const workWaiting=(w:any)=>!w.execution && w.status === "approved";
 const workMatches=(w:any)=>{if(!bySearch(w))return false;if(serviceHubStatusFilter==="all")return true;if(serviceHubStatusFilter==="waiting")return workWaiting(w);if(serviceHubStatusFilter==="unpaid")return !(w.consultation?.paid) || (w.consultation?.paymentPlan?.installments||[]).some((i:any)=>i.status!=="received");return (w.execution?"completed":(w.status==="in_progress"?"approved":w.status))===serviceHubStatusFilter;};
 const saleMatches=(x:any)=>{if(!bySearch(x))return false;if(serviceHubStatusFilter==="all")return true;if(serviceHubStatusFilter==="unpaid")return !x.consultation?.paid || (x.consultation?.paymentPlan?.installments||[]).some((i:any)=>i.status!=="received");return serviceHubStatusFilter===x.saleStatus;};
 const readingMatches=(x:any)=>bySearch(x) && (serviceHubStatusFilter==="all" || (serviceHubStatusFilter==="scheduled" ? !!x.scheduledAt && x.status!=="completed" && x.status!=="cancelled" : serviceHubStatusFilter===x.status));
 const budgetMatches=(x:any)=>bySearch(x) && (serviceHubStatusFilter==="all" || (serviceHubStatusFilter==="awaiting_approval" ? ["draft","sent"].includes(x.status) : serviceHubStatusFilter===x.status));
 const visibleWorks=allWorks.filter(workMatches).sort(bySort);
 const visibleSales=sales.filter(saleMatches).sort(bySort);
 const readingStatusRank=(x:any)=>{
  if (x?.scheduledAt && x?.status!=="completed" && x?.status!=="cancelled") return 0;
  if (x?.status==="standby") return 1;
  if (x?.status==="active") return 2;
  if (x?.status==="completed") return 3;
  return 4;
};
const visibleReadings=readings.filter(readingMatches).sort((a:any,b:any)=>{
  const rank=readingStatusRank(a)-readingStatusRank(b);
  if(rank!==0) return rank;
  if(readingStatusRank(a)===0){
    const ad=a.scheduledAt||""; const bd=b.scheduledAt||"";
    const scheduledCompare=ad.localeCompare(bd);
    if(scheduledCompare!==0) return scheduledCompare;
  }
  return bySort(a,b);
});
 const visibleBudgets=budgetsList.filter(budgetMatches).sort(bySort);
 const setHub=(tab:"works"|"sales"|"readings"|"budgets")=>{
  setServiceHubTab(tab);
  setServiceHubStatusFilter(tab==="works"?"waiting":tab==="readings"?"scheduled":"all");
};
 return <>
  <button style={styles.backButton} onClick={()=>setScreen("dashboard")}>← Início</button>
  <section style={styles.hero}><div style={styles.eyebrow}>CENTRAL DE SERVIÇOS</div><h2 style={styles.pageTitle}>Trabalhos, vendas, tiragens e orçamentos</h2><p style={styles.heroText}>Encontre e administre cada tipo de serviço sem precisar entrar no histórico de cada consulente.</p></section>
  <div className="serviceTabs" style={styles.serviceTabs}><button style={{...styles.serviceTab,...(serviceHubTab==="works"?styles.serviceTabActive:{})}} onClick={()=>setHub("works")}>🔥 Trabalhos</button><button style={{...styles.serviceTab,...(serviceHubTab==="sales"?styles.serviceTabActive:{})}} onClick={()=>setHub("sales")}>🛍️ Vendas</button><button style={{...styles.serviceTab,...(serviceHubTab==="readings"?styles.serviceTabActive:{})}} onClick={()=>setHub("readings")}>🔮 Tiragens</button><button style={{...styles.serviceTab,...(serviceHubTab==="budgets"?styles.serviceTabActive:{})}} onClick={()=>setHub("budgets")}>📋 Orçamentos</button></div>
  <section style={styles.card}><div className="searchToolbar" style={styles.searchToolbar}><input value={serviceHubSearch} onChange={e=>setServiceHubSearch(e.target.value)} placeholder="🔎 Pesquisar por consulente, trabalho ou descrição..." style={styles.input}/><div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}><select value={serviceHubStatusFilter} onChange={e=>setServiceHubStatusFilter(e.target.value)} style={styles.input}>{serviceHubTab==="works" ? <><option value="waiting">⏳ Aguardando execução</option><option value="all">Todos os trabalhos</option><option value="scheduled">🟡 Agendados</option><option value="completed">✅ Executados</option><option value="postponed">⏸️ Prorrogados</option><option value="cancelled">❌ Cancelados</option><option value="unpaid">💳 Não pagos</option></> : serviceHubTab==="sales" ? <><option value="all">Todas as vendas</option><option value="approved">🟢 Venda aprovada</option><option value="awaiting_confection">🧵 Aguardando confecção</option><option value="in_confection">🛠️ Em confecção</option><option value="awaiting_shipping">📦 Aguardando envio</option><option value="shipped">🚚 Enviadas</option><option value="delivered">✅ Entregues</option><option value="cancelled">❌ Canceladas</option><option value="unpaid">💳 Não pagas</option></> : serviceHubTab==="readings" ? <><option value="all">Todas as tiragens</option><option value="scheduled">📅 Agendadas</option><option value="standby">🔵 Standby</option><option value="active">🔮 Em atendimento</option><option value="completed">✅ Concluídas</option></> : <><option value="all">Todos os orçamentos</option><option value="awaiting_approval">🕐 Aguardando aprovação</option><option value="draft">📝 Rascunhos</option><option value="sent">📤 Enviados</option><option value="approved">✓ Aprovados / trabalho criado</option><option value="rejected">❌ Rejeitados</option><option value="expired">⌛ Expirados</option></>}</select><select value={serviceHubSort} onChange={e=>setServiceHubSort(e.target.value as "recent"|"oldest")} style={styles.input}><option value="recent">Mais recentes primeiro</option><option value="oldest">Mais antigos primeiro</option></select></div></div>
   {serviceHubTab==="works" && <div style={styles.list}>{visibleWorks.map(w=>{const executed=!!w.execution || w.status==="completed"; return <div key={w.id} className="serviceCard" style={styles.serviceCard} onClick={()=>openWorkDetail(w)}><div style={{minWidth:0,flex:1}}><ClientIdentity clientId={w.consultation?.clientId} clientName={w.clientName} size={42} /><div style={styles.cardTitleSmall}>🔥 {w.title}</div><div style={styles.muted}>{w.scheduledAt?`Agendado: ${formatDateTime(w.scheduledAt)}`:"Sem agendamento"} · {formatForeign(w.amount||0,w.currency||"BRL")}</div>{(()=>{const qs=consultations.flatMap(c=>c.questions||[]).filter(q=>q.relatedWorkId===w.id);const benefit=qs.filter(q=>q.workQuestionKind==="benefit").length;const paid=qs.filter(q=>q.workQuestionKind==="paid"||(!q.workQuestionKind&&q.billingMode!=="free"&&q.billingMode!=="desfalque")).length;const desfalqueCount=qs.filter(q=>q.billingMode==="desfalque"||(q.billingMode==="free"&&!q.workQuestionKind)).length;const courtesy=qs.filter(q=>q.workQuestionKind==="courtesy").length;return <div style={styles.muted}>🔮 {qs.length} pergunta(s) · 🎁 {benefit} benefício · 💰 {paid} paga(s) · 🎁 {courtesy} cortesia(s)</div>;})()}<div style={{display:"flex",gap:6,flexWrap:"wrap",marginTop:6}}><span style={executed?styles.successBadge:w.status==="cancelled"?styles.deleteBadge:styles.warningBadge}>{statusLabel(executed?"completed":w.status)}</span><span style={w.paymentStatus==="paid"?styles.successBadge:w.paymentStatus==="partial"?styles.warningBadge:styles.statusPillDanger}>💳 {w.paymentStatus==="paid"?"Pago":w.paymentStatus==="partial"?"Pago parcialmente":"Não pago"}</span></div></div><div className="serviceActions" style={styles.serviceActions} onClick={e=>e.stopPropagation()}>{!executed&&w.status!=="cancelled"&&<button style={styles.primaryButton} onClick={()=>openWorkExecution(w)}>▶ Executar</button>}<button style={styles.smallButton} onClick={()=>openWorkDetail(w)}>Abrir</button></div></div>})}</div>}
   {serviceHubTab==="sales" && <div style={styles.list}>{visibleSales.map(x=><div key={x.id} className="serviceCard" style={styles.serviceCard} onClick={()=>openWorkDetail(x)}><div style={{minWidth:0,flex:1}}><ClientIdentity clientId={x.consultation?.clientId} clientName={x.clientName} size={42} /><div className="cardTitleSmall">🛍️ {x.title}</div><div style={styles.muted}>{formatForeign(x.amount||0,x.currency||"BRL")} · {x.shippingEnabled?"Com envio":"Sem envio"}</div><div style={{display:"flex",gap:6,flexWrap:"wrap",marginTop:6}}><span style={x.saleStatus==="delivered"?styles.successBadge:styles.warningBadge}>{statusLabel(x.saleStatus)}</span><span style={x.paymentStatus==="paid"?styles.successBadge:x.paymentStatus==="partial"?styles.warningBadge:styles.statusPillDanger}>💳 {x.paymentStatus==="paid"?"Pago":x.paymentStatus==="partial"?"Pago parcialmente":"Não pago"}</span></div></div><div className="serviceActions" style={styles.serviceActions} onClick={e=>e.stopPropagation()}><button style={styles.smallButton} onClick={()=>openWorkDetail(x)}>Abrir</button></div></div>)}</div>}
   {serviceHubTab==="readings" && <div style={styles.list}>{visibleReadings.map(x=><div key={x.id} className="serviceCard" style={styles.serviceCard} onClick={()=>openWorkDetail(x)}><div><ClientIdentity clientId={x.consultation?.clientId} clientName={x.clientName} size={42} /><div className="cardTitleSmall">🔮 {x.title}</div><div style={styles.muted}>{consultationPackageLabel(x.consultation)} · {formatForeign(x.amount||0,x.currency||"BRL")}</div><div style={{marginTop:6}}><span style={styles.warningBadge}>{statusLabel(x.status)}</span></div></div></div>)}</div>}
   {serviceHubTab==="budgets" && <div style={styles.list}>{visibleBudgets.map(b=><div key={b.id} className="serviceCard" style={styles.serviceCard} onClick={()=>openWorkDetail(b)}><div style={{minWidth:0,flex:1}}><ClientIdentity clientId={b.clientId} clientName={b.clientName} size={42} /><div className="cardTitleSmall">📋 {b.title}</div><div style={styles.muted}>{b.serviceName} · {formatForeign(b.value,b.currency||"BRL")}</div><div style={{display:"flex",gap:6,flexWrap:"wrap",marginTop:6}}><span style={b.status==="approved"?styles.successBadge:b.status==="rejected"?styles.deleteBadge:styles.warningBadge}>{["draft","sent"].includes(b.status)?"🕐 Aguardando aprovação":statusLabel(b.status)}</span>{b.linkedWorkId&&<span style={styles.successBadge}>🔥 Trabalho criado</span>}</div></div><div className="serviceActions" style={styles.serviceActions} onClick={e=>e.stopPropagation()}>{(["draft","sent"].includes(b.status) || (b.status==="approved" && !b.linkedWorkId))&&<><button style={styles.primaryButton} onClick={()=>approveBudget(b)}>{b.status==="approved"?"🔥 Criar trabalho agora":"✓ Aprovar e criar trabalho"}</button>{b.status!=="approved"&&<button style={styles.deleteButton} onClick={()=>rejectBudget(b)}>✕ Reprovar</button>}</>}<button style={styles.smallButton} onClick={()=>openWorkDetail(b)}>Abrir</button></div></div>)}</div>}
   {((serviceHubTab==="works"&&visibleWorks.length===0)||(serviceHubTab==="sales"&&visibleSales.length===0)||(serviceHubTab==="readings"&&visibleReadings.length===0)||(serviceHubTab==="budgets"&&visibleBudgets.length===0))&&<div style={styles.emptyBox}>Nenhum registro encontrado para os filtros atuais.</div>}
  </section>
  {showServiceDetail && liveSelectedServiceRecord && <Modal title={`Detalhes · ${liveSelectedServiceRecord.title}`} onClose={()=>{setShowServiceDetail(false);setSelectedServiceRecord(null);}}><div style={{display:"grid",gap:10}}><div style={styles.infoBox}><ClientIdentity clientId={liveSelectedServiceRecord.consultation?.clientId || liveSelectedServiceRecord.clientId} clientName={liveSelectedServiceRecord.clientName} size={46} /><div style={styles.muted}>{liveSelectedServiceRecord.recordType==="work"?"🔥":liveSelectedServiceRecord.recordType==="sale"?"🛍️":liveSelectedServiceRecord.recordType==="reading"?"🔮":"📋"} {liveSelectedServiceRecord.title}</div><div style={{marginTop:7}}><span style={styles.warningBadge}>{statusLabel(liveSelectedServiceRecord.recordType==="sale" ? liveSelectedServiceRecord.saleStatus : (liveSelectedServiceRecord.execution?"completed":liveSelectedServiceRecord.status))}</span></div></div>{liveSelectedServiceRecord.recordType==="reading"&&liveSelectedServiceRecord.consultation&&<div style={styles.infoBox}>🏷️ <strong>{consultationPackageLabel(liveSelectedServiceRecord.consultation)}</strong>{consultationPackageUnitPrice(liveSelectedServiceRecord.consultation)!==null&&<div style={styles.muted}>Valor individual aproximado: {formatForeign(consultationPackageUnitPrice(liveSelectedServiceRecord.consultation)||0,(liveSelectedServiceRecord.consultation.questions.find((q:any)=>q.packageId)?.currency||liveSelectedServiceRecord.consultation.currency||"BRL") as CurrencyCode)}</div>}</div>}<div style={styles.listItem}><div><strong>Valor</strong><div style={styles.muted}>{formatForeign(liveSelectedServiceRecord.amount||liveSelectedServiceRecord.value||0,liveSelectedServiceRecord.currency||"BRL")}</div></div><div><strong>Data</strong><div style={styles.muted}>{liveSelectedServiceRecord.scheduledAt?formatDateTime(liveSelectedServiceRecord.scheduledAt):formatDateTime(liveSelectedServiceRecord.createdAt||"")}</div></div></div>{liveSelectedServiceRecord.recordType!=="budget"&&<div style={styles.infoBox}><strong>💳 Pagamento</strong><div><strong>{liveSelectedServiceRecord.paymentStatus === "paid" ? "✓ Pago" : liveSelectedServiceRecord.paymentStatus === "partial" ? "🟠 Pago parcialmente" : "⚠ Não pago"}</strong>{liveSelectedServiceRecord.consultation?.paymentPlan?.installments?.length ? ` · ${liveSelectedServiceRecord.consultation.paymentPlan.installments.length} parcela(s)` : ""}</div><div style={styles.muted}>{liveSelectedServiceRecord.consultation?.paymentMethod||"Forma ainda não definida"} · {liveSelectedServiceRecord.consultation?.currency || "BRL"}</div>{liveSelectedServiceRecord.consultation?.paymentPlan?.fee ? <div style={styles.muted}>Taxa: {formatMoney(liveSelectedServiceRecord.consultation.paymentPlan.fee)} · líquido: {formatMoney(Math.max(0,(liveSelectedServiceRecord.consultation.value||0)-liveSelectedServiceRecord.consultation.paymentPlan.fee))}</div> : null}{liveSelectedServiceRecord.consultation?.paymentPlan?.installments?.length ? <div style={{marginTop:8,paddingTop:8,borderTop:"1px solid #eadfe6"}}>{liveSelectedServiceRecord.consultation.paymentPlan.installments.map((i:any)=><div key={i.id} style={{display:"flex",justifyContent:"space-between",gap:8,flexWrap:"wrap",padding:"4px 0"}}><span>Parcela {i.number} · {formatDate(i.dueDate)}</span><span style={{display:"flex",gap:6,alignItems:"center",flexWrap:"wrap"}}><strong>{installmentReceivedAmount(i)>=i.amount-0.01?"✓ Paga":installmentReceivedAmount(i)>0?`🟠 Parcial · recebido ${formatMoney(installmentReceivedAmount(i))}`:i.status==="defaulted"?"⚠ Não paga":i.status==="overdue"?"🔴 Vencida":"🕐 Pendente"} · {formatMoney(i.amount)}</strong>{installmentOpenAmount(i)>0.009&&<button type="button" style={styles.smallButton} onClick={()=>promptInstallmentPartialPayment({consultationId:liveSelectedServiceRecord.consultation?.id,installmentId:i.id})}>💰 Receber valor</button>}</span></div>)}</div> : null}</div>}{liveSelectedServiceRecord.recordType==="budget"&&<div style={styles.infoBox}><strong>📋 Orçamento</strong><div>{liveSelectedServiceRecord.description||"Sem descrição."}</div><div style={styles.muted}>Status: {statusLabel(liveSelectedServiceRecord.status)}</div></div>}{liveSelectedServiceRecord.recordType==="sale"&&<div style={styles.infoBox}><strong>🛍️ Fluxo da venda</strong><div>Status operacional: <strong>{statusLabel(liveSelectedServiceRecord.saleStatus)}</strong></div><div style={styles.muted}>{liveSelectedServiceRecord.needsConfection?"Esta venda exige confecção antes do envio.":liveSelectedServiceRecord.shippingEnabled?"Esta venda possui envio.":"Esta venda não exige confecção nem envio."}</div></div>}{liveSelectedServiceRecord.recordType==="work" && (()=>{ const workId=liveSelectedServiceRecord.id; const qs=consultations.flatMap(c=>c.questions||[]).filter(q=>q.relatedWorkId===workId); const benefit=qs.filter(q=>q.workQuestionKind==="benefit").length; const paid=qs.filter(q=>q.workQuestionKind==="paid" || (!q.workQuestionKind && q.billingMode!=="free" && q.billingMode!=="desfalque")).length;const desfalqueCount=qs.filter(q=>q.billingMode==="desfalque" || (q.billingMode==="free"&&!q.workQuestionKind)).length; const courtesy=qs.filter(q=>q.workQuestionKind==="courtesy").length; return <div style={{display:"grid",gap:10}}><div style={styles.infoBox}><strong>🔮 Perguntas deste trabalho</strong><div>Total: <strong>{qs.length}</strong></div><div>🎁 Benefício do trabalho: {benefit}</div><div>💰 Pagas: {paid}</div><div>🎁 Cortesias extras: {courtesy}</div><div>⚠️ Desfalques do checkout: {desfalqueCount} · {formatMoney(desfalques.filter(d=>d.workId===workId && !d.deletedAt).reduce((s,d)=>s+d.amount,0))}</div>{qs.length>0&&<div style={{marginTop:8,display:"grid",gap:4}}>{qs.sort((a,b)=>(a.createdAt||"").localeCompare(b.createdAt||"")).map(q=><div key={q.id} style={styles.muted}>• {formatDateTime(q.createdAt)} · pergunta {q.workQuestionNumber||q.number} · {q.workQuestionKind==="benefit"?"benefício grátis":q.workQuestionKind==="courtesy"?"cortesia extra":"paga"}</div>)}</div>}</div>{liveSelectedServiceRecord.consultation?.paymentPlan?.installments?.length>0&&<div style={styles.infoBox}><strong>💳 Parcelas deste trabalho</strong>{liveSelectedServiceRecord.consultation.paymentPlan.installments.map((i:any)=><div key={i.id} style={{display:"flex",justifyContent:"space-between",gap:8,padding:"6px 0",borderBottom:"1px solid #eee"}}><span>Parcela {i.number} · {formatDate(i.dueDate)}{installmentPaymentSummary(i)&&<><br/><small style={styles.muted}>📅 {installmentPaymentSummary(i)}</small></>}</span><strong>{installmentReceivedAmount(i)>=i.amount-0.01?"✓ Paga":installmentReceivedAmount(i)>0?`🟠 Parcial · recebido ${formatMoney(installmentReceivedAmount(i))}`:i.status==="defaulted"?"⚠ Não paga":i.status==="overdue"?"🔴 Vencida":"🕐 Pendente"} · {formatMoney(i.amount)}</strong></div>)}<div style={{marginTop:6,fontWeight:800}}>Recebido: {formatMoney(liveSelectedServiceRecord.consultation.paymentPlan.installments.reduce((a:number,i:any)=>a+installmentReceivedAmount(i),0))} · Em aberto: {formatMoney(liveSelectedServiceRecord.consultation.paymentPlan.installments.reduce((a:number,i:any)=>a+installmentOpenAmount(i),0))}</div></div>}</div>; })()}
{liveSelectedServiceRecord.execution&&<div style={styles.infoBox}><strong>🧾 Execução</strong><div>Custo de materiais: {formatMoney(liveSelectedServiceRecord.execution.totalCost)}</div><div>Economia por reutilização: {formatMoney(liveSelectedServiceRecord.execution.estimatedSavings||0)}</div></div>}<div style={{display:"flex",gap:8,flexWrap:"wrap"}}>{liveSelectedServiceRecord.recordType==="work"&&!liveSelectedServiceRecord.execution&&liveSelectedServiceRecord.status!=="cancelled"&&<button style={styles.primaryButton} onClick={()=>{setShowServiceDetail(false);openWorkExecution(liveSelectedServiceRecord);}}>▶ Executar</button>}{liveSelectedServiceRecord.recordType!=="budget"&&liveSelectedServiceRecord.consultation&&<button style={styles.smallButton} onClick={()=>{if(liveSelectedServiceRecord.consultation.status === "completed"){openEditConsultation(liveSelectedServiceRecord.consultation);}else{setActiveConsultation(liveSelectedServiceRecord.consultation);setShowFinishConsultation(true);}setShowServiceDetail(false);}}>✏️ {liveSelectedServiceRecord.consultation.status === "completed" ? "Editar atendimento / preços" : "Abrir atendimento / preços"}</button>}{liveSelectedServiceRecord.recordType==="work"&&liveSelectedServiceRecord.consultation&&<button style={styles.primaryButton} onClick={()=>{openEditConsultation(liveSelectedServiceRecord.consultation);setShowServiceDetail(false);}}>💰 Editar valor do trabalho</button>}{liveSelectedServiceRecord.recordType==="work"&&liveSelectedServiceRecord.status!=="cancelled"&&liveSelectedServiceRecord.status!=="completed"&&<><button style={styles.smallButton} onClick={()=>rescheduleWork(liveSelectedServiceRecord)}>📅 Reagendar</button><button style={styles.smallButton} onClick={()=>updateWorkLifecycle(liveSelectedServiceRecord,"postponed")}>⏸️ Adiar</button><button style={styles.deleteButton} onClick={()=>updateWorkLifecycle(liveSelectedServiceRecord,"cancelled")}>❌ Cancelar</button></>}{liveSelectedServiceRecord.recordType==="budget"&&<>{(["draft","sent"].includes(liveSelectedServiceRecord.status) || (liveSelectedServiceRecord.status==="approved" && !liveSelectedServiceRecord.linkedWorkId))&&<><button style={styles.primaryButton} onClick={()=>{approveBudget(liveSelectedServiceRecord);setShowServiceDetail(false);}}>{liveSelectedServiceRecord.status==="approved"?"🔥 Criar trabalho agora":"✓ Aprovar e criar trabalho"}</button>{liveSelectedServiceRecord.status!=="approved"&&<button style={styles.deleteButton} onClick={()=>{rejectBudget(liveSelectedServiceRecord);setShowServiceDetail(false);}}>✕ Reprovar</button>}</>}<button style={styles.smallButton} onClick={()=>editBudgetDirect(liveSelectedServiceRecord)}>✏️ Editar</button>{liveSelectedServiceRecord.linkedWorkId&&<div style={{...styles.infoBox,flexBasis:"100%"}}>🔥 Trabalho criado automaticamente · Aguardando execução</div>}<button style={styles.deleteButton} onClick={()=>{deleteBudget(liveSelectedServiceRecord.id);setShowServiceDetail(false);}}>Excluir</button></>}
{liveSelectedServiceRecord.recordType==="sale"&&<>{liveSelectedServiceRecord.saleStatus==="awaiting_confection"&&<button style={styles.primaryButton} onClick={()=>updateSaleLifecycle(liveSelectedServiceRecord,"in_confection")}>🛠️ Iniciar confecção</button>}{liveSelectedServiceRecord.saleStatus==="in_confection"&&<button style={styles.primaryButton} onClick={()=>updateSaleLifecycle(liveSelectedServiceRecord,"awaiting_shipping")}>✓ Marcar como confeccionado</button>}{liveSelectedServiceRecord.saleStatus==="approved"&&liveSelectedServiceRecord.shippingEnabled&&!liveSelectedServiceRecord.needsConfection&&<button style={styles.primaryButton} onClick={()=>updateSaleLifecycle(liveSelectedServiceRecord,"awaiting_shipping")}>📦 Preparar para envio</button>}{liveSelectedServiceRecord.saleStatus==="awaiting_shipping"&&<button style={styles.primaryButton} onClick={()=>updateSaleLifecycle(liveSelectedServiceRecord,"shipped")}>🚚 Marcar como enviado</button>}{liveSelectedServiceRecord.saleStatus==="shipped"&&<button style={styles.primaryButton} onClick={()=>updateSaleLifecycle(liveSelectedServiceRecord,"delivered")}>✓ Marcar como entregue</button>}{!["delivered","cancelled"].includes(liveSelectedServiceRecord.saleStatus)&&<button style={styles.deleteButton} onClick={()=>updateSaleLifecycle(liveSelectedServiceRecord,"cancelled")}>❌ Cancelar venda</button>}</>}</div><div style={{display:"flex",gap:8,flexWrap:"wrap",marginTop:8}}><button type="button" style={styles.smallButton} onClick={()=>openEditRecordModal(liveSelectedServiceRecord)}>⚙️ Editar status e condições</button><button type="button" style={styles.deleteButton} onClick={()=>deleteServiceRecord(liveSelectedServiceRecord)}>🗑️ Excluir registro</button></div></div></Modal>}

   {workSetupTarget && <Modal title={`Novo trabalho · ${workSetupTarget.title}`} onClose={()=>setWorkSetupTarget(null)}><div style={{display:"grid",gap:12}}><div style={styles.infoBox}><strong>✓ Orçamento aprovado</strong><div>{workSetupTarget.clientName}</div><div style={styles.muted}>{workSetupTarget.serviceName}</div></div><section style={styles.paymentBox}><div className="checkoutSectionTitle" style={styles.eyebrow}>1 · VALOR E PAGAMENTO</div><label style={styles.label}>Valor do trabalho</label><input type="number" min="0" step="0.01" value={workSetupValue} onChange={e=>setWorkSetupValue(e.target.value)} style={styles.input}/><label style={styles.label}>Como será recebido?</label><div className="segmented"><button type="button" style={workSetupPaymentMode==="paid"?styles.segmentActive:styles.segmentButton} onClick={()=>setWorkSetupPaymentMode("paid")}>✓ Pago</button><button type="button" style={workSetupPaymentMode==="pending"?styles.segmentActive:styles.segmentButton} onClick={()=>setWorkSetupPaymentMode("pending")}>🕐 Pendente</button><button type="button" style={workSetupPaymentMode==="installments"?styles.segmentActive:styles.segmentButton} onClick={()=>setWorkSetupPaymentMode("installments")}>📆 Parcelado</button></div><label style={styles.label}>Forma de recebimento</label><select value={workSetupPaymentMethod} onChange={e=>setWorkSetupPaymentMethod(e.target.value as PaymentMethod)} style={styles.input}>{(["pix","credit","debit","cash","transfer","paypal","wise","other"] as PaymentMethod[]).map(m=><option key={m} value={m}>{m==="pix"?"Pix":m==="credit"?"Cartão de crédito":m==="debit"?"Cartão de débito":m==="cash"?"Dinheiro":m==="transfer"?"Transferência":m==="paypal"?"PayPal":m==="wise"?"Wise":"Outro"}</option>)}</select>{workSetupPaymentMode!=="installments"&&<><label style={styles.label}>Data de pagamento/vencimento</label><input type="date" value={workSetupPaymentDate} onChange={e=>setWorkSetupPaymentDate(e.target.value)} style={styles.input}/></>}{workSetupPaymentMode==="installments"&&<div style={{display:"grid",gap:8}}>{workSetupInstallmentRows.map((row,i)=><div key={row.id} className="installment-edit-row"><strong>#{i+1}</strong><input type="number" min="0" step="0.01" value={row.amount} onChange={e=>setWorkSetupInstallmentRows(prev=>prev.map(x=>x.id===row.id?{...x,amount:e.target.value}:x))} style={styles.input}/><input type="date" value={row.dueDate} onChange={e=>setWorkSetupInstallmentRows(prev=>prev.map(x=>x.id===row.id?{...x,dueDate:e.target.value}:x))} style={styles.input}/></div>)}<button type="button" style={styles.smallButton} onClick={()=>setWorkSetupInstallmentRows(prev=>[...prev,{id:makeId(),amount:"0",dueDate:localDateKey()}])}>+ Nova parcela</button><div style={styles.muted}>Total: {formatMoney(workSetupInstallmentRows.reduce((s,r)=>s+(Number(String(r.amount).replace(",","."))||0),0))} · Deve fechar em {formatMoney(Number(String(workSetupValue).replace(",","."))||0)}</div></div>}</section><section style={styles.paymentBox}><div className="checkoutSectionTitle" style={styles.eyebrow}>2 · OBJETOS / MATERIAIS</div><button type="button" className="checkboxItem object-checkbox-card" onClick={()=>{setObjectDraftName("");setObjectDraftValue("");setObjectDraftNotes("");const c=clients.find(x=>x.id===workSetupTarget?.clientId);setObjectAddress("");setObjectPostalCode("");setObjectCountry("Brasil");setObjectModalContext("workSetup");setObjectModalKind("received");}}><span className="fake-checkbox">{workSetupReceivedObjects.length?"✓":""}</span><span>A cliente enviou algo para o trabalho</span></button>{workSetupReceivedObjects.length>0&&<div style={styles.list}>{workSetupReceivedObjects.map(x=><div key={x.id} style={styles.listItem}><div><strong>📥 {x.name}</strong>{x.referenceValue?<div style={styles.muted}>Valor de referência: {formatMoney(x.referenceValue)}</div>:null}{x.notes?<div style={styles.muted}>{x.notes}</div>:null}</div><button type="button" style={styles.deleteButton} onClick={()=>setWorkSetupReceivedObjects(prev=>prev.filter(o=>o.id!==x.id))}>×</button></div>)}</div>}<button type="button" className="checkboxItem object-checkbox-card" onClick={()=>{setObjectDraftName("");setObjectDraftValue("");setObjectDraftNotes("");const c=clients.find(x=>x.id===workSetupTarget?.clientId);setObjectAddress(clientAddressText(c));setObjectPostalCode(clientPostalCodeText(c));setObjectCountry(c?.address?.country || c?.country || "Brasil");setObjectModalContext("workSetup");setObjectModalKind("sent");}}><span className="fake-checkbox">{workSetupSentObjects.length?"✓":""}</span><span>Eu enviei alguma coisa para a cliente</span></button>{workSetupSentObjects.length>0&&<div style={styles.list}>{workSetupSentObjects.map(x=><div key={x.id} style={styles.listItem}><div><strong>📤 {x.name}</strong>{x.referenceValue?<div style={styles.muted}>Valor de referência: {formatMoney(x.referenceValue)} · não é cobrança separada</div>:null}{x.notes?<div style={styles.muted}>{x.notes}</div>:null}</div><button type="button" style={styles.deleteButton} onClick={()=>setWorkSetupSentObjects(prev=>prev.filter(o=>o.id!==x.id))}>×</button></div>)}</div>}</section><section style={styles.paymentBox}><div className="checkoutSectionTitle" style={styles.eyebrow}>3 · PRIORIDADE E AGENDAMENTO</div><label style={styles.label}>Prioridade do trabalho (1 = menor · 5 = máxima)</label><select value={workSetupPriority} onChange={e=>setWorkSetupPriority(Math.min(5,Math.max(1,Number(e.target.value)||3)))} style={styles.input}>{[5,4,3,2,1].map(n=><option key={n} value={n}>{n}{n===5?" · Máxima":n>=4?" · Alta":n===3?" · Média":" · Baixa"}</option>)}</select><label style={styles.checkboxItem}><input type="checkbox" checked={workSetupScheduleEnabled} onChange={e=>setWorkSetupScheduleEnabled(e.target.checked)}/> Agendar a execução agora</label>{workSetupScheduleEnabled&&<div className="twoColumns"><input type="date" value={workSetupDate} onChange={e=>setWorkSetupDate(e.target.value)} style={styles.input}/><input type="time" value={workSetupTime} onChange={e=>setWorkSetupTime(e.target.value)} style={styles.input}/></div>}<div style={styles.muted}>Se não agendar agora, o trabalho fica na fila de execução. Se agendar, ele também aparecerá em Próximos agendamentos.</div></section><section style={styles.paymentBox}><div className="checkoutSectionTitle" style={styles.eyebrow}>4 · OBSERVAÇÕES</div><textarea value={workSetupNotes} onChange={e=>setWorkSetupNotes(e.target.value)} style={{...styles.input,minHeight:100}} placeholder="Observações para a execução"/></section><div style={{display:"flex",gap:8,flexWrap:"wrap"}}><button style={styles.secondaryButtonLarge} onClick={()=>setWorkSetupTarget(null)}>Cancelar</button><button style={styles.primaryButtonLarge} onClick={confirmBudgetApproval}>✓ Criar trabalho</button></div></div></Modal>}
 </>
 })()}
  {showEditRecordModal && editRecordTarget && <Modal title="Editar status e condições" onClose={()=>{setShowEditRecordModal(false);setEditRecordTarget(null);}}><div style={styles.infoBox}>Altere aqui uma condição do registro e o sistema atualizará as áreas que dependem dele.</div><label style={styles.label}>Status</label><select value={editRecordStatus} onChange={e=>setEditRecordStatus(e.target.value)} style={styles.input}>{editRecordTarget.recordType==="work"?<><option value="approved">Aguardando execução</option><option value="scheduled">Agendado</option><option value="in_progress">Em execução</option><option value="completed">Executado</option><option value="postponed">Prorrogado</option><option value="cancelled">Cancelado</option></>:editRecordTarget.recordType==="sale"?<><option value="approved">Venda aprovada</option><option value="awaiting_confection">Aguardando confecção</option><option value="in_confection">Em confecção</option><option value="awaiting_shipping">Aguardando envio</option><option value="shipped">Enviada</option><option value="delivered">Entregue</option><option value="cancelled">Cancelada</option></>:<><option value="active">Ativo</option><option value="standby">Em espera</option><option value="scheduled">Agendado</option><option value="completed">Concluído</option></>}</select>{editRecordTarget.recordType!=="reading"&&<><label style={styles.label}>Valor do registro</label><input type="number" min="0" step="0.01" value={editRecordValue} onChange={e=>setEditRecordValue(e.target.value)} style={styles.input}/></>}<label style={styles.label}>Forma de pagamento</label><select value={editRecordPaymentMethod} onChange={e=>setEditRecordPaymentMethod(e.target.value as PaymentMethod)} style={styles.input}>{(["pix","credit","debit","cash","transfer","paypal","wise","other"] as PaymentMethod[]).map(m=><option key={m} value={m}>{paymentMethodLabelText(m)}</option>)}</select>{editRecordInstallments.length>0&&<section style={{...styles.card,display:"grid",gap:8}}><strong>💳 Parcelas</strong>{editRecordInstallments.map((row,index)=><div key={row.id} className="installment-edit-row"><strong>#{index+1}</strong><input type="number" min="0" step="0.01" value={row.amount} onChange={e=>setEditRecordInstallments(prev=>prev.map(x=>x.id===row.id?{...x,amount:e.target.value}:x))} style={styles.input}/><input type="date" value={row.dueDate} onChange={e=>setEditRecordInstallments(prev=>prev.map(x=>x.id===row.id?{...x,dueDate:e.target.value}:x))} style={styles.input}/><span style={styles.muted}>Recebido: {formatMoney(Number(row.receivedAmount||0))} · Restante: {formatMoney(Math.max(0,Number(row.amount||0)-Number(row.receivedAmount||0)))}</span><div style={{display:"flex",gap:6,flexWrap:"wrap"}}><button type="button" style={styles.smallButton} disabled={Number(row.receivedAmount||0)>=Number(row.amount||0)-0.01} onClick={()=>{setPartialPaymentTarget({consultationId:(editRecordTarget?.consultation as Consultation|undefined)?.id || "",installmentId:row.id,questionId:undefined,openAmount:Math.max(0,Number(row.amount||0)-Number(row.receivedAmount||0)),installment:((editRecordTarget?.consultation as Consultation|undefined)?.paymentPlan?.installments || []).find(x=>x.id===row.id)||({id:row.id,number:index+1,amount:Number(row.amount||0),dueDate:row.dueDate,status:row.status,paymentMethod:editRecordPaymentMethod,receivedAt:""} as Installment),consultation:(editRecordTarget?.consultation as Consultation|undefined)});setPartialPaymentAmount("");setPartialPaymentMethod(editRecordPaymentMethod);setShowEditRecordModal(false);}}>💰 Receber valor</button><select value={row.status} onChange={e=>setEditRecordInstallments(prev=>prev.map(x=>x.id===row.id?{...x,status:e.target.value as Installment["status"]}:x))} style={{...styles.input,flex:1,minWidth:150}}><option value="pending">Pendente</option><option value="received">Paga</option><option value="defaulted">Não paga</option><option value="overdue">Vencida</option></select></div></div>)}</section>}{editRecordTarget.recordType==="work"&&<><label style={styles.label}>Data real da execução</label><input type="date" value={editRecordExecutionDate} onChange={e=>setEditRecordExecutionDate(e.target.value)} style={styles.input}/></>}<button type="button" style={styles.primaryButtonLarge} onClick={saveEditRecord}>✓ Salvar alterações</button><button type="button" style={styles.secondaryButtonLarge} onClick={()=>{setShowEditRecordModal(false);setEditRecordTarget(null);}}>Cancelar</button></Modal>}
{selectedWorkExecutionId && (()=>{const w=(()=>{const direct=consultations.find(c=>c.id===selectedWorkExecutionId && c.serviceType==="work" && !c.deletedAt); if(direct) return {id:direct.id,recordType:"work",consultationId:direct.id,workTypeId:direct.workTypeId,title:direct.workTypeName||direct.title,clientName:direct.clientName,scheduledAt:direct.scheduledAt,amount:direct.value,currency:direct.currency||"BRL",execution:workExecutions.find(e=>e.id===direct.id),status:direct.workStatus||"approved",consultation:direct,paymentStatus:getPaymentStatus(direct),createdAt:direct.createdAt}; for(const c of consultations){const ch=(c.relatedCharges||[]).find(x=>x.id===selectedWorkExecutionId && x.kind==="work" && !x.deletedAt); if(ch) return {id:ch.id,recordType:"work",consultationId:c.id,chargeId:ch.id,workTypeId:ch.workTypeId,title:ch.title,clientName:c.clientName,scheduledAt:ch.scheduledAt,amount:ch.originalAmount,currency:ch.currency||"BRL",execution:workExecutions.find(e=>e.id===ch.id),status:ch.status||"approved",consultation:c,paymentStatus:getPaymentStatus(c),createdAt:ch.scheduledAt||c.createdAt};} return null;})(); if(!w)return null; const items=executionItems; const consultation=w.consultation as Consultation|undefined; const paymentRows=executionPaymentMode==="installments"?executionInstallmentRows:[]; return <Modal title={`Executar · ${w.title}`} onClose={()=>{setSelectedWorkExecutionId(null);setExecutionItems([]);setExecutionExternalItems([]);setExecutionNotes("");}}>
<div className="execution-modal-body">
<div style={styles.infoBox}><ClientIdentity clientId={consultation?.clientId} clientName={w.clientName} size={46} /><div className="muted">Confirme o que foi executado. Estoque, financeiro e informações do trabalho ficam organizados em seções expansíveis.</div><div style={{marginTop:8,fontWeight:850}}>Valor atual: {formatForeign(Number(String(executionValue).replace(",","."))||0,(consultation?.currency||w.currency||"BRL") as CurrencyCode)}</div></div>
<section style={{...styles.paymentBox,marginBottom:10}}><div style={styles.eyebrow}>📅 DATA REAL DA EXECUÇÃO</div><label style={styles.label}>Em que dia este trabalho foi realmente executado?</label><input type="date" value={executionDate} onChange={e=>setExecutionDate(e.target.value)} style={styles.input}/><div style={styles.muted}>Esta data é independente do dia em que você está registrando a conclusão.</div></section>
<button type="button" className="execution-accordion" onClick={()=>setExecutionStockOpen(v=>!v)}><span>📦 Itens de estoque e materiais</span><strong>{executionStockOpen?"−":"+"}</strong></button>
{executionStockOpen&&<section className="execution-accordion-panel"><div style={styles.list}>{items.map((item,idx)=>{const stock=stockItems.find(x=>x.id===item.stockItemId);return <div key={idx} style={styles.listItem}><div style={{minWidth:0,flex:1}}><strong>{stock?.name||"Item"}</strong><div style={styles.muted}>Estoque: {stock?.quantity??0} {stock?.unit||"un"} · custo médio {formatMoney(stock?.averageCost||0)}</div></div><input type="number" min="0" step="0.01" value={item.quantity} onChange={e=>setExecutionItems(prev=>prev.map((x,i)=>i===idx?{...x,quantity:e.target.value}:x))} style={{...styles.input,width:90}}/><select value={item.usage} onChange={e=>setExecutionItems(prev=>prev.map((x,i)=>i===idx?{...x,usage:e.target.value as "new"|"reused"}:x))} style={{...styles.input,width:130}}><option value="new">🆕 Novo</option><option value="reused">♻️ Reutilizado</option></select><button style={styles.deleteButton} onClick={()=>setExecutionItems(prev=>prev.filter((_,i)=>i!==idx))}>×</button></div>})}</div><label style={styles.label}>Adicionar item do estoque</label><div style={{display:"grid",gap:6}}><select style={styles.input} value="" onChange={e=>{if(!e.target.value)return;setExecutionItems(prev=>[...prev,{stockItemId:e.target.value,quantity:"1",usage:"new"}]);}}><option value="">Selecione um item...</option>{stockItems.filter(x=>x.active).map(x=><option key={x.id} value={x.id}>{x.name} · {x.quantity} {x.unit}</option>)}</select><button type="button" style={styles.smallButton} onClick={()=>openQuickCatalog("stock")}>＋ Novo item de estoque</button></div><section style={{...styles.infoBox,display:"grid",gap:8}}><strong>🌿 Item fora do estoque</strong><input value={externalItemDraft.name} onChange={e=>setExternalItemDraft({...externalItemDraft,name:e.target.value})} placeholder="Ex.: Boldo colhido" style={styles.input}/><div style={styles.twoColumns}><input type="number" min="0" step="0.01" value={externalItemDraft.quantity} onChange={e=>setExternalItemDraft({...externalItemDraft,quantity:e.target.value})} placeholder="Quantidade" style={styles.input}/><input value={externalItemDraft.unit} onChange={e=>setExternalItemDraft({...externalItemDraft,unit:e.target.value})} placeholder="Unidade" style={styles.input}/></div><input type="number" min="0" step="0.01" value={externalItemDraft.cost} onChange={e=>setExternalItemDraft({...externalItemDraft,cost:e.target.value})} placeholder="Custo (R$)" style={styles.input}/><input value={externalItemDraft.notes} onChange={e=>setExternalItemDraft({...externalItemDraft,notes:e.target.value})} placeholder="Observação" style={styles.input}/><button style={styles.smallButton} onClick={()=>{if(!externalItemDraft.name.trim())return;setExecutionExternalItems(prev=>[...prev,externalItemDraft]);setExternalItemDraft({name:"",quantity:"1",unit:"un",cost:"0",notes:""});}}>+ Adicionar material externo</button>{executionExternalItems.map((x,i)=><div key={i} className="listItem"><strong>{x.name}</strong><span>{x.quantity} {x.unit} · {formatMoney(Number(x.cost)||0)}</span><button style={styles.deleteButton} onClick={()=>setExecutionExternalItems(prev=>prev.filter((_,idx)=>idx!==i))}>×</button></div>)}</section></section>}
<button type="button" className="execution-accordion" onClick={()=>setExecutionFinanceOpen(v=>!v)}><span>💰 Financeiro, valor e parcelas</span><strong>{executionFinanceOpen?"−":"+"}</strong></button>
{executionFinanceOpen&&<section className="execution-accordion-panel"><label style={styles.label}>Moeda do trabalho</label><select value={executionCurrency} onChange={e=>{const next=e.target.value as CurrencyCode; const previous=executionCurrency; const currentDisplay=Math.max(0,Number(String(executionValue).replace(",","."))||0); const converted=convertCurrency(currentDisplay,previous,next); setExecutionCurrency(next); setExecutionValue(String(Number(converted.toFixed(2))));}} style={styles.input}>{currencyList.map(c=><option key={c} value={c}>{c} · {currencySymbol(c)}</option>)}</select><label style={styles.label}>Valor do trabalho ({currencySymbol(executionCurrency)})</label><input type="number" min="0" step="0.01" value={executionValue} onChange={e=>setExecutionValue(e.target.value)} style={styles.input}/>{executionCurrency!=="BRL"&&<div style={styles.infoBox}>≈ {formatMoney((Number(String(executionValue).replace(",","."))||0)*(currencyRates[executionCurrency]||0))} · cotação {formatMoney(currencyRates[executionCurrency]||0)} por {currencySymbol(executionCurrency)}</div>}<label style={styles.label}>Situação do pagamento</label><div className="segmented"><button type="button" style={executionPaymentMode==="paid"?styles.segmentActive:styles.segmentButton} onClick={()=>setExecutionPaymentMode("paid")}>✓ Pago</button><button type="button" style={executionPaymentMode==="pending"?styles.segmentActive:styles.segmentButton} onClick={()=>setExecutionPaymentMode("pending")}>🕐 Pendente</button><button type="button" style={executionPaymentMode==="installments"?styles.segmentActive:styles.segmentButton} onClick={()=>setExecutionPaymentMode("installments")}>📆 Parcelado</button></div><label style={styles.label}>Forma de recebimento</label><select value={executionPaymentMethod} onChange={e=>setExecutionPaymentMethod(e.target.value as PaymentMethod)} style={styles.input}>{(["pix","credit","debit","cash","transfer","paypal","wise","other"] as PaymentMethod[]).map(m=><option key={m} value={m}>{m==="pix"?"Pix":m==="credit"?"Cartão de crédito":m==="debit"?"Cartão de débito":m==="cash"?"Dinheiro":m==="transfer"?"Transferência":m==="paypal"?"PayPal":m==="wise"?"Wise":"Outro"}</option>)}</select>{(executionPaymentMethod === "paypal" || executionPaymentMethod === "wise" || executionPaymentMethod === "other") && <div style={styles.infoBox}><strong>Taxa {executionPaymentMethod === "paypal" ? "PayPal" : executionPaymentMethod === "wise" ? "Wise" : "da forma selecionada"}:</strong> {getFeePercent(executionPaymentMethod).toFixed(2)}% · estimada {formatMoney(((Number(String(executionValue).replace(",","."))||0) * (executionCurrency === "BRL" ? 1 : (currencyRates[executionCurrency]||0))) * getFeePercent(executionPaymentMethod) / 100)} · líquido {formatMoney(Math.max(0,((Number(String(executionValue).replace(",","."))||0) * (executionCurrency === "BRL" ? 1 : (currencyRates[executionCurrency]||0))) * (1-getFeePercent(executionPaymentMethod)/100)))}</div>}{executionPaymentMode!=="installments"&&<><label style={styles.label}>Data do pagamento/vencimento</label><input type="date" value={executionPaymentDate} onChange={e=>setExecutionPaymentDate(e.target.value)} style={styles.input}/></>}{executionPaymentMode==="installments"&&<div style={{display:"grid",gap:8}}><strong>Parcelas</strong>{paymentRows.map((row,i)=><div key={row.id} className="installment-edit-row"><strong>#{i+1}</strong><input type="number" min="0" step="0.01" value={row.amount} onChange={e=>setExecutionInstallmentRows(prev=>prev.map(x=>x.id===row.id?{...x,amount:e.target.value}:x))} style={styles.input}/><input type="date" value={row.dueDate} onChange={e=>setExecutionInstallmentRows(prev=>prev.map(x=>x.id===row.id?{...x,dueDate:e.target.value}:x))} style={styles.input}/><select value={row.status||"pending"} onChange={e=>setExecutionInstallmentRows(prev=>prev.map(x=>x.id===row.id?{...x,status:e.target.value as Installment["status"]}:x))} style={styles.input}><option value="pending">🕐 Pendente</option><option value="received">✓ Recebida</option><option value="defaulted">🔴 Não paga</option><option value="overdue">🟠 Atrasada</option></select></div>)}<button type="button" style={styles.smallButton} onClick={()=>setExecutionInstallmentRows(prev=>[...prev,{id:makeId(),amount:"0",dueDate:localDateKey()}])}>+ Nova parcela</button><div style={styles.muted}>Total das parcelas: {formatForeign(paymentRows.reduce((s,r)=>s+(Number(String(r.amount).replace(",","."))||0),0),executionCurrency)} · Contratado: {formatForeign(Number(String(executionValue).replace(",","."))||0,executionCurrency)}</div></div>}</section>}
<button type="button" className="execution-accordion" onClick={()=>setExecutionScheduleOpen(v=>!v)}><span>📅 Agendamento</span><strong>{executionScheduleOpen?"−":"+"}</strong></button>
{executionScheduleOpen&&<section className="execution-accordion-panel"><label style={styles.checkboxItem}><input type="checkbox" checked={executionScheduleRequested || !!consultation?.scheduledAt} disabled={!!consultation?.scheduledAt} onChange={e=>{setExecutionScheduleRequested(e.target.checked);if(e.target.checked){setExecutionScheduleDate(executionScheduleDate||localDateKey());setExecutionScheduleTime(executionScheduleTime||"09:00");}else setExecutionScheduleDate("");}}/> {consultation?.scheduledAt?"Trabalho já agendado — executar este agendamento":"Agendar em vez de executar agora"}</label>{executionScheduleDate&&<div className="twoColumns"><input type="date" value={executionScheduleDate} onChange={e=>setExecutionScheduleDate(e.target.value)} style={styles.input}/><input type="time" value={executionScheduleTime} onChange={e=>setExecutionScheduleTime(e.target.value)} style={styles.input}/></div>}{!consultation?.scheduledAt&&executionScheduleRequested&&<div style={styles.infoBox}>📅 Ao salvar como agendado, o trabalho não será concluído. Ele ficará em <strong>Agendados</strong>, entrará na Agenda e receberá o lembrete.</div>}</section>}
<button type="button" className="execution-accordion" onClick={()=>setExecutionInfoOpen(v=>!v)}><span>📝 Observações da execução</span><strong>{executionInfoOpen?"−":"+"}</strong></button>
{executionInfoOpen&&<section className="execution-accordion-panel"><textarea value={executionNotes} onChange={e=>setExecutionNotes(e.target.value)} placeholder="O que aconteceu durante o trabalho? Materiais, observações, alterações..." style={{...styles.input,minHeight:120}}/><div style={styles.infoBox}><strong>Custo novo: {formatMoney(items.reduce((s,i)=>{const st=stockItems.find(x=>x.id===i.stockItemId);return s+(i.usage==="new"?(Number(i.quantity)||0)*(st?.averageCost||0):0)},0)+executionExternalItems.reduce((s,i)=>s+(Number(i.cost)||0),0))}</strong><div className="muted">Economia estimada por reutilização: {formatMoney(items.reduce((s,i)=>{const st=stockItems.find(x=>x.id===i.stockItemId);return s+(i.usage==="reused"?(Number(i.quantity)||0)*(st?.averageCost||0):0)},0))}</div></div></section>}
</div><div className="execution-modal-actions"><button style={styles.secondaryButtonLarge} onClick={()=>{setSelectedWorkExecutionId(null);setExecutionItems([]);setExecutionExternalItems([]);setExecutionNotes("");setExecutionScheduleRequested(false);}}>Cancelar</button>{!consultation?.scheduledAt&&executionScheduleRequested?<button style={styles.primaryButtonLarge} onClick={()=>saveWorkScheduled(w)}>📅 Agendar trabalho</button>:<button style={styles.primaryButtonLarge} onClick={()=>saveWorkExecution(w)}>✓ Concluir trabalho</button>}</div></Modal>})()}
 {screen === "reports" && (() => {
 const now = new Date();
 const currentMonth = now.toISOString().slice(0,7);
 const prev = new Date(now.getFullYear(), now.getMonth()-1, 1).toISOString().slice(0,7);
 const range = reportPeriod === "year" ? `${now.getFullYear()}-01-01` : reportPeriod === "quarter" ? new Date(now.getFullYear(), now.getMonth()-2, 1).toISOString().slice(0,10) : reportPeriod === "month" ? `${currentMonth}-01` : "0000-00-00";
 const inRange = (date:string) => reportPeriod === "custom" ? inEffectiveRange(date) : (date||"").slice(0,10) >= range && (date||"").slice(0,10) <= now.toISOString().slice(0,10);
 const q = reportSearch.trim().toLowerCase();
 const workConsultations = consultations.filter(c=>c.status === "completed" && inRange(c.createdAt) && (!q || `${c.clientName} ${c.title}`.toLowerCase().includes(q)));
 const workPaid = workConsultations.flatMap(c=>(c.paymentPlan?.installments||[])).reduce((s,i)=>s+installmentReceivedAmount(i),0);
 const workPending = workConsultations.flatMap(c=>(c.paymentPlan?.installments||[])).filter(i=>i.status!=="defaulted").reduce((s,i)=>s+installmentOpenAmount(i),0);
 const workDefaulted = desfalques.filter(d=>inRange(d.date) && !d.deletedAt).reduce((s,d)=>s+Math.max(0,Number(d.amount||0)),0);
 const workExpenses = purchases.filter(p=>p.destination==="work" && inRange(p.date)).reduce((s,p)=>s+p.total,0) + quickTransactions.filter(t=>t.type==="expense" && t.area==="work" && inRange(t.date)).reduce((s,t)=>s+t.amount,0) + payables.filter(p=>p.area==="work" && p.status==="paid" && inRange(p.dueDate)).reduce((s,p)=>s+p.amount,0);
 const homePurchases = purchases.filter(p=>p.destination==="home" && inRange(p.date));
 const homeExpenses = homePurchases.reduce((s,p)=>s+p.total,0) + quickTransactions.filter(t=>t.type==="expense" && t.area==="home" && inRange(t.date)).reduce((s,t)=>s+t.amount,0) + payables.filter(p=>p.status==="paid" && inRange(p.dueDate) && p.area==="home").reduce((s,p)=>s+p.amount,0);
 const sectorSpend:Record<string,number>={}; homePurchases.forEach(p=>p.items.forEach(i=>{const label=householdSectors.find(x=>x.id===i.sectorId)?.name || "Outros";sectorSpend[label]=(sectorSpend[label]||0)+i.total;}));
 const workSales = quickTransactions.filter(t=>inRange(t.date) && t.type==="sale").reduce((s,t)=>s+t.amount,0);
 const allPayments = consultations.filter(c=>c.status === "completed").flatMap(c=>(c.paymentPlan?.installments||[]).map(i=>({...i,clientName:c.clientName,consultationId:c.id})));
 const periodPayments = allPayments.filter(i=>inRange(i.dueDate));
 const receivedCount=periodPayments.filter(i=>getInstallmentPaymentState(i).status==="paid").length, pendingCount=periodPayments.filter(i=>getInstallmentPaymentState(i).status==="pending"||getInstallmentPaymentState(i).status==="overdue").length, defaultedCount=periodPayments.filter(i=>getInstallmentPaymentState(i).status==="defaulted").length;
 const workConsultationList = consultations.filter(c=>c.serviceType!=="work");
 const workList = consultations.filter(c=>c.serviceType==="work");
 const workBudgetCount = budgets.filter(b=>b.createdAt && inRange(b.createdAt)).length;
 const workSaleCount = quickTransactions.filter(t=>t.type==="sale" && inRange(t.date)).length + consultations.reduce((n,c)=>n+(c.relatedCharges||[]).filter(ch=>ch.kind==="sale").length,0);
 const workQuestionCount = workConsultationList.reduce((n,c)=>n+(c.questions||[]).length,0);
 const workConsultationCount = workConsultationList.length;
 const workDoneCount = workList.filter(c=>c.activityType==="work_done" || c.serviceType==="work").length;
 const customFrom = reportCustomFrom || `${currentMonth}-01`;
 const customTo = reportCustomTo || now.toISOString().slice(0,10);
 const effectiveStart = reportPeriod === "custom" ? customFrom : range;
 const effectiveEnd = reportPeriod === "custom" ? customTo : now.toISOString().slice(0,10);
 const inEffectiveRange = (date:string) => { const key=(date||"").slice(0,10); return key >= effectiveStart && key <= effectiveEnd; };
 const actualMovements = [
   ...quickTransactions.filter(t=>!isInstallmentMirrorTransaction(t) && inEffectiveRange(t.date)).map(t=>({id:`qt-${t.id}`,date:t.date,kind:t.type==="expense"?"expense":"income" as "income"|"expense",amount:Number(t.amount||0),title:t.type==="sale"?`🛍️ ${t.source}`:t.source,subtitle:`${t.area==="home"?"Casa":"Trabalho"}${t.clientName?` · ${t.clientName}`:""}${t.description?` · ${t.description}`:""}`})),
   ...consultations.flatMap(c=>{
     const inst=(c.paymentPlan?.installments||[]);
     const payments=inst.flatMap(i=>Array.isArray(i.payments)&&i.payments.length ? i.payments.map(p=>({i,p})) : i.status==="received" ? [{i,p:{id:`legacy-${i.id}`,amount:installmentReceivedAmount(i),date:i.receivedAt||c.createdAt,paymentMethod:i.paymentMethod}}] : []).filter(({p})=>inEffectiveRange(p.date||c.createdAt));
     if(payments.length) return payments.map(({i,p})=>({id:`inst-${c.id}-${i.id}-${p.id}`,date:p.date||c.createdAt,kind:"income" as const,amount:Number(p.amount||0),title:`💳 ${i.number===0?"Entrada":`Parcela ${i.number}`} · ${c.clientName}`,subtitle:`${c.title} · ${paymentMethodLabelText(p.paymentMethod)}`}));
     return c.paid && !c.paymentPlan?.installments?.length && inEffectiveRange(c.paymentDate||c.createdAt) ? [{id:`consult-${c.id}`,date:c.paymentDate||c.createdAt,kind:"income" as const,amount:Number(consultationReceivedAmount(c)||0),title:c.title,subtitle:`${c.clientName} · ${c.serviceType==="work"?"Trabalho":c.serviceType==="sale"?"Venda":"Pergunta"}`}] : [];
   }),
   ...purchases.filter(p=>inEffectiveRange(p.date||p.createdAt)).map(p=>({id:`purchase-${p.id}`,date:p.date||p.createdAt,kind:"expense" as const,amount:Number(p.total||0),title:p.supplierName||"Compra",subtitle:`${p.items.length} item(ns)` })),
   ...payables.filter(p=>p.status==="paid"&&inEffectiveRange(p.paidAt||p.dueDate)).map(p=>({id:`pay-${p.id}`,date:p.paidAt||p.dueDate,kind:"expense" as const,amount:Number(p.paidAmount??p.amount??0),title:p.description,subtitle:`${p.area==="home"?"Casa":"Trabalho"} · Conta paga`})),
 ].sort((x,y)=>Date.parse(y.date)-Date.parse(x.date));
 const v65Income = actualMovements.filter(x=>x.kind==="income").reduce((sum,x)=>sum+x.amount,0);
 const v65Expense = actualMovements.filter(x=>x.kind==="expense").reduce((sum,x)=>sum+x.amount,0);
 const v65Net = v65Income-v65Expense;
 const v65IncomeByType:Record<string,number>={"Perguntas":0,"Trabalhos":0,"Vendas":0,"Outras":0};
 actualMovements.filter(x=>x.kind==="income").forEach(x=>{const text=`${x.title} ${x.subtitle}`.toLowerCase(); const key=text.includes("trabalho")?"Trabalhos":text.includes("venda")?"Vendas":text.includes("pergunta")?"Perguntas":"Outras";v65IncomeByType[key]+=x.amount;});
 const v65ExpenseByCategory:Record<string,number>={};
 purchases.filter(p=>inEffectiveRange(p.date||p.createdAt)).flatMap(p=>p.items).forEach(i=>{const sector=householdSectors.find(x=>x.id===i.sectorId)?.name||"Outros";const cat=householdCategories.find(x=>x.id===i.categoryId)?.name||sector;v65ExpenseByCategory[cat]=(v65ExpenseByCategory[cat]||0)+Number(i.total||0);});
 quickTransactions.filter(t=>t.type==="expense"&&inEffectiveRange(t.date)).forEach(t=>{const key=t.source||"Saída rápida";v65ExpenseByCategory[key]=(v65ExpenseByCategory[key]||0)+Number(t.amount||0);});
 payables.filter(p=>p.status==="paid"&&inEffectiveRange(p.paidAt||p.dueDate)).forEach(p=>{const key=p.category||"Contas e utilidades";v65ExpenseByCategory[key]=(v65ExpenseByCategory[key]||0)+Number(p.paidAmount??p.amount??0);});
 const v65ExpenseRanking=Object.entries(v65ExpenseByCategory).sort((a,b)=>b[1]-a[1]);
 const v65ItemSpend:Record<string,number>={}; purchases.filter(p=>inEffectiveRange(p.date||p.createdAt)).flatMap(p=>p.items).forEach(i=>{v65ItemSpend[i.name]=(v65ItemSpend[i.name]||0)+Number(i.total||0);});
 const v65TopItems=Object.entries(v65ItemSpend).sort((a,b)=>b[1]-a[1]);
 const v65Budgets=budgets.filter(b=>!b.deletedAt&&inEffectiveRange(b.createdAt));
 const v65BudgetStatus={approved:v65Budgets.filter(b=>b.status==="approved").length,rejected:v65Budgets.filter(b=>b.status==="rejected").length,waiting:v65Budgets.filter(b=>b.status==="draft"||b.status==="sent").length,expired:v65Budgets.filter(b=>b.status==="expired").length};
 const v65BudgetByType=(type:string)=>({question:v65Budgets.filter(b=>b.serviceType==="reading"||b.items?.some(i=>i.kind==="question")).length,work:v65Budgets.filter(b=>b.serviceType==="work").length,sale:v65Budgets.filter(b=>b.serviceType==="sale"||b.serviceType==="product").length}[type]||0);
 const v65RejectedByType={question:v65Budgets.filter(b=>b.status==="rejected"&&(b.serviceType==="reading"||b.items?.some(i=>i.kind==="question"))).length,work:v65Budgets.filter(b=>b.status==="rejected"&&b.serviceType==="work").length,sale:v65Budgets.filter(b=>b.status==="rejected"&&(b.serviceType==="sale"||b.serviceType==="product")).length};
 const v65ApprovedByType={question:v65Budgets.filter(b=>b.status==="approved"&&(b.serviceType==="reading"||b.items?.some(i=>i.kind==="question"))).length,work:v65Budgets.filter(b=>b.status==="approved"&&b.serviceType==="work").length,sale:v65Budgets.filter(b=>b.status==="approved"&&(b.serviceType==="sale"||b.serviceType==="product")).length};
 const v65StatusCounts={concluded:workList.filter(c=>inEffectiveRange(c.createdAt)&&c.status==="completed").length,paused:workList.filter(c=>inEffectiveRange(c.createdAt)&&c.status==="standby").length,active:workList.filter(c=>inEffectiveRange(c.createdAt)&&c.status!=="completed"&&c.status!=="standby").length};
 const v65PendingInstallments=consultations.filter(c=>c.status === "completed").flatMap(c=>(c.paymentPlan?.installments||[]).map(i=>({...i,consultation:c}))).filter(i=>i.status!=="received").filter(i=>inEffectiveRange(i.dueDate));
 const v65ReceivedInstallments=consultations.filter(c=>c.status === "completed").flatMap(c=>(c.paymentPlan?.installments||[]).map(i=>({...i,consultation:c}))).filter(i=>i.status==="received"&&inEffectiveRange(i.receivedAt||i.dueDate));
 const v65QuestionIncome=v65IncomeByType["Perguntas"];
 const v65WorkIncome=v65IncomeByType["Trabalhos"];
 const v65SaleIncome=v65IncomeByType["Vendas"];
 const v65Daily=Array.from({length:Math.min(31,Math.max(1,Math.ceil((new Date(effectiveEnd).getTime()-new Date(effectiveStart).getTime())/86400000)+1))},(_,idx)=>{const d=new Date(`${effectiveStart}T00:00:00`);d.setDate(d.getDate()+idx);const k=d.toISOString().slice(0,10);return {label:d.toLocaleDateString("pt-BR",{day:"2-digit",month:"2-digit"}),income:actualMovements.filter(x=>x.kind==="income"&&x.date.slice(0,10)===k).reduce((s,x)=>s+x.amount,0),expense:actualMovements.filter(x=>x.kind==="expense"&&x.date.slice(0,10)===k).reduce((s,x)=>s+x.amount,0)};});
 const receivedByCurrency:Record<CurrencyCode,number>={BRL:0,EUR:0,USD:0,GBP:0};
 workConsultations.forEach(c=>(c.paymentPlan?.installments||[]).filter(i=>i.status==="received").forEach(i=>{const cur=(c.currency||"BRL") as CurrencyCode;receivedByCurrency[cur]+=cur==="BRL"?i.amount:convertFromBRL(i.amount,cur);}));
 quickTransactions.filter(t=>inRange(t.date)&&t.type!=="expense"&&t.area==="work").forEach(t=>{const cur=(t.currency||"BRL") as CurrencyCode;const val=Number(t.amount||0);receivedByCurrency[cur]+=cur==="BRL"?val:convertFromBRL(val,cur);});
 const pctChange=(current:number,previous:number)=>previous===0?(current===0?0:100):((current-previous)/Math.abs(previous))*100;
 const consultationListForMonth=(list:Consultation[],month:string)=>list.filter(c=>c.createdAt.slice(0,7)===month);
 const monthMetrics=(month:string)=>{
   const monthConsultations=consultationListForMonth(consultations.filter(c=>c.status === "completed"),month);
   const allWork=consultations.filter(c=>c.status === "completed"&&c.createdAt.slice(0,7)===month&&c.serviceType==="work");
   const allReadings=consultations.filter(c=>c.status === "completed"&&c.createdAt.slice(0,7)===month&&c.serviceType!=="work");
   const allBudgets=budgets.filter(x=>x.createdAt?.slice(0,7)===month);
   const allSales=quickTransactions.filter(t=>t.date.slice(0,7)===month&&t.type==="sale").length + consultations.filter(c=>c.status === "completed").reduce((n,c)=>n+(c.createdAt.slice(0,7)===month?(c.relatedCharges||[]).filter(ch=>ch.kind==="sale").length:0),0);
   const received=consultations.filter(c=>c.status === "completed"&&c.createdAt.slice(0,7)===month).flatMap(c=>(c.paymentPlan?.installments||[]).filter(i=>i.status==="received")).reduce((sum,i)=>sum+i.amount,0)+quickTransactions.filter(t=>t.date.slice(0,7)===month&&t.type!=="expense"&&t.area==="work").reduce((sum,t)=>sum+t.amount,0);
   const workExpense=purchases.filter(p=>p.destination==="work"&&p.date.slice(0,7)===month).reduce((sum,p)=>sum+p.total,0)+quickTransactions.filter(t=>t.type==="expense"&&t.area==="work"&&t.date.slice(0,7)===month).reduce((sum,t)=>sum+t.amount,0)+payables.filter(p=>p.area==="work"&&p.status==="paid"&&p.dueDate.slice(0,7)===month).reduce((sum,p)=>sum+p.amount,0);
   const homeExpense=purchases.filter(p=>p.destination==="home"&&p.date.slice(0,7)===month).reduce((sum,p)=>sum+p.total,0)+quickTransactions.filter(t=>t.type==="expense"&&t.area==="home"&&t.date.slice(0,7)===month).reduce((sum,t)=>sum+t.amount,0)+payables.filter(p=>p.area==="home"&&p.status==="paid"&&p.dueDate.slice(0,7)===month).reduce((sum,p)=>sum+p.amount,0);
   const installments=consultations.filter(c=>c.status === "completed").flatMap(c=>(c.paymentPlan?.installments||[]).map(i=>({i,c}))).filter(x=>x.i.dueDate.slice(0,7)===month);
   return {consultations:monthConsultations.length, readings:allReadings.length, works:allWork.length, budgets:allBudgets.length, sales:allSales, received, workExpense, homeExpense, workProfit:received-workExpense, net:received-workExpense-homeExpense, paidInstallments:installments.filter(x=>x.i.status==="received").length, pendingInstallments:installments.filter(x=>x.i.status==="pending"||x.i.status==="overdue").length, defaultedInstallments:installments.filter(x=>x.i.status==="defaulted").length};
 };
 const a=monthMetrics(reportMonthA), b=monthMetrics(reportMonthB);
 return <>
  <button style={styles.backButton} onClick={()=>setScreen("dashboard")}>← Início</button>
  <section style={styles.hero}>
   <div style={styles.eyebrow}>CENTRO FINANCEIRO</div>
   <h2 style={styles.pageTitle}>Relatórios profissionais</h2>
   <p style={styles.heroText}>Controle de entradas, gastos, recebimentos, perdas e desempenho com filtros e comparações.</p>
   <div style={{display:"flex",gap:7,overflowX:"auto",paddingBottom:4}}>
    <button style={{...styles.settingsTab,...(reportTab==="general"?styles.settingsTabActive:{})}} onClick={()=>setReportTab("general")}>📊 Geral</button>
    <button style={{...styles.settingsTab,...(reportTab==="home"?styles.settingsTabActive:{})}} onClick={()=>setReportTab("home")}>🏠 Casa</button>
    <button style={{...styles.settingsTab,...(reportTab==="work"?styles.settingsTabActive:{})}} onClick={()=>setReportTab("work")}>🔮 Trabalho</button><button style={{...styles.settingsTab,...(reportTab==="contacts"?styles.settingsTabActive:{})}} onClick={()=>setReportTab("contacts")}>👥 Contatos</button><button style={{...styles.settingsTab,...(reportTab==="routines"?styles.settingsTabActive:{})}} onClick={()=>setReportTab("routines")}>⏱️ Rotinas</button>
   </div>
   <div style={{display:"flex",gap:7,flexWrap:"wrap",marginTop:10}}>
    {([['month','Mês'],['quarter','Trimestre'],['year','Ano'],['custom','Personalizado']] as const).map(([key,label])=><button key={key} style={{...styles.settingsTab,...(reportPeriod===key?styles.settingsTabActive:{})}} onClick={()=>setReportPeriod(key)}>{label}</button>)}
   </div>
   {reportPeriod==="custom"&&<div style={{...styles.twoColumns,marginTop:10}}><div><label style={styles.label}>De</label><input type="date" value={reportCustomFrom} onChange={e=>setReportCustomFrom(e.target.value)} style={styles.input}/></div><div><label style={styles.label}>Até</label><input type="date" value={reportCustomTo} onChange={e=>setReportCustomTo(e.target.value)} style={styles.input}/></div></div>}
  </section>
  {reportTab==="general" && <>
   <section style={styles.card}>
    <div style={styles.eyebrow}>V65 · VISÃO EXECUTIVA</div><h2 style={styles.cardTitle}>Dinheiro que entrou e dinheiro que saiu</h2>
    <div style={styles.statsGrid}><StatCard title="Entradas realizadas" value={formatMoney(v65Income)}/><StatCard title="Saídas realizadas" value={formatMoney(v65Expense)}/><StatCard title="Resultado líquido" value={formatMoney(v65Net)}/><StatCard title="Movimentações" value={String(actualMovements.length)}/></div>
   </section>
   <V65LineChart title="Fluxo financeiro do período" data={v65Daily}/>
   <V65DonutChart title="Origem das entradas" data={Object.entries(v65IncomeByType).filter(([,v])=>v>0).map(([name,value])=>({name,value}))}/>
   <section style={styles.card}><div style={styles.eyebrow}>ORÇAMENTOS E EXECUÇÃO</div><h2 style={styles.cardTitle}>Conversão e situação</h2><div style={styles.statsGrid}><StatCard title="Aguardando" value={String(v65BudgetStatus.waiting)}/><StatCard title="Aprovados" value={String(v65BudgetStatus.approved)}/><StatCard title="Reprovados" value={String(v65BudgetStatus.rejected)}/><StatCard title="Expirados" value={String(v65BudgetStatus.expired)}/></div><div style={styles.reportProgress}><div><span>Perguntas</span><strong>{v65BudgetByType("question")}</strong><small>Aprovados {v65ApprovedByType.question} · não deram certo {v65RejectedByType.question}</small></div><div><span>Trabalhos</span><strong>{v65BudgetByType("work")}</strong><small>Aprovados {v65ApprovedByType.work} · não deram certo {v65RejectedByType.work}</small></div><div><span>Vendas</span><strong>{v65BudgetByType("sale")}</strong><small>Aprovados {v65ApprovedByType.sale} · não deram certo {v65RejectedByType.sale}</small></div></div></section>
   <section style={styles.card}><div style={styles.eyebrow}>STATUS DOS ATENDIMENTOS</div><h2 style={styles.cardTitle}>Concluídos, pausados e em andamento</h2><div style={styles.reportStatusGrid}><ReportStatusBox label="Concluídos" value={v65StatusCounts.concluded} tone="good"/><ReportStatusBox label="Pausados" value={v65StatusCounts.paused} tone="neutral"/><ReportStatusBox label="Em andamento" value={v65StatusCounts.active} tone="warning"/></div><div style={styles.reportMetricGrid}><ReportMetricBox label="Perguntas feitas" value={workQuestionCount.toString()} detail={formatMoney(v65QuestionIncome)}/><ReportMetricBox label="Trabalhos feitos" value={workDoneCount.toString()} detail={formatMoney(v65WorkIncome)}/><ReportMetricBox label="Vendas" value={workSaleCount.toString()} detail={formatMoney(v65SaleIncome)}/><ReportMetricBox label="Parcelas pendentes" value={String(v65PendingInstallments.length)} detail={formatMoney(v65PendingInstallments.reduce((s,i)=>s+i.amount,0))}/></div></section>
   <section style={styles.card}><div style={styles.eyebrow}>DESPESAS · RANKING</div><h2 style={styles.cardTitle}>Onde o dinheiro foi gasto</h2>{v65ExpenseRanking.length?<div style={styles.rankList}>{v65ExpenseRanking.slice(0,12).map(([name,value],idx)=><div key={name} style={styles.rankItem}><span style={styles.rankNumber}>{idx+1}</span><span style={{flex:1}}>{name}</span><strong>{formatMoney(value)}</strong></div>)}</div>:<div style={styles.emptyBox}>Nenhuma saída no período.</div>}</section>
   <section style={styles.card}><div style={styles.eyebrow}>COMPRAS · ITEM</div><h2 style={styles.cardTitle}>Detalhamento até o produto</h2>{v65TopItems.length?<div style={styles.rankList}>{v65TopItems.slice(0,20).map(([name,value],idx)=><div key={name} style={styles.rankItem}><span style={styles.rankNumber}>{idx+1}</span><span style={{flex:1}}>{name}</span><strong>{formatMoney(value)}</strong></div>)}</div>:<div style={styles.emptyBox}>Nenhum item comprado no período.</div>}<div style={styles.infoBox}>Ex.: frango, arroz, feijão, leite e cada outro item aparecem individualmente quando foram registrados nos itens da compra.</div></section>
   <section style={styles.card}><div style={styles.eyebrow}>PARCELAS</div><h2 style={styles.cardTitle}>Recebidas x ainda não pagas</h2><div style={styles.statsGrid}><StatCard title="Recebidas" value={String(v65ReceivedInstallments.length)}/><StatCard title="Pendentes" value={String(v65PendingInstallments.length)}/><StatCard title="Valor pendente" value={formatMoney(v65PendingInstallments.reduce((s,i)=>s+i.amount,0))}/><StatCard title="Recebido em parcelas" value={formatMoney(v65ReceivedInstallments.reduce((s,i)=>s+i.amount,0))}/></div></section>
   <section style={styles.card}>
    <div style={styles.eyebrow}>RESULTADO DO MÊS</div><h2 style={styles.cardTitle}>Casa + Trabalho</h2>
    <div style={styles.statsGrid}>
     <StatCard title="Entradas do trabalho" value={formatMoney(b.received)} />
     <StatCard title="Gastos do trabalho" value={formatMoney(b.workExpense)} />
     <StatCard title="Gastos da casa" value={formatMoney(b.homeExpense)} />
     <StatCard title="Sobra real do mês" value={formatMoney(b.net)} />
    </div>
    <div style={{...styles.infoBox,marginTop:12}}>Sobra real = recebido do trabalho − gastos do trabalho − gastos da casa.</div>
   </section>
   <section style={styles.card}>
    <div style={styles.eyebrow}>COMPARAÇÃO</div><h2 style={styles.cardTitle}>Mês A × Mês B</h2>
    <div style={styles.twoColumns}>
     <div><label style={styles.label}>Mês A</label><input type="month" value={reportMonthA} onChange={e=>setReportMonthA(e.target.value)} style={styles.input}/></div>
     <div><label style={styles.label}>Mês B</label><input type="month" value={reportMonthB} onChange={e=>setReportMonthB(e.target.value)} style={styles.input}/></div>
    </div>
    <div style={{display:"grid",gap:9,marginTop:12}}>
     <div style={styles.infoBox}>Entradas: {formatMoney(a.received)} → {formatMoney(b.received)} · {pctChange(b.received,a.received).toFixed(1)}%</div>
     <div style={styles.infoBox}>Gastos trabalho: {formatMoney(a.workExpense)} → {formatMoney(b.workExpense)} · {pctChange(b.workExpense,a.workExpense).toFixed(1)}%</div>
     <div style={styles.infoBox}>Gastos casa: {formatMoney(a.homeExpense)} → {formatMoney(b.homeExpense)} · {pctChange(b.homeExpense,a.homeExpense).toFixed(1)}%</div>
     <div style={styles.infoBox}>Sobra: {formatMoney(a.net)} → {formatMoney(b.net)} · {pctChange(b.net,a.net).toFixed(1)}%</div>
    </div>
   </section>
   <section style={styles.card}><div style={styles.eyebrow}>RECEBIMENTOS</div><h2 style={styles.cardTitle}>Por moeda</h2><div style={styles.statsGrid}><StatCard title="🇧🇷 Real" value={formatMoney(receivedByCurrency.BRL)}/><StatCard title="🇪🇺 Euro" value={formatForeign(receivedByCurrency.EUR,"EUR")}/><StatCard title="🇺🇸 Dólar" value={formatForeign(receivedByCurrency.USD,"USD")}/><StatCard title="🇬🇧 Libra" value={formatForeign(receivedByCurrency.GBP,"GBP")}/></div></section>
  </>}
  {reportTab==="home" && <>
   <section style={styles.card}><div style={styles.eyebrow}>CASA</div><h2 style={styles.cardTitle}>Visão financeira da casa</h2><div style={styles.statsGrid}><StatCard title="Gastos" value={formatMoney(homeExpenses)}/><StatCard title="Compras" value={formatMoney(homePurchases.reduce((s,p)=>s+p.total,0))}/><StatCard title="Contas pagas" value={formatMoney(payables.filter(p=>p.area==="home"&&p.status==="paid"&&inRange(p.dueDate)).reduce((s,p)=>s+p.amount,0))}/><StatCard title="Registros" value={String(homePurchases.length)}/></div></section>
   <section style={styles.card}><div style={styles.eyebrow}>GASTOS POR SETOR</div><h2 style={styles.cardTitle}>Onde a casa mais gastou</h2>{Object.keys(sectorSpend).length===0?<div style={styles.emptyBox}>Nenhum gasto encontrado.</div>:<div style={{display:"grid",gap:10}}>{Object.entries(sectorSpend).sort((x,y)=>y[1]-x[1]).map(([label,value])=><div key={label}><div style={{display:"flex",justifyContent:"space-between"}}><strong>{label}</strong><span>{formatMoney(value)}</span></div><div style={{height:8,borderRadius:99,background:"#eee",overflow:"hidden",marginTop:5}}><div style={{height:"100%",width:`${Math.max(3,value/Math.max(1,...Object.values(sectorSpend))*100)}%`}}/></div></div>)}</div>}</section>
  </>}
  {reportTab==="contacts" && (()=>{ const activeClients=clients.filter(c=>!c.deletedAt); const sourceLabels:Record<ClientSource,string>={indication:"Indicação",instagram:"Instagram",facebook:"Facebook / perfil",facebook_comment:"Comentário no Facebook",search:"Pesquisa",whatsapp:"WhatsApp",content:"Conteúdo / postagem",active_prospecting:"Prospecção ativa",other:"Outro"}; const counts=activeClients.reduce((a,c)=>{const k=c.source||"other";a[k]=(a[k]||0)+1;return a;},{} as Record<string,number>); const budgetBySource=activeClients.reduce((a,c)=>{const k=c.source||"other";a[k]=(a[k]||0)+budgets.filter(b=>b.clientId===c.id).length;return a;},{} as Record<string,number>); return <section style={styles.card}><div className={styles.eyebrow}>AQUISIÇÃO DE CONTATOS</div><h2 style={styles.cardTitle}>De onde estão vindo os consulentes?</h2><p style={styles.muted}>Mapeie a origem do contato e compare contatos e orçamentos por canal.</p><div style={styles.statsGrid}><StatCard title="Novos contatos" value={String(activeClients.length)}/><StatCard title="Indicações" value={String(counts.indication||0)}/><StatCard title="Pesquisa" value={String(counts.search||0)}/><StatCard title="Prospecção ativa" value={String(counts.active_prospecting||0)}/></div><div style={styles.list}>{Object.entries(sourceLabels).map(([key,label])=><div key={key} style={styles.listItem}><div><strong>{label}</strong><div style={styles.muted}>Contatos: {counts[key]||0} · Orçamentos: {budgetBySource[key]||0}</div></div><strong>{activeClients.length?((counts[key]||0)/activeClients.length*100).toFixed(1):"0.0"}%</strong></div>)}</div></section>; })()}
{reportTab==="work" && <>
   <section style={styles.card}><div style={styles.eyebrow}>TRABALHO · ATIVIDADE</div><h2 style={styles.cardTitle}>Painel completo</h2><div style={styles.statsGrid}><StatCard title="Consultas" value={String(workConsultationCount)}/><StatCard title="Trabalhos feitos" value={String(workDoneCount)}/><StatCard title="Orçamentos" value={String(workBudgetCount)}/><StatCard title="Vendas" value={String(workSaleCount)}/><StatCard title="Perguntas" value={String(workQuestionCount)}/><StatCard title="Recebido" value={formatMoney(workPaid)}/><StatCard title="A receber" value={formatMoney(workPending)}/><StatCard title="Não pago" value={formatMoney(workDefaulted)}/><StatCard title="Gastos" value={formatMoney(workExpenses)}/><StatCard title="Lucro" value={formatMoney(workPaid-workExpenses)}/></div></section>
   <section style={styles.card}><div style={styles.eyebrow}>PARCELAS</div><h2 style={styles.cardTitle}>Situação dos recebimentos</h2><div style={styles.statsGrid}><StatCard title="✓ Pagas" value={String(receivedCount)}/><StatCard title="⏳ Pendentes" value={String(pendingCount)}/><StatCard title="⚠ Não pagas" value={String(defaultedCount)}/></div><button style={styles.smallButton} onClick={()=>setScreen("finance")}>Abrir agenda financeira</button></section>
   <section style={styles.card}><div style={styles.eyebrow}>DESEMPENHO</div><h2 style={styles.cardTitle}>Mês A × Mês B</h2><div style={styles.twoColumns}><div><label style={styles.label}>Mês A</label><input type="month" value={reportMonthA} onChange={e=>setReportMonthA(e.target.value)} style={styles.input}/></div><div><label style={styles.label}>Mês B</label><input type="month" value={reportMonthB} onChange={e=>setReportMonthB(e.target.value)} style={styles.input}/></div></div><div style={{display:"grid",gap:9,marginTop:12}}><div style={styles.infoBox}>Consultas: {a.consultations} → {b.consultations} · {pctChange(b.consultations,a.consultations).toFixed(1)}%</div><div style={styles.infoBox}>Trabalhos: {a.works} → {b.works} · {pctChange(b.works,a.works).toFixed(1)}%</div><div style={styles.infoBox}>Orçamentos: {a.budgets} → {b.budgets} · {pctChange(b.budgets,a.budgets).toFixed(1)}%</div><div style={styles.infoBox}>Vendas: {a.sales} → {b.sales} · {pctChange(b.sales,a.sales).toFixed(1)}%</div><div style={styles.infoBox}>Recebido: {formatMoney(a.received)} → {formatMoney(b.received)} · {pctChange(b.received,a.received).toFixed(1)}%</div><div style={styles.infoBox}>Lucro: {formatMoney(a.workProfit)} → {formatMoney(b.workProfit)} · {pctChange(b.workProfit,a.workProfit).toFixed(1)}%</div><div style={styles.infoBox}>Resultado final: {formatMoney(a.net)} → {formatMoney(b.net)} · {pctChange(b.net,a.net).toFixed(1)}%</div></div></section>
  </>}
  {reportTab==="routines" && <section style={styles.card}><div style={styles.eyebrow}>ROTINAS · TEMPO</div><h2 style={styles.cardTitle}>Tempo de execução</h2><div style={styles.statsGrid}><StatCard title="Rotinas hoje" value={String(todayRoutineOccurrences.length)}/><StatCard title="Concluídas hoje" value={String(todayRoutineDone)}/><StatCard title="Pendentes hoje" value={String(todayRoutinePending)}/><StatCard title="Execuções cronometradas" value={String(routineDurationRows.length)}/></div><div style={styles.list}>{routineDurationRows.slice(-30).reverse().map(row=><div key={row.id} style={styles.listItem}><div><strong>{row.routine?.title}</strong><div style={styles.muted}>{row.date} · {row.routine?.area==="home"?"Casa":"Trabalho"} · {familyMembers.find(m=>m.id===row.routine?.responsibleId)?.name||""}</div></div><strong>{row.durationMinutes} min</strong></div>)}</div></section>}
 </>;
})()}
{/* =================================================
ADMINISTRAÇÃO
================================================= */}
{screen === "suppliers" && (
<>
<section style={styles.hero}>
<div style={styles.eyebrow}>CADASTROS</div>
<h2 style={styles.pageTitle}>Fornecedores e estabelecimentos</h2>
<p style={styles.heroText}>Cadastre os lugares onde vocês compram e vincule cada estabelecimento a Casa ou Trabalho, setor e uma ou mais categorias. Esses cadastros serão reutilizados nas saídas rápidas, compras e relatórios.</p>
<button style={styles.primaryButtonLarge} onClick={() => setShowSupplierModal(true)}>+ Cadastrar fornecedor</button>
</section>
<section style={styles.card}>
<div style={styles.cardHeader}>
<div><div style={styles.eyebrow}>ESTABELECIMENTOS</div><h2 style={styles.cardTitle}>Meus fornecedores</h2></div>
<strong>{suppliers.filter((item) => item.active).length}</strong>
</div>
{suppliers.length === 0 ? (
<div style={styles.emptyBox}>Nenhum fornecedor cadastrado ainda.</div>
) : (
<div style={styles.list}>
{suppliers.map((supplier) => {
const sector = householdSectors.find((item) => item.id === supplier.sectorId);
return (
<div key={supplier.id} style={styles.listItem}>
<div style={{ flex: 1 }}>
<strong>{supplier.name}</strong>
<div style={styles.muted}>{supplier.area === "home" ? "🏠 Casa" : "🔮 Trabalho"} · {supplier.type === "market" ? "Mercado" : supplier.type === "store" ? "Loja" : supplier.type === "restaurant" ? "Restaurante" : supplier.type === "service" ? "Serviço" : "Outro"}</div>
{supplier.area === "home" && <div style={styles.muted}>Setor: {sector?.name || "Não definido"}</div>}
{supplier.area === "home" && <div style={styles.muted}>Categorias: {getSupplierCategoriesLabel(supplier)}</div>}
{supplier.phone && <div style={styles.muted}>WhatsApp/telefone: {supplier.phone}</div>}
{supplier.document && <div style={styles.muted}>Documento: {supplier.document}</div>}
{supplier.notes && <div style={styles.muted}>Obs.: {supplier.notes}</div>}
</div>
</div>
);
})}
</div>
)}
</section>
</>
)}
{screen ===
"settings" && (
<>
<section
style={styles.hero}
>
<div
style={
styles.eyebrow
}
>
ADMINISTRAÇÃO
</div>
<h2
style={
styles.pageTitle
}
>
Configurações
</h2>
<p
style={
styles.heroText
}
>
Organize a casa, os serviços, os preços, os materiais e o financeiro em poucos grupos. As configurações servem como padrões; no atendimento e na execução vocês podem ajustar o que for necessário.
</p>
</section>
<div style={{display:"flex",gap:8,flexWrap:"wrap",marginBottom:10}}><button type="button" style={{...styles.smallOutlineButton,borderColor:"#c95b93",color:"#a53f76"}} onClick={()=>setSettingsTab("maintenance")}>🧪 Limpar dados para teste</button></div>
<div style={styles.settingsTabs}>
<button style={{...styles.settingsTab,...(settingsTab==="home"?styles.settingsTabActive:{})}} onClick={()=>setSettingsTab("home")}>🏠 Casa</button>
<button style={{...styles.settingsTab,...(settingsTab==="work"?styles.settingsTabActive:{})}} onClick={()=>setSettingsTab("work")}>✨ Serviços & vendas</button>
<button style={{...styles.settingsTab,...(settingsTab==="financial"?styles.settingsTabActive:{})}} onClick={()=>setSettingsTab("financial")}>💳 Financeiro</button>
<button style={{...styles.settingsTab,...(settingsTab==="backup"?styles.settingsTabActive:{})}} onClick={()=>setSettingsTab("backup")}>💾 Backup</button>
<button style={{...styles.settingsTab,...(settingsTab==="maintenance"?styles.settingsTabActive:{})}} onClick={()=>setSettingsTab("maintenance")}>🧹 Limpeza / Testes</button>
</div>
<section
style={{...styles.card, display: settingsTab === "home" ? undefined : "none"}}
>
<div
style={
styles.cardHeader
}
>
<div>
<div
style={
styles.eyebrow
}
>
CASA
</div>
<h2
style={
styles.cardTitle
}
>
Setores
</h2>
</div>
</div>
<div
style={styles.list}
>
{householdSectors.map(
(sector) => (
<div
key={
sector.id
}
style={
styles.listItem
}
>
<div>
<strong>
{
sector.name
}
</strong>
<div
style={
styles.muted
}
>
{
sector.description
}
</div>
</div>
<div style={{display:"flex",gap:6,alignItems:"center",flexWrap:"wrap"}}><span style={styles.successBadge}>Ativo</span><button type="button" style={styles.deleteButton} onClick={()=>deleteHouseholdSector(sector.id)}>Excluir</button></div>
</div>
)
)}
</div>
<button
style={
styles.secondaryButtonLarge
}
onClick={() => {
const name =
window.prompt(
"Nome do novo setor:"
);
if (!name?.trim())
return;
setHouseholdSectors(
(previous) => [
...previous,
{
id: makeId(),
name:
name.trim(),
description:
"",
active: true,
},
]
);
showToast(
"Setor criado."
);
}}
>
+ Novo setor
</button>
</section>
<section
style={{...styles.card, display: settingsTab === "home" ? undefined : "none"}}
>
<div
style={
styles.cardHeader
}
>
<div>
<div
style={
styles.eyebrow
}
>
CASA
</div>
<h2
style={
styles.cardTitle
}
>
Categorias
</h2>
</div>
</div>
<div
style={styles.list}
>
{householdCategories.map(
(category) => {
const sector =
householdSectors.find(
(item) =>
item.id ===
category.sectorId
);
return (
<div
key={
category.id
}
style={
styles.listItem
}
>
<div>
<strong>
{
category.name
}
</strong>
<div style={styles.muted}>Setor: {sector?.name || "Não definido"}</div>
</div><button type="button" style={styles.deleteButton} onClick={()=>deleteHouseholdCategory(category.id)}>Excluir</button>
</div>
);
}
)}
</div>
<button
style={
styles.secondaryButtonLarge
}
onClick={() => {
const name =
window.prompt(
"Nome da nova categoria:"
);
if (!name?.trim())
return;
const sector =
householdSectors.find(
(item) =>
item.active
);
if (!sector) {
showToast(
"Crie um setor primeiro."
);
return;
}
setHouseholdCategories(
(previous) => [
...previous,
{
id: makeId(),
sectorId:
sector.id,
name:
name.trim(),
active: true,
},
]
);
showToast(
"Categoria criada."
);
}}
>
+ Nova categoria
</button>
</section>
<section style={{...styles.card, display: settingsTab === "work" ? undefined : "none"}}>
<div style={styles.eyebrow}>ATENDIMENTOS</div>
<h2 style={styles.cardTitle}>Tipos de tiragem e preços</h2>
<div style={styles.muted}>Cadastre quantas perguntas a tiragem terá e o preço total do pacote em BRL, EUR, USD e GBP. Ex.: 4 perguntas por R$ 20 significa R$ 20 pela tiragem inteira, não R$ 20 por pergunta.</div>
<div style={{display:"grid",gap:12,marginTop:14}}>
{(Array.isArray(readingTypes)?readingTypes:initialReadingTypes).map(type=><div key={type.id} style={{...styles.listItem,display:"grid",gap:8}}>
<div style={{display:"flex",justifyContent:"space-between",gap:8,alignItems:"center"}}><div><strong>{type.name}</strong><div style={styles.muted}>{type.questions} pergunta(s) · {type.active?"Ativo":"Inativo"}</div></div><div style={{display:"flex",gap:6,flexWrap:"wrap"}}><button style={styles.smallButton} onClick={()=>{const questions=Number(window.prompt(`Quantas perguntas para "${type.name}"?`,String(type.questions)));if(!Number.isFinite(questions)||questions<1)return;setReadingTypes(prev=>prev.map(item=>item.id===type.id?{...item,questions:Math.floor(questions)}:item));showToast("Tipo de tiragem atualizado.");}}>Qtd.</button><button style={styles.deleteButton} onClick={()=>deleteReadingType(type.id)}>Excluir</button></div></div>
<div style={{display:"grid",gridTemplateColumns:"repeat(2,minmax(0,1fr))",gap:6}}>
{currencyList.map(currency=><label key={currency} style={styles.label}>{currency}<input type="number" min="0" step="0.01" value={normalizeCurrencyPrices(type.prices)[currency]} onChange={e=>{const value=Math.max(0,Number(String(e.target.value).replace(",","."))||0);setReadingTypes(prev=>prev.map(item=>item.id===type.id?{...item,prices:{...normalizeCurrencyPrices(item.prices),[currency]:value}}:item));}} style={styles.input}/></label>)}
</div>
</div>)}
</div>
<button style={styles.secondaryButtonLarge} onClick={()=>{const name=window.prompt("Nome da nova tiragem:");if(!name?.trim())return;const questions=Number(window.prompt("Quantidade de perguntas:","1"));if(!Number.isFinite(questions)||questions<1)return;const normalizedName=name.trim().toLocaleLowerCase("pt-BR");if(readingTypes.some(item=>item.name.trim().toLocaleLowerCase("pt-BR")===normalizedName&&Number(item.questions)===Math.floor(questions))){showToast("Esse tipo de tiragem já está cadastrado.");return;}setReadingTypes(prev=>[...prev,{id:makeId(),name:name.trim(),questions:Math.floor(questions),active:true,prices:emptyCurrencyPrices()}]);showToast("Tipo de tiragem criado.");}}>+ Nova tiragem</button>
</section>
<section style={{...styles.card, display: settingsTab === "work" ? undefined : "none"}}>
 <div style={styles.eyebrow}>EXECUÇÃO DOS TRABALHOS</div><h2 style={styles.cardTitle}>Materiais padrão por trabalho</h2>
 <p style={styles.muted}>Cadastre o que normalmente é usado. Na execução, a quantidade pode ser ajustada e vocês decidem na hora se o item foi novo ou reutilizado.</p>
 <div style={styles.twoColumns}><div><label style={styles.label}>Trabalho</label><select value={templateWorkId} onChange={e=>setTemplateWorkId(e.target.value)} style={styles.input}><option value="">Selecione...</option>{workTypes.filter(x=>x.active).map(x=><option key={x.id} value={x.id}>{x.name}</option>)}</select></div><div><label style={styles.label}>Item do estoque</label><select value={templateStockId} onChange={e=>setTemplateStockId(e.target.value)} style={styles.input}><option value="">Selecione...</option>{stockItems.filter(x=>x.active).map(x=><option key={x.id} value={x.id}>{x.name} · {x.unit}</option>)}</select></div></div>
 <label style={styles.label}>Quantidade padrão</label><input type="number" min="0" step="0.01" value={templateStockQty} onChange={e=>setTemplateStockQty(e.target.value)} style={styles.input}/><button style={styles.primaryButtonLarge} onClick={addWorkTemplateItem}>+ Adicionar material padrão</button>
 <div style={{display:"grid",gap:10,marginTop:14}}>{workTypes.filter(x=>x.active).map(w=><div key={w.id} style={styles.infoBox}><strong>{w.name}</strong>{(w.standardItems||[]).length===0?<div style={styles.muted}>Nenhum material padrão cadastrado.</div>:<div style={{display:"grid",gap:6,marginTop:7}}>{(w.standardItems||[]).map(i=>{const st=stockItems.find(x=>x.id===i.stockItemId);return <div key={i.stockItemId} style={{display:"flex",alignItems:"center",justifyContent:"space-between",gap:8}}><span>{st?.name||"Item removido"} · {i.quantity} {st?.unit||"un"}</span><button style={styles.deleteButton} onClick={()=>removeWorkTemplateItem(w.id,i.stockItemId)}>×</button></div>})}</div>}</div>)}</div>
</section>
<section style={{...styles.card, display: settingsTab === "home" ? undefined : "none"}}>
<div style={styles.eyebrow}>AGENDA · CONTAS</div>
<h2 style={styles.cardTitle}>Contas recorrentes</h2>
<div style={{ ...styles.muted, marginTop: 8 }}>
Cadastre contas que se repetem. Elas aparecerão automaticamente na aba Contas da Agenda no dia do vencimento.
</div>
<label style={styles.label}>Nome da conta</label>
<input value={accountTemplateName} onChange={event => setAccountTemplateName(event.target.value)} placeholder="Ex.: Internet, aluguel, escola..." style={styles.input} />
<label style={styles.label}>Descrição</label>
<input value={accountTemplateDescription} onChange={event => setAccountTemplateDescription(event.target.value)} placeholder="Opcional" style={styles.input} />
<label style={styles.label}>Destino</label>
<div style={styles.segmented}>
<button style={{ ...styles.segmentButton, ...(accountTemplateArea === "home" ? styles.segmentActive : {}) }} onClick={() => setAccountTemplateArea("home")}>🏠 Casa</button>
<button style={{ ...styles.segmentButton, ...(accountTemplateArea === "work" ? styles.segmentActive : {}) }} onClick={() => setAccountTemplateArea("work")}>💼 Trabalho</button>
</div>
<label style={styles.label}>Dia do vencimento</label>
<input type="number" min="1" max="31" value={accountTemplateDueDay} onChange={event => setAccountTemplateDueDay(event.target.value)} style={styles.input} />
<label style={styles.label}>Tipo de conta</label>
<select value={accountTemplateAmount.trim()?"fixed":"variable"} onChange={event=>{if(event.target.value==="variable")setAccountTemplateAmount("0");}} style={styles.input}><option value="fixed">Fixa — valor conhecido</option><option value="variable">Variável — informar quando chegar</option></select>
<label style={styles.label}>Valor habitual (deixe 0 para variável)</label>
<input type="number" min="0" step="0.01" value={accountTemplateAmount} onChange={event => setAccountTemplateAmount(event.target.value)} placeholder="0,00" style={styles.input} />
<label style={styles.label}>Fornecedor (opcional)</label>
<select value={accountTemplateSupplierId} onChange={event => setAccountTemplateSupplierId(event.target.value)} style={styles.input}>
<option value="">Nenhum</option>
{suppliers.filter(supplier => supplier.area === accountTemplateArea).map(supplier => <option key={supplier.id} value={supplier.id}>{supplier.name}</option>)}
</select>
<button style={styles.primaryButtonLarge} onClick={saveAccountTemplate}>✓ Cadastrar conta recorrente</button>
<div style={{ ...styles.list, marginTop: 14 }}>
{accountTemplates.length === 0 ? <div style={styles.emptyBox}>Nenhuma conta recorrente cadastrada.</div> : accountTemplates.map(item => {
 const supplier = suppliers.find(supplier => supplier.id === item.supplierId);
 return <div key={item.id} style={styles.listItem}>
  <div><strong>{item.name}</strong><div style={styles.muted}>{item.area === "home" ? "Casa" : "Trabalho"} · Todo dia {item.dueDay} · {formatMoney(item.amount)}{supplier ? ` · ${supplier.name}` : ""}</div>{item.description && <div style={styles.muted}>{item.description}</div>}</div>
  <div style={styles.futureActions}><button style={styles.smallButton} onClick={() => toggleAccountTemplate(item.id)}>{item.active ? "Ativa" : "Inativa"}</button><button style={styles.deleteButton} onClick={() => deleteAccountTemplate(item.id)}>Excluir</button></div>
 </div>;
})}
</div>
</section>
<section style={{...styles.card, display: settingsTab === "home" ? undefined : "none"}}>
<div style={styles.eyebrow}>CONTAS</div>
<h2 style={styles.cardTitle}>Contas bancárias e cheque especial</h2>
<div style={{ ...styles.muted, marginTop: 8 }}>
Cadastre o saldo e o limite de cheque especial de cada conta. Quando o saldo ficar
negativo, o uso do limite é calculado automaticamente.
</div>
<button style={styles.primaryButtonLarge} onClick={addBankAccountByPrompt}>
+ Cadastrar conta bancária
</button>
<div style={{ ...styles.list, marginTop: 14 }}>
{bankAccounts.length === 0 ? (
<div style={styles.emptyBox}>Nenhuma conta bancária cadastrada.</div>
) : (
bankAccounts.map((account) => {
const used = Math.max(0, -account.balance);
const available = Math.max(0, account.overdraftLimit - used);
return (
<div key={account.id} style={styles.listItem}>
<div>
<strong>{account.bank}</strong>
<div style={styles.muted}>
{account.area === "home" ? "Casa" : "Trabalho"} · Saldo
{formatMoney(account.balance)}
</div>
<div style={styles.muted}>
Cheque especial: {formatMoney(account.overdraftLimit)} ·
Usado: {formatMoney(used)} ·
Disponível: {formatMoney(available)}
</div>
</div>
<button
style={styles.smallButton}
onClick={() => {
const value = Number(
String(
window.prompt(
`Novo saldo para ${account.bank}:`,
String(account.balance)
) || ""
).replace(",", ".")
);
if (!Number.isFinite(value)) return;
updateBankBalance(account.id, value);
showToast("Saldo atualizado.");
}}
>
Atualizar
</button>
</div>
);
})
)}
</div>
</section>
<section
style={{...styles.card, display: settingsTab === "home" ? undefined : "none"}}
>
<div
style={
styles.eyebrow
}
>
ESTABELECIMENTOS
</div>
<h2
style={
styles.cardTitle
}
>
Fornecedores cadastrados
</h2>
<div style={{ ...styles.muted, marginTop: 8 }}>{suppliers.length} estabelecimento(s) cadastrado(s).</div>
<div style={{ ...styles.list, marginTop: 12 }}>
{suppliers.length === 0 ? <div style={styles.emptyBox}>Nenhum estabelecimento cadastrado.</div> : suppliers.map((supplier) => { const sector = householdSectors.find((item) => item.id === supplier.sectorId); return <div key={supplier.id} style={styles.listItem}><div><strong>{supplier.name}</strong><div style={styles.muted}>{supplier.area === "home" ? "Casa" : "Trabalho"} · {supplier.type === "market" ? "Mercado" : supplier.type === "store" ? "Loja" : supplier.type === "restaurant" ? "Restaurante" : supplier.type === "service" ? "Serviço" : "Outro"}</div>{supplier.area === "home" && <div style={styles.muted}>{sector ? `Setor: ${sector.name}` : "Sem setor"} · {getSupplierCategoriesLabel(supplier)}</div>}{supplier.phone && <div style={styles.muted}>WhatsApp/telefone: {supplier.phone}</div>}</div></div>; })}
</div>
<button
style={
styles.primaryButtonLarge
}
onClick={() =>
setShowSupplierModal(
true
)
}
>
+ Cadastrar estabelecimento
</button>
</section>
<section style={{...styles.card, display: settingsTab === "work" ? undefined : "none"}}><div style={styles.eyebrow}>TRABALHO</div><h2 style={styles.cardTitle}>Tipos de trabalho e preços</h2><div style={styles.muted}>O preço cadastrado aqui será sugerido automaticamente ao adicionar um trabalho ao atendimento.</div><div style={{display:"grid",gap:12,marginTop:14}}>{workTypes.map(w=><div key={w.id} style={{...styles.listItem,display:"grid",gap:8}}><div><strong>{w.name}</strong><div style={styles.muted}>{w.active?"Ativo":"Inativo"}</div><button type="button" style={{...styles.deleteButton,marginTop:6}} onClick={()=>deleteWorkType(w.id)}>Excluir</button></div><div style={{display:"grid",gridTemplateColumns:"repeat(2,minmax(0,1fr))",gap:6}}>{currencyList.map(currency=><label key={currency} style={styles.label}>{currency}<input type="number" min="0" step="0.01" value={normalizeCurrencyPrices(w.prices)[currency]} onChange={e=>{const value=Math.max(0,Number(String(e.target.value).replace(",","."))||0);setWorkTypes(prev=>prev.map(item=>item.id===w.id?{...item,prices:{...normalizeCurrencyPrices(item.prices),[currency]:value}}:item));}} style={styles.input}/></label>)}</div></div>)}</div><button style={styles.primaryButtonLarge} onClick={()=>{const name=window.prompt("Nome do novo tipo de trabalho:");if(!name?.trim())return;setWorkTypes(prev=>[...prev,{id:makeId(),name:name.trim(),active:true,prices:emptyCurrencyPrices(),createdAt:nowISO()}]);showToast("Tipo de trabalho criado.")}}>+ Adicionar tipo de trabalho</button></section>
<section style={{...styles.card, display: settingsTab === "work" ? undefined : "none"}}><div style={styles.eyebrow}>PRODUTOS PARA VENDA</div><h2 style={styles.cardTitle}>Catálogo de vendas e preços</h2><div style={styles.muted}>Cada produto pode ter um preço padrão em cada moeda.</div>{saleItems.length===0?<div style={styles.emptyBox}>Nenhum produto cadastrado.</div>:<div style={{display:"grid",gap:12,marginTop:14}}>{saleItems.map(x=><div key={x.id} style={{...styles.listItem,display:"grid",gap:8}}><div><strong>{x.name}</strong><div style={styles.muted}>{x.active?"Ativo":"Inativo"}</div><button type="button" style={{...styles.deleteButton,marginTop:6}} onClick={()=>deleteSaleItem(x.id)}>Excluir</button></div><div style={{display:"grid",gridTemplateColumns:"repeat(2,minmax(0,1fr))",gap:6}}>{currencyList.map(currency=><label key={currency} style={styles.label}>{currency}<input type="number" min="0" step="0.01" value={normalizeCurrencyPrices(x.prices,x.price)[currency]} onChange={e=>{const value=Math.max(0,Number(String(e.target.value).replace(",","."))||0);setSaleItems(prev=>prev.map(item=>item.id===x.id?{...item,price:currency==="BRL"?value:item.price,prices:{...normalizeCurrencyPrices(item.prices,item.price),[currency]:value}}:item));}} style={styles.input}/></label>)}</div></div>)}</div>}<button style={styles.primaryButtonLarge} onClick={()=>{const name=window.prompt("Nome do produto para venda:");if(!name?.trim())return;const price=Number(String(window.prompt("Preço padrão em BRL:","0")||"0").replace(",","."));setSaleItems(prev=>[...prev,{id:makeId(),name:name.trim(),price:Number.isFinite(price)?Math.max(0,price):0,prices:{...emptyCurrencyPrices(),BRL:Number.isFinite(price)?Math.max(0,price):0},description:"",category:"",active:true,createdAt:nowISO()}]);showToast("Produto cadastrado.")}}>+ Adicionar produto para venda</button></section>
<section style={{...styles.card, display: settingsTab === "financial" ? undefined : "none"}}>
<div style={styles.eyebrow}>GESTÃO FINANCEIRA</div><h2 style={styles.cardTitle}>Empréstimos, reservas e aplicações</h2><p style={styles.muted}>Cadastros financeiros ficam integrados ao caixa, às contas a pagar e aos relatórios.</p>
<div style={styles.actionGrid}><button style={styles.actionCard} onClick={createLoan}>🏦<strong>Novo empréstimo</strong><span>Parcelas, juros e saldo devedor</span></button><button style={styles.actionCard} onClick={createReserve}>🐷<strong>Nova reserva</strong><span>Dinheiro guardado separado do caixa</span></button></div>
<div style={styles.list}>{loans.map(l=><div key={l.id} style={styles.listItem}><div><strong>🏦 {l.name}</strong><div style={styles.muted}>Saldo devedor {formatMoney(l.balanceDue??l.principal)} · {l.installments} parcelas</div></div></div>)}{reserves.map(r=><button key={r.id} style={{...styles.listItem,width:"100%",textAlign:"left"}} onClick={()=>{setSelectedReserveId(r.id);setShowReserveManager(true);}}><div><strong>🐷 {r.name}</strong><div style={styles.muted}>Guardado: {formatMoney(r.balance)} · {r.cdiPercent ?? 115}% do CDI</div></div><strong>→</strong></button>)}</div>
</section>
<section style={{...styles.card, display: settingsTab === "financial" ? undefined : "none"}}><div style={styles.eyebrow}>RECEBIMENTOS INTERNACIONAIS</div><h2 style={styles.cardTitle}>Moedas e taxas</h2><div style={styles.muted}>Cotação diária via Frankfurter/BCB. Última atualização: {currencyRateDate || "não atualizada"}.</div><div style={styles.twoColumns}><div><label style={styles.label}>PayPal · taxa %</label><input type="number" min="0" step="0.01" value={currencySettings.paypalFeePercent} onChange={e=>setCurrencySettings({...currencySettings,paypalFeePercent:Number(e.target.value)||0})} style={styles.input}/></div><div><label style={styles.label}>Wise · taxa %</label><input type="number" min="0" step="0.01" value={currencySettings.wiseFeePercent} onChange={e=>setCurrencySettings({...currencySettings,wiseFeePercent:Number(e.target.value)||0})} style={styles.input}/></div></div><label style={styles.label}>Outras taxas · %</label><input type="number" min="0" step="0.01" value={currencySettings.otherFeePercent} onChange={e=>setCurrencySettings({...currencySettings,otherFeePercent:Number(e.target.value)||0})} style={styles.input}/><button type="button" style={styles.primaryButtonLarge} onClick={()=>{safeSetStorage("currency-settings",currencySettings);showToast("Taxas salvas com sucesso.")}}>✓ Salvar taxas</button><div style={styles.infoBox}>USD: {currencyRates.USD?.toFixed(4) || "—"} · EUR: {currencyRates.EUR?.toFixed(4) || "—"} · GBP: {currencyRates.GBP?.toFixed(4) || "—"} BRL por unidade.</div></section>
<section style={{...styles.card, display: settingsTab === "backup" ? undefined : "none"}}>
<div style={styles.eyebrow}>SEGURANÇA DOS DADOS</div>
<h2 style={styles.cardTitle}>💾 Backup completo</h2>
<div style={styles.infoBox}>Baixe um arquivo <strong>.zip</strong> com os dados persistidos do aplicativo. O backup é independente do Supabase e não inclui credenciais ou tokens de login.</div>
<div className="backup-actions" style={{marginTop:14}}>
<button type="button" style={styles.primaryButtonLarge} onClick={()=>void exportFullBackup()}>⬇️ Baixar backup completo</button>
<button type="button" style={styles.secondaryButtonLarge} onClick={()=>fullBackupInputRef.current?.click()}>⬆️ Importar backup completo</button>
</div>
<input ref={fullBackupInputRef} type="file" accept=".zip,application/zip" hidden onChange={e=>{const file=e.target.files?.[0]; if(file) void importFullBackup(file); e.currentTarget.value="";}} />
<div style={{...styles.muted,marginTop:12}}>O arquivo inclui movimentações, consulentes, atendimentos, trabalhos, vendas, parcelas, agenda, inventário, configurações, organização e demais dados que estejam salvos no armazenamento local do aplicativo, inclusive mídias que façam parte desses registros.</div>
</section>
<section style={{...styles.card, display: settingsTab === "maintenance" ? undefined : "none"}}>
<div style={styles.eyebrow}>ADMINISTRAÇÃO DE DADOS</div>
<h2 style={styles.cardTitle}>🧹 Limpeza e testes</h2>
<div style={styles.infoBox}>Esta área existe para testar o aplicativo do zero. Cada botão limpa o módulo escolhido <strong>no Supabase e neste aparelho</strong>. O login e a conta do Supabase permanecem intactos.</div>
<div style={{display:"grid",gap:10,marginTop:14}}>
{Object.entries(RESET_GROUPS).map(([id,group]) => <div key={id} style={styles.listItem}>
<div style={{display:"flex",gap:10,alignItems:"flex-start",flex:1,minWidth:0}}><label style={{display:"flex",alignItems:"flex-start",paddingTop:3,cursor:"pointer"}}><input type="checkbox" checked={selectedResetGroups.includes(id)} onChange={()=>toggleResetGroup(id)} aria-label={`Selecionar ${group.label} para reset`} /></label><span style={{fontSize:24}}>{group.icon}</span><div><strong>{group.label}</strong><div style={styles.muted}>{group.description}</div></div></div>
<button style={styles.smallButton} onClick={() => resetApplicationGroup(id)}>Resetar</button>
</div>)}
</div><div style={{display:"flex",gap:8,flexWrap:"wrap",marginTop:12}}><button style={styles.smallButton} onClick={()=>setSelectedResetGroups(Object.keys(RESET_GROUPS))}>☑️ Selecionar todos</button><button style={styles.smallButton} onClick={()=>setSelectedResetGroups([])}>Limpar seleção</button><button style={{...styles.primaryButton,opacity:selectedResetGroups.length?1:.55}} disabled={!selectedResetGroups.length} onClick={()=>void resetSelectedGroups()}>🧹 Resetar selecionados ({selectedResetGroups.length})</button></div><div style={{...styles.infoBox,marginTop:12}}><strong>🧪 Limpeza financeira por área</strong><div style={styles.muted}>Use quando quiser testar somente Casa ou Trabalho sem apagar o outro lado.</div><div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginTop:8}}><button style={styles.smallButton} onClick={()=>resetFinanceArea("home")}>🧹 Zerar Casa</button><button style={styles.smallButton} onClick={()=>resetFinanceArea("work")}>🧹 Zerar Trabalho</button></div></div>
<div style={{marginTop:18,padding:16,borderRadius:16,border:"1px solid #efb0b0",background:"#fff7f7"}}>
<div style={{fontWeight:900,color:"#9a3030",fontSize:16}}>⚠️ Reset geral</div>
<div style={{...styles.muted,marginTop:6}}>Apaga todos os dados e configurações do aplicativo, no Supabase e no aparelho. Não apaga o usuário/login.</div>
<button style={{...styles.primaryButtonLarge,marginTop:12,background:"#a83b4b"}} onClick={resetEverything}>🗑️ Resetar tudo e começar do zero</button>
</div>
</section>
</>
)}

</main>
{showReserveManager && (
 <Modal title="🐷 Caixinhas" onClose={()=>setShowReserveManager(false)}>
  <div style={styles.infoBox}>O dinheiro guardado continua fazendo parte do patrimônio, mas fica separado do saldo disponível. O rendimento da própria caixinha é configurado aqui pelo percentual do CDI.</div>
  <div style={styles.actionGrid}><button style={styles.primaryButtonLarge} onClick={createReserve}>＋ Criar nova caixinha</button></div>
  <div style={styles.list}>{reserves.map(r=><button key={r.id} style={{...styles.listItem,width:"100%",textAlign:"left",border:selectedReserveId===r.id?"2px solid #c05b88":undefined}} onClick={()=>setSelectedReserveId(r.id)}><div><strong>🐷 {r.name}</strong><div style={styles.muted}>{formatMoney(r.balance)} · {r.cdiPercent ?? 115}% do CDI</div></div><span>›</span></button>)}</div>
  {selectedReserveId && (()=>{const r=reserves.find(x=>x.id===selectedReserveId);if(!r)return null;return <div style={{...styles.card,marginTop:12}}><div style={styles.cardHeader}><div><strong>{r.name}</strong><div style={styles.muted}>Saldo guardado</div></div><strong style={{fontSize:20}}>{formatMoney(r.balance)}</strong></div><label style={styles.label}>Percentual do CDI da caixinha</label><input type="number" min="0" step="0.01" value={r.cdiPercent ?? 115} onChange={e=>setReserves(prev=>prev.map(x=>x.id===r.id?{...x,cdiPercent:Number(e.target.value)||0,updatedAt:nowISO()}:x))} style={styles.input}/><div className="dashboard-action-grid"><button className="dashboard-action" onClick={()=>moveToReserve(r.id)}>＋ Guardar dinheiro</button><button className="dashboard-action" onClick={()=>redeemReserve(r.id)}>↩ Resgatar dinheiro</button></div></div>})()}
 </Modal>
)}
{showLoanManager && (
 <Modal title="🏦 Empréstimos" onClose={()=>setShowLoanManager(false)}>
  <div style={styles.infoBox}>Um empréstimo aumenta o caixa, mas não é lucro. As parcelas reduzem o saldo devedor e registram juros/multas quando houver atraso.</div>
  <button style={styles.primaryButtonLarge} onClick={createLoan}>＋ Criar novo empréstimo</button>
  {showLoanForm&&<div style={{...styles.card,marginTop:12}}><div style={styles.eyebrow}>NOVO EMPRÉSTIMO</div><label style={styles.label}>Nome</label><input value={loanFormName} onChange={e=>setLoanFormName(e.target.value)} style={styles.input}/><label style={styles.label}>Área</label><div style={styles.segmented}><button style={{...styles.segmentButton,...(loanFormArea==="home"?styles.segmentActive:{})}} onClick={()=>setLoanFormArea("home")}>🏠 Casa</button><button style={{...styles.segmentButton,...(loanFormArea==="work"?styles.segmentActive:{})}} onClick={()=>setLoanFormArea("work")}>🔮 Trabalho</button></div><label style={styles.label}>Valor recebido</label><input type="number" min="0" step="0.01" value={loanFormPrincipal} onChange={e=>setLoanFormPrincipal(e.target.value)} style={styles.input}/><label style={styles.label}>Juros ao mês (%)</label><input type="number" min="0" step="0.01" value={loanFormRate} onChange={e=>setLoanFormRate(e.target.value)} style={styles.input}/><label style={styles.label}>Número de parcelas</label><input type="number" min="1" value={loanFormCount} onChange={e=>setLoanFormCount(e.target.value)} style={styles.input}/><label style={styles.label}>Primeiro vencimento</label><input type="date" value={loanFormFirstDate} onChange={e=>setLoanFormFirstDate(e.target.value)} style={styles.input}/><label style={styles.label}>Observações</label><textarea value={loanFormNotes} onChange={e=>setLoanFormNotes(e.target.value)} style={styles.textarea}/><button style={styles.primaryButtonLarge} onClick={saveLoan}>✓ Salvar empréstimo</button><button style={styles.secondaryButtonLarge} onClick={()=>setShowLoanForm(false)}>Cancelar</button></div>}
  <div style={styles.list}>{loans.map(l=><button key={l.id} style={{...styles.listItem,width:"100%",textAlign:"left",border:selectedLoanId===l.id?"2px solid #c05b88":undefined}} onClick={()=>setSelectedLoanId(l.id)}><div><strong>🏦 {l.name}</strong><div style={styles.muted}>Saldo devedor {formatMoney(l.balanceDue??l.principal)} · {l.paidInstallments}/{l.installments} pagas</div></div><span>›</span></button>)}</div>
  {selectedLoanId && (()=>{const l=loans.find(x=>x.id===selectedLoanId);if(!l)return null;return <div style={{...styles.card,marginTop:12}}><div style={styles.cardHeader}><div><strong>{l.name}</strong><div style={styles.muted}>Saldo devedor</div></div><strong>{formatMoney(l.balanceDue??l.principal)}</strong></div><div style={styles.list}>{(l.installmentSchedule||[]).map(i=><div key={i.id} style={styles.listItem}><div><strong>Parcela {i.number}</strong><div style={styles.muted}>{formatDate(i.dueDate)} · {formatMoney(i.amount)} · {i.status==="paid"?"Paga":"Pendente"}</div></div>{i.status!=="paid"&&<button style={styles.smallButton} onClick={()=>payLoanInstallment(l.id,i.id)}>Pagar</button>}</div>)}</div></div>})()}
 </Modal>
)}
{showHealthNoteModal && <Modal title="💬 Como você está se sentindo?" onClose={()=>setShowHealthNoteModal(false)}><textarea autoFocus value={healthNote} onChange={e=>setHealthNote(e.target.value)} placeholder="Escreva livremente como você está, o que sentiu ou o que aconteceu..." style={{...styles.textarea,minHeight:180}}/><button style={styles.primaryButtonLarge} onClick={()=>setShowHealthNoteModal(false)}>✓ Salvar observação</button></Modal>}
{/* =====================================================
   MENU LATERAL
===================================================== */}
{menuOpen && typeof document !== "undefined" && createPortal((
 <div className="menu-overlay-scroll" style={{...styles.menuOverlay,zIndex:2147482000}} onClick={() => setMenuOpen(false)}>
  <aside className="side-menu-scroll" style={styles.sideMenu} onClick={event => event.stopPropagation()}>
   <div style={styles.menuHeader}><div><div style={styles.eyebrow}>GESTÃO</div><h2 style={styles.menuTitle}>Menu</h2></div><button style={styles.modalClose} onClick={() => setMenuOpen(false)}>×</button></div>
   <button style={styles.menuItem} onClick={() => { setOrganizationSection("index"); setScreen("organization"); setMenuOpen(false); }}>🏠 <span>Organização</span></button>
   <button style={styles.menuItem} onClick={() => { setScreen("tools"); setMenuOpen(false); }}>🧰 <span>Ferramentas</span></button>
   <button style={styles.menuItem} onClick={() => { setScreen("services"); setMenuOpen(false); }}>✨ <span>Serviços</span></button>
   <button style={styles.menuItem} onClick={() => { setDailyDate(localDateKey()); setDailyFilter("all"); setDailySearch(""); setScreen("daily"); setMenuOpen(false); }}>🗓️ <span>Histórico do dia</span></button>
   <button style={styles.menuItem} onClick={() => { setScreen("budgets"); setMenuOpen(false); }}>💼 <span>Orçamentos</span></button>
   <button style={styles.menuItem} onClick={() => { setScreen("clients"); setMenuOpen(false); }}>👤 <span>Histórico dos consulentes</span></button>
   <button style={styles.menuItem} onClick={() => { setScreen("trash"); setMenuOpen(false); }}>🗑️ <span>Lixeira{trash.length ? ` (${trash.length})` : ""}</span></button>
   <div style={styles.menuDivider}></div>
   <button style={styles.menuItem} onClick={() => { setScreen("dashboard"); setMenuOpen(false); }}>⌂ <span>Início</span></button>
   <button style={styles.menuItem} onClick={() => { setScreen("finance"); setMenuOpen(false); }}>💰 <span>Financeiro</span></button>
   <button style={styles.menuItem} onClick={() => { setScreen("reports"); setMenuOpen(false); }}>📊 <span>Relatórios</span></button>
   <button style={styles.menuItem} onClick={() => { setScreen("stock"); setMenuOpen(false); }}>📦 <span>Estoque de consumo</span></button>
   <button type="button" style={styles.menuItem} onClick={() => { setShowNewConsultation(false); setScreen("inventory"); setMenuOpen(false); }}>🗃️ <span>Inventário</span></button>
   <button style={styles.menuItem} onClick={() => { setScreen("suppliers"); setMenuOpen(false); }}>🏪 <span>Fornecedores</span></button>
   <button style={styles.menuItem} onClick={() => { setScreen("settings"); setMenuOpen(false); }}>⚙ <span>Configurações</span></button>
  </aside>
 </div>
), document.body)}
 
<nav className="bottom-nav" style={styles.bottomNav}>
 <button className={screen==="dashboard"?"active":""} onClick={()=>setScreen("dashboard")}>⌂<span>Início</span></button>
 <button className={screen==="clients"?"active":""} onClick={()=>setScreen("clients")}>👤<span>Clientes</span></button>
 <button className="new-main" onClick={()=>{setShowNewConsultation(true);}}>＋<span>Nova</span></button>
 <button className={screen==="services"?"active":""} onClick={()=>setScreen("services")}>💼<span>Serviços</span></button>
 <button className={screen==="agenda"?"active":""} onClick={()=>{setAgendaTab("work");setAgendaFilterDate("");setScreen("agenda");}}>📅<span>Agenda</span></button>
</nav>
{/* =====================================================
NOVO ATENDIMENTO
===================================================== */}
{showFinancialMovements && <Modal title="Movimentações financeiras" onClose={()=>setShowFinancialMovements(false)}><p style={styles.modalText}>Somente o dinheiro que realmente entrou ou saiu aparece aqui. Orçamentos, parcelas pendentes e outros valores futuros não são movimentações realizadas. Use os botões de cada lançamento para corrigir ou excluir o registro; quando houver uma origem vinculada, o sistema atualiza também essa origem.</p><div className="segmented"><button style={financialMovementFilter==="all"?styles.segmentActive:styles.segmentButton} onClick={()=>setFinancialMovementFilter("all")}>Tudo</button><button style={financialMovementFilter==="income"?styles.segmentActive:styles.segmentButton} onClick={()=>setFinancialMovementFilter("income")}>Entradas</button><button style={financialMovementFilter==="expense"?styles.segmentActive:styles.segmentButton} onClick={()=>setFinancialMovementFilter("expense")}>Saídas</button></div><div style={styles.list}>{recentTransactions.filter(x=>x.kind!=="receivable"&&(financialMovementFilter==="all"||x.kind===financialMovementFilter)).map((item:any)=><div key={item.id} style={{...styles.listItem,alignItems:"center",gap:10}}><div style={{minWidth:0,flex:1}}><strong>{item.title}</strong><div style={styles.muted}>{item.subtitle} · {formatDateTime(item.date)}</div></div><strong style={{color:item.kind==="income"?"#16803c":"#c62828",whiteSpace:"nowrap"}}>{item.kind==="income"?"+":"-"}{formatMoney(item.amount)}</strong><div style={{display:"flex",gap:5,flexShrink:0}}><button type="button" aria-label="Editar movimentação" title="Editar" style={styles.smallButton} onClick={()=>editFinancialMovement(item)}>✏️</button><button type="button" aria-label="Excluir movimentação" title="Excluir" style={styles.deleteButton} onClick={()=>deleteFinancialMovement(item)}>🗑️</button></div></div>)}</div></Modal>}

{showNewConsultation && (
<Modal title="Novo atendimento" onClose={() => setShowNewConsultation(false)}>
<div style={styles.compactFormGrid}>
<div>
<label style={styles.label}>Consulente</label>
<input value={newClientSearch} onChange={event=>setNewClientSearch(event.target.value)} placeholder="🔎 Pesquisar consulente..." style={styles.input} />
<select value={selectedClientId} onChange={event => { const id=event.target.value; setSelectedClientId(id); prefillServiceShippingFromClient(id); }} style={styles.input}>
{clients.filter(client=>!newClientSearch.trim() || client.name.toLowerCase().includes(newClientSearch.toLowerCase().trim()) || client.phone.includes(newClientSearch.trim())).map(client => <option key={client.id} value={client.id}>{client.name}</option>)}
</select>
<button style={styles.smallOutlineButton} onClick={() => { setReturnToNewConsultationAfterClient(true); setShowNewClient(true); }}>+ Cadastrar consulente</button>

</div>
<div>
<label style={styles.label}>Tipo de atendimento</label>
<select value={newServiceType} onChange={event => { setNewServiceType(event.target.value as any); setSelectedWorkTypeId(""); setSelectedSaleItemId(""); if(event.target.value!=="sale") setServiceNeedsConfection(false); }} style={styles.input}>
<option value="consultation">🔮 Nova consulta</option><option value="work">✨ Novo trabalho</option><option value="sale">🛍️ Nova venda</option>
</select>
</div>
</div>
<button type="button" style={{...styles.compactActionCard,marginTop:10}} onClick={()=>{setShowNewConsultation(false);setBudgetClientId(selectedClientId||"");openQuickBudgetForClient(selectedClientId||"");}}>📋 <strong>Novo orçamento separado</strong><span>Orçar perguntas, tiragens, trabalhos, pedras, materiais e outros itens.</span></button>
{newServiceType === "work" && <section style={styles.infoBox}><label style={styles.label}>Tipo de trabalho</label><div style={{display:"grid",gap:6}}><select value={selectedWorkTypeId} onChange={e=>{setSelectedWorkTypeId(e.target.value); const w=workTypes.find(x=>x.id===e.target.value); if(w){setNewTitle(w.name); const price=workPrice(w,serviceCurrency); if(serviceCurrency==="BRL") setServiceValue(String(price)); else setServiceForeignAmount(String(price));}}} style={styles.input}><option value="">Selecione...</option>{workTypes.filter(x=>x.active).map(x=><option key={x.id} value={x.id}>{x.name}</option>)}</select><button type="button" style={styles.smallButton} onClick={()=>openQuickCatalog("work")}>＋ Novo tipo de trabalho</button></div></section>}
{newServiceType === "sale" && <section style={styles.infoBox}><label style={styles.label}>Item para vender</label><div style={{display:"grid",gap:6}}><select value={selectedSaleItemId} onChange={e=>{setSelectedSaleItemId(e.target.value); const item=saleItems.find(x=>x.id===e.target.value); if(item){setNewTitle(item.name); const price=salePrice(item,serviceCurrency); if(serviceCurrency==="BRL") setServiceValue(String(price)); else setServiceForeignAmount(String(price));}}} style={styles.input}><option value="">Selecione...</option>{saleItems.filter(x=>x.active).map(x=><option key={x.id} value={x.id}>{x.name} · {formatMoney(x.price)}</option>)}</select>{saleItems.filter(x=>x.active).length===0 && <div style={styles.muted}>Cadastre itens em Administração → Itens para venda.</div>}</div></section>}
{newServiceType === "consultation" && (
<div>
<label style={styles.label}>Tipo de tiragem</label>
<div style={styles.twoColumns}>
<select value={selectedReadingTypeId} onChange={event => setSelectedReadingTypeId(event.target.value)} style={styles.input}>
{(Array.isArray(readingTypes) ? readingTypes : initialReadingTypes).filter(item => item.active).map(item => <option key={item.id} value={item.id}>{item.name} · {item.questions} pergunta(s)</option>)}
</select>
<select value={newReadingCurrency} onChange={event => setNewReadingCurrency(event.target.value as CurrencyCode)} style={styles.input}>
{currencyList.map(c => <option key={c} value={c}>{c}</option>)}
</select>
</div>
{(() => { const t=(Array.isArray(readingTypes)?readingTypes:initialReadingTypes).find(x=>x.id===selectedReadingTypeId); const price=readingPrice(t,newReadingCurrency); const unit=t && t.questions>1 ? Number((price / t.questions).toFixed(2)) : price; return <div style={styles.infoBox}>💰 {t && t.questions > 1 ? `Pacote de ${t.questions} perguntas: ${formatForeign(price,newReadingCurrency)} no total · ${formatForeign(unit,newReadingCurrency)} por pergunta` : `Pergunta individual: ${formatForeign(price,newReadingCurrency)}`}</div>; })()}
<section style={{...styles.infoBox,marginTop:10,border:"1px solid #e6bfd5"}}>
  <label style={{display:"flex",alignItems:"center",gap:8,fontWeight:850}}>
    <input type="checkbox" checked={preWorkReadingEnabled} onChange={e=>{setPreWorkReadingEnabled(e.target.checked); if(!e.target.checked) setPreWorkReadingWorkTypeId("");}} />
    🔮 Leitura pré-trabalho
  </label>
  {preWorkReadingEnabled && <div style={{display:"grid",gap:8,marginTop:10}}>
    <label style={styles.label}>Trabalho da leitura</label>
    <select value={preWorkReadingWorkTypeId} onChange={e=>setPreWorkReadingWorkTypeId(e.target.value)} style={styles.input}>
      <option value="">Selecione o trabalho...</option>
      {workTypes.filter(x=>x.active).map(work=><option key={work.id} value={work.id}>{work.name}</option>)}
    </select>
    <div style={styles.muted}>A leitura ficará vinculada ao trabalho escolhido. Depois você poderá criar o orçamento/trabalho a partir deste vínculo.</div>
  </div>}
  {relatedReadingEnabled && <div style={{display:"grid",gap:8,marginTop:10}}>
    <label style={styles.label}>Trabalho desta consulente</label>
    <select value={relatedReadingWorkId} onChange={e=>setRelatedReadingWorkId(e.target.value)} style={styles.input}>
      <option value="">Selecione o trabalho...</option>
      {getClientWorkOptions(selectedClientId).map(work=><option key={work.id} value={work.id}>{work.title} · {formatDate(work.createdAt)}</option>)}
    </select>
    {relatedReadingWorkId && (()=>{ const work=getClientWorkOptions(selectedClientId).find(x=>x.id===relatedReadingWorkId); const stats=work?getWorkQuestionStats(work.id):{total:0,paid:0,courtesy:0,benefitUsed:false}; return <div style={{background:"#fff",borderRadius:12,padding:10,border:"1px solid #ead9e2"}}>
      <strong>📌 {work?.title || "Trabalho"}</strong>
      <div style={styles.muted}>Perguntas já feitas: {stats.total} · pagas: {stats.paid} · cortesias extras: {stats.courtesy}</div>
      <div style={{marginTop:6,fontWeight:800}}>{stats.benefitUsed ? "🟢 Pergunta gratuita do trabalho já utilizada." : "🎁 A primeira pergunta deste trabalho ainda está disponível gratuitamente."}</div>
    </div>; })()}
    {getClientWorkOptions(selectedClientId).length===0 && <div style={styles.muted}>Esta consulente ainda não possui trabalhos registrados.</div>}
  </div>}
</section>
</div>
)}
<section style={{...styles.infoBox,display:"grid",gap:8,marginTop:10}}><label style={styles.label}>Prioridade (1 = menor · 5 = máxima)</label><select value={newServicePriority} onChange={e=>setNewServicePriority(Math.min(5,Math.max(1,Number(e.target.value)||3)))} style={styles.input}>{[5,4,3,2,1].map(n=><option key={n} value={n}>{n}{n===5?" · Máxima":n>=4?" · Alta":n===3?" · Média":" · Baixa"}</option>)}</select><div style={styles.muted}>A prioridade será usada no topo de Prioridades e na Agenda quando este registro tiver data agendada.</div></section>
<div style={styles.compactActionGrid}>
<button type="button" style={styles.compactActionCard} onClick={() => setShowIntakeModal(true)}>
<span style={styles.compactActionIcon}>📎</span><strong>Informações recebidas</strong><span>{intakeNotes || intakePhotos.length || intakeAudios.length ? `${intakePhotos.length} foto(s) · ${intakeAudios.length} áudio(s) · ${intakeNotes ? "texto salvo" : ""}` : "Cadastrar informações"}</span>
</button>
<button type="button" style={styles.compactActionCard} onClick={() => setShowScheduleModal(true)}>
<span style={styles.compactActionIcon}>📅</span><strong>Agendar atendimento</strong><span>{newScheduledDate && newScheduledTime ? `${formatDate(newScheduledDate)} · ${newScheduledTime}` : "Definir data e horário"}</span>
</button>
</div>
<label style={styles.label}>{newServiceType === "consultation" ? "Título do atendimento" : "Título / identificação"}</label>
<input value={newTitle} onChange={event => setNewTitle(event.target.value)} placeholder={newServiceType === "consultation" ? "Ex.: Amor, trabalho, caminho..." : "Identificação do registro"} style={styles.input} />
{newServiceType === "consultation" ? <div style={styles.infoBox}>💰 O valor e o pagamento serão definidos somente no final, ao encerrar o atendimento.</div> : <><section style={styles.card}><div style={styles.eyebrow}>COBRANÇA</div><label style={styles.label}>Valor</label><input type="number" min="0" value={serviceValue} onChange={e=>setServiceValue(e.target.value)} style={styles.input}/><label style={styles.label}>Moeda</label><select value={serviceCurrency} onChange={e=>{const c=e.target.value as CurrencyCode;setServiceCurrency(c);if(newServiceType==="work"){const w=workTypes.find(x=>x.id===selectedWorkTypeId);const price=workPrice(w,c);if(c==="BRL")setServiceValue(String(price));else setServiceForeignAmount(String(price));}if(newServiceType==="sale"){const item=saleItems.find(x=>x.id===selectedSaleItemId);const price=salePrice(item,c);if(c==="BRL")setServiceValue(String(price));else setServiceForeignAmount(String(price));}}} style={styles.input}>{(["BRL","EUR","USD","GBP"] as CurrencyCode[]).map(c=><option key={c} value={c}>{c}</option>)}</select>{serviceCurrency !== "BRL" && <><label style={styles.label}>Valor na moeda escolhida</label><input type="number" min="0" value={serviceForeignAmount} onChange={e=>setServiceForeignAmount(e.target.value)} style={styles.input}/><div style={styles.infoBox}>{serviceForeignAmount ? `${currencySymbol(serviceCurrency)} ${serviceForeignAmount} ≈ ${formatMoney((Number(String(serviceForeignAmount).replace(",","."))||0)*(currencyRates[serviceCurrency]||0))}` : "Informe o valor na moeda escolhida."}</div></>}<label style={styles.label}>Pagamento</label><select value={servicePaymentMode} onChange={e=>{const mode=e.target.value as any;setServicePaymentMode(mode);if(mode==="installments"){const total=serviceCurrency==="BRL"?(Number(String(serviceValue).replace(",","."))||0):(Number(String(serviceForeignAmount).replace(",","."))||0)*(currencyRates[serviceCurrency]||0);rebuildServiceInstallmentRows(serviceInstallmentCount,serviceInstallmentFirstDate||servicePaymentDate,total,true);}}} style={styles.input}><option value="paid">Pago</option><option value="pending">Não pago</option><option value="installments">Parcelado</option><option value="free">Grátis</option></select>{servicePaymentMode !== "free" && <><label style={styles.label}>Forma de pagamento</label><select value={servicePaymentMethod} onChange={e=>setServicePaymentMethod(e.target.value as PaymentMethod)} style={styles.input}>{(["pix","credit","debit","cash","transfer","paypal","wise","other"] as PaymentMethod[]).map(m=><option key={m} value={m}>{m}</option>)}</select></>}{servicePaymentMode === "pending" && <><label style={styles.label}>Vencimento</label><input type="date" value={servicePaymentDate} onChange={e=>setServicePaymentDate(e.target.value)} style={styles.input}/></>}{servicePaymentMode === "installments" && <div style={{display:"grid",gap:8,marginTop:8}}><label style={styles.label}>Número de parcelas</label><input type="number" min="2" value={serviceInstallmentCount} onChange={e=>{setServiceInstallmentCount(e.target.value);const total=serviceCurrency==="BRL"?(Number(String(serviceValue).replace(",","."))||0):(Number(String(serviceForeignAmount).replace(",","."))||0)*(currencyRates[serviceCurrency]||0);rebuildServiceInstallmentRows(e.target.value,serviceInstallmentFirstDate||servicePaymentDate,total,true);}} style={styles.input}/><label style={styles.label}>Primeiro vencimento</label><input type="date" value={serviceInstallmentFirstDate} onChange={e=>updateServiceInstallmentFirstDate(e.target.value)} style={styles.input}/><label style={{display:"flex",alignItems:"center",gap:8,marginTop:8}}><input type="checkbox" checked={serviceInstallmentEntry} onChange={e=>{const enabled=e.target.checked;setServiceInstallmentEntry(enabled);if(serviceInstallmentRows.length){if(enabled){setServiceEntryAmount(serviceInstallmentRows[0].amount);setServiceInstallmentRows(prev=>prev.map((row,i)=>i===0?{...row,status:"received"}:row));}else{setServiceInstallmentRows(prev=>prev.map((row,i)=>i===0?{...row,status:"pending"}:row));}}}}/> Primeira parcela como entrada paga</label>{serviceInstallmentEntry&&<><label style={styles.label}>Valor da entrada</label><input type="number" min="0" step="0.01" value={serviceEntryAmount} onChange={e=>{setServiceEntryAmount(e.target.value);setServiceInstallmentRows(prev=>prev.map((row,i)=>i===0?{...row,amount:e.target.value,status:"received"}:row));}} style={styles.input}/></>}<div style={{...styles.infoBox,display:"grid",gap:8}}><strong>Parcelas — configure cada uma</strong>{serviceInstallmentRows.map((row,index)=><div key={row.id} className="installment-edit-row"><strong>#{index+1}</strong><input type="number" min="0" step="0.01" value={row.amount} onChange={e=>setServiceInstallmentRows(prev=>prev.map(x=>x.id===row.id?{...x,amount:e.target.value}:x))} style={styles.input}/><input type="date" value={row.dueDate} onChange={e=>setServiceInstallmentRows(prev=>prev.map(x=>x.id===row.id?{...x,dueDate:e.target.value}:x))} style={styles.input}/></div>)}<div style={styles.muted}>Valores livres por parcela. O sistema não divide nem altera o que você configurar. Total: {formatMoney(serviceInstallmentRows.reduce((sum,row)=>sum+(Number(String(row.amount).replace(",","."))||0),0))}.</div></div></div>}{(servicePaymentMethod === "paypal" || servicePaymentMethod === "wise") && <div style={styles.infoBox}>Taxa: {getFeePercent(servicePaymentMethod).toFixed(2)}% · líquido estimado: {formatMoney(Math.max(0, ((serviceCurrency === "BRL" ? (Number(String(serviceValue).replace(",","."))||0) : (Number(String(serviceForeignAmount).replace(",","."))||0)*(currencyRates[serviceCurrency]||0))) * (1-getFeePercent(servicePaymentMethod)/100)))}</div>}</section><section style={styles.card}><div style={styles.eyebrow}>REGISTRO</div><label style={styles.label}>Observações</label><textarea value={serviceNotes} onChange={e=>setServiceNotes(e.target.value)} style={{...styles.input,minHeight:100}}/><div style={styles.compactActionGrid}><button type="button" style={styles.compactActionCard} onClick={()=>takeNativePhoto("service")}>📷 <strong>Tirar foto</strong><span>{servicePhotos.length} foto(s)</span></button><label style={styles.compactActionCard}><span style={styles.compactActionIcon}>🖼️</span><strong>Galeria</strong><span>Escolher foto(s) do celular</span><input type="file" accept="image/*" multiple hidden onChange={addServicePhotos}/></label><div style={styles.compactActionCard}><span style={styles.compactActionIcon}>🎙️</span><strong>Gravar áudio</strong><span>{serviceAudios.length} áudio(s)</span><button type="button" style={styles.smallButton} onClick={() => handleOpenAudioRecorderClick({kind:"service"})}>🎙️ Abrir gravador</button></div></div>{servicePhotos.length>0&&<div style={{marginTop:10}}><div style={styles.eyebrow}>FOTOS SELECIONADAS</div><div className="photoGrid" style={styles.photoGrid}>{servicePhotos.map((photo,index)=><div key={photo.id} style={{position:"relative"}}><button type="button" onClick={()=>setSelectedServicePhotoId(photo.id)} style={{border:0,background:"transparent",padding:0,textAlign:"left",cursor:"pointer",width:"100%"}}><div style={styles.photoThumbCard}><img src={photo.data} alt={photo.name} style={styles.photoThumb}/><div style={styles.photoThumbFooter}><strong>Foto {index+1}</strong><span>🔎 Abrir</span></div></div></button><button type="button" aria-label="Excluir foto" style={{position:"absolute",top:5,right:5,width:30,height:30,border:0,borderRadius:"50%",background:"rgba(180,40,90,.92)",color:"#fff",fontWeight:900,cursor:"pointer"}} onClick={()=>deleteDraftServicePhoto(photo.id)}>×</button></div>)}</div></div>}
{newServiceType === "work" && <section style={{...styles.card,display:"grid",gap:10,marginTop:10}}><div className="checkoutSectionTitle" style={styles.eyebrow}>📦 OBJETOS / MATERIAIS DO TRABALHO</div><button type="button" className="checkboxItem object-checkbox-card" aria-pressed={serviceReceivedObjects.length>0} onClick={()=>{setObjectDraftName("");setObjectDraftValue("");setObjectDraftNotes("");const c=clients.find(x=>x.id===selectedClientId);setObjectAddress("");setObjectPostalCode("");setObjectCountry("Brasil");setObjectModalContext("service");setObjectModalKind("received");}}><span className="fake-checkbox" aria-hidden="true">{serviceReceivedObjects.length>0?"✓":""}</span><span>A cliente enviou algo para o trabalho</span></button>{serviceReceivedObjects.length>0&&<div style={styles.list}>{serviceReceivedObjects.map(x=><div key={x.id} style={styles.listItem}><div><strong>📥 {x.name}</strong>{x.referenceValue?<div style={styles.muted}>Valor de referência: {formatMoney(x.referenceValue)}</div>:null}{x.notes?<div style={styles.muted}>{x.notes}</div>:null}</div><button type="button" style={styles.deleteButton} onClick={()=>removeServiceObject("received",x.id)}>×</button></div>)}</div>}<button type="button" className="checkboxItem object-checkbox-card" aria-pressed={serviceSentObjects.length>0} onClick={()=>{setObjectDraftName("");setObjectDraftValue("");setObjectDraftNotes("");const c=clients.find(x=>x.id===selectedClientId);setObjectAddress(clientAddressText(c));setObjectPostalCode(clientPostalCodeText(c));setObjectCountry(c?.address?.country || c?.country || "Brasil");setObjectModalContext("service");setObjectModalKind("sent");}}><span className="fake-checkbox" aria-hidden="true">{serviceSentObjects.length>0?"✓":""}</span><span>Eu enviei alguma coisa para a cliente</span></button>{serviceSentObjects.length>0&&<div style={styles.list}>{serviceSentObjects.map(x=><div key={x.id} style={styles.listItem}><div><strong>📤 {x.name}</strong>{x.referenceValue?<div style={styles.muted}>Valor de referência: {formatMoney(x.referenceValue)} · não é cobrança separada</div>:null}{x.notes?<div style={styles.muted}>{x.notes}</div>:null}</div><button type="button" style={styles.deleteButton} onClick={()=>removeServiceObject("sent",x.id)}>×</button></div>)}</div>}</section>}
<label style={styles.label}>Orçamento vinculado</label><select value={serviceBudgetId} onChange={e=>setServiceBudgetId(e.target.value)} style={styles.input}><option value="">Nenhum</option>{budgets.filter(b=>b.clientId===selectedClientId).map(b=><option key={b.id} value={b.id}>{b.title} · {formatMoney(b.value)}</option>)}</select>{newServiceType === "sale" && <section style={{...styles.card,display:"grid",gap:10}}><div className="checkoutSectionTitle" style={styles.eyebrow}>🛍️ PRODUÇÃO DA VENDA</div><label className="checkboxItem"><input type="checkbox" checked={serviceNeedsConfection} onChange={e=>setServiceNeedsConfection(e.target.checked)}/> Esta venda precisa de confecção?</label>{serviceNeedsConfection && <div style={styles.infoBox}>A venda ficará em <strong>Aguardando confecção</strong>. Depois de marcar como confeccionada, ela seguirá automaticamente para a próxima etapa.</div>}<div className="checkoutSectionTitle" style={styles.eyebrow}>📦 ENVIO / ENTREGA</div><label className={"checkboxItem"}><input type="checkbox" checked={serviceShippingEnabled} onChange={e=>{const enabled=e.target.checked;setServiceShippingEnabled(enabled);if(enabled)prefillServiceShippingFromClient(selectedClientId);}}/> Esta venda precisa de envio/entrega</label>{serviceShippingEnabled && <div style={{display:"grid",gap:10,marginTop:10}}><label style={styles.label}>Tipo de envio</label><select value={serviceShippingMethod} onChange={e=>setServiceShippingMethod(e.target.value as any)} style={styles.input}><option value="uber">🛵 Uber / entrega</option><option value="correios">📮 Correios</option><option value="retirada">🏠 Retirada com vocês</option><option value="outro">📦 Outro</option></select><div style={styles.twoColumns}><div><label style={styles.label}>Data/hora do envio</label><input type="datetime-local" value={serviceShippingScheduledAt} onChange={e=>setServiceShippingScheduledAt(e.target.value)} style={styles.input}/></div><div><label style={styles.label}>Valor do frete cobrado</label><input type="number" min="0" step="0.01" value={serviceShippingMethod==="uber"?serviceShippingUber:serviceShippingCorreios} onChange={e=>serviceShippingMethod==="uber"?setServiceShippingUber(e.target.value):setServiceShippingCorreios(e.target.value)} style={styles.input}/></div></div><div className="twoColumns"><div><label style={styles.label}>Nome para entrega</label><input value={serviceShippingRecipientName} onChange={e=>setServiceShippingRecipientName(e.target.value)} style={styles.input}/></div><div><label style={styles.label}>Telefone</label><input value={serviceShippingPhone} onChange={e=>setServiceShippingPhone(e.target.value)} style={styles.input}/></div></div><label style={styles.label}>Endereço</label><input value={serviceShippingAddress} onChange={e=>setServiceShippingAddress(e.target.value)} placeholder="Rua, número, complemento" style={styles.input}/><div className="twoColumns"><input value={serviceShippingZipCode} onChange={e=>setServiceShippingZipCode(e.target.value)} placeholder="CEP" style={styles.input}/><input value={serviceShippingCity} onChange={e=>setServiceShippingCity(e.target.value)} placeholder="Cidade" style={styles.input}/></div><input value={serviceShippingState} onChange={e=>setServiceShippingState(e.target.value)} placeholder="Estado" style={styles.input}/>{serviceShippingMethod === "uber" && <div style={{padding:12,borderRadius:14,background:"#fff8e8",border:"1px solid #f0d89a"}}><label className="checkboxItem"><input type="checkbox" checked={serviceShippingUberSpent} onChange={e=>{setServiceShippingUberSpent(e.target.checked);if(e.target.checked&&!serviceShippingUberSpentAmount)setServiceShippingUberSpentAmount(serviceShippingUber);}}/> Eu realmente gastei com Uber</label>{serviceShippingUberSpent && <><label style={styles.label}>Valor realmente gasto no Uber</label><input type="number" min="0" step="0.01" value={serviceShippingUberSpentAmount} onChange={e=>setServiceShippingUberSpentAmount(e.target.value)} style={styles.input}/><div style={styles.muted}>Se você cobrou o frete mas não gastou com Uber, deixe a caixa desmarcada: o frete continua como entrada e não vira despesa.</div></>}</div>}<div style={styles.infoBox}>O frete cobrado entra no valor da venda. O Uber só entra como saída financeira quando “Eu realmente gastei com Uber” estiver marcado.</div></div>}</section>}{serviceShippingEnabled && serviceShippingMethod === "correios" && <input type="hidden" value={serviceShippingCorreios} readOnly/>}</section></>}
<button style={styles.primaryButtonLarge} onClick={createConsultation}>{newServiceType === "consultation" ? "Iniciar atendimento" : newServiceType === "work" ? "Cadastrar trabalho" : "Registrar venda"}</button>
<button style={styles.secondaryButtonLarge} onClick={() => setShowNewConsultation(false)}>Cancelar</button>
</Modal>
)}
{showIntakeModal && (
<Modal title={intakeEditingExisting ? "Editar informações recebidas" : "Informações recebidas"} onClose={() => { setShowIntakeModal(false); setIntakeEditingExisting(false); }}>
<div style={styles.infoBox}>Cadastre aqui, uma única vez, tudo que foi recebido antes do atendimento. Isso ficará anexado ao histórico do consulente.</div>
<label style={styles.label}>Texto / contexto recebido</label>
<textarea value={intakeNotes} onChange={event => setIntakeNotes(event.target.value)} placeholder="Textos, contexto do WhatsApp e observações importantes..." style={{ ...styles.input, minHeight: 170 }} />
<div style={styles.compactActionGrid}>
<button type="button" style={styles.compactActionCard} onClick={() => takeNativePhoto("intake")}><span style={styles.compactActionIcon}>📷</span><strong>Tirar foto</strong><span>Usar a câmera</span></button>
<label style={styles.compactActionCard}><span style={styles.compactActionIcon}>🖼️</span><strong>Adicionar print/foto</strong><span>{intakePhotos.length} arquivo(s)</span><input type="file" accept="image/*" multiple hidden onChange={addIntakePhotos} /></label>
<div style={styles.compactActionCard}><span style={styles.compactActionIcon}>🎙️</span><strong>Gravar áudio</strong><span>{intakeAudios.length} áudio(s) anexado(s)</span><button type="button" style={styles.smallButton} onClick={() => handleOpenAudioRecorderClick({kind:"intake"})}>🎙️ Abrir gravador</button></div>
<label style={styles.compactActionCard}><span style={styles.compactActionIcon}>🎧</span><strong>Adicionar áudio</strong><span>{intakeAudios.length} arquivo(s)</span><input type="file" accept="audio/*" multiple hidden onChange={addIntakeAudios} /></label>
</div>
{recording && <div style={{display:"flex",gap:8,flexWrap:"wrap"}}><button type="button" style={styles.smallButton} onClick={recordingPaused?resumeRecording:pauseRecording}>{recordingPaused?"▶ Retomar":"⏸ Pausar"}</button><button type="button" style={styles.primaryButtonLarge} onClick={stopRecording}>⏹ Finalizar e salvar</button></div>}
{intakePhotos.length>0&&<div className="photoGrid" style={styles.photoGrid}>{intakePhotos.map((photo,index)=><button type="button" key={photo.id} onClick={()=>setSelectedIntakePhotoId(photo.id)} style={{border:0,background:"transparent",padding:0,textAlign:"left",cursor:"pointer"}}><div style={styles.photoThumbCard}><img src={photo.data} alt={photo.name} style={styles.photoThumb}/><div style={styles.photoThumbFooter}><strong>Foto {index+1}</strong><span>🔎 Abrir</span></div></div></button>)}</div>}
{intakeAudios.length>0&&<div style={{display:"grid",gap:8}}>{intakeAudios.map(audio=><div key={audio.id} style={styles.listItem}><AudioPlayer audio={audio} /><button type="button" style={styles.deleteButton} onClick={()=>setIntakeAudios(prev=>prev.filter(x=>x.id!==audio.id))}>Excluir</button></div>)}</div>}
{(intakePhotos.length > 0 || intakeAudios.length > 0) && <div style={styles.infoBox}>{intakePhotos.length} foto(s) e {intakeAudios.length} áudio(s) anexados. Toque na miniatura para ampliar e salvar.</div>}
<button style={styles.primaryButtonLarge} onClick={saveIntakeModal}>✓ Salvar informações</button>
</Modal>
)}
{showScheduleModal && (
<Modal title="Agendar atendimento" onClose={() => setShowScheduleModal(false)}>
<div style={styles.infoBox}>Escolha a data e o horário. O atendimento será salvo como agendado e aparecerá na Agenda e nos próximos agendamentos da tela inicial.</div>
<label style={styles.label}>Consulente (opcional)</label>
<div className="twoColumns"><select value={selectedClientId} onChange={event => setSelectedClientId(event.target.value)} style={styles.input}>
<option value="">Nenhuma consulente vinculada</option>
{clients.map(client => <option key={client.id} value={client.id}>{client.name}</option>)}
</select><button type="button" style={styles.smallButton} onClick={()=>{setEditingClientId(null);setNewClientName("");setNewClientPhone("");setNewClientBirthDate("");setNewClientCPF("");setNewClientStreet("");setNewClientNumber("");setNewClientComplement("");setNewClientNeighborhood("");setNewClientCity("");setNewClientState("");setNewClientPostalCode("");setNewClientCountry("");setNewClientNotes("");setNewClientSource("instagram");setNewClientReferrerId("");setNewClientSourceDetails("");setReturnToAgendaClientContext("schedule");setShowNewClient(true);}}>＋ Novo contato</button></div>
<label style={styles.label}>Data</label>
<input type="date" value={newScheduledDate} onChange={event => setNewScheduledDate(event.target.value)} style={styles.input} />
<label style={styles.label}>Horário</label>
<input type="time" value={newScheduledTime} onChange={event => setNewScheduledTime(event.target.value)} style={styles.input} />
<label style={styles.checkboxItem}><input type="checkbox" defaultChecked /> Exibir lembrete na agenda</label>
<button style={styles.primaryButtonLarge} onClick={saveConsultationSchedule}>✓ Salvar agendamento</button>
<button style={styles.secondaryButtonLarge} onClick={() => { setNewScheduledDate(""); setNewScheduledTime(""); setShowScheduleModal(false); }}>Limpar agendamento</button>
</Modal>
)}
{showEditConsultation && (
<Modal title="Editar atendimento" onClose={() => { setShowEditConsultation(false); setEditingConsultationId(null); }}>
<div style={styles.infoBox}>Corrija o atendimento sem apagar perguntas, fotos ou áudios. Você pode alterar o que foi feito, o preço e a situação do pagamento.</div>
<label style={styles.label}>O que foi feito / título do atendimento</label>
<input value={editConsultationTitle} onChange={event => setEditConsultationTitle(event.target.value)} style={styles.input} />
<label style={styles.label}>{consultations.find(x=>x.id===editingConsultationId)?.serviceType === "work" ? "Valor do trabalho" : "Valor do atendimento"}</label>
<input type="number" min="0" step="0.01" value={editConsultationValue} onChange={event => setEditConsultationValue(event.target.value)} style={styles.input} />
<label style={styles.label}>Observações / o que foi realizado</label>
<textarea value={editConsultationNotes} onChange={event => setEditConsultationNotes(event.target.value)} placeholder="Corrija ou complemente o que foi feito no atendimento..." style={{ ...styles.input, minHeight: 120 }} />
<label style={styles.checkboxItem}><input type="checkbox" checked={editConsultationPaid} onChange={event => setEditConsultationPaid(event.target.checked)} /> Atendimento pago</label>
{editConsultationPaid && <>
<label style={styles.label}>Data do pagamento</label>
<input type="date" value={editConsultationPaymentDate} onChange={event => setEditConsultationPaymentDate(event.target.value)} style={styles.input} />
</>}
<button style={styles.primaryButtonLarge} onClick={saveEditedConsultation}>✓ Salvar alterações</button>
<button style={styles.secondaryButtonLarge} onClick={() => { setShowEditConsultation(false); setEditingConsultationId(null); }}>Cancelar</button>
</Modal>
)}
{showRelatedActivity && <Modal title="Nova atividade vinculada ao trabalho" onClose={()=>setShowRelatedActivity(false)}><div style={styles.infoBox}>Esta atividade ficará presa ao trabalho e aparecerá no histórico do consulente e no registro do dia.</div><label style={styles.label}>Tipo</label><div style={styles.segmented}><button style={{...styles.segmentButton,...(relatedActivityType==="reading"?styles.segmentActive:{})}} onClick={()=>setRelatedActivityType("reading")}>🔮 Tiragem</button><button style={{...styles.segmentButton,...(relatedActivityType==="work_done"?styles.segmentActive:{})}} onClick={()=>setRelatedActivityType("work_done")}>✨ Trabalho realizado</button><button style={{...styles.segmentButton,...(relatedActivityType==="free_support"?styles.segmentActive:{})}} onClick={()=>setRelatedActivityType("free_support")}>🎁 Suporte grátis</button></div><label style={styles.label}>Descrição</label><input value={relatedTitle} onChange={e=>setRelatedTitle(e.target.value)} style={styles.input} placeholder="Ex.: Tiragem de acompanhamento"/>{relatedActivityType !== "free_support" && <><label style={styles.label}>Valor cobrado</label><input type="number" min="0" step="0.01" value={relatedValue} onChange={e=>setRelatedValue(e.target.value)} style={styles.input}/></>}<label style={styles.label}>Valor que seria cobrado (para controle de desfalque)</label><input type="number" min="0" step="0.01" value={relatedPotentialValue} onChange={e=>setRelatedPotentialValue(e.target.value)} placeholder="Opcional" style={styles.input}/>{relatedActivityType !== "free_support" && <><label style={styles.checkboxItem}><input type="checkbox" checked={relatedPaid} onChange={e=>setRelatedPaid(e.target.checked)}/> Pago</label><label style={styles.label}>Forma de pagamento</label><select value={relatedPaymentMethod} onChange={e=>setRelatedPaymentMethod(e.target.value as PaymentMethod)} style={styles.input}><option value="pix">Pix</option><option value="paypal">PayPal</option><option value="wise">Wise</option><option value="cash">Dinheiro</option><option value="credit">Cartão de crédito</option><option value="debit">Cartão de débito</option><option value="transfer">Transferência</option><option value="other">Outra</option></select></>}<button style={styles.primaryButtonLarge} onClick={saveRelatedActivity}>✓ Registrar atividade</button><button style={styles.secondaryButtonLarge} onClick={()=>setShowRelatedActivity(false)}>Cancelar</button></Modal>}
{/* =====================================================
NOVO CLIENTE
===================================================== */}
{showNewClient && (
<Modal
title={editingClientId ? "Editar consulente" : "Novo consulente"}
onClose={() => {
setShowNewClient(false);
setEditingClientId(null);
}}
>
<label
style={styles.label}
>
Nome
</label>
<input
value={
newClientName
}
onChange={(event) =>
setNewClientName(
event.target.value
)
}
placeholder="Nome do consulente"
style={styles.input}
/>
<label
style={styles.label}
>
Telefone / WhatsApp
</label>
<input
value={
newClientPhone
}
onChange={(event) =>
setNewClientPhone(
event.target.value
)
}
placeholder="(00) 00000-0000"
style={styles.input}
/>
<label style={styles.label}>Data de nascimento</label><input type="date" value={newClientBirthDate} onChange={e=>setNewClientBirthDate(e.target.value)} style={styles.input}/><label style={styles.label}>CPF / documento (opcional)</label><input value={newClientCPF} onChange={e=>setNewClientCPF(e.target.value)} placeholder="CPF ou documento" style={styles.input}/>
<section style={{...styles.infoBox,display:"grid",gap:8}}><strong>📍 Endereço cadastrado</strong><div className="twoColumns"><input value={newClientStreet} onChange={e=>setNewClientStreet(e.target.value)} placeholder="Rua / endereço" style={styles.input}/><input value={newClientNumber} onChange={e=>setNewClientNumber(e.target.value)} placeholder="Número" style={styles.input}/></div><input value={newClientComplement} onChange={e=>setNewClientComplement(e.target.value)} placeholder="Complemento" style={styles.input}/><input value={newClientNeighborhood} onChange={e=>setNewClientNeighborhood(e.target.value)} placeholder="Bairro / região" style={styles.input}/><div className="twoColumns"><input value={newClientCity} onChange={e=>setNewClientCity(e.target.value)} placeholder="Cidade" style={styles.input}/><input value={newClientState} onChange={e=>setNewClientState(e.target.value)} placeholder="Estado / província" style={styles.input}/></div><input value={newClientPostalCode} onChange={e=>setNewClientPostalCode(e.target.value)} placeholder="CEP / código postal" style={styles.input}/><div style={styles.muted}>Aceita CEP brasileiro e códigos postais de outros países.</div></section>
<label style={styles.label}>Origem do contato</label>
<select value={newClientSource} onChange={e=>setNewClientSource(e.target.value as ClientSource)} style={styles.input}>
<option value="indication">🤝 Indicação</option><option value="instagram">📸 Instagram</option><option value="facebook">📘 Facebook / perfil</option><option value="facebook_comment">💬 Comentário no Facebook</option><option value="search">🔎 Pesquisa / encontrou o perfil</option><option value="whatsapp">💬 WhatsApp</option><option value="content">📝 Conteúdo / postagem</option><option value="active_prospecting">🎯 Prospecção ativa</option><option value="other">Outro</option>
</select>
{newClientSource === "indication" && <><label style={styles.label}>Indicado por qual consulente?</label><select value={newClientReferrerId} onChange={e=>setNewClientReferrerId(e.target.value)} style={styles.input}><option value="">Selecione...</option>{clients.filter(c=>c.id!==editingClientId).map(c=><option key={c.id} value={c.id}>{c.name}</option>)}</select></>}
<label style={styles.label}>Detalhe da origem (opcional)</label><input value={newClientSourceDetails} onChange={e=>setNewClientSourceDetails(e.target.value)} placeholder="Ex.: comentário no post de proteção" style={styles.input}/>
<label style={styles.label}>País do consulente</label>
<div style={styles.muted}>Detectado automaticamente pelo DDI quando possível. Você pode alterar manualmente (ex.: WhatsApp com número brasileiro).</div>
<select value={newClientCountry} onChange={e=>setNewClientCountry(e.target.value)} style={styles.input}>
<option value="">Não informado</option>
{Array.from(new Set(COUNTRY_DDI.map(([,country])=>country))).sort((a,b)=>a.localeCompare(b,"pt-BR")).map(country=><option key={country} value={country}>{country}</option>)}
</select>
<label style={styles.label}>Foto do consulente</label>
<div style={{display:"flex",gap:8,alignItems:"center",flexWrap:"wrap"}}>{clientPhotoDraft ? <img src={clientPhotoDraft} alt="Foto do consulente" style={{width:72,height:72,borderRadius:"50%",objectFit:"cover",border:"2px solid #ead9e2"}} /> : <div style={{...styles.clientAvatar,width:72,height:72,fontSize:26}}>A</div>}<button type="button" style={styles.smallButton} onClick={takeClientProfilePhoto}>📷 Câmera</button><label style={styles.smallButton}>🖼️ Galeria<input type="file" accept="image/*" hidden onChange={chooseClientProfilePhoto}/></label>{clientPhotoDraft&&<button type="button" style={styles.deleteButton} onClick={()=>setClientPhotoDraft("")}>Remover</button>}</div>
<label style={styles.label}>Observações da ficha</label>
<textarea
value={newClientNotes}
onChange={(event) => setNewClientNotes(event.target.value)}
placeholder="Informações importantes sobre o consulente..."
style={styles.textarea}
/>
<button
style={
styles.secondaryButtonLarge
}
onClick={
importContact
}
>
📱Escolher dos contatos
</button>
<button
style={
styles.primaryButtonLarge
}
onClick={
saveClient
}
>
{editingClientId ? "✓ Salvar alterações" : "✓ Salvar consulente"}
</button>
<button
style={
styles.secondaryButtonLarge
}
onClick={() => { setShowNewClient(false); setReturnToNewConsultationAfterClient(false); setReturnToAgendaClientContext(null); }}
>
Cancelar
</button>
</Modal>
)}
{/* =====================================================
COMPRA
===================================================== */}
{showQuickBudgetModal && (
<Modal title="Novo orçamento" onClose={() => setShowQuickBudgetModal(false)}>
<div style={styles.infoBox}>Crie o orçamento diretamente daqui. Ele ficará vinculado ao consulente e aparecerá no histórico.</div>
<label style={styles.label}>Consulente (opcional)</label><select value={budgetClientId} onChange={e=>{const id=e.target.value;setBudgetClientId(id);const c=clients.find(x=>x.id===id);if(c){setBudgetShippingRecipientName(c.name);setBudgetShippingPhone(c.phone||"");setBudgetShippingAddress(clientAddressText(c));setBudgetShippingZipCode(clientPostalCodeText(c));setBudgetShippingCity(c.address?.city||"");setBudgetShippingState(c.address?.state||"");}}} style={styles.input}><option value="">Sem consulente vinculado</option>{clients.map(c=><option key={c.id} value={c.id}>{c.name}</option>)}</select>
<label style={styles.label}>Tipo de serviço</label><select value={budgetServiceType} onChange={e=>setBudgetServiceType(e.target.value as Budget["serviceType"])} style={styles.input}><option value="reading">Tiragem</option><option value="spell">Feitiço</option><option value="work">Trabalho</option><option value="sale">Venda</option><option value="product">Produto</option><option value="other">Outro</option></select>
<label style={styles.label}>Serviço</label><input value={budgetServiceName} onChange={e=>setBudgetServiceName(e.target.value)} style={styles.input} placeholder="Ex.: Feitiço de prosperidade"/>
<label style={styles.label}>Título do orçamento</label><input value={budgetTitle} onChange={e=>setBudgetTitle(e.target.value)} style={styles.input} placeholder="Ex.: Orçamento de prosperidade"/>
<section style={{...styles.infoBox,display:"grid",gap:8}}><strong>🧾 Itens do orçamento</strong>{budgetItems.map((item,idx)=><div key={item.id} style={styles.listItem}><div style={{minWidth:0,flex:1}}><strong>{item.description}</strong><div style={styles.muted}>{item.quantity||1} × {formatMoney(item.unitPrice)} · {item.kind||"outro"}</div></div><button style={styles.deleteButton} onClick={()=>setBudgetItems(prev=>prev.filter((_,i)=>i!==idx))}>×</button></div>)}<div style={styles.twoColumns}><input value={budgetItemDescription} onChange={e=>setBudgetItemDescription(e.target.value)} placeholder="Ex.: Pergunta 1 / pedra / tiragem" style={styles.input}/><input type="number" min="0" step="0.01" value={budgetItemUnitPrice} onChange={e=>setBudgetItemUnitPrice(e.target.value)} placeholder="Valor unitário" style={styles.input}/></div><div style={styles.twoColumns}><select value={budgetItemKind} onChange={e=>setBudgetItemKind(e.target.value as BudgetItem["kind"])} style={styles.input}><option value="question">Pergunta</option><option value="reading">Tiragem</option><option value="work">Trabalho</option><option value="sale">Venda</option><option value="material">Material</option><option value="other">Outro</option></select><input type="number" min="1" step="1" value={budgetItemQuantity} onChange={e=>setBudgetItemQuantity(e.target.value)} placeholder="Qtd." style={styles.input}/></div><button style={styles.smallButton} onClick={()=>{const d=budgetItemDescription.trim();const price=Number(String(budgetItemUnitPrice).replace(",","."))||0;const qty=Math.max(1,Number(budgetItemQuantity)||1);if(!d||price<=0){showToast("Informe descrição e valor do item.");return;}setBudgetItems(prev=>[...prev,{id:makeId(),description:d,kind:budgetItemKind,quantity:qty,unitPrice:price,currency:budgetCurrency}]);setBudgetItemDescription("");setBudgetItemUnitPrice("");setBudgetItemQuantity("1");}}>+ Adicionar item</button><div><strong>Total dos itens: {formatForeign(budgetItems.reduce((sum,i)=>sum+(i.quantity||1)*i.unitPrice,0),budgetCurrency)}</strong></div></section><label style={styles.label}>Descrição</label><textarea value={budgetDescription} onChange={e=>setBudgetDescription(e.target.value)} style={styles.textarea} placeholder="Detalhes do orçamento..."/>
<div style={styles.twoColumns}><div><label style={styles.label}>Valor</label><input type="number" min="0" step="0.01" value={budgetValue} onChange={e=>setBudgetValue(e.target.value)} style={styles.input}/></div><div><label style={styles.label}>Desconto</label><input type="number" min="0" step="0.01" value={budgetDiscount} onChange={e=>setBudgetDiscount(e.target.value)} style={styles.input}/></div></div>
<label style={styles.label}>Acréscimo</label><input type="number" min="0" step="0.01" value={budgetSurcharge} onChange={e=>setBudgetSurcharge(e.target.value)} style={styles.input}/>
<label style={styles.label}>Validade</label><input type="date" value={budgetValidUntil} onChange={e=>setBudgetValidUntil(e.target.value)} style={styles.input}/>
<div style={styles.infoBox}><strong>Valor final:</strong> {formatMoney(Math.max(0,(Number(String(budgetValue).replace(",","."))||0)+(Number(String(budgetSurcharge).replace(",","."))||0)-(Number(String(budgetDiscount).replace(",","."))||0)))}</div>
<label style={styles.label}>Moeda do orçamento</label><select value={budgetCurrency} onChange={e=>setBudgetCurrency(e.target.value as CurrencyCode)} style={styles.input}><option value="BRL">Real (R$)</option><option value="EUR">Euro (€)</option><option value="USD">Dólar ($)</option><option value="GBP">Libra (£)</option></select><section style={{...styles.infoBox,display:"grid",gap:8,marginTop:10}}><strong>💳 Condições de pagamento</strong><label style={styles.label}>Forma</label><select value={budgetPaymentMode} onChange={e=>setBudgetPaymentMode(e.target.value as any)} style={styles.input}><option value="paid">Pago na confirmação</option><option value="pending">Pendente / uma parcela</option><option value="installments">Parcelado</option></select><label style={styles.label}>Método</label><select value={budgetPaymentMethod} onChange={e=>setBudgetPaymentMethod(e.target.value as PaymentMethod)} style={styles.input}>{(["pix","credit","debit","cash","transfer","paypal","wise","other"] as PaymentMethod[]).map(m=><option key={m} value={m}>{m}</option>)}</select>{budgetPaymentMode==="pending"&&<><label style={styles.label}>Vencimento</label><input type="date" value={budgetPaymentDate} onChange={e=>setBudgetPaymentDate(e.target.value)} style={styles.input}/></>}{budgetPaymentMode==="installments"&&<><label style={styles.label}>Número de parcelas</label><input type="number" min="2" value={budgetInstallmentCount} onChange={e=>setBudgetInstallmentCount(e.target.value)} style={styles.input}/><label style={styles.label}>Primeiro vencimento</label><input type="date" value={budgetInstallmentFirstDate} onChange={e=>setBudgetInstallmentFirstDate(e.target.value)} style={styles.input}/><label style={styles.checkboxItem}><input type="checkbox" checked={budgetInstallmentEntry} onChange={e=>setBudgetInstallmentEntry(e.target.checked)}/> Entrada paga agora</label>{budgetInstallmentEntry&&<input type="number" min="0" step="0.01" value={budgetInstallmentEntryAmount} onChange={e=>setBudgetInstallmentEntryAmount(e.target.value)} placeholder="Valor da entrada" style={styles.input}/>}</>}</section>
<label style={styles.checkboxItem}><input type="checkbox" checked={budgetShippingEnabled} onChange={e=>setBudgetShippingEnabled(e.target.checked)}/> Envio necessário</label>
{budgetShippingEnabled && <div style={styles.paymentBox}><label style={styles.label}>Nome para envio</label><input value={budgetShippingRecipientName} onChange={e=>setBudgetShippingRecipientName(e.target.value)} style={styles.input}/><label style={styles.label}>Telefone</label><input value={budgetShippingPhone} onChange={e=>setBudgetShippingPhone(e.target.value)} style={styles.input}/><label style={styles.label}>Endereço</label><input value={budgetShippingAddress} onChange={e=>setBudgetShippingAddress(e.target.value)} style={styles.input}/><div style={styles.twoColumns}><input value={budgetShippingZipCode} onChange={e=>setBudgetShippingZipCode(e.target.value)} placeholder="CEP" style={styles.input}/><input value={budgetShippingCity} onChange={e=>setBudgetShippingCity(e.target.value)} placeholder="Cidade" style={styles.input}/></div><input value={budgetShippingState} onChange={e=>setBudgetShippingState(e.target.value)} placeholder="Estado" style={styles.input}/><div style={styles.twoColumns}><input type="number" min="0" step="0.01" value={budgetShippingUber} onChange={e=>setBudgetShippingUber(e.target.value)} placeholder="Uber" style={styles.input}/><input type="number" min="0" step="0.01" value={budgetShippingCorreios} disabled={budgetShippingCorreiosPending} onChange={e=>setBudgetShippingCorreios(e.target.value)} placeholder="Correios" style={styles.input}/></div><label style={styles.checkboxItem}><input type="checkbox" checked={budgetShippingCorreiosPending} onChange={e=>setBudgetShippingCorreiosPending(e.target.checked)}/> Correios ainda não informado</label></div>}
<button style={styles.primaryButtonLarge} onClick={saveQuickBudget}>✓ Salvar orçamento</button><button style={styles.secondaryButtonLarge} onClick={()=>setShowQuickBudgetModal(false)}>Cancelar</button>
</Modal>
)}
{showQuickIncomeModal && (
<Modal title={quickType === "sale" ? "Venda de feitiço / venda rápida" : "Entrada rápida"} onClose={() => setShowQuickIncomeModal(false)}>
<label style={styles.label}>Destino</label>
<div style={styles.segmented}>
<button style={{...styles.segmentButton, ...(quickArea === "home" ? styles.segmentActive : {})}} onClick={() => setQuickArea("home")}>🏠Casa</button>
<button style={{...styles.segmentButton, ...(quickArea === "work" ? styles.segmentActive : {})}} onClick={() => setQuickArea("work")}>🔮Trabalho</button>
</div>
<label style={styles.label}>Valor</label>
<input type="number" min="0" step="0.01" value={quickAmount} onChange={(e) => setQuickAmount(e.target.value)} placeholder="0,00" style={styles.input} />
<label style={styles.label}>Moeda</label><select value={quickCurrency} onChange={e=>setQuickCurrency(e.target.value as CurrencyCode)} style={styles.input}><option value="BRL">Real (R$)</option><option value="EUR">Euro (€)</option><option value="USD">Dólar ($)</option><option value="GBP">Libra (£)</option></select>
{quickCurrency!=="BRL" && <div style={styles.infoBox}>Valor em reais: {formatMoney((Number(String(quickAmount).replace(",","."))||0)*(currencyRates[quickCurrency]||0))} · Cotação: {currencyRates[quickCurrency]?.toFixed(4)||"—"}</div>}
<label style={styles.label}>Fonte do dinheiro</label>
<input value={quickSource} onChange={(e) => setQuickSource(e.target.value)} placeholder="Ex.: venda, serviço, reembolso..." style={styles.input} />
<label style={styles.label}>Descrição</label>
<input value={quickDescription} onChange={(e) => setQuickDescription(e.target.value)} placeholder="Detalhes opcionais" style={styles.input} />
<label style={styles.label}>Forma de pagamento</label>
<select value={quickPaymentMethod} onChange={(e) => setQuickPaymentMethod(e.target.value as PaymentMethod)} style={styles.input}>
<option value="pix">Pix</option><option value="paypal">PayPal</option><option value="wise">Wise</option><option value="cash">Dinheiro</option><option value="transfer">Transferência</option><option value="credit">Cartão de crédito</option><option value="debit">Cartão de débito</option><option value="combined">Combinado</option><option value="other">Outro</option>
</select>
<label style={styles.label}>Atribuir a consulente (opcional)</label>
<select value={quickClientId} onChange={(e) => setQuickClientId(e.target.value)} style={styles.input}>
<option value="">Nenhum</option>
{clients.map((client) => <option key={client.id} value={client.id}>{client.name}</option>)}
</select>
<button style={styles.primaryButtonLarge} onClick={saveQuickTransaction}>✓ Registrar {quickType === "sale" ? "venda" : "entrada"}</button>
</Modal>
)}
{showQuickExpenseModal && (
<Modal title="Saída rápida" onClose={() => setShowQuickExpenseModal(false)}>
<label style={styles.label}>O que aconteceu?</label>
<div style={styles.segmented}>
<button style={{...styles.segmentButton, ...(quickType === "expense" ?
styles.segmentActive : {})}} onClick={() => setQuickType("expense")}>🔴Despesa</button>
<button style={{...styles.segmentButton, ...(quickType === "sale" ? styles.segmentActive
: {})}} onClick={() => setQuickType("sale")}>🛍️Venda / saiu do estoque</button>
</div>
<label style={styles.label}>1. Casa ou Trabalho</label>
<div style={styles.segmented}>
<button type="button" style={{...styles.segmentButton, ...(quickArea === "home" ? styles.segmentActive : {})}} onClick={() => { setQuickArea("home"); setQuickSupplierId(""); setQuickSource(""); setQuickSectorId(""); setQuickCategoryId(""); }}>🏠 Casa</button>
<button type="button" style={{...styles.segmentButton, ...(quickArea === "work" ? styles.segmentActive : {})}} onClick={() => { setQuickArea("work"); setQuickSupplierId(""); setQuickSource(""); setQuickSectorId(""); setQuickCategoryId(""); }}>🔮 Trabalho</button>
</div>
{quickType === "expense" ? (
<>
<label style={styles.label}>2. Fornecedor / estabelecimento</label>
<select value={quickSupplierId} onChange={(e) => { const id = e.target.value; setQuickSupplierId(id); const supplier = suppliers.find((item) => item.id === id); if (supplier) { setQuickArea(supplier.area); setQuickSource(supplier.name); setQuickSectorId(supplier.sectorId || ""); const firstCategory = supplier.categoryIds?.[0] || ""; setQuickCategoryId(firstCategory); } else { setQuickSource(""); setQuickSectorId(""); setQuickCategoryId(""); } }} style={styles.input}>
<option value="">Selecionar fornecedor cadastrado</option>
{suppliers.filter((supplier) => supplier.active && supplier.area === quickArea).map((supplier) => <option key={supplier.id} value={supplier.id}>{supplier.name}{supplier.sectorId ? ` · ${householdSectors.find((s) => s.id === supplier.sectorId)?.name || ""}` : ""}</option>)}
</select>
<div style={styles.muted}>A lista mostra somente fornecedores cadastrados para {quickArea === "home" ? "Casa" : "Trabalho"}.</div>
<button type="button" style={styles.secondaryButtonLarge} onClick={() => setShowSupplierModal(true)}>+ Cadastrar novo fornecedor</button>
<label style={styles.label}>3. Setor da despesa</label>
<select value={quickSectorId} onChange={(e) => { setQuickSectorId(e.target.value); setQuickCategoryId(""); }} style={styles.input}>
<option value="">Selecionar setor</option>
{householdSectors.filter((item) => item.active).map((sector) => <option key={sector.id} value={sector.id}>{sector.name}</option>)}
</select>
<label style={styles.label}>4. Categoria</label>
<select value={quickCategoryId} onChange={(e) => setQuickCategoryId(e.target.value)} style={styles.input}>
<option value="">Selecionar categoria</option>
{quickCategories.map((category) => <option key={category.id} value={category.id}>{category.name}</option>)}
</select>
{selectedQuickSupplier && selectedQuickSupplier.categoryIds?.length > 0 && (
<div style={styles.infoBox}>Categorias vinculadas a este fornecedor: <strong>{getSupplierCategoriesLabel(selectedQuickSupplier)}</strong></div>
)}
<div style={{ ...styles.cardHeader, marginTop: 14 }}>
<strong>Itens comprados</strong>
<button type="button" style={styles.primaryButton} onClick={addQuickExpenseItem}>+ Item</button>
</div>
{quickExpenseItems.length === 0 ? <div style={styles.emptyBox}>Adicione os produtos comprados para registrar exatamente o que foi gasto.</div> : quickExpenseItems.map((item) => (
<div key={item.id} style={styles.purchaseEditor}>
<input value={item.name} onChange={(e) => updateQuickExpenseItem(item.id, { name: e.target.value })} placeholder="Ex.: arroz, sabão, vela..." style={styles.input} />
<div style={styles.twoColumns}>
<input type="number" min="0.01" step="0.01" value={item.quantity} onChange={(e) => updateQuickExpenseItem(item.id, { quantity: Number(e.target.value) })} placeholder="Qtd." style={styles.input} />
<input value={item.unit} onChange={(e) => updateQuickExpenseItem(item.id, { unit: e.target.value })} placeholder="Unidade" style={styles.input} />
</div>
<div style={styles.twoColumns}>
<input type="number" min="0" step="0.01" value={item.unitPrice} onChange={(e) => updateQuickExpenseItem(item.id, { unitPrice: Number(e.target.value) })} placeholder="Preço unitário" style={styles.input} />
<input value={item.total.toFixed(2)} readOnly placeholder="Total" style={styles.input} />
</div>
<button type="button" style={styles.smallButton} onClick={() => removeQuickExpenseItem(item.id)}>Remover item</button>
</div>
))}
{quickExpenseItems.length > 0 && <div style={{ ...styles.infoBox, marginTop: 10 }}><strong>Total dos itens: {formatMoney(quickExpenseItemsTotal)}</strong></div>}
</>
) : (
<>
<label style={styles.label}>Fonte / descrição da venda</label>
<input value={quickSource} onChange={(e) => setQuickSource(e.target.value)} placeholder="Ex.: venda de colar" style={styles.input} />
</>
)}
<button type="button" style={styles.secondaryButtonLarge} onClick={() => { setShowQuickExpenseModal(false); setShowPurchaseModal(true); }}>🧾 Registrar/consultar compra por NF-e (QR ou chave)</button>
<label style={styles.label}>Descrição</label>
<input value={quickDescription} onChange={(e) => setQuickDescription(e.target.value)}
placeholder="Detalhes opcionais" style={styles.input} />
{quickType === "sale" && (
<>
<label style={styles.label}>Item do estoque</label>
<select value={quickStockItemId} onChange={(e) =>
setQuickStockItemId(e.target.value)} style={styles.input}>
<option value="">Selecione</option>
{stockItems.filter((item) => item.area === quickArea && item.active).map((item) => (
<option key={item.id} value={item.id}>{item.name} — {item.quantity}
{item.unit}</option>
))}
</select>
<label style={styles.label}>Quantidade</label>
<input type="number" min="0.01" step="0.01" value={quickQuantity} onChange={(e) =>
setQuickQuantity(e.target.value)} style={styles.input} />
<label style={styles.label}>Atribuir ao consulente (opcional)</label>
<select value={quickClientId} onChange={(e) => setQuickClientId(e.target.value)}
style={styles.input}>
<option value="">Nenhum</option>
{clients.map((client) => <option key={client.id}
value={client.id}>{client.name}</option>)}
</select>
</>
)}
<button style={styles.primaryButtonLarge} onClick={saveQuickTransaction}>
{quickType === "sale" ? "✓ Registrar venda e dar baixa no estoque" : "✓ Registrar saída"}
</button>
</Modal>
)}
{showQrScanner && (
<Modal title="Ler QR Code da NF-e" onClose={() => { stopQrScanner(); setShowQrScanner(false); }}>
<div style={styles.infoBox}>Aponte a câmera traseira para o QR Code da nota fiscal.</div>
<video ref={qrVideoRef} muted playsInline style={{ width: "100%", borderRadius: 14, marginTop: 12, background: "#111", minHeight: 220 }} />
<div style={{ ...styles.muted, marginTop: 10 }}>Se a câmera não abrir, feche esta janela e cole a URL/chave no campo da NF-e.</div>
</Modal>
)}
{showPurchaseModal && (
<Modal
title={editingPurchaseId ? "Editar compra" : "Registrar compra"}
onClose={() => {
setShowPurchaseModal(false);
setEditingPurchaseId(null);
}}
>
<label
style={styles.label}
>
Estabelecimento
</label>
<select
value={
purchaseSupplierId
}
onChange={(event) => {
const id = event.target.value;
setPurchaseSupplierId(id);
const supplier = suppliers.find((item) => item.id === id);
if (supplier) {
setPurchaseItems((previous) => previous.map((item) => item.name.trim() ? item : { ...item, destination: supplier.area, sectorId: supplier.sectorId || item.sectorId, categoryId: supplier.categoryIds?.[0] || item.categoryId }));
}
}}
style={styles.input}
>
<option value="">
Selecione
</option>
{suppliers.map(
(supplier) => (
<option
key={
supplier.id
}
value={
supplier.id
}
>
{supplier.name}
</option>
)
)}
</select>
<button
style={
styles.secondaryButtonLarge
}
onClick={() => {
setShowPurchaseModal(
false
);
setShowSupplierModal(
true
);
}}
>
+ Novo estabelecimento
</button>
<label
style={styles.label}
>
Data
</label>
<input
type="date"
value={
purchaseDate
}
onChange={(event) =>
setPurchaseDate(
event.target.value
)
}
style={styles.input}
/>
<label
style={styles.label}
>
Origem da compra
</label>
<div
style={
styles.segmented
}
>
<button
style={{
...styles.segmentButton,
...(purchaseSource ===
"manual"
? styles.segmentActive
: {}),
}}
onClick={() =>
setPurchaseSource(
"manual"
)
}
>
Manual
</button>
<button
style={{
...styles.segmentButton,
...(purchaseSource ===
"nfe_qr"
? styles.segmentActive
: {}),
}}
onClick={() =>
setPurchaseSource(
"nfe_qr"
)
}
>
📷QR Code NF-e
</button>
</div>
{purchaseSource ===
"nfe_qr" && (
<>
<label style={styles.label}>QR Code / chave da NF-e</label>
<div style={styles.twoColumns}>
<input value={purchaseQrCode} onChange={(event) => { const value = event.target.value; setPurchaseQrCode(value); setPurchaseAccessKey(extractNfeAccessKey(value)); }} placeholder="Cole o QR Code ou a URL da nota..." style={styles.input} />
<button type="button" style={styles.secondaryButtonLarge} onClick={startQrScanner}>📷 Ler QR pela câmera</button>
</div>
{purchaseQrCode && (
<div style={{ ...styles.infoBox, marginTop: 10 }}>
<div><strong>QR Code registrado.</strong>{purchaseAccessKey ? ` Chave NF-e: ${purchaseAccessKey}` : ""}</div>
<button type="button" style={{ ...styles.smallButton, marginTop: 8 }} onClick={openNfeQr}>Abrir nota no SEFAZ</button>
<div style={{ ...styles.muted, marginTop: 8 }}>A leitura do QR identifica o endereço/chave da nota. A importação automática dos itens da página da SEFAZ depende de uma integração de servidor, porque o navegador não pode ler diretamente uma página externa protegida por CORS. Se a importação não estiver disponível, os itens abaixo continuam cadastráveis manualmente.</div>
</div>
)}
</>
)}
<div
style={
styles.cardHeader
}
>
<div>
<label
style={styles.label}
>
Itens da compra
</label>
</div>
<button
style={
styles.primaryButton
}
onClick={
addPurchaseItem
}
>
+ Item
</button>
</div>
{purchaseItems.length ===
0 ? (
<div
style={
styles.emptyBox
}
>
Adicione os produtos da
compra.
</div>
) : (
<div
style={
styles.itemList
}
>
{purchaseItems.map(
(item) => (
<div
key={item.id}
style={
styles.purchaseEditor
}
>
<input
value={
item.name
}
onChange={(
event
) =>
updatePurchaseItem(
item.id,
{
name:
event
.target
.value,
}
)
}
placeholder="Nome do produto"
style={
styles.input
}
/>
<div
style={
styles.twoColumns
}
>
<div>
<label
style={
styles.label
}
>
Quantidade
</label>
<input
type="number"
min="0"
step="0.01"
value={
item.quantity
}
onChange={(
event
) =>
updatePurchaseItem(
item.id,
{
quantity:
Number(
event
.target
.value
) || 0,
}
)
}
style={
styles.input
}
/>
</div>
<div>
<label
style={
styles.label
}
>
Unidade
</label>
<input
value={
item.unit
}
onChange={(
event
) =>
updatePurchaseItem(
item.id,
{
unit:
event
.target
.value,
}
)
}
style={
styles.input
}
/>
</div>
</div>
<label
style={styles.label}
>
Preço unitário
</label>
<input
type="number"
min="0"
step="0.01"
value={
item.unitPrice
}
onChange={(
event
) =>
updatePurchaseItem(
item.id,
{
unitPrice:
Number(
event
.target
.value
) || 0,
}
)
}
style={
styles.input
}
/>
{item.destination === "home" && (
<>
<label style={styles.label}>Setor</label>
<select value={item.sectorId} onChange={(event) => updatePurchaseItem(item.id, { sectorId: event.target.value, categoryId: "" })} style={styles.input}>
<option value="">Selecione o setor</option>
{householdSectors.filter((sector) => sector.active).map((sector) => <option key={sector.id} value={sector.id}>{sector.name}</option>)}
</select>
<label style={styles.label}>Categoria</label>
<select value={item.categoryId} onChange={(event) => updatePurchaseItem(item.id, { categoryId: event.target.value })} style={styles.input}>
<option value="">Selecione a categoria</option>
{householdCategories.filter((category) => category.active && (!item.sectorId || category.sectorId === item.sectorId)).map((category) => <option key={category.id} value={category.id}>{category.name}</option>)}
</select>
</>
)}
<label
style={styles.label}
>
Destino
</label>
<div
style={
styles.segmented
}
>
<button
style={{
...styles.segmentButton,
...(item.destination ===
"home"
? styles.segmentActive
: {}),
}}
onClick={() =>
updatePurchaseItem(
item.id,
{
destination:
"home",
}
)
}
>
🏠Casa
</button>
<button
style={{
...styles.segmentButton,
...(item.destination ===
"work"
? styles.segmentActive
: {}),
}}
onClick={() =>
updatePurchaseItem(
item.id,
{
destination:
"work",
}
)
}
>
🔮Trabalho
</button>
</div>
<label
style={
styles.checkRow
}
>
<input
type="checkbox"
checked={
item.stockItem
}
onChange={(
event
) =>
updatePurchaseItem(
item.id,
{
stockItem:
event
.target
.checked,
}
)
}
/>
Controlar este item no
estoque
</label>
<div
style={
styles.purchaseEditorFooter
}
>
<strong>
Total:{" "}
{formatMoney(
item.total
)}
</strong>
<button
style={
styles.deleteButton
}
onClick={() =>
removePurchaseItem(
item.id
)
}
>
Excluir
</button>
</div>
</div>
)
)}
</div>
)}
<div
style={
styles.totalBox
}
>
<span>
Total da compra
</span>
<strong>
{formatMoney(
purchaseTotal
)}
</strong>
</div>
<label
style={styles.label}
>
Observações
</label>
<textarea
value={
purchaseNotes
}
onChange={(event) =>
setPurchaseNotes(
event.target.value
)
}
placeholder="Observações..."
style={
styles.textarea
}
/>
<button
style={
styles.primaryButtonLarge
}
onClick={
savePurchase
}
>
{editingPurchaseId ? "✓ Salvar alterações" : "✓ Salvar compra"}
</button>
<button
style={
styles.secondaryButtonLarge
}
onClick={() =>
setShowPurchaseModal(
false
)
}
>
Cancelar
</button>
</Modal>
)}
{/* =====================================================
FORNECEDOR
===================================================== */}
{showSupplierModal && (
<Modal
title="Novo estabelecimento"
onClose={() =>
setShowSupplierModal(
false
)
}
>
<label
style={styles.label}
>
Nome
</label>
<input
value={
supplierName
}
onChange={(event) =>
setSupplierName(
event.target.value
)
}
placeholder="Ex.: Magnânimo"
style={styles.input}
/>
<label
style={styles.label}
>
Tipo
</label>
<select
value={
supplierType
}
onChange={(event) =>
setSupplierType(
event.target
.value as SupplierType
)
}
style={styles.input}
>
<option value="market">
Mercado
</option>
<option value="store">
Loja
</option>
<option value="restaurant">
Restaurante
</option>
<option value="service">
Serviço
</option>
<option value="other">
Outro
</option>
</select>
<label style={styles.label}>Área</label>
<div style={styles.segmented}>
<button type="button" style={{...styles.segmentButton, ...(supplierArea === "home" ? styles.segmentActive : {})}} onClick={() => { setSupplierArea("home"); setSupplierSectorId(householdSectors.find((item) => item.active)?.id || ""); setSupplierCategoryIds([]); }}>🏠 Casa</button>
<button type="button" style={{...styles.segmentButton, ...(supplierArea === "work" ? styles.segmentActive : {})}} onClick={() => { setSupplierArea("work"); setSupplierSectorId(""); setSupplierCategoryIds([]); }}>🔮 Trabalho</button>
</div>
{supplierArea === "home" && (
<>
<label style={styles.label}>Setor principal</label>
<select value={supplierSectorId} onChange={(e) => { setSupplierSectorId(e.target.value); setSupplierCategoryIds([]); }} style={styles.input}>
<option value="">Selecione o setor</option>
{householdSectors.filter((item) => item.active).map((sector) => <option key={sector.id} value={sector.id}>{sector.name}</option>)}
</select>
<label style={styles.label}>Categorias atendidas pelo estabelecimento</label>
<div style={styles.checkboxGrid}>
{householdCategories.filter((item) => item.active && (!supplierSectorId || item.sectorId === supplierSectorId)).map((category) => (
<label key={category.id} style={styles.checkboxItem}><input type="checkbox" checked={supplierCategoryIds.includes(category.id)} onChange={(e) => setSupplierCategoryIds((previous) => e.target.checked ? [...previous, category.id] : previous.filter((id) => id !== category.id))} /> {category.name}</label>
))}
</div>
</>
)}
<label
style={styles.label}
>
WhatsApp / telefone
</label>
<input
value={
supplierPhone
}
onChange={(event) =>
setSupplierPhone(
event.target.value
)
}
placeholder="Telefone"
style={styles.input}
/>
<label
style={styles.label}
>
CNPJ / documento
</label>
<input
value={
supplierDocument
}
onChange={(event) =>
setSupplierDocument(
event.target.value
)
}
placeholder="Opcional"
style={styles.input}
/>
<label
style={styles.label}
>
Observações
</label>
<textarea
value={
supplierNotes
}
onChange={(event) =>
setSupplierNotes(
event.target.value
)
}
style={
styles.textarea
}
/>
<button
style={
styles.primaryButtonLarge
}
onClick={
saveSupplier
}
>
✓ Salvar estabelecimento
</button>
<button
style={
styles.secondaryButtonLarge
}
onClick={() =>
setShowSupplierModal(
false
)
}
>
Cancelar
</button>
</Modal>
)}
{/* =====================================================
NOVO ESTOQUE
===================================================== */}
{showStockModal && (
<Modal
title={editingStockItemId ? "Editar item de estoque" : "Novo item de estoque"}
onClose={() =>
setShowStockModal(
false
)
}
>
<label
style={styles.label}
>
Nome
</label>
<input
value={stockName}
onChange={(event) =>
setStockName(
event.target.value
)
}
placeholder="Ex.: Frango, vela branca, alecrim..."
style={styles.input}
/>
<label
style={styles.label}
>
Estoque
</label>
<div
style={
styles.segmented
}
>
<button
style={{
...styles.segmentButton,
...(stockArea ===
"home"
? styles.segmentActive
: {}),
}}
onClick={() =>
setStockArea(
"home"
)
}
>
🏠Casa
</button>
<button
style={{
...styles.segmentButton,
...(stockArea ===
"work"
? styles.segmentActive
: {}),
}}
onClick={() =>
setStockArea(
"work"
)
}
>
🔮Trabalho
</button>
</div>
<label
style={styles.label}
>
Quantidade inicial
</label>
<input
type="number"
min="0"
step="0.01"
value={
stockQuantity
}
onChange={(event) =>
setStockQuantity(
event.target.value
)
}
style={styles.input}
/>
<label
style={styles.label}
>
Unidade
</label>
<input
value={stockUnit}
onChange={(event) =>
setStockUnit(
event.target.value
)
}
placeholder="un, kg, g, L..."
style={styles.input}
/>
<label
style={styles.label}
>
Estoque mínimo
</label>
<input
type="number"
min="0"
step="0.01"
value={
stockMinimum
}
onChange={(event) =>
setStockMinimum(
event.target.value
)
}
style={styles.input}
/>
<label
style={styles.label}
>
Custo médio
</label>
<input
type="number"
min="0"
step="0.01"
value={
stockCost
}
onChange={(event) =>
setStockCost(
event.target.value
)
}
placeholder="0,00"
style={styles.input}
/>
<label
style={styles.label}
>
Categoria
</label>
<input
value={
stockCategory
}
onChange={(event) =>
setStockCategory(
event.target.value
)
}
placeholder="Ex.: alimentos, velas, ervas..."
style={styles.input}
/>
<button
style={
styles.primaryButtonLarge
}
onClick={
saveStockItem
}
>
✓ Salvar item
</button>
<button
style={
styles.secondaryButtonLarge
}
onClick={() => { setShowStockModal(false); setEditingStockItemId(null); }}
>
Cancelar
</button>
</Modal>
)}
{/* =====================================================
NOVA CONTA
===================================================== */}
{showPayableModal && (
<Modal
title="Nova conta"
onClose={() =>
setShowPayableModal(
false
)
}
>
<label
style={styles.label}
>
Descrição
</label>
<input
value={
payableDescription
}
onChange={(event) =>
setPayableDescription(
event.target
.value
)
}
placeholder="Ex.: Energia elétrica"
style={styles.input}
/>
<label
style={styles.label}
>
Destino
</label>
<div
style={
styles.segmented
}
>
<button
style={{
...styles.segmentButton,
...(payableArea ===
"home"
? styles.segmentActive
: {}),
}}
onClick={() =>
setPayableArea(
"home"
)
}
>
🏠Casa
</button>
<button
style={{
...styles.segmentButton,
...(payableArea ===
"work"
? styles.segmentActive
: {}),
}}
onClick={() =>
setPayableArea(
"work"
)
}
>
🔮Trabalho
</button>
</div>
<label
style={styles.label}
>
Valor
</label>
<input
type="number"
min="0"
step="0.01"
value={
payableAmount
}
onChange={(event) =>
setPayableAmount(
event.target
.value
)
}
placeholder="0,00"
style={styles.input}
/>
<label
style={styles.label}
>
Vencimento
</label>
<input type="date" value={payableDueDate} onChange={event=>setPayableDueDate(event.target.value)} style={styles.input}/><label style={styles.label}>Tipo de conta</label><select value={payableRecurrenceType} onChange={e=>setPayableRecurrenceType(e.target.value as any)} style={styles.input}><option value="none">Uma vez</option><option value="recurring">Recorrente (sempre)</option><option value="fixed">Parcelada / duração definida</option></select>{payableRecurrenceType==="fixed"&&<><label style={styles.label}>Quantidade de parcelas/meses</label><input type="number" min="1" value={payableRecurrenceCount} onChange={e=>setPayableRecurrenceCount(e.target.value)} style={styles.input}/></>}
<label
style={styles.label}
>
Fornecedor
</label>
<select
value={
payableSupplierId
}
onChange={(event) =>
setPayableSupplierId(
event.target
.value
)
}
style={styles.input}
>
<option value="">
Nenhum
</option>
{suppliers.map(
(supplier) => (
<option
key={
supplier.id
}
value={
supplier.id
}
>
{supplier.name}
</option>
)
)}
</select>
<label
style={styles.label}
>
Forma de pagamento
</label>
<select
value={
payableMethod
}
onChange={(event) =>
setPayableMethod(
event.target
.value as PaymentMethod
)
}
style={styles.input}
>
<option value="pix">
Pix
</option>
<option value="credit">
Cartão de crédito
</option>
<option value="debit">
Cartão de débito
</option>
<option value="cash">
Dinheiro
</option>
<option value="transfer">
Transferência
</option>
<option value="combined">
Combinado
</option>
<option value="other">
Outro
</option>
</select>
<button
style={
styles.primaryButtonLarge
}
onClick={
savePayable
}
>
✓ Salvar conta
</button>
<button
style={
styles.secondaryButtonLarge
}
onClick={() =>
setShowPayableModal(
false
)
}
>
Cancelar
</button>
</Modal>
)}
{/* =====================================================
TRANSFERÊNCIA
===================================================== */}
{showTransferModal && (
<Modal
title="Transferir estoque"
onClose={() =>
setShowTransferModal(
false
)
}
>
<p
style={
styles.modalText
}
>
A transferência não cria uma
nova compra. Ela apenas move o
material de um estoque para o
outro, mantendo o histórico.
</p>
<label
style={styles.label}
>
Item
</label>
<select
value={
transferStockId
}
onChange={(event) =>
setTransferStockId(
event.target
.value
)
}
style={styles.input}
>
<option value="">
Selecione
</option>
{stockItems.map(
(item) => (
<option
key={
item.id
}
value={
item.id
}
>
{item.name} —{" "}
{item.area ===
"home"
? "Casa"
: "Trabalho"}{" "}
—{" "}
{item.quantity}{" "}
{item.unit}
</option>
)
)}
</select>
<label
style={styles.label}
>
Quantidade
</label>
<input
type="number"
min="0"
step="0.01"
value={
transferQuantity
}
onChange={(event) =>
setTransferQuantity(
event.target
.value
)
}
style={styles.input}
/>
<label
style={styles.label}
>
Destino
</label>
<div
style={
styles.segmented
}
>
<button
style={{
...styles.segmentButton,
...(transferDestination ===
"home"
? styles.segmentActive
: {}),
}}
onClick={() =>
setTransferDestination(
"home"
)
}
>
🏠Casa
</button>
<button
style={{
...styles.segmentButton,
...(transferDestination ===
"work"
? styles.segmentActive
: {}),
}}
onClick={() =>
setTransferDestination(
"work"
)
}
>
🔮Trabalho
</button>
</div>
<button
style={
styles.primaryButtonLarge
}
onClick={
transferStock
}
>
✓ Transferir material
</button>
<button
style={
styles.secondaryButtonLarge
}
onClick={() =>
setShowTransferModal(
false
)
}
>
Cancelar
</button>
</Modal>
)}
{consumeStockId && (()=>{const item=stockItems.find(x=>x.id===consumeStockId); if(!item)return null; return <Modal title="Consumir estoque" onClose={()=>setConsumeStockId(null)}><div style={styles.infoBox}><strong>{item.name}</strong><div style={styles.muted}>Disponível: {item.quantity} {item.unit}</div></div><label style={styles.label}>Quantidade consumida</label><input type="number" min="0.01" step="0.01" max={item.quantity} value={consumeStockQuantity} onChange={e=>setConsumeStockQuantity(e.target.value)} style={styles.input}/><button style={styles.primaryButtonLarge} onClick={confirmConsumeStock}>✓ Confirmar consumo</button><button style={styles.secondaryButtonLarge} onClick={()=>setConsumeStockId(null)}>Cancelar</button></Modal>})()}
{partialPaymentTarget && <Modal title="Receber valor da parcela" onClose={()=>setPartialPaymentTarget(null)}><div style={styles.infoBox}><strong>{partialPaymentTarget.consultation?.clientName}</strong><div>{partialPaymentTarget.questionId?"Pagamento de uma pergunta":"Pagamento de uma parcela"}</div><div style={{marginTop:6}}>Valor da parcela: <strong>{formatMoney(partialPaymentTarget.installment?.amount||0)}</strong></div><div>Já recebido: <strong>{formatMoney(installmentReceivedAmount(partialPaymentTarget.installment))}</strong></div><div>Restante: <strong>{formatMoney(partialPaymentTarget.openAmount||0)}</strong></div></div><label style={styles.label}>Quanto recebeu agora?</label><input autoFocus type="number" min="0" max={partialPaymentTarget.openAmount||0} step="0.01" value={partialPaymentAmount} onChange={e=>setPartialPaymentAmount(e.target.value)} placeholder="Ex.: 100,00" style={styles.input}/><label style={styles.label}>Forma de recebimento</label><select value={partialPaymentMethod} onChange={e=>setPartialPaymentMethod(e.target.value as PaymentMethod)} style={styles.input}>{(["pix","credit","debit","cash","transfer","paypal","wise","other"] as PaymentMethod[]).map(m=><option key={m} value={m}>{paymentMethodLabelText(m)}</option>)}</select><div style={{display:"flex",gap:8,flexWrap:"wrap"}}><button style={styles.primaryButtonLarge} onClick={confirmPartialPayment}>✓ Registrar recebimento</button><button style={styles.secondaryButtonLarge} onClick={()=>setPartialPaymentTarget(null)}>Cancelar</button></div></Modal>}
{showDesfalqueModal && <Modal title="Registrar desfalque" onClose={()=>setShowDesfalqueModal(false)}><label style={styles.label}>Data do desfalque</label><input type="date" value={desfalqueDate} onChange={e=>setDesfalqueDate(e.target.value)} style={styles.input}/><label style={styles.label}>Valor que poderia ter sido recebido</label><input type="number" min="0" step="0.01" value={desfalquePotential} onChange={e=>setDesfalquePotential(e.target.value)} style={styles.input}/><label style={styles.label}>Valor efetivamente recebido</label><input type="number" min="0" step="0.01" value={desfalqueReceived} onChange={e=>setDesfalqueReceived(e.target.value)} style={styles.input}/><label style={styles.label}>Motivo</label><textarea value={desfalqueDescription} onChange={e=>setDesfalqueDescription(e.target.value)} style={styles.textarea}/><button style={styles.primaryButtonLarge} onClick={saveDesfalque}>✓ Registrar desfalque</button><button style={styles.secondaryButtonLarge} onClick={()=>setShowDesfalqueModal(false)}>Cancelar</button></Modal>}
{showRescheduleModal && <Modal title={rescheduleTarget?.serviceType === "consultation" ? "Reagendar atendimento" : rescheduleTarget?.serviceType === "sale" ? "Reagendar venda/envio" : "Reagendar trabalho"} onClose={()=>{setShowRescheduleModal(false);setRescheduleTarget(null);}}><div style={styles.infoBox}>Escolha a nova data e horário. O compromisso será atualizado na Agenda e no acesso rápido do início.</div><label style={styles.label}>Data</label><input type="date" value={rescheduleDate} onChange={e=>setRescheduleDate(e.target.value)} style={styles.input}/><label style={styles.label}>Horário</label><input type="time" value={rescheduleTime} onChange={e=>setRescheduleTime(e.target.value)} style={styles.input}/><label style={styles.label}>Prioridade (1 = menor · 5 = máxima)</label><select value={reschedulePriority} onChange={e=>setReschedulePriority(Math.min(5,Math.max(1,Number(e.target.value)||3)))} style={styles.input}>{[5,4,3,2,1].map(n=><option key={n} value={n}>{n}{n===5?" · Máxima":n>=4?" · Alta":n===3?" · Média":" · Baixa"}</option>)}</select><button style={styles.primaryButtonLarge} onClick={saveRescheduleWork}>✓ Reagendar</button><button style={styles.secondaryButtonLarge} onClick={()=>setShowRescheduleModal(false)}>Cancelar</button></Modal>}
{selectedDashboardPayment && (
<div style={{position:"fixed",inset:0,background:"rgba(25,18,31,.45)",zIndex:500,display:"flex",alignItems:"flex-end",justifyContent:"center"}} onClick={()=>setSelectedDashboardPayment(null)}>
<div className="dashboard-detail-sheet" style={{background:"#fff",width:"100%",maxWidth:520,borderRadius:"24px 24px 0 0",padding:20,boxSizing:"border-box",maxHeight:"calc(100dvh - 8px)",height:"calc(100dvh - 8px)",overflowY:"auto",overscrollBehavior:"contain",WebkitOverflowScrolling:"touch"}} onClick={e=>e.stopPropagation()}>
<div style={{display:"flex",justifyContent:"space-between",alignItems:"center",gap:10}}><div><div style={styles.eyebrow}>DETALHES</div><h2 style={{...styles.cardTitle,marginBottom:2}}>{selectedDashboardPayment.clientName||selectedDashboardPayment.title}</h2></div><button style={styles.smallButton} onClick={()=>setSelectedDashboardPayment(null)}>Fechar</button></div>
<div style={{...styles.paymentBox,marginTop:14}}><strong>{selectedDashboardPayment.number!==undefined?(selectedDashboardPayment.number===0?"Entrada":`Parcela ${selectedDashboardPayment.number}`):selectedDashboardPayment.title}</strong><div style={styles.muted}>{selectedDashboardPayment.title||selectedDashboardPayment.subtitle}</div><div style={{marginTop:8,fontSize:22,fontWeight:850}}>{selectedDashboardPayment.amountCurrency!==undefined?formatForeign(selectedDashboardPayment.amountCurrency,selectedDashboardPayment.currency):formatMoney(selectedDashboardPayment.amount)}</div><div style={styles.muted}>{selectedDashboardPayment.dueDate?`Vencimento: ${formatDate(selectedDashboardPayment.dueDate)}`:`Data: ${formatDateTime(selectedDashboardPayment.date)}`}</div>{selectedDashboardPayment.consultationId&&(()=>{const c=consultations.find(x=>x.id===selectedDashboardPayment.consultationId);const rows=selectedDashboardPayment.questionId ? (c?.questions.find(q=>q.id===selectedDashboardPayment.questionId)?.paymentPlan?.installments||[]) : (c?.paymentPlan?.installments||[]);const current=rows.find(i=>i.id===selectedDashboardPayment.installmentId);return <div style={{marginTop:12,borderTop:"1px solid #eadfe6",paddingTop:10}}>{current&&<div style={{...styles.infoBox,marginBottom:10}}><strong>{current.number===0?"Entrada":`Parcela ${current.number}`} · {formatMoney(current.amount)}</strong><div style={styles.muted}>Recebido: {formatMoney(installmentReceivedAmount(current))} · Restante: {formatMoney(installmentOpenAmount(current))}</div>{installmentPaymentSummary(current)&&<div style={{...styles.muted,marginTop:4}}>📅 {installmentPaymentSummary(current)}</div>}<div style={{marginTop:5,fontWeight:800}}>{getInstallmentPaymentState(current).status==="paid"?"✓ Paga":getInstallmentPaymentState(current).status==="partial"?"🟠 Pago parcialmente":getInstallmentPaymentState(current).status==="defaulted"?"⚠ Não paga":getInstallmentPaymentState(current).status==="overdue"?"🔴 Vencida":"⏳ Pendente"}</div></div>}{rows.length>1&&<><strong>Todas as parcelas</strong>{rows.map(i=>{const received=installmentReceivedAmount(i);const remaining=installmentOpenAmount(i);const state=getInstallmentPaymentState(i);const label=state.status==="paid"?"✓ Paga":state.status==="partial"?"🟠 Pago parcialmente":state.status==="defaulted"?"⚠ Não paga":state.status==="overdue"?"🔴 Vencida":"⏳ Pendente";return <div key={i.id} style={{display:"flex",justifyContent:"space-between",gap:8,padding:"7px 0",borderBottom:"1px solid #f0e9ee"}}><span>{i.number===0?"Entrada":`Parcela ${i.number}`} · {formatDate(i.dueDate)}<br/><small style={styles.muted}>Recebido: {formatMoney(received)} · Restante: {formatMoney(remaining)}</small>{installmentPaymentSummary(i)&&<small style={{...styles.muted,display:"block",marginTop:3}}>📅 {installmentPaymentSummary(i)}</small>}</span><strong>{formatMoney(i.amount)} · {label}</strong></div>})}</>}</div>;})()}{selectedDashboardPayment.consultationId&&selectedDashboardPayment.installmentId&&<div style={{...styles.futureActions,marginTop:12}}><button style={styles.smallButton} onClick={()=>{promptInstallmentPartialPayment(selectedDashboardPayment);setSelectedDashboardPayment(null);}}>💰 Receber valor</button><button style={styles.smallButton} onClick={()=>{setAnyInstallmentStatus(selectedDashboardPayment.consultationId,selectedDashboardPayment.installmentId,"received",selectedDashboardPayment.questionId);setSelectedDashboardPayment(null);}}>✓ Pagou</button><button style={styles.smallButton} onClick={()=>{setAnyInstallmentStatus(selectedDashboardPayment.consultationId,selectedDashboardPayment.installmentId,"defaulted",selectedDashboardPayment.questionId);setSelectedDashboardPayment(null);}}>Não pagou</button><button style={styles.smallButton} onClick={()=>postponeDashboardPayment(selectedDashboardPayment)}>Prorrogar</button></div>}</div>
</div></div>)}
{resetDialog && (
 <Modal title={resetDialog.mode === "all" ? "⚠️ Confirmar reset geral" : resetDialog.mode === "selected" ? "⚠️ Confirmar reset dos selecionados" : `⚠️ Confirmar reset · ${RESET_GROUPS[resetDialog.groupId]?.label || "Módulo"}`} onClose={()=>setResetDialog(null)}>
  <div style={{display:"grid",gap:12}}>
   <div style={{...styles.infoBox,background:"#fff8f8",border:"1px solid #efc0c0"}}>
    <strong>Essa limpeza é destrutiva.</strong>
    <div style={styles.muted}>{resetDialog.mode === "all" ? "Todos os dados serão limpos, mas o login/Supabase Auth permanece." : resetDialog.mode === "selected" ? `Serão limpos somente: ${selectedResetGroups.map(id=>RESET_GROUPS[id]?.label).filter(Boolean).join(", ")}.` : RESET_GROUPS[resetDialog.groupId]?.description}</div>
    <div style={{marginTop:7,fontWeight:800}}>Espere {resetCountdown} segundo{resetCountdown===1?"":"s"} antes de confirmar.</div>
   </div>
   <div>
    <div style={{fontWeight:850,marginBottom:7}}>Onde aplicar o reset?</div>
    {([
      ["both","☑️ Supabase + armazenamento local"],
      ["supabase","☁️ Somente Supabase"],
      ["local","📱 Somente armazenamento local"],
    ] as const).map(([value,label])=><label key={value} style={{display:"flex",alignItems:"center",gap:9,padding:"9px 0",fontWeight:750}}>
      <input type="radio" name="reset-target" checked={resetDialog.target===value} onChange={()=>setResetDialog(prev=>prev?{...prev,target:value}:prev)} />
      <span>{label}</span>
    </label>)}
   </div>
   <div style={styles.muted}>O login não será apagado. Para um reset dos módulos escolhidos, mantenha <strong>Supabase + armazenamento local</strong> para limpar os dois lados.</div>
   <div style={{display:"grid",gridTemplateColumns:"1fr 1.4fr",gap:8}}>
    <button style={styles.secondaryButtonLarge} onClick={()=>setResetDialog(null)}>Cancelar</button>
    <button style={{...styles.primaryButtonLarge,background:resetCountdown>0?"#cfc8cd":"#a83b4b"}} disabled={resetCountdown>0} onClick={()=>void executeReset()}>
      {resetCountdown>0?`Aguarde ${resetCountdown}s`:"✓ OK · Confirmar reset"}
    </button>
   </div>
  </div>
 </Modal>
)}
{showPayableActionModal && (()=>{const item=payables.find(x=>x.id===showPayableActionModal.id);if(!item)return null;return <Modal title={showPayableActionModal.kind==="pay"?"Registrar pagamento":"Prorrogar vencimento"} onClose={()=>setShowPayableActionModal(null)}>
<div style={styles.infoBox}><strong>{item.description}</strong><div style={styles.muted}>Vencimento atual: {formatDate(item.dueDate)} · {formatMoney(item.amount)}</div></div>
{showPayableActionModal.kind==="postpone" ? <><label style={styles.label}>Novo vencimento</label><input type="date" value={payableActionDate} onChange={e=>setPayableActionDate(e.target.value)} style={styles.input}/></> : <><label style={styles.label}>Juros por atraso (R$)</label><input type="number" min="0" step="0.01" value={payableActionInterest} onChange={e=>setPayableActionInterest(e.target.value)} style={styles.input}/><label style={styles.label}>Multa (R$)</label><input type="number" min="0" step="0.01" value={payableActionFine} onChange={e=>setPayableActionFine(e.target.value)} style={styles.input}/><label style={styles.label}>Valor efetivamente pago (R$)</label><input type="number" min="0" step="0.01" value={payableActionAmount} onChange={e=>setPayableActionAmount(e.target.value)} style={styles.input}/></>}
<button style={styles.primaryButtonLarge} onClick={confirmPayableAction}>{showPayableActionModal.kind==="pay"?"✓ Confirmar pagamento":"✓ Prorrogar vencimento"}</button><button style={styles.secondaryButtonLarge} onClick={()=>setShowPayableActionModal(null)}>Cancelar</button>
</Modal>})()}
{quickCatalogKind && (
  <div className="quick-catalog-layer" role="dialog" aria-modal="true" aria-label={quickCatalogKind==="stock"?"Novo item de estoque":quickCatalogKind==="work"?"Novo tipo de trabalho":quickCatalogKind==="category"?"Nova categoria":quickCatalogKind==="sale"?"Novo item para venda":"Nova tiragem"}>
    <div className="quick-catalog-sheet">
      <div className="modal-header" style={styles.modalHeader}>
        <div style={{minWidth:0}}>
          <h2 className="modal-title" style={styles.modalTitle}>{quickCatalogKind==="stock"?"Novo item de estoque":quickCatalogKind==="work"?"Novo tipo de trabalho":quickCatalogKind==="category"?"Nova categoria":quickCatalogKind==="sale"?"Novo item para venda":"Nova tiragem"}</h2>
          <AppDateTime compact />
        </div>
        <button type="button" aria-label="Fechar cadastro rápido" style={styles.modalClose} onClick={()=>{setQuickCatalogKind(null);setQuickCatalogReturnContext(null);}}>×</button>
      </div>
      <div className="modal-body-scroll" style={styles.modalBodyScroll}>
        <div style={styles.infoBox}>Cadastre sem sair da tela atual. Depois de salvar, o novo item ficará disponível no campo que você estava preenchendo.</div>
        <label style={styles.label}>Nome</label><input autoFocus value={quickCatalogName} onChange={e=>setQuickCatalogName(e.target.value)} style={styles.input}/>
        {quickCatalogKind!=="category" && <label style={styles.label}>Preço padrão em BRL</label>}{quickCatalogKind!=="category" && <input type="number" min="0" step="0.01" value={quickCatalogPrice} onChange={e=>setQuickCatalogPrice(e.target.value)} style={styles.input}/>}
        {quickCatalogKind==="reading" && <><label style={styles.label}>Quantidade de perguntas</label><input type="number" min="1" value={quickCatalogQuestions} onChange={e=>setQuickCatalogQuestions(e.target.value)} style={styles.input}/></>}
        {quickCatalogKind==="category" && <><label style={styles.label}>Setor</label><select value={quickCatalogSectorId} onChange={e=>setQuickCatalogSectorId(e.target.value)} style={styles.input}>{householdSectors.filter(x=>x.active).map(x=><option key={x.id} value={x.id}>{x.name}</option>)}</select></>}
        <button style={styles.primaryButtonLarge} onClick={saveQuickCatalog}>✓ Salvar cadastro</button>
        <button style={styles.secondaryButtonLarge} onClick={()=>{setQuickCatalogKind(null);setQuickCatalogReturnContext(null);}}>Cancelar</button>
      </div>
    </div>
  </div>
)}
{selectedClientPhoto && (
  <Modal title={`Foto · ${selectedClientPhoto.name}`} onClose={()=>setSelectedClientPhoto(null)}>
    <div style={styles.photoModalContent}>
      <img
        src={selectedClientPhoto.data}
        alt={`Foto de ${selectedClientPhoto.name}`}
        style={{...styles.photoLarge,maxHeight:"58vh",objectFit:"contain",borderRadius:18}}
      />
      <div style={{display:"grid",gap:8,width:"100%"}}>
        {selectedClientPhoto.id && (
          <button
            type="button"
            style={{...styles.primaryButtonLarge,minHeight:52,padding:"12px 16px",fontSize:16}}
            onClick={()=>{
              const client=clients.find(x=>x.id===selectedClientPhoto.id);
              if(client) editClient(client);
              setSelectedClientPhoto(null);
            }}
          >
            ✏️ Editar foto do consulente
          </button>
        )}
        <button
          type="button"
          style={{...styles.secondaryButtonLarge,minHeight:48,padding:"11px 16px",fontSize:15}}
          onClick={()=>setSelectedClientPhoto(null)}
        >
          Fechar
        </button>
      </div>
    </div>
  </Modal>
)}
{toast && (
<Toast message={toast} />
)}
</div>
);
}
/* =========================================================
V63 · DATA E HORA DO APLICATIVO
========================================================= */
function V65Metric({label,value,detail}:{label:string;value:string;detail:string}){return <div style={styles.reportMetric}><span style={styles.muted}>{label}</span><strong>{value}</strong><small>{detail}</small></div>;}
function ReportMetricBox({label,value,detail}:{label:string;value:string;detail:string}){return <V65Metric label={label} value={value} detail={detail}/>;}
function ReportStatusBox({label,value,tone}:{label:string;value:number;tone:"good"|"neutral"|"warning"}){const bg=tone==="good"?"#eaf7ef":tone==="warning"?"#fff3e6":"#f0f1f3";const fg=tone==="good"?"#198754":tone==="warning"?"#c77700":"#666";return <div style={{...styles.reportStatusBox,background:bg,color:fg}}><strong>{value}</strong><span>{label}</span></div>;}
function V65DonutChart({title,data}:{title:string;data:{name:string;value:number}[]}){const total=data.reduce((s,x)=>s+x.value,0);const r=54;const c=2*Math.PI*r;let off=0;return <section style={styles.card}><div style={styles.eyebrow}>GRÁFICO</div><h2 style={styles.cardTitle}>{title}</h2>{total<=0?<div style={styles.emptyBox}>Sem dados no período.</div>:<div style={styles.donutLayout}><svg width="150" height="150" viewBox="0 0 150 150"><circle cx="75" cy="75" r={r} fill="none" stroke="#edf0f2" strokeWidth="20"/>{data.map(x=>{const len=x.value/total*c;const node=<circle key={x.name} cx="75" cy="75" r={r} fill="none" strokeWidth="20" strokeDasharray={`${len} ${c-len}`} strokeDashoffset={-off} transform="rotate(-90 75 75)"/>;off+=len;return node;})}<text x="75" y="72" textAnchor="middle" fontSize="12" fill="#777">Total</text><text x="75" y="92" textAnchor="middle" fontSize="16" fontWeight="700">{formatMoney(total)}</text></svg><div style={{flex:1,minWidth:180}}>{data.map(x=><div key={x.name} style={styles.reportListItem}><span>{x.name}</span><strong>{formatMoney(x.value)}</strong></div>)}</div></div>}</section>;}
function V65LineChart({title,data}:{title:string;data:{label:string;income:number;expense:number}[]}){const max=Math.max(1,...data.flatMap(x=>[x.income,x.expense]));const w=620,h=190,p=22;const points=(key:"income"|"expense")=>data.map((x,i)=>`${p+(data.length===1?0:i*(w-2*p)/Math.max(1,data.length-1))},${h-p-(x[key]/max)*(h-2*p)}`).join(" ");return <section style={styles.card}><div style={styles.eyebrow}>GRÁFICO</div><h2 style={styles.cardTitle}>{title}</h2>{data.length===0?<div style={styles.emptyBox}>Sem dados no período.</div>:<div style={{overflowX:"auto"}}><svg viewBox={`0 0 ${w} ${h}`} width="100%" height="210" role="img" aria-label={title}><line x1={p} y1={h-p} x2={w-p} y2={h-p} stroke="#ddd"/><polyline points={points("income")} fill="none" stroke="#2ea4cf" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round"/><polyline points={points("expense")} fill="none" stroke="#e45b61" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round"/></svg><div style={styles.chartLegend}><span>● Entradas</span><span>● Saídas</span></div></div>}</section>;}

function AppDateTime({compact=false}:{compact?:boolean}) {
 const [now,setNow]=useState(() => new Date());
 useEffect(() => {
  const timer=window.setInterval(() => setNow(new Date()), 30000);
  return () => window.clearInterval(timer);
 }, []);
 const date=now.toLocaleDateString("pt-BR", {day:"2-digit",month:"2-digit",year:"numeric"});
 const time=now.toLocaleTimeString("pt-BR", {hour:"2-digit",minute:"2-digit"});
 return <div style={{...styles.appDateTime, ...(compact ? styles.appDateTimeCompact : {})}} aria-label={`Data ${date}, hora ${time}`}>
  <span>{date}</span><span>·</span><strong>{time}</strong>
 </div>;
}

function AudioPlayer({audio}:{audio:AudioItem}) {
  const ref=useRef<HTMLAudioElement|null>(null);
  const [playing,setPlaying]=useState(false);
  const [speed,setSpeed]=useState(1);
  const [current,setCurrent]=useState(0);
  useEffect(()=>{ const el=ref.current; if(!el)return; el.playbackRate=speed; },[speed]);
  const toggle=()=>{const el=ref.current;if(!el)return;if(el.paused){el.play().then(()=>setPlaying(true)).catch(()=>{});}else{el.pause();setPlaying(false);}};
  const cycleSpeed=()=>setSpeed(v=>v===1?1.5:v===1.5?2:1);
  return <div className="wa-audio-player"><button type="button" className="wa-audio-play" onClick={toggle} aria-label={playing?"Pausar áudio":"Ouvir áudio"}>{playing?"❚❚":"▶"}</button><div className="wa-audio-main"><div className="wa-audio-wave" aria-hidden="true">{[8,14,20,12,18,10,23,15,19,11,17,9,21,13].map((h,i)=><span key={i} style={{height:h}} className={playing?"active":""}/>)}</div><input className="wa-audio-progress" type="range" min="0" max={Math.max(1,elDuration(ref.current,audio.duration))} step="0.1" value={Math.min(current,Math.max(1,elDuration(ref.current,audio.duration)))} onChange={e=>{const el=ref.current;if(!el)return;el.currentTime=Number(e.target.value);setCurrent(el.currentTime);}}/><div className="wa-audio-meta"><span>{formatDuration(current)} / {formatDuration(audio.duration)}</span><button type="button" className="wa-audio-speed" onClick={cycleSpeed}>{speed}x</button></div></div><audio ref={ref} src={audio.data} preload="metadata" onTimeUpdate={e=>setCurrent(e.currentTarget.currentTime)} onLoadedMetadata={e=>{if(Number.isFinite(e.currentTarget.duration)&&e.currentTarget.duration>0){}}} onEnded={()=>{setPlaying(false);setCurrent(0);}} /></div>;
}
const elDuration = (el:HTMLAudioElement|null,fallback:number) => { const d=el?.duration; return Number.isFinite(d)&&d>0?d:Math.max(1,fallback||1); };

/* =========================================================
MODAL — V70: pilha real de modais aninhados
========================================================= */
let modalInstanceCounter = 0;
function Modal({title,children,onClose,priority}:{title:string;children:React.ReactNode;onClose:()=>void;priority?:number;}) {
 const [minimized,setMinimized]=useState(false);
 const modalInstanceId = useRef(++modalInstanceCounter);
 const z = priority ?? (2000 + modalInstanceId.current * 10);
 const content = <div className={minimized ? "modal-overlay modal-overlay-minimized" : "modal-overlay"} style={minimized ? {position:"fixed",inset:0,zIndex:z,pointerEvents:"none",["--modal-z-index" as any]:z} : {...styles.modalOverlay,zIndex:z,["--modal-z-index" as any]:z}}>
  {minimized ? <div style={{position:"fixed",left:12,right:12,bottom:"calc(78px + env(safe-area-inset-bottom, 0px))",zIndex:120,display:"flex",pointerEvents:"auto",justifyContent:"center"}}><div style={{background:"#fff",borderRadius:16,boxShadow:"0 8px 30px rgba(0,0,0,.22)",padding:"10px 12px",display:"flex",alignItems:"center",gap:8,width:"100%",maxWidth:760}}><strong style={{flex:1,minWidth:0,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>↕ {title}</strong><button type="button" style={styles.smallButton} onClick={()=>setMinimized(false)}>Reabrir</button><button type="button" style={styles.deleteButton} onClick={onClose}>Fechar</button></div></div> : <div className="modal" style={{...styles.modal,zIndex:z+1}}>
   <div className="modal-header" style={styles.modalHeader}><div style={{minWidth:0}}><h2 className="modal-title" style={styles.modalTitle}>{title}</h2><AppDateTime compact /></div><div style={{display:"flex",gap:6,alignItems:"center",flexShrink:0}}><button type="button" aria-label="Minimizar janela" style={styles.modalClose} onClick={()=>setMinimized(true)}>−</button><button type="button" aria-label="Fechar janela" style={styles.modalClose} onClick={onClose}>×</button></div></div>
   <div className="modal-body-scroll" style={styles.modalBodyScroll}>{children}</div>
  </div>}
 </div>;
 return typeof document !== "undefined" ? createPortal(content, document.body) : content;
}
/* =========================================================
TOAST
========================================================= */
function Toast({
message,
}: {
message: string;
}) {
return (
<div style={{...styles.toast,position:"fixed",left:"50%",bottom:"calc(96px + env(safe-area-inset-bottom, 0px))",transform:"translateX(-50%)",zIndex:10000,maxWidth:"min(92vw, 560px)",whiteSpace:"normal",textAlign:"center"}}>
{message}
</div>
);
}
/* =========================================================
STAT CARD
========================================================= */
function StatCard({
title,
value,
onClick,
}: {
title: string;
value: string;
onClick?: () => void;
}) {
return (
<div
role={onClick ? "button" : undefined}
tabIndex={onClick ? 0 : undefined}
onClick={onClick}
onKeyDown={event=>{if(onClick && (event.key==="Enter" || event.key===" ")){event.preventDefault();onClick();}}}
style={{...styles.statCard,...(onClick?{cursor:"pointer"}:{})}}
>
<span
style={styles.muted}
>
{title}
</span>
<strong
style={styles.statValue}
>
{value}
</strong>
</div>
);
}
/* =========================================================
FINANCE MINI
========================================================= */
function FinanceMini({
title,
value,
subtitle,
onClick,
}: {
title: string;
value: string;
subtitle: string;
onClick?: () => void;
}) {
return (
<div
style={{...styles.financeMini,...(onClick?{cursor:"pointer"}:{})}}
role={onClick ? "button" : undefined}
onClick={onClick}
>
<strong>
{title}
</strong>
<span>
{value}
</span>
<small>
{subtitle}
</small>
</div>
);
}
/* =========================================================
HISTÓRICO
========================================================= */
function HistoryItem({
consultation,
execution,
onResume,
onEdit,
onDelete,
onPhotoDelete,
}: {
consultation: Consultation;
execution?: WorkExecution;
onResume: () => void;
onEdit: () => void;
onDelete: () => void;
onPhotoDelete: (photoId:string) => void;
}) {
const [expanded, setExpanded] = useState(false);
const [showFullDetails, setShowFullDetails] = useState(false);
const [selectedPhoto, setSelectedPhoto] = useState<PhotoItem | null>(null);
const [playingAudioId, setPlayingAudioId] = useState<string | null>(null);
const audioRefs = useRef<Record<string, HTMLAudioElement | null>>({});
const allQuestionPhotos = consultation.questions.flatMap(question => question.photos || []);
const allQuestionAudios = consultation.questions.flatMap(question => question.audios || []);
const intakePhotos = consultation.intakePhotos || [];
const intakeAudios = consultation.intakeAudios || [];
const servicePhotos = consultation.photos || [];
const serviceAudios = consultation.audios || [];
const paymentInstallments = consultation.paymentPlan?.installments || [];
const serviceTypeLabel = consultation.serviceType === "work" ? "✨ Trabalho" : consultation.serviceType === "sale" ? "🛍️ Venda" : consultation.serviceType === "consultation" ? "🔮 Consulta / Tiragem" : "📋 Atendimento";
const workStatusLabel = (status?: Consultation["workStatus"]) => ({approved:"🟢 Aguardando execução",scheduled:"📅 Agendado",in_progress:"🟢 Aguardando execução",completed:"✅ Executado",cancelled:"❌ Cancelado",postponed:"⏸️ Prorrogado"}[status || "approved"] || "—");
const saleStatusLabel = (status?: RelatedCharge["saleStatus"]) => ({approved:"🟢 Venda aprovada",awaiting_confection:"🧵 Aguardando confecção",in_confection:"🛠️ Em confecção",awaiting_shipping:"📦 Aguardando envio",shipped:"🚚 Enviado",delivered:"✅ Entregue",cancelled:"❌ Cancelada"}[status || "approved"] || "—");
const paymentMethodLabel = (method?: PaymentMethod) => ({pix:"Pix",paypal:"PayPal",wise:"Wise",cash:"Dinheiro",credit:"Cartão de crédito",debit:"Cartão de débito",transfer:"Transferência",other:"Outra"}[method || "other"] || method || "—");
const playAudio = (audio: AudioItem) => {
  const element = audioRefs.current[audio.id];
  if (!element) return;
  Object.entries(audioRefs.current).forEach(([id, item]) => { if (id !== audio.id && item) { item.pause(); item.currentTime = 0; } });
  if (playingAudioId === audio.id) { element.pause(); setPlayingAudioId(null); }
  else { element.play().then(() => setPlayingAudioId(audio.id)).catch(() => setPlayingAudioId(null)); }
};
const PhotoStrip = ({photos, label}:{photos:PhotoItem[];label:string}) => photos.length === 0 ? null : <div style={{marginTop:10}}><strong>{label} ({photos.length})</strong><div style={styles.historyPhotoRow}>{photos.map(photo=><div key={photo.id} style={{display:"grid",gap:6,minWidth:120}}><button type="button" onClick={()=>setSelectedPhoto(photo)} style={{display:"grid",gap:6,minWidth:120,border:0,background:"transparent",padding:0,textAlign:"left",cursor:"pointer"}}><img src={photo.data} alt={photo.name} style={styles.historyPhoto}/><div style={styles.muted}>🔎 Abrir foto · 🎙️ {(photo.audios||[]).length} áudio(s)</div>{photo.note?<div style={styles.muted}>📝 {photo.note}</div>:null}</button><button type="button" style={styles.smallButton} onClick={()=>void shareDataFile(photo.data, `tiragem-${photo.id}.jpg`, "image/jpeg", "Foto da tiragem")}>↗ Compartilhar foto</button></div>)}</div></div>;
const AudioList = ({audios,label}:{audios:AudioItem[];label:string}) => audios.length === 0 ? null : <div style={{display:"grid",gap:8,marginTop:10}}><strong>{label} ({audios.length})</strong>{audios.map(audio=><div key={audio.id} style={{display:"grid",gap:7,padding:8,border:"1px solid #eadfe6",borderRadius:14,background:"#fff"}}><AudioPlayer audio={audio} /><div style={styles.muted}>🎙️ {audio.name} · {formatDuration(audio.duration)}</div><button type="button" style={styles.smallButton} onClick={()=>void shareDataFile(audio.data, `${audio.name || "audio"}.aac`, "audio/aac", "Áudio da tiragem")}>↗ Compartilhar áudio</button></div>)}</div>;
const historyPaymentStatus = getPaymentStatusValue(consultation);
const historyReceivedAmount = consultationReceivedAmountValue(consultation);
const historyOpenAmount = Math.max(0, (consultation.paymentPlan?.installments || []).reduce((sum, row) => sum + Number(row.amount || 0), 0) - historyReceivedAmount);

return (
<>
<section style={styles.historyCard}>
<button style={styles.historyHeader} onClick={()=>setExpanded(!expanded)}>
<div>
<div style={styles.muted}>{formatDate(consultation.createdAt)}</div>
<strong style={styles.historyTitle}>{consultation.title}</strong>
{consultation.preWorkReading&&<div style={{marginTop:5,fontWeight:800,color:"#8063a2"}}>🔮 Leitura pré-trabalho · {consultation.preWorkWorkTitle||"Trabalho"}</div>}
<div style={{display:"flex",gap:6,flexWrap:"wrap",alignItems:"center",marginTop:5}}><span style={styles.statusPill}>🏷️ {consultationPackageLabel(consultation)}</span>{consultationPackageUnitPrice(consultation)!==null&&<span style={styles.statusPill}>≈ {formatForeign(consultationPackageUnitPrice(consultation)||0,(consultation.questions.find(q=>q.packageId)?.currency||consultation.currency||"BRL") as CurrencyCode)} / pergunta</span>}</div>
<div style={styles.muted}>{serviceTypeLabel} · {consultation.questions.length} pergunta(s) · {formatForeign(consultation.value || 0,(consultation.currency||"BRL") as CurrencyCode)}</div>
</div><span>{expanded?"⌃":"⌄"}</span>
</button>
{expanded && <div style={styles.historyContent}>
<div style={styles.historyPayment}>{historyPaymentStatus==="paid" ? "✓ Pago" : historyPaymentStatus==="partial" ? "🟠 Pago parcialmente" : "⚠ Pagamento pendente"}{historyPaymentStatus!=="paid"&&consultation.paymentDate?<span>Previsão: {formatDate(consultation.paymentDate)}</span>:null}{consultation.paymentPlan?.installments?.length ? <span>Recebido: {formatMoney(historyReceivedAmount)} · Em aberto: {formatMoney(historyOpenAmount)}</span> : null}</div>
<div style={{...styles.infoBox,marginTop:8}}><strong>{serviceTypeLabel}</strong><div style={styles.muted}>Status geral: {consultation.status === "completed" ? "Concluído" : consultation.status === "standby" ? "Em espera" : consultation.status === "scheduled" ? "Agendado" : "Ativo"}</div>{consultation.serviceType === "work"&&<div style={{marginTop:4}}>{workStatusLabel(consultation.workStatus)}</div>}{consultation.serviceType === "sale"&&<div style={{marginTop:4}}>{saleStatusLabel((consultation as any).saleStatus)}</div>}</div>
{consultation.intakeNotes&&<div style={{...styles.infoBox,marginTop:8}}><strong>📥 Informações recebidas</strong><div style={{whiteSpace:"pre-wrap",marginTop:6}}>{consultation.intakeNotes}</div></div>}
{intakePhotos.length>0&&<PhotoStrip photos={intakePhotos} label="📷 Fotos das informações recebidas"/>}
{intakeAudios.length>0&&<AudioList audios={intakeAudios} label="🎙️ Áudios das informações recebidas"/>}
{paymentInstallments.length>0&&<div style={{...styles.infoBox,marginTop:8}}><strong>💳 Parcelamento · {paymentInstallments.length} parcela(s)</strong>{paymentInstallments.map(i=>{const state=getInstallmentPaymentState(i);const label=state.status==="paid"?"✓ Paga":state.status==="partial"?"🟠 Pago parcialmente":state.status==="defaulted"?"⚠ Não paga":state.status==="overdue"?"🔴 Vencida":"🕐 Pendente";return <div key={i.id} style={{marginTop:8,paddingTop:8,borderTop:"1px solid #eadfe6"}}><div style={{display:"flex",justifyContent:"space-between",gap:8,flexWrap:"wrap"}}><span>Parcela {i.number}: <strong>{formatMoney(i.amount)}</strong> · {label} · vence {formatDate(i.dueDate)}</span><strong>{formatMoney(state.openAmount)} em aberto</strong></div><div style={styles.muted}>Recebido: {formatMoney(state.receivedAmount)} · Restante: {formatMoney(state.openAmount)}</div>{state.payments.length>0&&<div style={{marginTop:5,display:"grid",gap:3}}>{state.payments.map(payment=><div key={payment.id} style={styles.muted}>↳ {formatMoney(payment.amount)} · {formatDateTime(payment.date)} · {paymentMethodLabel(payment.paymentMethod)}</div>)}</div>}</div>})}</div>}
{(consultation.serviceType === "work" || consultation.serviceType === "sale")&&<div style={styles.infoBox}><strong>{consultation.serviceType === "work"?"✨ Dados do trabalho":"🛍️ Dados da venda"}</strong>{consultation.workTypeName?<div>Tipo: {consultation.workTypeName}</div>:null}{consultation.saleItemName?<div>Produto: {consultation.saleItemName}</div>:null}{consultation.paymentMethod?<div>Pagamento: {paymentMethodLabel(consultation.paymentMethod)}</div>:null}{consultation.budgetId?<div>🔗 Vinculado ao orçamento</div>:null}{consultation.scheduledAt?<div>📅 Agendado: {formatDateTime(consultation.scheduledAt)}</div>:null}{consultation.serviceType === "work"?<div style={{marginTop:5}}>{workStatusLabel(consultation.workStatus)}</div>:null}{consultation.serviceType === "sale"?<div style={{marginTop:5}}>{saleStatusLabel((consultation as any).saleStatus)}</div>:null}{consultation.shippingEnabled?<div style={{marginTop:8,paddingTop:8,borderTop:"1px solid #eadfe6"}}><strong>📦 Envio</strong><div>Método: {consultation.shippingMethod||"não informado"}</div>{consultation.shippingScheduledAt?<div>Data: {formatDateTime(consultation.shippingScheduledAt)}</div>:null}{consultation.shippingRecipientName?<div>Destinatário: {consultation.shippingRecipientName}</div>:null}{consultation.shippingPhone?<div>Telefone: {consultation.shippingPhone}</div>:null}{consultation.shippingAddress?<div>Endereço: {consultation.shippingAddress}</div>:null}{consultation.shippingZipCode||consultation.shippingCity||consultation.shippingState?<div>{consultation.shippingZipCode||""} · {consultation.shippingCity||""}/{consultation.shippingState||""}</div>:null}{consultation.shippingUber!==undefined?<div>Uber/frete: {formatMoney(consultation.shippingUber||0)}</div>:null}{consultation.shippingUberSpent?<div>Custo real Uber: {formatMoney(consultation.shippingUberSpentAmount||0)}</div>:null}</div>:null}</div>}
{consultation.serviceType === "work" && ((consultation.receivedObjects||[]).length>0 || (consultation.sentObjects||[]).length>0) && <div style={{...styles.infoBox,marginTop:8}}><strong>📦 Objetos do trabalho</strong>{(consultation.receivedObjects||[]).map(o=><div key={o.id}>📥 Recebido: <strong>{o.name}</strong>{o.referenceValue?` · referência ${formatMoney(o.referenceValue)}`:""}{o.notes?` · ${o.notes}`:""}</div>)}{(consultation.sentObjects||[]).map(o=><div key={o.id}>📤 Enviado: <strong>{o.name}</strong>{o.referenceValue?` · referência ${formatMoney(o.referenceValue)} · não é cobrança separada`:""}{o.notes?` · ${o.notes}`:""}</div>)}</div>}
{execution&&<div style={{...styles.infoBox,marginTop:8}}><strong>🧰 Execução registrada</strong><div>Data: {formatDateTime(execution.executedAt)}</div><div>Custo novo: {formatMoney(execution.totalCost)}</div><div>Economia estimada: {formatMoney(execution.estimatedSavings)}</div>{execution.notes?<div style={{whiteSpace:"pre-wrap",marginTop:6}}>{execution.notes}</div>:null}{execution.items?.length?<div style={{marginTop:8}}><strong>Materiais de estoque</strong>{execution.items.map((item,index)=><div key={index}>{item.stockItemId} · {item.quantity} · {item.usage === "reused" ? "reutilizado" : "novo"} · {formatMoney(item.cost)}</div>)}</div>:null}{execution.externalItems?.length?<div style={{marginTop:8}}><strong>Materiais externos</strong>{execution.externalItems.map((item,index)=><div key={index}>{item.name} · {item.quantity} {item.unit} · {formatMoney(item.cost)}{item.notes?` · ${item.notes}`:""}</div>)}</div>:null}</div>}
{consultation.questions.map(question=><div key={question.id} style={styles.historyQuestion}><strong>Pergunta {question.number}</strong><p>{question.text||"Sem pergunta registrada."}</p>{question.notes?<div style={styles.noteBox}>📝 {question.notes}</div>:null}<div style={styles.muted}>Cobrança: {question.workQuestionKind==="benefit"?"🎁 Benefício do trabalho":question.workQuestionKind==="courtesy"?"🎁 Cortesia extra":question.billingMode||"incluída"}{question.value!==undefined?` · ${formatForeign(question.value,(question.currency||consultation.currency||"BRL") as CurrencyCode)}`:""}{question.relatedWorkId?` · 🔮 ${question.relatedWorkTitle || "Trabalho"} · pergunta ${question.workQuestionNumber || question.number}`:""}</div><PhotoStrip photos={question.photos||[]} label="📷 Fotos desta pergunta"/><AudioList audios={question.audios||[]} label="🎙️ Áudios desta pergunta"/></div>)}
{(consultation.relatedCharges||[]).length>0&&<section style={{...styles.infoBox,marginBottom:10}}><strong>🧾 Registros adicionais</strong>{(consultation.relatedCharges||[]).map(c=><div key={c.id} style={{marginTop:8,paddingTop:8,borderTop:"1px solid #eadfe6"}}><strong>{c.kind==="work"?"✨ Trabalho":"🛍️ Venda"} · {c.title}</strong><div>Valor: {formatForeign(c.originalAmount,c.currency||"BRL")}</div>{c.status?<div>Status: {c.status}</div>:null}{c.saleStatus?<div>Status da venda: {saleStatusLabel(c.saleStatus)}</div>:null}{c.shippingEnabled?<div>📦 Envio: {c.shippingMethod||"não informado"} · {c.shippingScheduledAt?formatDateTime(c.shippingScheduledAt):"sem data"}</div>:null}{c.shippingRecipientName?<div>Destinatário: {c.shippingRecipientName}</div>:null}{c.shippingAddress?<div>Endereço: {c.shippingAddress}</div>:null}{c.shippingUber!==undefined?<div>Uber/frete: {formatMoney(c.shippingUber||0)}{c.shippingUberSpent?` · gasto real ${formatMoney(c.shippingUberSpentAmount||0)}`:""}</div>:null}{c.notes?<div style={{whiteSpace:"pre-wrap",marginTop:4}}>{c.notes}</div>:null}<PhotoStrip photos={c.photos||[]} label="📷 Fotos"/><AudioList audios={c.audios||[]} label="🎙️ Áudios"/></div>)}</section>}
{consultation.preWorkReading&&<div style={{...styles.infoBox,marginTop:10}}><strong>🔥 Leitura pré-trabalho</strong><div>Trabalho vinculado: <strong>{consultation.preWorkWorkTitle||"selecionado"}</strong>. Use o botão de orçamento no atendimento para continuar a venda.</div></div>}
<div style={{display:"flex",gap:8,flexWrap:"wrap",marginTop:12}}><button style={styles.primaryButtonLarge} onClick={()=>setShowFullDetails(true)}>🔎 Ver ficha completa</button><button style={styles.smallButton} onClick={onEdit}>✏️ Editar informações</button></div>
</div>}
</section>
{showFullDetails&&<Modal title={`Ficha completa · ${consultation.clientName}`} onClose={()=>setShowFullDetails(false)}><div style={{display:"grid",gap:12}}><div style={styles.infoBox}><div style={styles.eyebrow}>ATENDIMENTO</div><h3 style={{margin:"4px 0",fontSize:22}}>{consultation.title}</h3><div>{serviceTypeLabel} · Criado em {formatDateTime(consultation.createdAt)}</div><div style={{marginTop:5}}>Valor: <strong>{formatForeign(consultation.value||0,(consultation.currency||"BRL") as CurrencyCode)}</strong></div><div style={{marginTop:5}}>Status: <strong>{consultation.status === "completed" ? "Concluído" : consultation.status === "standby" ? "Em espera" : consultation.status === "scheduled" ? "Agendado" : "Ativo"}</strong></div>{consultation.serviceType === "work"?<div style={{marginTop:5}}>{workStatusLabel(consultation.workStatus)}</div>:null}{consultation.serviceType === "sale"?<div style={{marginTop:5}}>{saleStatusLabel((consultation as any).saleStatus)}</div>:null}</div>
{consultation.intakeNotes||intakePhotos.length||intakeAudios.length?<div style={styles.card}><h3 style={{marginTop:0}}>📥 Informações recebidas</h3>{consultation.intakeNotes?<div style={{whiteSpace:"pre-wrap"}}>{consultation.intakeNotes}</div>:<div style={styles.muted}>Sem texto registrado.</div>}<PhotoStrip photos={intakePhotos} label="Fotos recebidas"/><AudioList audios={intakeAudios} label="Áudios recebidos"/></div>:null}
<div style={styles.card}><h3 style={{marginTop:0}}>🔮 Tiragem e perguntas</h3><div style={styles.muted}>{consultationPackageLabel(consultation)}{consultationPackageUnitPrice(consultation)!==null?` · ${formatForeign(consultationPackageUnitPrice(consultation)||0,(consultation.questions.find(q=>q.packageId)?.currency||consultation.currency||"BRL") as CurrencyCode)} por pergunta`:""}</div>{consultation.questions.length===0?<div style={styles.emptyBox}>Nenhuma pergunta registrada.</div>:consultation.questions.map(question=><div key={question.id} style={{...styles.historyQuestion,marginTop:10}}><strong>Pergunta {question.number}</strong><p>{question.text||"Sem pergunta registrada."}</p>{question.notes?<div style={styles.noteBox}>📝 {question.notes}</div>:null}<div style={styles.muted}>Valor: {question.value!==undefined?formatForeign(question.value,(question.currency||consultation.currency||"BRL") as CurrencyCode):"—"} · Cobrança: {question.workQuestionKind==="benefit"?"🎁 Benefício do trabalho":question.workQuestionKind==="courtesy"?"🎁 Cortesia extra":question.billingMode||"incluída"}{question.relatedWorkId?` · 🔮 ${question.relatedWorkTitle || "Trabalho"} · pergunta ${question.workQuestionNumber || question.number}`:""}</div><PhotoStrip photos={question.photos||[]} label="Fotos"/><AudioList audios={question.audios||[]} label="Áudios"/></div>)}</div>
{paymentInstallments.length>0?<div style={styles.card}><h3 style={{marginTop:0}}>💳 Pagamento e parcelamento</h3><div>Total: <strong>{formatMoney(consultation.paymentPlan?.total||consultation.value||0)}</strong></div>{consultation.paymentMethod?<div>Forma: {paymentMethodLabel(consultation.paymentMethod)}</div>:null}{paymentInstallments.map(i=><div key={i.id} style={{padding:"8px 0",borderBottom:"1px solid #eee"}}><div>Parcela {i.number}: {formatMoney(i.amount)} · {installmentReceivedAmount(i) >= i.amount-0.01 ? "✓ Paga" : installmentReceivedAmount(i)>0 ? `🟠 Parcial · ${formatMoney(installmentOpenAmount(i))} restante` : i.status === "defaulted" ? "⚠ Não paga" : "🕐 Pendente"} · vencimento {formatDate(i.dueDate)}</div>{installmentPaymentSummary(i)&&<div style={styles.muted}>📅 {installmentPaymentSummary(i)}</div>}</div>)}</div>:null}
{consultation.serviceType === "sale"?<div style={styles.card}><h3 style={{marginTop:0}}>🛍️ Venda e envio</h3><div>Produto: {consultation.saleItemName||consultation.title}</div><div>{saleStatusLabel((consultation as any).saleStatus)}</div>{consultation.shippingEnabled?<><div style={{marginTop:6}}>Método: {consultation.shippingMethod||"não informado"}</div><div>Destinatário: {consultation.shippingRecipientName||"—"}</div><div>Telefone: {consultation.shippingPhone||"—"}</div><div>Endereço: {consultation.shippingAddress||"—"}</div><div>CEP: {consultation.shippingZipCode||"—"}</div><div>Cidade/UF: {consultation.shippingCity||"—"}/{consultation.shippingState||"—"}</div><div>Frete cobrado: {formatMoney(consultation.shippingUber||0)}</div>{consultation.shippingUberSpent?<div>Custo real Uber: {formatMoney(consultation.shippingUberSpentAmount||0)}</div>:null}</>:<div style={styles.muted}>Sem envio.</div>}<PhotoStrip photos={servicePhotos} label="Fotos da venda"/><AudioList audios={serviceAudios} label="Áudios da venda"/></div>:null}
{consultation.serviceType === "work"?<div style={styles.card}><h3 style={{marginTop:0}}>✨ Trabalho</h3><div>Tipo: {consultation.workTypeName||consultation.title}</div><div>{workStatusLabel(consultation.workStatus)}</div>{consultation.scheduledAt?<div>Agendamento: {formatDateTime(consultation.scheduledAt)}</div>:null}{execution?<><div>Executado em: {formatDate(execution.executedDate || execution.executedAt?.slice(0,10) || execution.executedAt)}</div><div>Custo: {formatMoney(execution.totalCost)}</div><div>Economia estimada: {formatMoney(execution.estimatedSavings)}</div>{execution.notes?<div style={{whiteSpace:"pre-wrap",marginTop:6}}>{execution.notes}</div>:null}</>:null}{consultation.paymentPlan?.installments?.length>0?<div style={{marginTop:10,paddingTop:10,borderTop:"1px solid #eadfe6"}}><strong>💳 Parcelas do trabalho</strong>{consultation.paymentPlan.installments.map(i=><div key={i.id} style={{display:"flex",justifyContent:"space-between",gap:8,padding:"6px 0"}}><span>Parcela {i.number} · {formatDate(i.dueDate)}</span><strong>{installmentReceivedAmount(i)>=i.amount-0.01?"✓ Paga":installmentReceivedAmount(i)>0?`🟠 Parcial · recebido ${formatMoney(installmentReceivedAmount(i))}`:i.status==="defaulted"?"⚠ Não paga":i.status==="overdue"?"🔴 Vencida":"🕐 Pendente"} · {formatMoney(i.amount)}</strong></div>)}</div>:null}{((consultation.receivedObjects||[]).length>0 || (consultation.sentObjects||[]).length>0)&&<div style={{marginTop:10,paddingTop:10,borderTop:"1px solid #eadfe6"}}><strong>📦 Objetos do trabalho</strong>{(consultation.receivedObjects||[]).map(o=><div key={o.id}>📥 Recebido: {o.name}{o.referenceValue?` · referência ${formatMoney(o.referenceValue)}`:""}{o.address?` · endereço: ${o.address}`:""}{o.postalCode?` · ${o.postalCode}`:""}</div>)}{(consultation.sentObjects||[]).map(o=><div key={o.id}>📤 Enviado: {o.name}{o.referenceValue?` · referência ${formatMoney(o.referenceValue)} · não é cobrança separada`:""}</div>)}</div>}<PhotoStrip photos={servicePhotos} label="Fotos do trabalho"/><AudioList audios={serviceAudios} label="Áudios do trabalho"/></div>:null}
{(consultation.relatedCharges||[]).length>0?<div style={styles.card}><h3 style={{marginTop:0}}>🧾 Trabalhos e vendas vinculados</h3>{(consultation.relatedCharges||[]).map(c=><div key={c.id} style={{padding:"10px 0",borderBottom:"1px solid #eee"}}><strong>{c.kind === "work"?"✨":"🛍️"} {c.title}</strong><div>Valor: {formatForeign(c.originalAmount,c.currency||"BRL")}</div>{c.status?<div>Status: {c.status}</div>:null}{c.saleStatus?<div>{saleStatusLabel(c.saleStatus)}</div>:null}{c.shippingEnabled?<div>📦 {c.shippingMethod||"Envio"} · {c.shippingAddress||"endereço não informado"}</div>:null}{c.notes?<div style={{whiteSpace:"pre-wrap"}}>{c.notes}</div>:null}<PhotoStrip photos={c.photos||[]} label="Fotos"/><AudioList audios={c.audios||[]} label="Áudios"/></div>)}</div>:null}
</div></Modal>}
{selectedPhoto&&<Modal title={consultation.serviceType === "work" ? "Foto do trabalho" : consultation.serviceType === "sale" ? "Foto da venda" : "Foto da pergunta"} onClose={()=>setSelectedPhoto(null)}><div style={styles.photoModalContent}><img src={selectedPhoto.data} alt={selectedPhoto.name||"Foto"} style={styles.photoLarge}/><div style={styles.photoModalActions}><button type="button" style={styles.deleteButton} onClick={() => { onPhotoDelete(selectedPhoto.id); setSelectedPhoto(null); }}>🗑️ Excluir foto</button></div>{selectedPhoto.note&&<div style={styles.noteBox}>📝 {selectedPhoto.note}</div>}<div style={styles.photoModalSectionTitle}>Áudios desta foto ({(selectedPhoto.audios||[]).length})</div>{(selectedPhoto.audios||[]).length===0?<div style={styles.muted}>Nenhum áudio foi salvo nesta foto.</div>:(selectedPhoto.audios||[]).map(audio=><div key={audio.id} style={{display:"flex",alignItems:"center",gap:8,flexWrap:"wrap",marginBottom:8}}><AudioPlayer audio={audio} /><span style={styles.muted}>{audio.name} · {formatDuration(audio.duration)}</span></div>)}</div></Modal>}
</>
);
}

/* =========================================================
AUDIO WAV
========================================================= */
function audioBufferToWav(
buffer: AudioBuffer
): Blob {
const channels =
buffer.numberOfChannels;
const sampleRate =
buffer.sampleRate;
const length =
buffer.length;
const bytesPerSample = 2;
const blockAlign =
channels *
bytesPerSample;
const arrayBuffer =
new ArrayBuffer(
44 +
length *
blockAlign
);
const view =
new DataView(
arrayBuffer
);
const writeString = (
offset: number,
value: string
) => {
for (
let i = 0;
i < value.length;
i++
) {
view.setUint8(
offset + i,
value.charCodeAt(i)
);
}
};
writeString(
0,
"RIFF"
);
view.setUint32(
4,
36 +
length *
blockAlign,
true
);
writeString(
8,
"WAVE"
);
writeString(
12,
"fmt "
);
view.setUint32(
16,
16,
true
);
view.setUint16(
20,
1,
true
);
view.setUint16(
22,
channels,
true
);
view.setUint32(
24,
sampleRate,
true
);
view.setUint32(
28,
sampleRate *
blockAlign,
true
);
view.setUint16(
32,
blockAlign,
true
);
view.setUint16(
34,
16,
true
);
writeString(
36,
"data"
);
view.setUint32(
40,
length *
blockAlign,
true
);
const channelData:
Float32Array[] = [];
for (
let channel = 0;
channel < channels;
channel++
) {
channelData.push(
buffer.getChannelData(
channel
)
);
}
let offset = 44;
for (
let i = 0;
i < length;
i++
) {
for (
let channel = 0;
channel < channels;
channel++
) {
let sample =
channelData[
channel
][i];
sample = Math.max(
-1,
Math.min(
1,
sample
)
);
const intSample =
sample < 0
? sample *
0x8000
: sample *
0x7fff;
view.setInt16(
offset,
intSample,
true
);
offset += 2;
}
}
return new Blob(
[view],
{
type: "audio/wav",
}
);
}
/* =========================================================
ESTILOS
========================================================= */
const styles: Record<
string,
React.CSSProperties
> = {
app: {
minHeight: "100vh",
background: "#fff7fb",
paddingTop: "env(safe-area-inset-top, 0px)",
color: "#29252d",
fontFamily:
"Inter, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
paddingBottom: 90,
},
topbar: {
minHeight: 78,
background: "#ffffff",
borderBottom:
"1px solid #e8e4ea",
display: "flex",
alignItems: "center",
justifyContent:
"space-between",
padding: "16px 20px",
boxSizing: "border-box",
position: "sticky",
top: 0,
zIndex: 20,
},
topbarLeft: {
 display: "flex",
 alignItems: "center",
 gap: 12,
},
menuButton: {
 width: 44,
 height: 44,
 borderRadius: 12,
 border: "1px solid #e5dfe8",
 background: "#f7f4f9",
 color: "#5d4d68",
 fontSize: 24,
 cursor: "pointer",
 display: "flex",
 alignItems: "center",
 justifyContent: "center",
},
menuOverlay: {
 position: "fixed",
 inset: 0,
 background: "rgba(25,20,28,.48)",
 zIndex: 90,
},
sideMenu: {
 width: "min(86vw, 360px)",
 height: "100%",
 background: "#ffffff",
 padding: 20,
 boxSizing: "border-box",
 boxShadow: "8px 0 30px rgba(30,20,40,.18)",
 overflowY: "auto",
},
menuHeader: {
 display: "flex",
 alignItems: "center",
 justifyContent: "space-between",
 marginBottom: 18,
},
menuTitle: { margin: 0, fontSize: 26, fontWeight: 850 },
agendaTabs: {
 display: "grid",
 gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
 gap: 8,
 marginTop: 14,
},
agendaTab: {
 border: "1px solid #ddd6e2",
 background: "#ffffff",
 color: "#5f5667",
 borderRadius: 12,
 padding: "11px 8px",
 fontWeight: 750,
 cursor: "pointer",
},
agendaTabActive: {
 background: "#eee8f5",
 borderColor: "#c95b93",
 color: "#c95b93",
},
agendaCard: {
 display: "flex",
 alignItems: "flex-start",
 gap: 12,
 border: "1px solid #ead9e2",
 borderRadius: 15,
 padding: 14,
 background: "#ffffff",
},
agendaAutoCard: {
 display: "flex",
 alignItems: "flex-start",
 gap: 12,
 border: "1px solid #e1d8e8",
 borderRadius: 15,
 padding: 14,
 background: "#f9f7fb",
},
agendaTime: {
 minWidth: 54,
 fontWeight: 850,
 fontSize: 17,
 color: "#c95b93",
},
menuItem: {
 width: "100%",
 border: "none",
 background: "transparent",
 padding: "15px 12px",
 borderRadius: 14,
 display: "flex",
 alignItems: "center",
 gap: 12,
 textAlign: "left",
 fontSize: 16,
 fontWeight: 750,
 color: "#3f3744",
 cursor: "pointer",
},
checkboxGrid: { display: "grid", gap: 8, marginBottom: 12 },
checkboxItem: { display: "flex", alignItems: "center", gap: 8, padding: "8px 10px", border: "1px solid #ddd", borderRadius: 10 },
menuDivider: { height: 1, background: "#e9e4eb", margin: "12px 0" },
priorityGrid: { display: "grid", gridTemplateColumns: "repeat(2, minmax(0, 1fr))", gap: 8 },
priorityButton: { border: "1px solid #ddd6e2", background: "#ffffff", color: "#62596a", borderRadius: 12, padding: "11px 8px", fontWeight: 750, cursor: "pointer" },
priorityActive: { background: "#eee8f5", borderColor: "#c95b93", color: "#c95b93" },
urgentBadge: { background: "#fce5e8", color: "#a13e4b", borderRadius: 10, padding: "7px 9px", fontSize: 11, fontWeight: 800 },
futurePurchaseCard: { border: "1px solid #e7e0e9", borderRadius: 16, padding: 14, background: "#ffffff" },
futureCompleted: { opacity: 0.62, textDecoration: "line-through" },
futureActions: { display: "flex", gap: 8, flexWrap: "wrap", marginTop: 12 },
linkButton: { display: "inline-flex", marginTop: 10, color: "#c95b93", fontWeight: 750, textDecoration: "none" },
dailyActivity: { width: "100%", border: "1px solid #ead9e2", background: "#ffffff", borderRadius: 15, padding: 13, display: "flex", alignItems: "flex-start", gap: 11, textAlign: "left", cursor: "pointer" },
dailyIcon: { width: 38, height: 38, borderRadius: 12, background: "#f1edf4", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, fontSize: 19 },
dailyInfo: { flex: 1, minWidth: 0, display: "flex", flexDirection: "column", gap: 4 },
dailyDetails: { background: "#f7f4f8", borderRadius: 12, padding: 10, marginTop: 7, lineHeight: 1.55, fontSize: 13, color: "#5f5764" },
noteCard: { border: "1px solid #ead9e2", borderRadius: 16, padding: 14, background: "#ffffff" },
eyebrow: {
fontSize: 12,
fontWeight: 800,
letterSpacing: 1.5,
color: "#80639f",
textTransform:
"uppercase",
marginBottom: 6,
},
headerTitle: {
margin: 0,
fontSize: 25,
fontWeight: 800,
},
pageTitle: {
margin: "4px 0 10px",
fontSize: 28,
lineHeight: 1.15,
fontWeight: 850,
},
avatar: {
width: 48,
height: 48,
borderRadius: "50%",
background: "#c95b93",
color: "#ffffff",
display: "flex",
alignItems: "center",
justifyContent: "center",
fontWeight: 800,
fontSize: 20,
},
main: {
width: "100%",
maxWidth: 850,
margin: "0 auto",
padding: "20px 20px 112px",
boxSizing: "border-box",
},
hero: {
background: "#ffffff",
borderRadius: 22,
padding: 24,
marginBottom: 18,
boxShadow:
"0 5px 24px rgba(50,35,60,.06)",
},
heroText: {
fontSize: 16,
lineHeight: 1.55,
color: "#68616c",
marginBottom: 20,
},
statsGrid: {
display: "grid",
gridTemplateColumns:
"repeat(2, minmax(0, 1fr))",
gap: 12,
marginBottom: 18,
},
statCard: {
background: "#ffffff",
border:
"1px solid #e9e5eb",
borderRadius: 18,
padding: 17,
display: "flex",
flexDirection:
"column",
gap: 7,
},
statValue: {
fontSize: 20,
},
card: {
background: "#ffffff",
border:
"1px solid #e9e5eb",
borderRadius: 22,
padding: 20,
marginBottom: 18,
boxShadow:
"0 5px 24px rgba(50,35,60,.05)",
},
cardHeader: {
display: "flex",
justifyContent:
"space-between",
alignItems: "center",
gap: 12,
marginBottom: 18,
},
cardTitle: {
margin: 0,
fontSize: 20,
fontWeight: 800,
},
label: {
display: "block",
fontSize: 14,
fontWeight: 750,
marginBottom: 7,
marginTop: 15,
},
input: {
width: "100%",
boxSizing: "border-box",
border:
"1px solid #dcd6df",
borderRadius: 14,
padding: "13px 14px",
fontSize: 16,
background: "#ffffff",
outline: "none",
},
textarea: {
width: "100%",
minHeight: 110,
boxSizing: "border-box",
border:
"1px solid #dcd6df",
borderRadius: 14,
padding: 14,
fontSize: 16,
resize: "vertical",
fontFamily: "inherit",
outline: "none",
},
primaryButton: {
background: "#c95b93",
color: "#ffffff",
border: "none",
borderRadius: 12,
padding: "10px 15px",
fontWeight: 750,
cursor: "pointer",
display: "inline-flex",
alignItems: "center",
justifyContent:
"center",
fontSize: 14,
},
primaryButtonLarge: {
width: "100%",
background: "#c95b93",
color: "#ffffff",
border: "none",
borderRadius: 14,
padding: "15px 18px",
fontWeight: 800,
cursor: "pointer",
fontSize: 16,
marginTop: 12,
},
secondaryButtonLarge: {
width: "100%",
background: "#f8eaf0",
color: "#554d59",
border: "none",
borderRadius: 14,
padding: "15px 18px",
fontWeight: 750,
cursor: "pointer",
fontSize: 16,
marginTop: 10,
},
ghostButton: {
width: "100%",
background: "transparent",
color: "#c95b93",
border: "none",
padding: 14,
fontWeight: 700,
cursor: "pointer",
marginTop: 8,
},
smallButton: {
background: "#f0edf3",
color: "#584d60",
border: "none",
borderRadius: 10,
padding: "9px 11px",
fontWeight: 700,
cursor: "pointer",
fontSize: 12,
},
deleteButton: {
background: "#fcebed",
color: "#a44351",
border: "none",
borderRadius: 10,
padding: "9px 11px",
fontWeight: 700,
cursor: "pointer",
fontSize: 12,
},
iconButton: {
width: 42,
height: 42,
borderRadius: 12,
border: "none",
background: "#f8eaf0",
fontSize: 22,
cursor: "pointer",
},
finishSmallButton: {
border: "none",
borderRadius: 10,
background: "#f5e8eb",
color: "#974653",
padding: "10px 12px",
fontWeight: 750,
cursor: "pointer",
},
backButton: {
border: "none",
background: "transparent",
color: "#c95b93",
fontWeight: 750,
fontSize: 15,
cursor: "pointer",
padding:
"4px 0 15px",
},
sessionHeader: {
display: "flex",
justifyContent:
"space-between",
alignItems: "center",
gap: 15,
marginBottom: 15,
},
valueBadge: {
background: "#f8e8f1",
color: "#725492",
padding: "9px 12px",
borderRadius: 12,
fontWeight: 800,
whiteSpace:
"nowrap",
},
questionTabs: {
display: "flex",
gap: 8,
overflowX: "auto",
paddingBottom: 10,
marginBottom: 8,
},
questionTab: {
minWidth: 42,
height: 42,
borderRadius: 12,
border:
"1px solid #ded8e1",
background: "#ffffff",
fontWeight: 800,
cursor: "pointer",
},
questionTabActive: {
background: "#c95b93",
color: "#ffffff",
borderColor: "#c95b93",
},
successBadge: {
background: "#e6f4ea",
color: "#26733e",
borderRadius: 10,
padding: "7px 10px",
fontWeight: 750,
fontSize: 12,
},
countBadge: {
background: "#f8e8f1",
color: "#c95b93",
minWidth: 30,
height: 30,
borderRadius: 10,
display: "flex",
alignItems: "center",
justifyContent:
"center",
fontWeight: 800,
},
warningBadge: {
background: "#fff2d8",
color: "#8a6111",
borderRadius: 10,
padding: "7px 9px",
fontSize: 11,
fontWeight: 800,
},
homeBadge: {
background: "#eaf3ff",
color: "#3e6594",
borderRadius: 9,
padding: "5px 8px",
fontSize: 11,
fontWeight: 800,
},
workBadge: {
background: "#eee8f5",
color: "#70528e",
borderRadius: 9,
padding: "5px 8px",
fontSize: 11,
fontWeight: 800,
},
infoBox: {
background: "#f3eff7",
color: "#655a6c",
borderRadius: 14,
padding: 13,
marginTop: 12,
fontSize: 13,
lineHeight: 1.5,
},
emptyBox: {
border:
"1px dashed #d8d1db",
background: "#faf9fb",
borderRadius: 14,
padding: 20,
color: "#77717b",
textAlign: "center",
},
photoThumbCard: { border: "1px solid #e4dde8", background: "#fff", borderRadius: 16, padding: 8, cursor: "pointer", textAlign: "left", overflow: "hidden" },
photoThumb: { width: "100%", aspectRatio: "1 / 1", objectFit: "cover", display: "block", borderRadius: 12, background: "#f2eef4" },
photoThumbFooter: { display: "flex", justifyContent: "space-between", alignItems: "center", gap: 8, padding: "9px 4px 3px", fontSize: 13, color: "#4f4656" },
photoLarge: { width: "100%", maxHeight: "55vh", objectFit: "contain", borderRadius: 16, background: "#f4f0f5" },
photoModalContent: { display: "grid", gap: 12 },
photoModalActions: { display: "flex", flexWrap: "wrap", gap: 8 },
photoModalSectionTitle: { fontWeight: 850, fontSize: 18, marginTop: 6 },
trashCard: { border: "1px solid #ead9e2", borderRadius: 16, padding: 14, background: "#fff", display: "flex", gap: 12, alignItems: "flex-start" },
trashIcon: { width: 42, height: 42, borderRadius: 12, background: "#f1edf4", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, fontSize: 20 },
photoGrid: {
display: "grid",
gridTemplateColumns:
"repeat(2, minmax(0, 1fr))",
gap: 12,
},
photoCard: {
border:
"1px solid #ead9e2",
borderRadius: 15,
overflow: "hidden",
background: "#faf9fb",
},
photoWithAudio: {
display: "grid",
gridTemplateColumns: "minmax(0, 1.2fr) minmax(150px, 0.8fr)",
alignItems: "stretch",
},
photoAudioPanel: {
padding: 10,
display: "flex",
flexDirection: "column",
gap: 8,
minWidth: 0,
},
photoAudioHeader: {
display: "flex",
alignItems: "center",
justifyContent: "space-between",
gap: 6,
fontSize: 13,
color: "#4b4650",
},
photoRecordButton: {
width: "100%",
background: "#c95b93",
color: "#ffffff",
border: "none",
borderRadius: 10,
padding: "10px 8px",
fontWeight: 800,
cursor: "pointer",
fontSize: 13,
},
photoAudioList: {
display: "flex",
flexDirection: "column",
gap: 7,
maxHeight: 220,
overflowY: "auto",
},
relatedChargeTabs: { display:"flex", gap:8, flexWrap:"wrap", margin:"10px 0 14px", alignItems:"center" },
relatedChargeTabWrap: { position:"relative", display:"inline-flex" },
relatedChargeTab: { minWidth:48, height:44, border:"1px solid #e2d9e8", borderRadius:12, background:"#fff", color:"#5d4d68", display:"flex", alignItems:"center", justifyContent:"center", gap:3, fontSize:18, boxShadow:"0 2px 6px rgba(50,30,60,.06)", cursor:"pointer" },
relatedChargeDelete: { position:"absolute", top:-7, right:-7, width:19, height:19, borderRadius:"50%", border:"1px solid #fff", background:"#b42318", color:"#fff", fontWeight:900, fontSize:12, lineHeight:"17px", padding:0, cursor:"pointer", boxShadow:"0 1px 4px rgba(0,0,0,.25)" },
consultationEndBar: { marginTop:18, padding:"14px 0 28px", borderTop:"1px solid #e5dfe8" },
consultationEndButton: { width:"100%", minHeight:68, border:"none", borderRadius:16, background:"#c95b93", color:"#fff", fontSize:17, fontWeight:850, boxShadow:"0 6px 18px rgba(96,70,120,.2)", cursor:"pointer", padding:"14px 18px" },
recordingStatusCard: { marginTop:8, padding:"10px 12px", borderRadius:12, border:"1px solid #eadce9", background:"#fbf7fc", display:"flex", alignItems:"center", gap:10 },
recordingDot: { width:10, height:10, borderRadius:"50%", background:"#b42318", boxShadow:"0 0 0 5px rgba(180,35,24,.10)" },
audioWave: { display:"flex", alignItems:"center", gap:3, height:24, flex:1 },
audioWaveBar: { width:4, height:20, borderRadius:4, background:"#c95b93", transformOrigin:"center", animation:"audioWavePulse .8s ease-in-out infinite" },
photoAudioItem: {
border: "1px solid #ead9e2",
borderRadius: 10,
padding: 7,
background: "#ffffff",
},
photoAudioTitle: {
display: "flex",
justifyContent: "space-between",
gap: 5,
fontSize: 12,
fontWeight: 800,
marginBottom: 6,
},
photoAudioActions: {
display: "flex",
gap: 4,
flexWrap: "wrap",
},
photo: {
width: "100%",
aspectRatio: "1 / 1",
objectFit: "cover",
display: "block",
},
photoActions: {
display: "flex",
gap: 6,
padding: 8,
flexWrap: "wrap",
},
recordArea: {
background: "#faf8fb",
borderRadius: 16,
padding: 16,
marginBottom: 14,
},
recordButton: {
width: "100%",
background: "#c95b93",
color: "#ffffff",
border: "none",
borderRadius: 14,
padding: 15,
fontWeight: 800,
cursor: "pointer",
fontSize: 16,
marginBottom: 10,
},
stopButton: {
width: "100%",
background: "#a84452",
color: "#ffffff",
border: "none",
borderRadius: 14,
padding: 15,
fontWeight: 800,
cursor: "pointer",
fontSize: 16,
marginBottom: 10,
},
audioList: {
display: "flex",
flexDirection:
"column",
gap: 10,
},
audioItem: {
border:
"1px solid #ead9e2",
borderRadius: 14,
padding: 12,
display: "flex",
alignItems: "center",
gap: 10,
flexWrap: "wrap",
},
audioNumber: {
width: 34,
height: 34,
borderRadius: "50%",
background: "#f8e8f1",
color: "#c95b93",
display: "flex",
alignItems: "center",
justifyContent:
"center",
fontWeight: 800,
},
audioInfo: {
display: "flex",
flexDirection:
"column",
flex: 1,
minWidth: 100,
gap: 3,
},
audioActions: {
display: "flex",
gap: 6,
flexWrap: "wrap",
},
finishQuestionButton: {
width: "100%",
background: "#c95b93",
color: "#ffffff",
border: "none",
borderRadius: 15,
padding: 16,
fontSize: 17,
fontWeight: 850,
cursor: "pointer",
marginBottom: 18,
},
bottomNav: {
position: "fixed",
bottom: "calc(env(safe-area-inset-bottom, 0px) + 8px)",
left: 10,
right: 10,
height: 74,
background: "#ffffff",
borderTop:
"1px solid #ead9e2",
display: "flex",
justifyContent:
"space-around",
alignItems: "center",
zIndex: 30,
padding: "7px 10px",
boxShadow: "0 8px 28px rgba(80,35,60,.14)",
borderRadius: 18,
boxSizing: "border-box",
},
bottomNavButton: {
border: "none",
background: "transparent",
color: "#716b74",
fontSize: 20,
cursor: "pointer",
display: "flex",
flexDirection:
"column",
alignItems: "center",
gap: 2,
minWidth: 54,
},
bottomNavActive: {
color: "#c95b93",
},
bottomNavMain: {
width: 52,
height: 52,
borderRadius: "50%",
background: "#c95b93",
color: "#ffffff",
border: "none",
fontSize: 22,
fontWeight: 800,
cursor: "pointer",
display: "flex",
flexDirection:
"column",
alignItems: "center",
justifyContent:
"center",
gap: 0,
},
modalOverlay: {
position: "fixed",
inset: 0,
background:
"rgba(25,20,28,.58)",
zIndex: 100,
display: "flex",
alignItems: "flex-end",
justifyContent:
"center",
overflow: "hidden",
overscrollBehavior: "none",
touchAction: "auto",
paddingTop: "env(safe-area-inset-top, 0px)",
boxSizing: "border-box",
},
modal: {
width: "100%",
maxWidth: 760,
maxHeight: "calc(100dvh - env(safe-area-inset-top, 0px) - 8px)",
minHeight: 0,
overflow: "hidden",
display: "flex",
flexDirection: "column",
WebkitOverflowScrolling: "touch",
overscrollBehavior: "contain",
touchAction: "auto",
background: "#ffffff",
borderRadius:
"25px 25px 0 0",
padding: "18px 20px calc(24px + env(safe-area-inset-bottom, 0px))",
boxSizing: "border-box",
},
modalBodyScroll: {
flex: "1 1 auto",
minHeight: 0,
overflowY: "auto",
overflowX: "hidden",
WebkitOverflowScrolling: "touch",
overscrollBehaviorY: "auto",
touchAction: "pan-y",
paddingBottom: "calc(32px + env(safe-area-inset-bottom, 0px))",
},
appDateTime: {
fontSize: 13,
lineHeight: 1.2,
color: "#756c78",
fontWeight: 650,
display: "flex",
alignItems: "center",
gap: 5,
whiteSpace: "nowrap",
},
appDateTimeCompact: {
fontSize: 11,
fontWeight: 650,
marginTop: 3,
},
modalHeader: {
display: "flex",
flex: "0 0 auto",
alignItems: "center",
justifyContent:
"space-between",
marginBottom: 20,
},
modalTitle: {
margin: 0,
fontSize: 25,
fontWeight: 850,
},
modalClose: {
width: 42,
height: 42,
border: "none",
borderRadius: "50%",
background: "#f8eaf0",
color: "#5d5661",
fontSize: 27,
cursor: "pointer",
},
modalText: {
color: "#625c65",
lineHeight: 1.5,
},
successMessage: {
background: "#e9f6ec",
color: "#26733e",
borderRadius: 14,
padding: 15,
fontWeight: 700,
},
segmented: {
display: "grid",
gridTemplateColumns:
"1fr 1fr",
gap: 8,
},
segmentButton: {
border:
"1px solid #ddd6e0",
background: "#ffffff",
borderRadius: 12,
padding: 13,
fontWeight: 750,
cursor: "pointer",
},
segmentActive: {
background: "#c95b93",
color: "#ffffff",
borderColor: "#c95b93",
},
twoColumns: {
display: "grid",
gridTemplateColumns:
"1fr 1fr",
gap: 10,
},
toast: {
position: "fixed",
bottom: 86,
left: "50%",
transform:
"translateX(-50%)",
background: "#29252d",
color: "#ffffff",
padding:
"12px 17px",
borderRadius: 13,
zIndex: 200,
fontSize: 14,
fontWeight: 650,
boxShadow:
"0 8px 25px rgba(0,0,0,.25)",
maxWidth: "90%",
textAlign: "center",
},
list: {
display: "flex",
flexDirection:
"column",
gap: 10,
},
listItem: {
border:
"1px solid #ead9e2",
borderRadius: 14,
padding: 14,
display: "flex",
alignItems: "center",
justifyContent:
"space-between",
gap: 12,
minWidth: 0,
boxSizing: "border-box",
},
clientCard: {
background: "#ffffff",
border:
"1px solid #ead9e2",
borderRadius: 17,
padding: 14,
display: "flex",
alignItems: "center",
gap: 12,
},
clientAvatar: {
width: 44,
height: 44,
borderRadius: "50%",
background: "#f8e8f1",
color: "#c95b93",
display: "flex",
alignItems: "center",
justifyContent:
"center",
fontWeight: 850,
fontSize: 18,
},
clientInfo: {
display: "flex",
flexDirection:
"column",
gap: 4,
flex: 1,
},
muted: {
color: "#77717b",
fontSize: 13,
},
historyList: {
display: "flex",
flexDirection:
"column",
gap: 12,
},
historyCard: {
background: "#ffffff",
border:
"1px solid #e5dfe8",
borderRadius: 18,
overflow: "hidden",
},
historyHeader: {
width: "100%",
border: "none",
background: "#ffffff",
padding: 17,
display: "flex",
alignItems: "center",
justifyContent:
"space-between",
textAlign: "left",
cursor: "pointer",
},
historyTitle: {
display: "block",
fontSize: 17,
marginBottom: 5,
},
historyContent: {
borderTop:
"1px solid #ece7ee",
padding: 16,
},
historyPayment: {
display: "flex",
justifyContent:
"space-between",
gap: 10,
flexWrap: "wrap",
background: "#f7f4f8",
borderRadius: 12,
padding: 12,
fontSize: 13,
fontWeight: 700,
marginBottom: 15,
},
historyQuestion: {
borderTop:
"1px solid #eee9ef",
paddingTop: 14,
marginTop: 14,
},
noteBox: {
background: "#faf8fb",
borderRadius: 10,
padding: 12,
whiteSpace:
"pre-wrap",
color: "#625c65",
marginBottom: 10,
},
historyPhotoRow: {
display: "flex",
gap: 8,
overflowX: "auto",
marginBottom: 10,
},
historyPhoto: {
width: 85,
height: 85,
objectFit: "cover",
borderRadius: 10,
flexShrink: 0,
},
historyAudio: {
background: "#f8e8f1",
color: "#725492",
borderRadius: 10,
padding: 9,
fontSize: 13,
display: "inline-block",
},
financeSummary: {
display: "grid",
gridTemplateColumns:
"repeat(2, minmax(0, 1fr))",
gap: 10,
},
financeMini: {
background: "#faf8fb",
borderRadius: 14,
padding: 13,
display: "flex",
flexDirection:
"column",
gap: 4,
},
financeBigNumber: {
fontSize: 30,
fontWeight: 850,
color: "#c95b93",
marginBottom: 5,
},
compactFormGrid: { display: "grid", gridTemplateColumns: "repeat(2, minmax(0, 1fr))", gap: 10 },
compactActionGrid: { display: "grid", gridTemplateColumns: "repeat(2, minmax(0, 1fr))", gap: 10, margin: "12px 0" },
consultationQuickActions: { display:"grid", gridTemplateColumns:"repeat(2,minmax(0,1fr))", gap:7, margin:"10px 0 12px" },
compactSecondaryAction: { border:"1px solid #e1d8e6", background:"#fff", color:"#5e4b6a", borderRadius:11, padding:"10px 9px", fontWeight:800, fontSize:13, cursor:"pointer", minHeight:42 },
checkoutSummaryRow: { display:"flex", justifyContent:"space-between", gap:8, alignItems:"center", padding:"3px 0" },
checkoutTotalProfessional: { marginTop:6, paddingTop:10, borderTop:"1px solid #ddd4e3", display:"flex", justifyContent:"space-between", gap:10, alignItems:"flex-end" },
savedAudioBadge: { margin:"8px 8px 0", padding:"9px 10px", borderRadius:12, background:"#f7f3f9", display:"flex", alignItems:"center", gap:8, border:"1px solid #e6dce9" },
savedAudioIcon: { width:30, height:30, borderRadius:"50%", display:"grid", placeItems:"center", background:"#fff", border:"1px solid #e3d8e8" },
audioMiniWave: { display:"flex", alignItems:"center", gap:2, height:18, marginTop:2 },
statusPill: { display:"inline-flex", alignItems:"center", borderRadius:999, padding:"5px 9px", fontSize:12, fontWeight:850 },
statusPillDanger: { background:"#fff0f0", color:"#a51f1f" },
statusPillSuccess: { background:"#edf9f0", color:"#27753a" },
statusPillPending: { background:"#f4eff8", color:"#6c5180" },
compactActionCard: { border: "1px solid #e5dfe8", background: "#faf8fb", borderRadius: 15, padding: 13, display: "flex", flexDirection: "column", alignItems: "flex-start", gap: 4, cursor: "pointer", textAlign: "left", fontSize: 14, fontWeight: 650 },
compactActionIcon: { fontSize: 24 },
smallOutlineButton: { marginTop: 8, border: "1px solid #ddd5e4", background: "#ffffff", color: "#70558d", borderRadius: 10, padding: "8px 10px", fontWeight: 700, cursor: "pointer" },
paymentBox: { background: "#faf8fb", border: "1px solid #e6dfe9", borderRadius: 15, padding: 13, marginTop: 10 },
installmentList: { display: "grid", gap: 8, marginTop: 12 },
installmentEditor: { display: "grid", gridTemplateColumns: "45px 1fr 1fr", gap: 8, alignItems: "center", background: "#ffffff", border: "1px solid #ead9e2", borderRadius: 12, padding: 8 },
dashboardActions: { display: "grid", gap: 0, marginBottom: 18 },
dashboardQuickRow: { display: "grid", gridTemplateColumns: "repeat(2, minmax(0, 1fr))", gap: 10 },
settingsTabs: { display: "flex", gap: 8, overflowX: "auto", marginBottom: 14, paddingBottom: 2 },
settingsTab: { border: "1px solid #e3dce7", background: "#fff", borderRadius: 999, padding: "10px 14px", fontWeight: 750, cursor: "pointer", whiteSpace: "nowrap" },
settingsTabActive: { background: "#c95b93", color: "#fff", borderColor: "#c95b93" },
actionGrid: {
display: "grid",
gridTemplateColumns:
"repeat(2, minmax(0, 1fr))",
gap: 10,
marginBottom: 18,
},
actionCard: {
border:
"1px solid #ead9e2",
background: "#ffffff",
borderRadius: 18,
padding: 16,
display: "flex",
flexDirection:
"column",
alignItems: "flex-start",
gap: 5,
cursor: "pointer",
textAlign: "left",
fontSize: 22,
},
purchaseCard: {
background: "#ffffff",
border:
"1px solid #ead9e2",
borderRadius: 18,
padding: 16,
},
itemList: {
display: "flex",
flexDirection:
"column",
gap: 8,
},
purchaseItem: {
border:
"1px solid #eee8f0",
borderRadius: 12,
padding: 11,
display: "flex",
alignItems: "center",
justifyContent:
"space-between",
gap: 10,
},
purchaseItemRight: {
display: "flex",
flexDirection:
"column",
alignItems: "flex-end",
gap: 5,
},
purchaseEditor: {
border:
"1px solid #e4dce7",
borderRadius: 16,
padding: 14,
background: "#faf9fb",
},
purchaseEditorFooter: {
display: "flex",
justifyContent:
"space-between",
alignItems: "center",
gap: 10,
marginTop: 12,
},
totalBox: {
marginTop: 16,
background: "#f8e8f1",
color: "#725492",
borderRadius: 15,
padding: 16,
display: "flex",
justifyContent:
"space-between",
alignItems: "center",
fontSize: 17,
},
checkRow: {
display: "flex",
gap: 8,
alignItems: "center",
marginTop: 14,
fontSize: 14,
color: "#625c65",
},
stockCard: {
background: "#ffffff",
border:
"1px solid #ead9e2",
borderRadius: 17,
padding: 14,
display: "flex",
alignItems: "center",
gap: 12,
},
stockIcon: {
width: 45,
height: 45,
borderRadius: 14,
background: "#f8e8f1",
display: "flex",
alignItems: "center",
justifyContent:
"center",
fontSize: 22,
},
stockInfo: {
display: "flex",
flexDirection:
"column",
gap: 4,
flex: 1,
},
stockActions: {
display: "flex",
flexDirection:
"column",
alignItems: "flex-end",
gap: 6,
},
rightStack: {
display: "flex",
flexDirection:
"column",
alignItems: "flex-end",
gap: 7,
},
serviceTabs:{display:"grid",gridTemplateColumns:"repeat(4,minmax(0,1fr))",gap:8,marginBottom:12},serviceTab:{border:"1px solid #ead9e2",background:"#fff",borderRadius:14,padding:"11px 8px",fontWeight:800,color:"#6d5967",cursor:"pointer",minWidth:0},serviceTabActive:{background:"#c95b93",color:"#fff",borderColor:"#c95b93"},serviceCard:{border:"1px solid #ead9e2",borderRadius:16,padding:14,display:"flex",alignItems:"center",justifyContent:"space-between",gap:12,minWidth:0,background:"#fff"},serviceActions:{display:"flex",gap:7,flexWrap:"wrap",justifyContent:"flex-end"},statusRow:{display:"flex",gap:8,alignItems:"center",flexWrap:"wrap",marginTop:7},cardTitleSmall:{fontWeight:800,fontSize:15,marginTop:4},searchToolbar:{display:"grid",gridTemplateColumns:"1fr",gap:8,marginBottom:12},warningBox: { marginTop: 16, padding: 14, borderRadius: 14, background: "#fff4e5", border:
"1px solid #f0c36d" },
emptyState: { padding: 20, textAlign: "center" as const, color: "#777" },  reportMetricGrid:{display:"grid",gridTemplateColumns:"repeat(2,minmax(0,1fr))",gap:10,marginTop:12},
  reportMetric:{background:"#f7f7f8",borderRadius:16,padding:14,display:"flex",flexDirection:"column" as const,gap:4},
  reportStatusGrid:{display:"grid",gridTemplateColumns:"repeat(3,minmax(0,1fr))",gap:10},
  reportStatusBox:{borderRadius:16,padding:16,display:"flex",flexDirection:"column" as const,alignItems:"center",gap:4},
  reportProgress:{display:"grid",gap:9,marginTop:12},
  donutLayout:{display:"flex",alignItems:"center",gap:18,flexWrap:"wrap" as const},
  chartLegend:{display:"flex",gap:18,justifyContent:"center",color:"#777",fontSize:13,paddingTop:4},
  rankList:{display:"grid",gap:2},
  rankItem:{display:"flex",alignItems:"center",gap:10,padding:"11px 0",borderBottom:"1px solid #eee"},
  rankNumber:{width:28,height:28,borderRadius:14,background:"#eef1f2",display:"flex",alignItems:"center",justifyContent:"center",fontWeight:700,color:"#666",flexShrink:0},

};
export default App;
