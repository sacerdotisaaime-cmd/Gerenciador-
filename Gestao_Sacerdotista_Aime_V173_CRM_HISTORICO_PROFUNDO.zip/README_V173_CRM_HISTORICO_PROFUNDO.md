# V173 — CRM / Histórico de Consulente — Auditoria Profunda

Correção sobre a V172.

## Objetivo
Restaurar o CRM para que o Histórico do Consulente reúna os registros pelo consulente, independentemente do status operacional.

## Regras
- Atendimento/tiragem concluído continua no histórico.
- Atendimento agendado continua no histórico.
- Atendimento em Standby continua identificável no histórico, mas Standby é o único estado de pausa operacional.
- Trabalhos aguardando execução, agendados, em execução, concluídos, prorrogados ou cancelados permanecem vinculados ao consulente quando pertencem a uma Consultation.
- Vendas vinculadas ou diretas permanecem vinculadas ao consulente.
- Vendas criadas diretamente no Financeiro (`QuickTransaction` com `type: sale`) também entram no CRM, mesmo sem Consultation correspondente.
- Execuções de trabalho órfãs, quando a Consultation não estiver mais disponível, entram por nome normalizado do consulente.
- A pesquisa do Histórico procura também status, tipo de serviço, trabalhos, vendas e registros vinculados.
- O relacionamento usa `clientId` como chave principal e nome normalizado como fallback para dados legados/migrados.
- `deletedAt` continua sendo a única exclusão lógica do histórico.

## Relação com V172
A V172 separou corretamente edição de checkout/Standby. A V173 não altera esse fluxo. Ela apenas reforça o índice e a apresentação do CRM/Histórico.
