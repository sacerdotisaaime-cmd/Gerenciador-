# V158 — Correção da seleção de consulente na pesquisa

Correção aplicada na tela **Novo atendimento**.

Quando o campo de pesquisa filtrava os consulentes, o `<select>` podia ficar
sem a opção correspondente ao `selectedClientId` antigo. No Android, tocar no
primeiro resultado visível podia não disparar `onChange`, fazendo o atendimento
ser criado para o consulente anterior.

A pesquisa agora mostra resultados como botões de seleção explícitos. Ao tocar
no resultado:
- atualiza `selectedClientId`;
- atualiza os dados dependentes do consulente;
- limpa a pesquisa;
- volta a mostrar o seletor normal já com o consulente escolhido.

O restante da lógica de criação do atendimento permanece usando
`selectedClientId`, agora sincronizado com a seleção feita pela pesquisa.
