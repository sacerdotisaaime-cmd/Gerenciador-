# Gestão Sacerdotista Aimê — V184 — Histórico visual restaurado

Base: V183.

Objetivo desta versão:
- restaurar a apresentação visual do histórico no modelo antigo da V158;
- usar o componente HistoryItem/HistoryItemBoundary com a ficha expandível completa;
- manter a recuperação de dados já corrigida nas versões anteriores;
- manter perguntas, respostas/notas, pagamentos/parcelas, trabalhos, vendas, execução, objetos, termos, fotos e áudios dentro do histórico quando existirem nos dados;
- manter a ficha completa da consulente no topo;
- manter pesquisa do histórico;
- remover da tela o painel/janela de diagnóstico/debug.

O diagnóstico interno não é mais exibido na interface.

Não foi feito reset de dados.
