import { Capacitor, CapacitorHttp } from '@capacitor/core';

const STORAGE_KEY = 'luna_api_base_url';
const DEFAULT_BASE_URL = import.meta.env.VITE_LUNA_API_BASE_URL || 'http://192.168.1.100/gestao-aime-comercial/sistema_teste/public/api/v1';

export type LunaApiResult<T> = { data: T };
export type LunaLoginResult = {
  access_token: string;
  token_type: 'Bearer' | string;
  expires_in: number;
  user: { id: string; name: string; email: string };
  organization: { id: string; name: string; role: string };
};
export type LunaClientRecord = { id: string; data: Record<string, unknown>; version: number; updated_at?: string };

export function getLunaApiBaseUrl(): string {
  const saved = localStorage.getItem(STORAGE_KEY);
  return (saved || DEFAULT_BASE_URL).replace(/\/+$/, '');
}

export function setLunaApiBaseUrl(value: string): string {
  const normalized = value.trim().replace(/\/+$/, '');
  if (!/^https?:\/\//i.test(normalized)) throw new Error('Informe um endereço começando com http:// ou https://.');
  localStorage.setItem(STORAGE_KEY, normalized);
  return normalized;
}

async function request<T>(path: string, options: { method?: 'GET' | 'POST' | 'PUT' | 'DELETE'; token?: string; body?: unknown; idempotencyKey?: string } = {}): Promise<T> {
  const url = `${getLunaApiBaseUrl()}/${path.replace(/^\/+/, '')}`;
  const headers: Record<string, string> = { Accept: 'application/json', 'Content-Type': 'application/json' };
  if (options.token) headers.Authorization = `Bearer ${options.token}`;
  if (options.idempotencyKey) headers['Idempotency-Key'] = options.idempotencyKey;
  const method = options.method || 'GET';
  let status: number;
  let payload: any;
  if (Capacitor.isNativePlatform()) {
    const response = await CapacitorHttp.request({
      url, method, headers, data: options.body,
      connectTimeout: 15000, readTimeout: 20000,
    });
    status = response.status;
    payload = response.data;
  } else {
    const response = await fetch(url, {
      method, headers,
      body: options.body === undefined ? undefined : JSON.stringify(options.body),
      cache: 'no-store',
    });
    status = response.status;
    payload = await response.json().catch(() => ({}));
  }
  if (typeof payload === 'string') {
    try { payload = JSON.parse(payload); } catch { /* handled below */ }
  }
  if (status < 200 || status >= 300) {
    const message = payload?.error?.message || `A API Luna respondeu HTTP ${status}.`;
    throw new Error(message);
  }
  if (!payload || typeof payload !== 'object' || !('data' in payload)) throw new Error('Resposta inesperada da API Luna.');
  return payload.data as T;
}

export const lunaApi = {
  health: () => request<{ service: string; version: string; status: string; database: string; scope: string }>('health'),
  login: (email: string, password: string, deviceName = 'Luna Android') => request<LunaLoginResult>('auth/login', {
    method: 'POST', body: { email, password, device_name: deviceName },
  }),
  me: (token: string) => request<{ user: LunaLoginResult['user']; organization: LunaLoginResult['organization'] }>('auth/me', { token }),
  logout: (token: string) => request<{ logged_out: boolean }>('auth/logout', { method: 'POST', token }),
  listClients: (token: string, limit = 100, after = 0) => request<{ items: LunaClientRecord[]; next_cursor: number; has_more: boolean }>(`clients?limit=${limit}&after=${after}`, { token }),
  createClient: (token: string, data: Record<string, unknown>, idempotencyKey?: string) => request<{ id: string; version: number; data: Record<string, unknown> }>('clients', { method: 'POST', token, body: { data }, idempotencyKey }),
  updateClient: (token: string, id: string, data: Record<string, unknown>, baseVersion: number) => request<{ id: string; version: number; data: Record<string, unknown> }>(`clients/${encodeURIComponent(id)}`, { method: 'PUT', token, body: { data, base_version: baseVersion } }),
  deleteClient: (token: string, id: string, baseVersion: number) => request<{ id: string; version: number; deleted: boolean }>(`clients/${encodeURIComponent(id)}`, { method: 'DELETE', token, body: { base_version: baseVersion } }),
};
