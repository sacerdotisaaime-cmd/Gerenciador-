# Luna Android — conector para a API Web (etapa de conectividade)

Esta entrega adiciona ao projeto V185 um cliente HTTP para a Luna API V1 e um painel de diagnóstico na tela de login. O painel testa, usando as credenciais informadas na própria tela:

1. `GET /health` (API e MySQL online);
2. `POST /auth/login` (autenticação comercial);
3. `GET /auth/me` (identidade e organização);
4. `POST /auth/logout` (revoga o token temporário de teste).

O token usado no teste não é salvo no aparelho: ele é revogado ao final.

## Configurar endereço da API

Na tela de login, informe o endereço-base da API. Em desenvolvimento local, use o IPv4 LAN do computador que executa o XAMPP, por exemplo:

`http://192.168.1.100/gestao-aime-comercial/sistema_teste/public/api/v1`

Troque `192.168.1.100` pelo IPv4 real do computador (Windows: `ipconfig`). Celular e computador precisam estar na mesma rede Wi-Fi. O Apache precisa aceitar conexões pela rede local e o Firewall do Windows deve permitir a porta usada pelo Apache.

No navegador do computador, o health test pode ser feito em:

`http://127.0.0.1/gestao-aime-comercial/sistema_teste/public/api/v1/index.php/health`

No celular, não use `127.0.0.1`: esse endereço apontaria para o próprio celular.

## Instalação da API no Web

A API V1 precisa estar instalada no projeto Web em:

`sistema_teste/public/api/v1/`

A versão corrigida do `index.php` foi fornecida separadamente no pacote `Luna_API_V1_Correcao_Rota_Health.zip`. O backend precisa estar acessível pela rede e o health precisa responder com `status: online` e `database: connected`.

## Limite desta etapa

Esta entrega habilita e testa a comunicação HTTP/autenticação com a API Web, e inclui métodos tipados para consultar/criar/editar/excluir consulentes. Ela **não substitui ainda o login principal Supabase do V185**, não migra o estado principal do aplicativo e não ativa sincronização bidirecional automática. Isso é intencional para não deixar os módulos existentes sem backend enquanto a migração ainda está incompleta.

A próxima etapa de integração deverá ligar a sessão Luna ao estado principal do aplicativo e migrar a persistência/sync de consulentes com fila offline, controle de versão e reconciliação. Até essa etapa ser concluída, continue usando o fluxo de login existente para trabalhar no aplicativo.

## Segurança e produção

- HTTP em IP local é apenas para desenvolvimento em rede privada.
- Para VPS/produção, use HTTPS com certificado válido.
- Não exponha MySQL diretamente à rede; somente Apache/API deve ser acessível.
- Não publique o app com endpoint local `192.168.x.x` fixo.
- O teste cria um token de curta duração conforme a API e tenta revogá-lo ao final. Se a conexão cair antes do logout, o token expira conforme `expires_at`.
- O backend atual exige usuário ativo, organização ativa e assinatura `trialing` ainda válida ou `active` com `current_period_end` válido.

## Android: permitir HTTP somente no ambiente local de desenvolvimento

Depois de gerar a pasta nativa com `npx cap add android`, abra `android/app/src/main/AndroidManifest.xml` e, no elemento `<application>`, acrescente temporariamente:

`android:usesCleartextTraffic="true"`

Isso permite testar o endereço `http://192.168...` em rede local. Antes de gerar a versão de produção, remova essa permissão e configure o servidor HTTPS. O cliente usa `CapacitorHttp` no Android nativo para evitar limitações de CORS do WebView; a opção já está habilitada no `capacitor.config.ts` existente.
